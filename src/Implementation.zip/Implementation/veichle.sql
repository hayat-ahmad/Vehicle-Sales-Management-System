
-- Select the VSMS database before creating the vehicle table.
USE vsms;

-- Create the vehicles table if it does not already exist.
CREATE TABLE IF NOT EXISTS vehicles (

    -- Create a unique automatically increasing ID for each vehicle.
    vehicle_id INT UNSIGNED NOT NULL AUTO_INCREMENT,

    -- Store the vehicle identification number and prevent duplicates.
    vin VARCHAR(50) NOT NULL,

    -- Store the vehicle manufacturer, such as Toyota or Honda.
    make VARCHAR(100) NOT NULL,

    -- Store the vehicle model, such as Corolla or Civic.
    model VARCHAR(100) NOT NULL,

    -- Store the vehicle manufacturing or model year.
    year SMALLINT UNSIGNED NOT NULL,

    -- Store the vehicle category, such as Sedan, SUV, or Truck.
    category VARCHAR(50) NOT NULL,

    -- Store the vehicle selling price with two decimal places.
    price DECIMAL(12, 2) NOT NULL,

    -- Store the vehicle mileage as a non-negative whole number.
    mileage INT UNSIGNED NOT NULL,

    -- Store the vehicle fuel type, such as Petrol, Diesel, or Electric.
    fuel_type VARCHAR(50) NOT NULL,

    -- Store the transmission type, such as Manual or Automatic.
    transmission VARCHAR(50) NOT NULL,

    -- Store the vehicle exterior color.
    color VARCHAR(50) NOT NULL,

    -- Store the current vehicle inventory status.
    STATUS ENUM(
        'Available',
        'Reserved',
        'Sold',
        'Under Maintenance',
        'Unavailable'
    ) NOT NULL DEFAULT 'Available',

    -- Store an optional description of the vehicle.
    description TEXT NULL,

    -- Store the relative path of an optional vehicle photograph.
    image_path VARCHAR(255) NULL,

    -- Indicate whether the vehicle record is active in the system.
    is_active BOOLEAN NOT NULL DEFAULT TRUE,

    -- Automatically store the date and time when the vehicle is created.
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Automatically update the date and time when the record changes.
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    -- Set vehicle_id as the primary key of the table.
    PRIMARY KEY (vehicle_id),

    -- Ensure that no two vehicle records have the same VIN.
    UNIQUE KEY uq_vehicles_vin (vin),

    -- Improve searches that use vehicle make and model together.
    INDEX idx_vehicles_make_model (make, model),

    -- Improve searches that filter vehicles by status.
    INDEX idx_vehicles_status (status),

    -- Improve searches that filter vehicles by manufacturing year.
    INDEX idx_vehicles_year (year)

-- Use InnoDB to support transactions and reliable database operations.
) ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_0900_ai_ci;
