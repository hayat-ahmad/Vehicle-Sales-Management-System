-- Create the employee table only if it does not already exist.
CREATE TABLE IF NOT EXISTS employees (

    -- Give every employee a unique database ID.
    employee_id INT UNSIGNED NOT NULL AUTO_INCREMENT,

    -- Optionally connect an employee to an existing VSMS login account.
    -- INT is signed to match users.user_id.
    user_id INT NULL,

    -- Store the employee's full name.
    full_name VARCHAR(150) NOT NULL,

    -- Store the employee's contact phone number.
    phone VARCHAR(30) NOT NULL,

    -- Store the employee's email address when available.
    email VARCHAR(150) NULL,

    -- Store the employee's job position.
    position VARCHAR(100) NOT NULL,

    -- Track whether the employee is active or inactive.
    status ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',

    -- Record when the employee was registered.
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Automatically update this timestamp when the record changes.
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    -- Set employee_id as the primary key.
    PRIMARY KEY (employee_id),

    -- Prevent one login account from being linked to multiple employees.
    UNIQUE KEY uq_employees_user_id (user_id),

    -- Add indexes to make employee searches faster.
    INDEX idx_employees_name (full_name),
    INDEX idx_employees_phone (phone),
    INDEX idx_employees_position (position),

    -- Link the employee to an existing user account when applicable.
    CONSTRAINT fk_employees_user
        FOREIGN KEY (user_id)
        REFERENCES users(user_id)
        ON UPDATE CASCADE
        ON DELETE SET NULL

-- Use InnoDB to support foreign keys and transactions.
) ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_0900_ai_ci;