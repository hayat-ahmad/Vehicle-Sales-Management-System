
-- Select the existing VSMS database.
USE vsms;

-- Create the reservations table if it does not already exist.
CREATE TABLE IF NOT EXISTS reservations (

    -- Unique ID for each reservation.
    reservation_id INT UNSIGNED NOT NULL AUTO_INCREMENT,

    -- Customer associated with this reservation.
    customer_id INT UNSIGNED NOT NULL,

    -- Vehicle being reserved.
    vehicle_id INT UNSIGNED NOT NULL,

    -- User account of the salesperson responsible for the reservation.
    salesperson_id INT NOT NULL,

    -- Date and time when the reservation is created.
    reservation_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Optional expiration date for the reservation.
    expiration_date DATETIME NULL,

    -- Current reservation status.
    reservation_status ENUM(
        'Active',
        'Cancelled',
        'Completed'
    ) NOT NULL DEFAULT 'Active',

    -- Record creation timestamp.
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Automatically update this timestamp when the record changes.
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    -- Set the primary key.
    PRIMARY KEY (reservation_id),

    -- Index customer searches.
    INDEX idx_reservations_customer (customer_id),

    -- Index vehicle and reservation status searches.
    INDEX idx_reservations_vehicle_status (
        vehicle_id,
        reservation_status
    ),

    -- Index salesperson searches.
    INDEX idx_reservations_salesperson (salesperson_id),

    -- Index reservation dates.
    INDEX idx_reservations_date (reservation_date),

    -- Connect each reservation to an existing customer.
    CONSTRAINT fk_reservations_customer
        FOREIGN KEY (customer_id)
        REFERENCES customers(customer_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    -- Connect each reservation to an existing vehicle.
    CONSTRAINT fk_reservations_vehicle
        FOREIGN KEY (vehicle_id)
        REFERENCES vehicles(vehicle_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    -- Connect each reservation to an existing system user.
    CONSTRAINT fk_reservations_salesperson
        FOREIGN KEY (salesperson_id)
        REFERENCES users(user_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT

) ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_0900_ai_ci;
