
-- Select the VSMS database.
USE vsms;

-- Create the table that stores payments made against sales.
CREATE TABLE IF NOT EXISTS payments (

    -- Unique ID for each payment.
    payment_id INT UNSIGNED NOT NULL AUTO_INCREMENT,

    -- Sale associated with this payment.
    sale_id INT UNSIGNED NOT NULL,

    -- Amount received in this payment.
    payment_amount DECIMAL(12, 2) NOT NULL,

    -- Method used to make the payment.
    payment_method VARCHAR(50) NOT NULL,

    -- Optional bank or transaction reference.
    transaction_reference VARCHAR(100) NULL,

    -- Date and time when the payment was recorded.
    payment_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Current payment status.
    payment_status ENUM(
        'Pending',
        'Completed',
        'Failed',
        'Refunded'
    ) NOT NULL DEFAULT 'Completed',

    -- Optional additional information.
    notes TEXT NULL,

    -- User who recorded the payment.
    created_by INT NOT NULL,

    -- Record creation timestamp.
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Record update timestamp.
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    -- Define the primary key.
    PRIMARY KEY (payment_id),

    -- Indexes improve payment searches and reporting.
    INDEX idx_payments_sale (sale_id),
    INDEX idx_payments_status (payment_status),
    INDEX idx_payments_date (payment_date),
    INDEX idx_payments_created_by (created_by),

    -- Connect each payment to an existing sale.
    CONSTRAINT fk_payments_sale
        FOREIGN KEY (sale_id)
        REFERENCES sales(sale_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    -- Connect each payment to the user who recorded it.
    CONSTRAINT fk_payments_user
        FOREIGN KEY (created_by)
        REFERENCES users(user_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    -- Payment amounts must be greater than zero.
    CONSTRAINT chk_payment_amount
        CHECK (payment_amount > 0)

) ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_0900_ai_ci;
