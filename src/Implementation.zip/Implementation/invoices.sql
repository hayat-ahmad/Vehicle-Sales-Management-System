
-- Select the existing VSMS database.
USE vsms;

-- Create the invoices table if it does not already exist.
CREATE TABLE IF NOT EXISTS invoices (

    -- Unique ID for each invoice.
    invoice_id INT UNSIGNED NOT NULL AUTO_INCREMENT,

    -- Link the invoice to its corresponding sale.
    sale_id INT UNSIGNED NOT NULL,

    -- Store the unique invoice number displayed on the document.
    invoice_number VARCHAR(50) NOT NULL,

    -- Store the date and time when the invoice is issued.
    issue_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Store the sale total shown on the issued invoice.
    total DECIMAL(12, 2) NOT NULL,

    -- Store the payment summary recorded when the invoice is issued.
    payment_summary TEXT NULL,

    -- Store when the invoice record was created.
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Store when the invoice record was last updated.
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    -- Define the primary key.
    PRIMARY KEY (invoice_id),

    -- Prevent more than one invoice for the same sale.
    UNIQUE KEY uq_invoices_sale (sale_id),

    -- Prevent duplicate invoice numbers.
    UNIQUE KEY uq_invoices_number (invoice_number),

    -- Add an index for invoice issue-date searches.
    INDEX idx_invoices_issue_date (issue_date),

    -- Link each invoice to an existing sale.
    CONSTRAINT fk_invoices_sale
        FOREIGN KEY (sale_id)
        REFERENCES sales(sale_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    -- Ensure the invoice total cannot be negative.
    CONSTRAINT chk_invoice_total
        CHECK (total >= 0)

) ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_0900_ai_ci;
