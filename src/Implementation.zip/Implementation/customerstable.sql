
-- Select the existing Vehicle Sales Management System database.
USE vsms;

-- Create the customers table if it does not already exist.
CREATE TABLE IF NOT EXISTS customers (

    -- Generate a unique ID for every customer automatically.
    customer_id INT UNSIGNED NOT NULL AUTO_INCREMENT,

    -- Store the customer's full name.
    full_name VARCHAR(150) NOT NULL,

    -- Store the customer's primary contact phone number.
    phone VARCHAR(30) NOT NULL,

    -- Store the customer's email address when provided.
    email VARCHAR(150) NULL,

    -- Store the customer's residential or contact address when provided.
    address TEXT NULL,

    -- Record the date and time when the customer is registered.
    registration_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Record the date and time when the customer record is last updated.
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    -- Set customer_id as the table's primary key.
    PRIMARY KEY (customer_id),

    -- Add an index to make customer-name searches faster.
    INDEX idx_customers_full_name (full_name),

    -- Add an index to make phone-number searches faster.
    INDEX idx_customers_phone (phone),

    -- Add an index to make email searches faster.
    INDEX idx_customers_email (email)

-- Use InnoDB to support reliable database operations and relationships.
) ENGINE=InnoDB

-- Support international customer names and text.
DEFAULT CHARSET=utf8mb4

-- Use the MySQL 8 default Unicode collation.
COLLATE=utf8mb4_0900_ai_ci;
