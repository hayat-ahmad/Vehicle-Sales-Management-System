-- Create the database if it does not already exist.
CREATE DATABASE IF NOT EXISTS vsms;

-- Select the VSMS database for the following commands.
USE vsms;

-- Create a table to store the available system roles.
CREATE TABLE IF NOT EXISTS roles (
    -- Create a unique ID for every role.
    role_id INT AUTO_INCREMENT PRIMARY KEY,

    -- Store the role name, such as Administrator.
    role_name VARCHAR(50) NOT NULL UNIQUE,

    -- Store a short explanation of the role.
    description VARCHAR(255) NULL,

    -- Record when this role was created.
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert the three roles required by the project.
INSERT IGNORE INTO roles (role_name, description)
VALUES
    ('Administrator', 'Full system administration access'),
    ('Manager', 'Management and operational access'),
    ('Salesperson', 'Sales-related access');

-- Create a table to store registered system users.
CREATE TABLE IF NOT EXISTS users (
    -- Create a unique ID for every user.
    user_id INT AUTO_INCREMENT PRIMARY KEY,

    -- Store the user's full name.
    full_name VARCHAR(100) NOT NULL,

    -- Store the username used for login.
    username VARCHAR(50) NOT NULL UNIQUE,

    -- Store the user's email address.
    email VARCHAR(150) NOT NULL UNIQUE,

    -- Store the hashed password, never the plain-text password.
    password_hash VARCHAR(255) NOT NULL,

    -- Connect each user to their assigned role.
    role_id INT NOT NULL,

    -- Store whether the account is active or inactive.
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',

    -- Record when the user account was created.
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    -- Automatically update this field when the user record changes.
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    -- Connect the role_id field to the roles table.
    CONSTRAINT fk_users_roles
        FOREIGN KEY (role_id)
        REFERENCES roles(role_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);