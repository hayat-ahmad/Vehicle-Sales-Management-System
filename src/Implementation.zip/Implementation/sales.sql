USE vsms;

-- Create the main sales transaction table.
CREATE TABLE IF NOT EXISTS sales (

    -- Unique ID for each sale.
    sale_id INT UNSIGNED NOT NULL AUTO_INCREMENT,

    -- Customer who is purchasing the vehicle.
    customer_id INT UNSIGNED NOT NULL,

    -- Vehicle included in this sale.
    vehicle_id INT UNSIGNED NOT NULL,

    -- User account of the responsible salesperson.
    salesperson_id INT NOT NULL,

    -- Optional reservation associated with this sale.
    reservation_id INT UNSIGNED NULL,

    -- Date and time when the sale is registered.
    sale_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Original vehicle price recorded at the time of sale.
    vehicle_price DECIMAL(12, 2) NOT NULL,

    -- Discount applied to the vehicle.
    discount_amount DECIMAL(12, 2) NOT NULL DEFAULT 0.00,

    -- Additional charges associated with the sale.
    additional_charges DECIMAL(12, 2) NOT NULL DEFAULT 0.00,

    -- Final amount payable by the customer.
    final_amount DECIMAL(12, 2) NOT NULL,

    -- Current transaction status.
    sale_status ENUM(
        'Pending',
        'Completed',
        'Cancelled'
    ) NOT NULL DEFAULT 'Pending',

    -- Record creation timestamp.
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Record update timestamp.
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    -- Define the primary key.
    PRIMARY KEY (sale_id),

    -- Prevent one reservation from being linked to multiple sales.
    UNIQUE KEY uq_sales_reservation (reservation_id),

    -- Add indexes for faster searches.
    INDEX idx_sales_customer (customer_id),
    INDEX idx_sales_vehicle (vehicle_id),
    INDEX idx_sales_salesperson (salesperson_id),
    INDEX idx_sales_date (sale_date),
    INDEX idx_sales_status (sale_status),

    -- Link the sale to an existing customer.
    CONSTRAINT fk_sales_customer
        FOREIGN KEY (customer_id)
        REFERENCES customers(customer_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    -- Link the sale to an existing vehicle.
    CONSTRAINT fk_sales_vehicle
        FOREIGN KEY (vehicle_id)
        REFERENCES vehicles(vehicle_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    -- Link the sale to an existing salesperson account.
    CONSTRAINT fk_sales_salesperson
        FOREIGN KEY (salesperson_id)
        REFERENCES users(user_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    -- Link the sale to a reservation when applicable.
    CONSTRAINT fk_sales_reservation
        FOREIGN KEY (reservation_id)
        REFERENCES reservations(reservation_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    -- Ensure monetary amounts cannot be negative.
    CONSTRAINT chk_sales_amounts CHECK (
        vehicle_price >= 0
        AND discount_amount >= 0
        AND additional_charges >= 0
        AND final_amount >= 0
    ),

    -- Ensure the discount does not exceed the vehicle price.
    CONSTRAINT chk_sales_discount CHECK (
        discount_amount <= vehicle_price
    )

) ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_0900_ai_ci;