
<?php

// Define the location of the private environment file.
$env_file = __DIR__ . "/../.env";

// Check whether the private environment file exists.
if (!file_exists($env_file)) {
    exit("Database configuration file is missing.");
}

// Read the environment file.
$env = parse_ini_file($env_file);

// Check whether the environment file was read successfully.
if ($env === false) {
    exit("Unable to read database configuration.");
}

// List the required database settings.
$required_settings = [
    "DB_HOST",
    "DB_PORT",
    "DB_NAME",
    "DB_USER",
    "DB_PASSWORD"
];

// Check that every required setting exists.
foreach ($required_settings as $setting) {

    if (!array_key_exists($setting, $env) || $env[$setting] === "") {
        exit("Missing database setting: " . $setting);
    }
}

// Read the database configuration.
$host = $env["DB_HOST"];
$port = $env["DB_PORT"];
$dbname = $env["DB_NAME"];
$username = $env["DB_USER"];
$password = $env["DB_PASSWORD"];

// Build the MySQL connection string.
$dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4";

// Configure PDO options.
$options = [

    // Throw exceptions when database errors occur.
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,

    // Return database results as associative arrays.
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,

    // Use native prepared statements.
    PDO::ATTR_EMULATE_PREPARES => false
];

// Establish the database connection.
$pdo = new PDO($dsn, $username, $password, $options);
