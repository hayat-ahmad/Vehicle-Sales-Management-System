<?php

// Load the database connection from the config folder.
require_once __DIR__ . "/../config/database.php";

// Allow this setup script to run only from the command line.
if (PHP_SAPI !== "cli") {

    // Stop the script if someone tries to open it in a browser.
    exit("This script can only run from the command line.");
}

// Ask the administrator for their full name.
$full_name = trim(readline("Enter administrator full name: "));

// Ask for the administrator's username.
$username = trim(readline("Enter administrator username: "));

// Ask for the administrator's email address.
$email = trim(readline("Enter administrator email: "));

// Ask for the administrator's password.
$password = readline("Enter administrator password: ");

// Check whether any required field is empty.
if ($full_name === "" || $username === "" || $email === "" || $password === "") {

    // Display an error message if any field is missing.
    exit("Error: All fields are required.\n");
}

// Check whether the email address has a valid format.
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

    // Stop the script if the email address is invalid.
    exit("Error: Please enter a valid email address.\n");
}

// Require a password containing at least 12 characters.
if (strlen($password) < 12) {

    // Stop the script if the password is too short.
    exit("Error: Password must contain at least 12 characters.\n");
}

// Find the Administrator role in the roles table.
$role_query = $pdo->prepare("SELECT role_id FROM roles WHERE role_name = ?");

// Execute the role query using the Administrator role name.
$role_query->execute(["Administrator"]);

// Fetch the Administrator role record.
$role = $role_query->fetch();

// Stop if the Administrator role does not exist.
if (!$role) {
    exit("Error: Administrator role was not found.\n");
}

// Check whether the username or email is already registered.
$check_query = $pdo->prepare("SELECT user_id FROM users WHERE username = ? OR email = ?");

// Execute the duplicate-account check.
$check_query->execute([$username, $email]);

// Fetch a matching user if one exists.
$existing_user = $check_query->fetch();

// Stop if the username or email is already in use.
if ($existing_user) {
    exit("Error: This username or email is already registered.\n");
}

// Convert the plain-text password into a secure password hash.
$password_hash = password_hash($password, PASSWORD_DEFAULT);

// Prepare an SQL statement to insert the Administrator account.
$insert_query = $pdo->prepare(
    "INSERT INTO users (full_name, username, email, password_hash, role_id, status)
     VALUES (?, ?, ?, ?, ?, 'active')"
);

// Execute the insertion using the supplied account details.
$insert_query->execute([
    $full_name,
    $username,
    $email,
    $password_hash,
    $role["role_id"]
]);

// Display a success message after creating the account.
echo "Administrator account created successfully!\n";