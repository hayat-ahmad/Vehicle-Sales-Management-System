
<?php

// Enable stronger session security before starting the session.
if (session_status() === PHP_SESSION_NONE) {

    // Reject uninitialized session IDs.
    ini_set('session.use_strict_mode', '1');

    // Allow session IDs to be sent only through cookies.
    ini_set('session.use_only_cookies', '1');

    // Determine whether the application is using HTTPS.
    $isSecure = (
        isset($_SERVER['HTTPS']) &&
        $_SERVER['HTTPS'] !== 'off'
    );

    // Configure secure session cookie options.
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $isSecure,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);

    // Start the protected session.
    session_start();
}

// Load the database connection.
require_once __DIR__ . '/../config/database.php';


// Check whether a user ID exists in the current session.
function isLoggedIn(): bool
{
    return isset($_SESSION['user_id']);
}


// Redirect the browser to another page.
function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}


// Destroy the current session and expire its cookie.
function destroyCurrentSession(): void
{
    // Remove all session data.
    $_SESSION = [];

    // Expire the session cookie if cookies are enabled.
    if (ini_get('session.use_cookies')) {

        $cookieParameters = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            [
                'expires' => time() - 42000,
                'path' => $cookieParameters['path'],
                'domain' => $cookieParameters['domain'],
                'secure' => $cookieParameters['secure'],
                'httponly' => $cookieParameters['httponly'],
                'samesite' => $cookieParameters['samesite'] ?? 'Lax'
            ]
        );
    }

    // Destroy the session on the server.
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
}


// Retrieve the currently logged-in user's latest account information.
function currentUser(): ?array
{
    // Return null if no user is logged in.
    if (!isLoggedIn()) {
        return null;
    }

    // Access the shared database connection.
    global $pdo;

    // Retrieve the user only if the account is active.
    $query = $pdo->prepare(
        "SELECT
            u.user_id,
            u.full_name,
            u.username,
            u.email,
            u.status,
            r.role_name
         FROM users AS u
         INNER JOIN roles AS r
            ON u.role_id = r.role_id
            WHERE u.user_id = ?
           AND u.status = 'active'

           AND (
                r.role_name <> 'Salesperson'
                OR EXISTS (
                    SELECT 1
                    FROM employees AS e
                    WHERE e.user_id = u.user_id
                      AND e.status = 'Active'
                )
           )

           AND NOT EXISTS (
                SELECT 1
                FROM employees AS e
                WHERE e.user_id = u.user_id
                  AND e.status = 'Inactive'
           )

         LIMIT 1"
    );

    // Execute the query using the session user ID.
    $query->execute([$_SESSION['user_id']]);

    // Return the user record or null.
    $user = $query->fetch(PDO::FETCH_ASSOC);

    return $user ?: null;
}


// Protect pages against unauthenticated and inactive accounts.
function requireLogin(): void
{
    // Redirect users who do not have a session.
    if (!isLoggedIn()) {
        redirect('login.php');
    }

    // Verify that the account still exists and is active.
    $user = currentUser();

    // Invalidate the session if the account is unavailable.
    if ($user === null) {

        destroyCurrentSession();

        redirect('login.php');
    }
}


// Check whether the logged-in user has a specific role.
function hasRole(string $roleName): bool
{
    // Retrieve the current user's information.
    $user = currentUser();

    // Return true only when the role matches.
    return $user !== null &&
           $user['role_name'] === $roleName;
}


// Restrict access to a specific role.
function requireRole(string $roleName): void
{
    // Verify authentication and account status first.
    requireLogin();

    // Retrieve the current user.
    $user = currentUser();

    // Deny access if the role does not match.
    if ($user === null || $user['role_name'] !== $roleName) {

        http_response_code(403);

        exit(
            'Access denied. You do not have permission to access this page.'
        );
    }
}
