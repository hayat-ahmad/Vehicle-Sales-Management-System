
<?php
// Load the existing authentication functions and PDO database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to log in before accessing this page.
requireLogin();

// Retrieve the currently logged-in user's information.
$user = currentUser();

// If the account is no longer active, clear the session and return to login.
if ($user === null) {
    $_SESSION = [];
    session_destroy();
    redirect("login.php");
}

// Store the current user's role for permission checks.
$userRole = $user["role_name"];

// Define the roles allowed to create vehicle reservations.
$allowedRoles = ["Administrator", "Manager", "Salesperson"];

// Reject users whose roles are not authorized to create reservations.
if (!in_array($userRole, $allowedRoles, true)) {
    http_response_code(403);
    exit("Access denied. Your role cannot create reservations.");
}

// Create a helper function to safely display database values in HTML.
function reservationEscape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Generate a CSRF token if the session does not already have one.
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Keep the CSRF token available for the form.
$csrfToken = $_SESSION["csrf_token"];

// Initialize the form data and feedback messages.
$customers = [];
$availableVehicles = [];
$salespeople = [];
$errors = [];
$successMessage = "";
$databaseError = false;

// Keep submitted values when validation fails.
$selectedCustomerId = "";
$selectedVehicleId = "";
$selectedSalespersonId = "";
$expirationInput = "";

// Retrieve the available customers, vehicles, and salespeople.
try {
    // Retrieve customers for the reservation customer dropdown.
    $customerQuery = $pdo->query(
        "SELECT customer_id, full_name, phone
         FROM customers
         ORDER BY full_name ASC"
    );

    // Store all customer records for the form.
    $customers = $customerQuery->fetchAll();

    // Retrieve only active vehicles that are currently available.
    $vehicleQuery = $pdo->query(
        "SELECT vehicle_id, vin, make, model, `year`, price
         FROM vehicles
         WHERE is_active = 1
           AND status = 'Available'
         ORDER BY make ASC, model ASC"
    );

    // Store available vehicles for the form.
    $availableVehicles = $vehicleQuery->fetchAll();

    // Only administrators and managers can select a salesperson.
    if (in_array($userRole, ["Administrator", "Manager"], true)) {

        // Retrieve active user accounts that have the Salesperson role.
        // Retrieve only active salesperson employees with active accounts.
        $salespersonQuery = $pdo->query(
            "SELECT u.user_id, u.full_name
             FROM users AS u
             INNER JOIN roles AS r ON u.role_id = r.role_id
             INNER JOIN employees AS e
                ON e.user_id = u.user_id
               AND e.status = 'Active'
             WHERE u.status = 'active'
               AND r.role_name = 'Salesperson'
             ORDER BY u.full_name ASC"
        );

        // Store the salesperson records for the dropdown.
        $salespeople = $salespersonQuery->fetchAll();
    }

} catch (PDOException $exception) {

    // Log technical database details privately.
    error_log("VSMS add reservation dropdown error: " . $exception->getMessage());

    // Show a friendly message instead of database details.
    $databaseError = true;
}

// Process the form only when the user submits it using POST.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Read the submitted CSRF token.
    $submittedToken = $_POST["csrf_token"] ?? "";

    // Verify that the form came from the current authenticated session.
    if (!is_string($submittedToken) ||
        !hash_equals($_SESSION["csrf_token"], $submittedToken)) {

        // Add a security error if the token is invalid.
        $errors[] = "Your session security check failed. Please refresh the page and try again.";
    }

    // Read the submitted customer ID.
    $selectedCustomerId = trim($_POST["customer_id"] ?? "");

    // Read the submitted vehicle ID.
    $selectedVehicleId = trim($_POST["vehicle_id"] ?? "");

    // Read the submitted expiration date and time.
    $expirationInput = trim($_POST["expiration_date"] ?? "");

    // Validate that a customer has been selected.
    if ($selectedCustomerId === "" ||
        !ctype_digit($selectedCustomerId) ||
        (int) $selectedCustomerId < 1) {

        $errors[] = "Please select a valid customer.";
    }

    // Validate that a vehicle has been selected.
    if ($selectedVehicleId === "" ||
        !ctype_digit($selectedVehicleId) ||
        (int) $selectedVehicleId < 1) {

        $errors[] = "Please select a valid vehicle.";
    }

    // Determine which salesperson will be responsible for the reservation.
    if ($userRole === "Salesperson") {

        // Salespersons can create reservations only under their own account.
        $salespersonId = (int) $user["user_id"];

    } else {

        // Administrators and managers may select an active salesperson.
        $selectedSalespersonId = trim($_POST["salesperson_id"] ?? "");

        // Validate the selected salesperson ID.
        if ($selectedSalespersonId === "" ||
            !ctype_digit($selectedSalespersonId) ||
            (int) $selectedSalespersonId < 1) {

            $errors[] = "Please select a valid salesperson.";
            $salespersonId = 0;

        } else {

            // Convert the selected salesperson ID to an integer.
            $salespersonId = (int) $selectedSalespersonId;
        }
    }

    // Convert valid submitted IDs into integers.
    $customerId = ctype_digit($selectedCustomerId) ? (int) $selectedCustomerId : 0;
    $vehicleId = ctype_digit($selectedVehicleId) ? (int) $selectedVehicleId : 0;

    // Prepare the optional expiration date.
    $expirationDate = null;

    // Validate the expiration date only when the user entered one.
    if ($expirationInput !== "") {

        // Parse the browser's datetime-local value.
        $parsedExpiration = DateTimeImmutable::createFromFormat(
            "!Y-m-d\TH:i",
            $expirationInput
        );

        // Retrieve date parsing errors and warnings.
        $dateErrors = DateTimeImmutable::getLastErrors();

        // Check whether the date was parsed correctly.
        $validExpiration = $parsedExpiration !== false &&
            ($dateErrors === false ||
                ($dateErrors["warning_count"] === 0 &&
                 $dateErrors["error_count"] === 0));

        // Reject invalid or past expiration dates.
        if (!$validExpiration) {

            $errors[] = "Please enter a valid reservation expiration date.";

        } elseif ($parsedExpiration <= new DateTimeImmutable()) {

            $errors[] = "The expiration date must be in the future.";

        } else {

            // Convert the date to the MySQL DATETIME format.
            $expirationDate = $parsedExpiration->format("Y-m-d H:i:s");
        }
    }

    // Continue only when all initial validation checks have passed.
    if (empty($errors)) {

        // Start with no active database transaction.
        $transactionStarted = false;

        try {

            // Begin a transaction so reservation creation is atomic.
            $pdo->beginTransaction();

            // Remember that a transaction is now active.
            $transactionStarted = true;

            // Lock the selected vehicle row to prevent simultaneous reservations.
            $vehicleCheck = $pdo->prepare(
                "SELECT vehicle_id, status, is_active
                 FROM vehicles
                 WHERE vehicle_id = ?
                 FOR UPDATE"
            );

            // Execute the vehicle lookup using the selected ID.
            $vehicleCheck->execute([$vehicleId]);

            // Retrieve the locked vehicle record.
            $vehicleRecord = $vehicleCheck->fetch();

            // Ensure the vehicle exists and is active.
            if (!$vehicleRecord || (int) $vehicleRecord["is_active"] !== 1) {

                throw new RuntimeException("The selected vehicle does not exist or is inactive.");
            }

            // Ensure the vehicle is still available.
            if ($vehicleRecord["status"] !== "Available") {

                throw new RuntimeException("This vehicle is no longer available. Please select another vehicle.");
            }

            // Verify that the selected customer exists.
            $customerCheck = $pdo->prepare(
                "SELECT customer_id
                 FROM customers
                 WHERE customer_id = ?"
            );

            // Execute the customer lookup.
            $customerCheck->execute([$customerId]);

            // Stop if the customer does not exist.
            if (!$customerCheck->fetch()) {

                throw new RuntimeException("The selected customer could not be found.");
            }

            // Verify that the assigned salesperson exists, is active, and has the correct role.
            // Verify that the salesperson has an active employee record and account.
            // Verify that the salesperson has an active employee record.
            $salespersonCheck = $pdo->prepare(
                "SELECT u.user_id
                 FROM users AS u
                 INNER JOIN roles AS r ON u.role_id = r.role_id
                 INNER JOIN employees AS e
                    ON e.user_id = u.user_id
                   AND e.status = 'Active'
                 WHERE u.user_id = ?
                   AND u.status = 'active'
                   AND r.role_name = 'Salesperson'
                 LIMIT 1"
            );

            // Execute the salesperson validation query.
            $salespersonCheck->execute([$salespersonId]);

            // Stop if the assigned salesperson is invalid.
            if (!$salespersonCheck->fetch()) {

                throw new RuntimeException("The selected salesperson is not an active salesperson.");
            }

            // Check whether this vehicle already has an active reservation.
            $activeReservationCheck = $pdo->prepare(
                "SELECT reservation_id
                 FROM reservations
                 WHERE vehicle_id = ?
                   AND reservation_status = 'Active'
                 LIMIT 1"
            );
            // Check whether this vehicle already has a Pending or Completed sale.
$existingSaleCheck = $pdo->prepare(
    "SELECT sale_id
     FROM sales
     WHERE vehicle_id = ?
       AND sale_status IN ('Pending', 'Completed')
     LIMIT 1
");

// Execute the sale check.
$existingSaleCheck->execute([$vehicleId]);

// Prevent a reservation from conflicting with an existing sale.
if ($existingSaleCheck->fetch()) {
    throw new RuntimeException(
        "This vehicle already has a Pending or Completed sale and cannot be reserved."
    );
}

            // Execute the active reservation check.
            $activeReservationCheck->execute([$vehicleId]);

            // Prevent another active reservation for the same vehicle.
            if ($activeReservationCheck->fetch()) {

                throw new RuntimeException("This vehicle already has an active reservation.");
            }

            // Insert the new reservation into the reservations table.
            $insertReservation = $pdo->prepare(
                "INSERT INTO reservations (
                    customer_id,
                    vehicle_id,
                    salesperson_id,
                    expiration_date,
                    reservation_status
                 ) VALUES (?, ?, ?, ?, 'Active')"
            );

            // Execute the insert using validated values.
            $insertReservation->execute([
                $customerId,
                $vehicleId,
                $salespersonId,
                $expirationDate
            ]);

            // Update the vehicle status after the reservation is inserted.
            $updateVehicle = $pdo->prepare(
                "UPDATE vehicles
                 SET status = 'Reserved'
                 WHERE vehicle_id = ?
                   AND status = 'Available'
                   AND is_active = 1"
            );

            // Execute the vehicle status update.
            $updateVehicle->execute([$vehicleId]);

            // Confirm that exactly one vehicle was changed.
            if ($updateVehicle->rowCount() !== 1) {

                throw new RuntimeException("The vehicle status could not be updated. Please try again.");
            }

            // Commit both database changes together.
            $pdo->commit();

            // Mark the transaction as completed.
            $transactionStarted = false;

            // Redirect to prevent the form from being submitted again on refresh.
            redirect("add_reservation.php?created=1");

        } catch (RuntimeException $exception) {

            // Roll back database changes if a transaction is active.
            if ($transactionStarted && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            // Display the specific validation or business-rule message.
            $errors[] = $exception->getMessage();

        } catch (PDOException $exception) {

            // Roll back database changes if a transaction is active.
            if ($transactionStarted && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            // Record technical details in the private PHP error log.
            error_log("VSMS reservation creation database error: " . $exception->getMessage());

            // Display a friendly database error.
            $errors[] = "The reservation could not be saved because of a database error. Please try again.";
        }
    }
}

// Prepare the user's information for safe HTML display.
$fullName = reservationEscape($user["full_name"]);

// Prepare the user's role for safe HTML display.
$roleName = reservationEscape($userRole);

// Check whether the current user can select a salesperson.
$canSelectSalesperson = in_array($userRole, ["Administrator", "Manager"], true);

?>
<!DOCTYPE html>
<!-- Declare this document as an HTML5 page. -->
<html lang="en">

<head>
    <!-- Set the document character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on different screen sizes. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Add Reservation | VSMS</title>

    <!-- Load the existing shared dashboard design. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Load the existing vehicle module styles. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <!-- Add focused styles for the reservation form. -->
    <style>
        /* Give the reservation form a clean white card. */
        .reservation-form-card {
            max-width: 900px;
            margin-top: 24px;
            padding: 28px;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
        }

        /* Arrange the form fields in two columns. */
        .reservation-form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 22px;
        }

        /* Keep each label and input together. */
        .reservation-field {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        /* Make form labels clear and readable. */
        .reservation-field label {
            color: #263247;
            font-size: 14px;
            font-weight: 600;
        }

        /* Give inputs and dropdowns a consistent appearance. */
        .reservation-field input,
        .reservation-field select {
            width: 100%;
            min-height: 46px;
            padding: 10px 12px;
            border: 1px solid #d7dce4;
            border-radius: 7px;
            background: #ffffff;
            color: #263247;
            font: inherit;
        }

        /* Highlight a field when the user selects it. */
        .reservation-field input:focus,
        .reservation-field select:focus {
            outline: 2px solid rgba(244, 112, 85, 0.2);
            border-color: #f07055;
        }

        /* Explain optional form fields. */
        .reservation-field small {
            color: #6b7280;
            font-size: 12px;
        }

        /* Let the form action buttons span the form width. */
        .reservation-form-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 28px;
        }

        /* Display form messages clearly. */
        .reservation-message {
            margin-top: 20px;
            padding: 14px 16px;
            border-radius: 8px;
            font-size: 14px;
        }

        /* Style successful reservation messages. */
        .reservation-success {
            color: #166534;
            background: #dcfce7;
            border: 1px solid #bbf7d0;
        }

        /* Style reservation error messages. */
        .reservation-error {
            color: #991b1b;
            background: #fee2e2;
            border: 1px solid #fecaca;
        }

        /* Display a short explanation below the form heading. */
        .reservation-help {
            margin-top: 8px;
            color: #6b7280;
            line-height: 1.6;
        }

        /* Arrange the form in one column on small screens. */
        @media (max-width: 700px) {
            .reservation-form-grid {
                grid-template-columns: 1fr;
            }

            .reservation-form-card {
                padding: 18px;
            }
        }
    </style>
</head>

<body>
    <!-- Create the main application layout. -->
    <div class="dashboard-layout">

        <!-- Create the navigation sidebar. -->
        <aside class="sidebar">

            <!-- Display the system logo and name. -->
            <div class="brand">

                <!-- Display the short system name inside a logo box. -->
                <div class="brand-logo">V</div>

                <!-- Display the full system name. -->
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>

            <!-- Close the brand section. -->
            </div>

            <!-- Display the main sidebar navigation. -->
            

<!-- Display all available system navigation links. -->
            <nav class="sidebar-navigation">

                <!-- Display the navigation section heading. -->
                <p class="navigation-heading">MAIN MENU</p>

                <!-- Link to the Dashboard. -->
                <a href="dashboard.php" class="nav-link active">
                    <span class="nav-icon">▦</span>
                    <span>Dashboard</span>
                </a>

                <!-- Link to Vehicle Management. -->
                <a href="vehicles.php" class="nav-link">
                    <span class="nav-icon">🚘</span>
                    <span>Vehicles</span>
                </a>

                <!-- Link to Customer Management. -->
                <a href="customers.php" class="nav-link">
                    <span class="nav-icon">♙</span>
                    <span>Customers</span>
                </a>

                <!-- Link to Reservation Management. -->
                <a href="reservations.php" class="nav-link">
                    <span class="nav-icon">▣</span>
                    <span>Reservations</span>
                </a>

                <!-- Link to Sales Management. -->
                <a href="sales.php" class="nav-link">
                    <span class="nav-icon">▤</span>
                    <span>Sales</span>
                </a>

                <!-- Link to Payment Management. -->
                <a href="payments.php" class="nav-link">
                    <span class="nav-icon">$</span>
                    <span>Payments</span>
                </a>
                <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
    <span class="nav-icon">◷</span>
    <span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
    <span class="nav-icon">▧</span>
    <span>Invoices</span>
</a>

                <!-- Show employee management only to authorized management roles. -->
                <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

                    <a href="employees.php" class="nav-link">
                        <span class="nav-icon">♧</span>
                        <span>Employees</span>
                    </a>

                <?php endif; ?>
                <!-- Only Administrators can access User Account Management. -->
<?php if ($user["role_name"] === "Administrator"): ?>

    <a href="users.php" class="nav-link">
        <span class="nav-icon">♙</span>
        <span>User Accounts</span>
    </a>

<?php endif; ?>

                <!-- Show reports only to authorized management roles. -->
                <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

                    <a href="reports.php" class="nav-link">
                        <span class="nav-icon">▥</span>
                        <span>Reports</span>
                    </a>

                <?php endif; ?>

            <!-- Close the navigation section. -->
            </nav>


            <!-- Display a short project description at the bottom of the sidebar. -->
            <div class="sidebar-footer">
                <p>Vehicle Sales &amp; Management System</p>
                <span>Development version</span>
            </div>

        <!-- Close the sidebar. -->
        </aside>

        <!-- Create the main workspace. -->
        <main class="main-content">

            <!-- Display the page header and current user. -->
            <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Main Menu / Reservations</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    
    <div class="user-information">
                    <a href="my_profile.php" class="profile-name-link">
        <?= $fullName ?>
    </a>
                        <span><?= $roleName ?></span>
                    </div>

    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>

          

            <!-- Display the reservation page content. -->
            <section class="page-content">

                <!-- Introduce the reservation form. -->
                <div class="page-heading">
                    <div>
                        <h1>Create Vehicle Reservation</h1>
                        <p>Reserve an available vehicle for an existing customer.</p>
                    </div>
                </div>

                <!-- Display a success message after a reservation is created. -->
                <?php if (isset($_GET["created"]) && $_GET["created"] === "1"): ?>
                    <div class="reservation-message reservation-success">
                        Reservation created successfully. The vehicle status has been changed to Reserved.
                    </div>
                <?php endif; ?>

                <!-- Display a database loading error when dropdown data is unavailable. -->
                <?php if ($databaseError): ?>
                    <div class="reservation-message reservation-error">
                        Unable to load reservation information. Please check the database connection and try again.
                    </div>
                <?php endif; ?>

                <!-- Display validation or reservation errors. -->
                <?php if (!empty($errors)): ?>
                    <div class="reservation-message reservation-error">
                        <strong>Please correct the following issue(s):</strong>
                        <ul>
                            <?php foreach ($errors as $error): ?>
                                <li><?= reservationEscape($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <!-- Display the reservation form card. -->
                <section class="reservation-form-card">

                    <!-- Explain the purpose of the form. -->
                    <h2>Reservation Information</h2>
                    <p class="reservation-help">
                        Select an existing customer and an available vehicle.
                        The system will automatically mark the vehicle as Reserved after saving.
                    </p>

                    <!-- Submit the reservation information securely using POST. -->
                    <form action="add_reservation.php" method="POST">

                        <!-- Include the session CSRF token. -->
                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= reservationEscape($csrfToken) ?>"
                        >

                        <!-- Arrange the form fields in a responsive grid. -->
                        <div class="reservation-form-grid">

                            <!-- Allow the user to select an existing customer. -->
                            <div class="reservation-field">
                                <label for="customer_id">Customer *</label>

                                <select
                                    id="customer_id"
                                    name="customer_id"
                                    required
                                >
                                    <option value="">Select a customer</option>

                                    <?php foreach ($customers as $customer): ?>
                                        <option
                                            value="<?= (int) $customer["customer_id"] ?>"
                                            <?= $selectedCustomerId === (string) $customer["customer_id"] ? "selected" : "" ?>
                                        >
                                            <?= reservationEscape($customer["full_name"]) ?>
                                            — <?= reservationEscape($customer["phone"]) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>

                                <small>Choose a customer already registered in VSMS.</small>
                            </div>

                            <!-- Allow the user to select an available vehicle. -->
                            <div class="reservation-field">
                                <label for="vehicle_id">Available Vehicle *</label>

                                <select
                                    id="vehicle_id"
                                    name="vehicle_id"
                                    required
                                >
                                    <option value="">Select an available vehicle</option>

                                    <?php foreach ($availableVehicles as $vehicle): ?>
                                        <option
                                            value="<?= (int) $vehicle["vehicle_id"] ?>"
                                            <?= $selectedVehicleId === (string) $vehicle["vehicle_id"] ? "selected" : "" ?>
                                        >
                                            <?= reservationEscape(
                                                $vehicle["year"] . " " .
                                                $vehicle["make"] . " " .
                                                $vehicle["model"] . " — VIN: " .
                                                $vehicle["vin"]
                                            ) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>

                                <small>Only active vehicles with Available status are listed.</small>
                            </div>

                            <!-- Allow administrators and managers to assign a salesperson. -->
                            <?php if ($canSelectSalesperson): ?>
                                <div class="reservation-field">
                                    <label for="salesperson_id">Salesperson *</label>

                                    <select
                                        id="salesperson_id"
                                        name="salesperson_id"
                                        required
                                    >
                                        <option value="">Select a salesperson</option>

                                        <?php foreach ($salespeople as $salesperson): ?>
                                            <option
                                                value="<?= (int) $salesperson["user_id"] ?>"
                                                <?= $selectedSalespersonId === (string) $salesperson["user_id"] ? "selected" : "" ?>
                                            >
                                                <?= reservationEscape($salesperson["full_name"]) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>

                                    <small>Only active users with the Salesperson role are listed.</small>
                                </div>
                            <?php else: ?>

                                <!-- Show the logged-in salesperson assigned to this reservation. -->
                                <div class="reservation-field">
                                    <label>Assigned Salesperson</label>
                                    <input
                                        type="text"
                                        value="<?= $fullName ?>"
                                        readonly
                                    >
                                    <small>Your account will be assigned to this reservation.</small>
                                </div>
                            <?php endif; ?>

                            <!-- Allow the user to enter an optional expiration date. -->
                            <div class="reservation-field">
                                <label for="expiration_date">Expiration Date (Optional)</label>

                                <input
                                    type="datetime-local"
                                    id="expiration_date"
                                    name="expiration_date"
                                    value="<?= reservationEscape($expirationInput) ?>"
                                >

                                <small>Leave empty if the reservation has no specified expiration date.</small>
                            </div>

                        </div>

                        <!-- Group the form submission and cancellation links. -->
                        <div class="reservation-form-actions">

                            <!-- Submit the new reservation. -->
                            <button
                                type="submit"
                                class="primary-button"
                                <?= ($databaseError || empty($customers) || empty($availableVehicles)) ? "disabled" : "" ?>
                            >
                                Create Reservation
                            </button>

                            <!-- Return to the customer directory without submitting. -->
                            <a href="customers.php" class="secondary-button">
                                Cancel
                            </a>

                        </div>
                    </form>
                </section>
            </section>
        </main>
    </div>
</body>
</html>
