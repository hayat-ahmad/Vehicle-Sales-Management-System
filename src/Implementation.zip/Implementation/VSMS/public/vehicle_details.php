
<?php
// Load the existing authentication functions and database connection.
require_once __DIR__ . "/../includes/auth.php";

// Make sure that only logged-in users can view vehicle details.
requireLogin();

// Get the currently logged-in user's information from the database.
$user = currentUser();

// Redirect to the login page if the user information is unavailable.
if (!$user) {
    header("Location: login.php");
    exit;
}

// Create a CSRF token if the current session does not already have one.
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Read the vehicle ID from the URL and validate that it is an integer.
$vehicleId = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

// Prepare an empty variable to store the vehicle information.
$vehicle = null;

// Prepare a variable to store an error message.
$errorMessage = "";

// Check whether the supplied vehicle ID is missing or invalid.
if ($vehicleId === false || $vehicleId === null || $vehicleId <= 0) {
    // Set the HTTP response status to indicate an invalid request.
    http_response_code(400);

    // Store a message explaining the problem.
    $errorMessage = "The vehicle ID is invalid. Please return to the vehicle inventory.";
} else {
    // Prepare a SQL query that retrieves one active vehicle by its ID.
    $sql = "SELECT
                vehicle_id,
                vin,
                make,
                model,
                year,
                category,
                price,
                mileage,
                fuel_type,
                transmission,
                color,
                status,
                description,
                image_path,
                created_at,
                updated_at
            FROM vehicles
            WHERE vehicle_id = :vehicle_id
            AND is_active = 1
            LIMIT 1";

    // Create a prepared SQL statement using the existing PDO connection.
    $statement = $pdo->prepare($sql);

    // Attach the requested vehicle ID to the named SQL parameter.
    $statement->bindValue(":vehicle_id", $vehicleId, PDO::PARAM_INT);

    // Execute the prepared SQL statement.
    $statement->execute();

    // Retrieve the matching vehicle as an associative array.
    $vehicle = $statement->fetch(PDO::FETCH_ASSOC);

    // Check whether the requested vehicle was found.
    if (!$vehicle) {
        // Set the HTTP response status to indicate that the vehicle was not found.
        http_response_code(404);

        // Store a helpful message for the user.
        $errorMessage = "The requested vehicle was not found or is no longer active.";
    }
}

// Create a helper function that safely displays database values in HTML.
$escape = static function ($value): string {
    // Convert the value to a string and escape special HTML characters.
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
};

// Prepare an empty variable for the vehicle image URL.
$imageUrl = "";

// Check whether the vehicle has an image path stored in the database.
if ($vehicle && !empty($vehicle["image_path"])) {
    // Convert the stored path to a safe filename.
    $imageFileName = basename(str_replace("\\", "/", $vehicle["image_path"]));

    // Build the physical path to the image inside the vehicle uploads folder.
    $imagePhysicalPath = __DIR__ . "/uploads/vehicles/" . $imageFileName;

    // Check whether the image file actually exists on the server.
    if (is_file($imagePhysicalPath)) {
        // Prepare the browser URL for displaying the vehicle image.
        $imageUrl = "uploads/vehicles/" . rawurlencode($imageFileName);
    }
}

// Prepare a formatted price without assuming a particular currency.
$formattedPrice = $vehicle ? number_format((float) $vehicle["price"], 2) : "";

// Prepare a formatted mileage value.
$formattedMileage = $vehicle ? number_format((int) $vehicle["mileage"]) : "";

// Prepare a formatted vehicle creation date.
$formattedCreatedAt = ($vehicle && !empty($vehicle["created_at"]))
    ? date("d M Y", strtotime($vehicle["created_at"]))
    : "Not available";

// Prepare the current user's full name for the page header.
$userName = $escape($user["full_name"]);

// Prepare the current user's role for the page header.
$userRole = $escape($user["role_name"]);

// Prepare the CSRF token for the secure logout form.
$csrfToken = $escape($_SESSION["csrf_token"]);
?>

<!DOCTYPE html>
<!-- Tell the browser that this document uses HTML5. -->
<html lang="en">
<!-- Start the HTML document and declare its language. -->

<head>
    <!-- Store page information and load the required stylesheets. -->
    <meta charset="UTF-8">
    <!-- Support standard characters and symbols. -->

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Make the page responsive on different screen sizes. -->

    <title>Vehicle Details | VSMS</title>
    <!-- Set the title displayed in the browser tab. -->

    <link rel="stylesheet" href="assets/css/dashboard.css">
    <!-- Load the shared dashboard design and layout styles. -->

    <link rel="stylesheet" href="assets/css/vehicles.css">
    <!-- Load the vehicle module styles. -->
</head>

<body>
    <!-- Start the visible page content. -->

    <div class="dashboard-layout">
        <!-- Create the main layout containing the sidebar and page content. -->

        <aside class="sidebar">

<!-- Display the system logo and name. -->
<div class="brand">

    <!-- Display the short system name inside a logo box. -->
    <div class="brand-logo">V</div>

    <!-- Display the full system name. -->
    <div class="brand-text">
        <h2>VSMS</h2>
        <p>Vehicle Management</p>
    </div>

<!-- Close the brand section. -->
</div>

<!-- Display the main sidebar navigation. -->


<!-- Display all available system navigation links. -->
<nav class="sidebar-navigation">

    <!-- Display the navigation section heading. -->
    <p class="navigation-heading">MAIN MENU</p>

    <!-- Link to the Dashboard. -->
    <a href="dashboard.php" class="nav-link active">
        <span class="nav-icon">▦</span>
        <span>Dashboard</span>
    </a>

    <!-- Link to Vehicle Management. -->
    <a href="vehicles.php" class="nav-link">
        <span class="nav-icon">🚘</span>
        <span>Vehicles</span>
    </a>

    <!-- Link to Customer Management. -->
    <a href="customers.php" class="nav-link">
        <span class="nav-icon">♙</span>
        <span>Customers</span>
    </a>

    <!-- Link to Reservation Management. -->
    <a href="reservations.php" class="nav-link">
        <span class="nav-icon">▣</span>
        <span>Reservations</span>
    </a>

    <!-- Link to Sales Management. -->
    <a href="sales.php" class="nav-link">
        <span class="nav-icon">▤</span>
        <span>Sales</span>
    </a>

    <!-- Link to Payment Management. -->
    <a href="payments.php" class="nav-link">
        <span class="nav-icon">$</span>
        <span>Payments</span>
    </a>
    <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
<span class="nav-icon">◷</span>
<span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
<span class="nav-icon">▧</span>
<span>Invoices</span>
</a>

    <!-- Show employee management only to authorized management roles. -->
    <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

        <a href="employees.php" class="nav-link">
            <span class="nav-icon">♧</span>
            <span>Employees</span>
        </a>

    <?php endif; ?>
    <!-- Only Administrators can access User Account Management. -->
<?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
<span class="nav-icon">♙</span>
<span>User Accounts</span>
</a>

<?php endif; ?>

    <!-- Show reports only to authorized management roles. -->
    <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

        <a href="reports.php" class="nav-link">
            <span class="nav-icon">▥</span>
            <span>Reports</span>
        </a>

    <?php endif; ?>

<!-- Close the navigation section. -->
</nav>


<!-- Display a short project description at the bottom of the sidebar. -->
<div class="sidebar-footer">
    <p>Vehicle Sales &amp; Management System</p>
    <span>Development version</span>
</div>

<!-- Close the sidebar. -->
</aside>

        <main class="main-content">
            <!-- Create the main content area beside the sidebar. -->
        


            <header class="topbar">
                <!-- Create the top header containing the page location and user information. -->
               
                    <!-- Display the current page location. -->
                    <div class="breadcrumb"> <strong>Vehicles / Vehicle Details</strong>    </div>
                    <!-- Show the navigation path for this page. -->
                

                <div class="topbar-user">
                    <!-- Display the logged-in user and logout control. -->
                    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
        
    </div>
                    <div class="user-information">
                        <!-- Group the user's name and role together. -->
                        <a href="my_profile.php" class="profile-name-link"><?= $userName ?>
   
</a>
                        <!-- Display the escaped user's full name. -->
                        <span><?= $userRole ?></span>
                        <!-- Display the escaped user's role. -->
                    </div>

                    <form action="logout.php" method="POST">
                        <!-- Submit a secure POST request when the user logs out. -->

                        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                        <!-- Send the current session's CSRF token for verification. -->

                        <button type="submit" class="logout-button">
                            <!-- Create the logout button. -->
                            Logout
                            <!-- Display the button label. -->
                        </button>
                    </form>
                </div>
            </header>

            <section class="vehicle-details-section">
                <!-- Start the section containing the vehicle information. -->

                <div class="detail-page-heading">
                    <!-- Display the page heading and return link. -->

                    <div>
                        <!-- Group the page title and its description. -->
                        <h1>Vehicle Details</h1>
                        <!-- Display the main page title. -->
                        <p>View the complete information about this vehicle.</p>
                        <!-- Explain the purpose of this page. -->
                    </div>

                    <a href="vehicles.php" class="secondary-button">
                        <!-- Provide a link back to the vehicle inventory. -->
                        Back to Vehicles
                        <!-- Display the return button label. -->
                    </a>
                </div>

                <?php if ($errorMessage !== ""): ?>
                    <!-- Display an error message when the ID is invalid or the vehicle is unavailable. -->

                    <div class="error-message">
                        <!-- Create the error message container. -->
                        <?= $escape($errorMessage) ?>
                        <!-- Display the safely escaped error message. -->
                    </div>

                <?php elseif ($vehicle): ?>
                    <!-- Display the vehicle information when a valid record is found. -->

                    <div class="detail-overview">
                        <!-- Create the main vehicle details card. -->

                        <div class="detail-image-container">
                            <!-- Create the area reserved for the vehicle photograph. -->

                            <?php if ($imageUrl !== ""): ?>
                                <!-- Display the photograph when a valid uploaded image exists. -->

                                <img
                                    src="<?= $escape($imageUrl) ?>"
                                    alt="<?= $escape($vehicle["make"] . " " . $vehicle["model"]) ?>"
                                    class="detail-vehicle-image"
                                >
                                <!-- Display the actual vehicle photograph and provide alternative text. -->

                            <?php else: ?>
                                <!-- Display a placeholder when the vehicle has no available photograph. -->

                                <div class="detail-image-placeholder">
                                    <!-- Create a clean placeholder instead of displaying a broken image. -->
                                    <span>No vehicle image available</span>
                                    <!-- Explain why no photograph is displayed. -->
                                </div>

                            <?php endif; ?>
                        </div>

                        <div class="detail-main-information">
                            <!-- Display the vehicle's most important information. -->

                            <span class="detail-category">
                                <!-- Display the vehicle category. -->
                                <?= $escape($vehicle["category"]) ?>
                                <!-- Safely display the category from the database. -->
                            </span>

                            <h2>
                                <!-- Display the vehicle's make, model, and year. -->
                                <?= $escape($vehicle["make"]) ?>
                                <?= $escape($vehicle["model"]) ?>
                                <!-- Display the vehicle make and model. -->
                                (<?= $escape($vehicle["year"]) ?>)
                                <!-- Display the vehicle manufacturing year. -->
                            </h2>

                            <p class="detail-price">
                                <!-- Display the vehicle's selling price. -->
                                <?= $escape($formattedPrice) ?>
                                <!-- Display the formatted price without assuming a currency. -->
                            </p>

                            <span class="status-badge">
                                <!-- Display the current vehicle status. -->
                                <?= $escape($vehicle["status"]) ?>
                                <!-- Safely display Available, Reserved, Sold, or another status. -->
                            </span>

                            <p class="detail-vin">
                                <!-- Display the vehicle identification number. -->
                                VIN: <?= $escape($vehicle["vin"]) ?>
                                <!-- Display the unique VIN stored in the database. -->
                            </p>
                        </div>
                    </div>

                    <div class="detail-information-card">
                        <!-- Create a separate card for the vehicle's complete specifications. -->

                        <h3>Vehicle Specifications</h3>
                        <!-- Display the specifications section heading. -->

                        <div class="detail-grid">
                            <!-- Arrange the vehicle specifications in a responsive grid. -->

                            <div class="detail-item">
                                <!-- Display the manufacturing year. -->
                                <span>Year</span>
                                <!-- Display the specification label. -->
                                <strong><?= $escape($vehicle["year"]) ?></strong>
                                <!-- Display the specification value. -->
                            </div>

                            <div class="detail-item">
                                <!-- Display the vehicle category. -->
                                <span>Category</span>
                                <!-- Display the specification label. -->
                                <strong><?= $escape($vehicle["category"]) ?></strong>
                                <!-- Display the specification value. -->
                            </div>

                            <div class="detail-item">
                                <!-- Display the vehicle mileage. -->
                                <span>Mileage</span>
                                <!-- Display the specification label. -->
                                <strong><?= $escape($formattedMileage) ?></strong>
                                <!-- Display the formatted mileage value. -->
                            </div>

                            <div class="detail-item">
                                <!-- Display the fuel type. -->
                                <span>Fuel Type</span>
                                <!-- Display the specification label. -->
                                <strong><?= $escape($vehicle["fuel_type"]) ?></strong>
                                <!-- Display the specification value. -->
                            </div>

                            <div class="detail-item">
                                <!-- Display the transmission type. -->
                                <span>Transmission</span>
                                <!-- Display the specification label. -->
                                <strong><?= $escape($vehicle["transmission"]) ?></strong>
                                <!-- Display the specification value. -->
                            </div>

                            <div class="detail-item">
                                <!-- Display the vehicle color. -->
                                <span>Color</span>
                                <!-- Display the specification label. -->
                                <strong><?= $escape($vehicle["color"]) ?></strong>
                                <!-- Display the specification value. -->
                            </div>

                            <div class="detail-item">
                                <!-- Display the vehicle identification number. -->
                                <span>VIN</span>
                                <!-- Display the specification label. -->
                                <strong><?= $escape($vehicle["vin"]) ?></strong>
                                <!-- Display the specification value. -->
                            </div>

                            <div class="detail-item">
                                <!-- Display the date when the vehicle record was created. -->
                                <span>Added to System</span>
                                <!-- Display the specification label. -->
                                <strong><?= $escape($formattedCreatedAt) ?></strong>
                                <!-- Display the formatted creation date. -->
                            </div>
                        </div>
                    </div>

                    <div class="detail-information-card detail-description">
                        <!-- Create a separate card for the vehicle description. -->

                        <h3>Description</h3>
                        <!-- Display the description section heading. -->

                        <?php if (!empty($vehicle["description"])): ?>
                            <!-- Check whether the vehicle has a description. -->

                            <p><?= nl2br($escape($vehicle["description"])) ?></p>
                            <!-- Escape the description and preserve its line breaks. -->

                        <?php else: ?>
                            <!-- Display a message when no description was entered. -->

                            <p>No description has been added for this vehicle.</p>
                            <!-- Explain that the description field is empty. -->

                        <?php endif; ?>
                    </div>

                <?php endif; ?>
                <!-- Finish the vehicle-found and error-message conditions. -->

            </section>
        </main>
    </div>
</body>
</html>
