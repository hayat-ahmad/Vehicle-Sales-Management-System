
<?php
// Load authentication, session handling, and the database connection.
require_once __DIR__ . "/../includes/auth.php";

// Only Administrators can reset other users' passwords.
requireRole("Administrator");

// Retrieve the logged-in Administrator.
$currentUser = currentUser();

// Redirect if the account is unavailable.
if ($currentUser === null) {
    redirect("login.php");
}

// Safely display text in HTML.
function escapeResetPasswordHtml($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Create a CSRF token if one does not already exist.
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION["csrf_token"];

// Read and validate the target user ID.
$userId = filter_var(
    $_GET["id"] ?? $_POST["user_id"] ?? "",
    FILTER_VALIDATE_INT,
    ["options" => ["min_range" => 1]]
);

// Stop if the account ID is invalid.
if ($userId === false) {
    http_response_code(400);
    exit("Invalid user account ID.");
}

// Prevent an Administrator from resetting their own password here.
if ((int) $userId === (int) $currentUser["user_id"]) {
    http_response_code(403);
    exit("You cannot reset your own password from this page. Please use My Profile.");
}

// Initialize page variables.
$errors = [];
$successMessage = "";

// Retrieve the target account.
try {
    $accountQuery = $pdo->prepare(
        "SELECT
            u.user_id,
            u.full_name,
            u.username,
            u.email,
            u.status,
            r.role_name
         FROM users AS u
         INNER JOIN roles AS r
            ON r.role_id = u.role_id
         WHERE u.user_id = ?
         LIMIT 1"
    );

    $accountQuery->execute([$userId]);
    $account = $accountQuery->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {
    error_log("VSMS reset password load error: " . $exception->getMessage());
    http_response_code(500);
    exit("The user account could not be loaded.");
}

// Stop if the account does not exist.
if (!$account) {
    http_response_code(404);
    exit("The selected user account was not found.");
}

// Process the submitted password reset form.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Read the submitted CSRF token.
    $submittedToken = $_POST["csrf_token"] ?? "";

    // Read the new password and confirmation.
    $newPassword = $_POST["new_password"] ?? "";
    $confirmPassword = $_POST["confirm_password"] ?? "";

    // Verify the CSRF token.
    if (
        !is_string($submittedToken) ||
        !hash_equals($csrfToken, $submittedToken)
    ) {
        $errors[] = "Invalid request. Refresh the page and try again.";
    }

    // Ensure both password fields contain text.
    if (
        !is_string($newPassword) ||
        !is_string($confirmPassword)
    ) {
        $errors[] = "Invalid password information.";

    } else {

        // Enforce the same minimum password length as My Profile.
        if (strlen($newPassword) < 12) {
            $errors[] = "The new password must contain at least 12 characters.";
        }

        // PASSWORD_DEFAULT currently uses bcrypt, which has a 72-byte limit.
        if (strlen($newPassword) > 72) {
            $errors[] = "The new password must not exceed 72 bytes.";
        }

        // Ensure the two password fields match.
        if ($newPassword !== $confirmPassword) {
            $errors[] = "The new password and confirmation do not match.";
        }
    }

    // Continue only if validation succeeds.
    if (empty($errors)) {

        try {
            // Generate a secure password hash.
            $newPasswordHash = password_hash(
                $newPassword,
                PASSWORD_DEFAULT
            );

            if ($newPasswordHash === false) {
                throw new RuntimeException(
                    "The new password could not be secured."
                );
            }

            // Update only the selected account's password.
            $updatePasswordQuery = $pdo->prepare(
                "UPDATE users
                 SET password_hash = ?
                 WHERE user_id = ?"
            );

            $updatePasswordQuery->execute([
                $newPasswordHash,
                $userId
            ]);

            // Confirm that the account was updated.
            if ($updatePasswordQuery->rowCount() !== 1) {
                // Check whether the account already has this password hash.
                // A zero row count can occur if the stored value is unchanged.
                $checkQuery = $pdo->prepare(
                    "SELECT user_id
                     FROM users
                     WHERE user_id = ?
                     LIMIT 1"
                );

                $checkQuery->execute([$userId]);

                if (!$checkQuery->fetchColumn()) {
                    throw new RuntimeException(
                        "The selected user account no longer exists."
                    );
                }
            }

            // Display the success message.
            $successMessage =
                "The password was reset successfully. Please communicate the temporary password securely to the account holder.";

        } catch (RuntimeException $exception) {

            $errors[] = $exception->getMessage();

        } catch (PDOException $exception) {

            // Record technical details privately.
            error_log("VSMS reset password update error: " . $exception->getMessage());

            $errors[] =
                "The password could not be reset. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Reset User Password | VSMS</title>

    <link rel="stylesheet" href="assets/css/dashboard.css">

    <style>
        .reset-page {
            padding: 28px;
        }

        .reset-card {
            max-width: 700px;
            background: #ffffff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.04);
        }

        .reset-card h2 {
            margin-top: 0;
            margin-bottom: 20px;
        }

        .reset-form {
            display: grid;
            gap: 18px;
        }

        .reset-form label {
            display: block;
            margin-bottom: 7px;
            font-weight: 600;
        }

        .reset-form input {
            width: 100%;
            padding: 12px;
            border: 1px solid #dce1e8;
            border-radius: 7px;
            font: inherit;
        }

        .reset-message {
            padding: 13px 16px;
            border-radius: 8px;
            margin-bottom: 18px;
        }

        .reset-success {
            color: #176b43;
            background: #e4f5eb;
        }

        .reset-error {
            color: #9b2929;
            background: #fdeaea;
        }

        .reset-note {
            color: #647084;
            font-size: 13px;
            line-height: 1.6;
        }

        .reset-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 5px;
        }

        .reset-actions a {
            display: inline-block;
            text-decoration: none;
            padding: 11px 16px;
            border-radius: 7px;
            background: #edf0f4;
            color: #26364b;
        }

        @media (max-width: 600px) {
            .reset-page {
                padding: 16px;
            }

            .reset-card {
                padding: 17px;
            }
        }
    </style>
</head>

<body>

<div class="dashboard-layout">

    <main class="main-content">

        <div class="reset-page">

            <div class="page-header">
                <div>
                    <h1>Reset User Password</h1>
                    <p>Set a new password for an existing login account.</p>
                </div>
            </div>

            <div class="reset-card">

                <h2>Account Information</h2>

                <?php if (!empty($errors)): ?>
                    <div class="reset-message reset-error">
                        <?php foreach ($errors as $error): ?>
                            <p><?= escapeResetPasswordHtml($error) ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($successMessage !== ""): ?>
                    <div class="reset-message reset-success">
                        <?= escapeResetPasswordHtml($successMessage) ?>
                    </div>
                <?php endif; ?>

                <div class="reset-form">

                    <div>
                        <label>Full Name</label>
                        <input
                            type="text"
                            value="<?= escapeResetPasswordHtml($account["full_name"]) ?>"
                            readonly
                        >
                    </div>

                    <div>
                        <label>Username</label>
                        <input
                            type="text"
                            value="<?= escapeResetPasswordHtml($account["username"]) ?>"
                            readonly
                        >
                    </div>

                    <div>
                        <label>Email Address</label>
                        <input
                            type="email"
                            value="<?= escapeResetPasswordHtml($account["email"]) ?>"
                            readonly
                        >
                    </div>

                    <div>
                        <label>System Role</label>
                        <input
                            type="text"
                            value="<?= escapeResetPasswordHtml($account["role_name"]) ?>"
                            readonly
                        >
                    </div>

                </div>

                <hr>

                <form
                    method="POST"
                    action="reset_user_password.php?id=<?= (int) $userId ?>"
                    class="reset-form"
                    onsubmit="return confirm('Are you sure you want to reset this user password?');"
                >

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= escapeResetPasswordHtml($csrfToken) ?>"
                    >

                    <input
                        type="hidden"
                        name="user_id"
                        value="<?= (int) $userId ?>"
                    >

                    <div>
                        <label for="new_password">New Password</label>

                        <input
                            type="password"
                            id="new_password"
                            name="new_password"
                            minlength="12"
                            maxlength="72"
                            autocomplete="new-password"
                            placeholder="Enter a new password"
                            required
                        >
                    </div>

                    <div>
                        <label for="confirm_password">Confirm New Password</label>

                        <input
                            type="password"
                            id="confirm_password"
                            name="confirm_password"
                            minlength="12"
                            maxlength="72"
                            autocomplete="new-password"
                            placeholder="Confirm the new password"
                            required
                        >
                    </div>

                    <p class="reset-note">
                        The new password must contain at least 12 characters.
                        Share the temporary password with the account holder
                        through a secure channel.
                    </p>

                    <div class="reset-actions">

                        <button type="submit" class="btn btn-primary">
                            Reset Password
                        </button>

                        <a href="users.php">
                            Back to User Management
                        </a>

                    </div>

                </form>

            </div>

        </div>

    </main>

</div>

</body>
</html>
