
<?php
// Load the existing authentication functions and PDO database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require users to log in before viewing the vehicle inventory.
requireLogin();

// Retrieve the currently logged-in user's information from the database.
$user = currentUser();

// Check that the user's account is still active.
if ($user === null) {
    // Clear the current session data.
    $_SESSION = [];

    // Destroy the current session.
    session_destroy();

    // Redirect the unavailable account to the login page.
    redirect("login.php");
}

// Store the user's role for permission checks and interface display.
$userRole = $user["role_name"];

// Allow only these three approved VSMS roles to view inventory.
$allowedRoles = ["Administrator", "Manager", "Salesperson"];

// Stop users whose roles are not part of the VSMS baseline.
if (!in_array($userRole, $allowedRoles, true)) {
    // Return the HTTP Forbidden status.
    http_response_code(403);

    // Stop execution and display a friendly message.
    exit("Access denied. Your role cannot view vehicle inventory.");
}

// Allow administrators and managers to manage vehicle records.
$canManageVehicles = in_array($userRole, ["Administrator", "Manager"], true);

// Create a helper function that safely displays text in HTML.
function escapeHtml($value): string
{
    // Convert special HTML characters to prevent cross-site scripting.
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Define the five vehicle statuses used by the VSMS database.
$vehicleStatuses = [
    "Available",
    "Reserved",
    "Sold",
    "Under Maintenance",
    "Unavailable"
];

// Create an empty array for search and filter conditions.
$conditions = ["is_active = 1"];

// Create an empty array for prepared-statement values.
$parameters = [];

// Read the search text submitted through the inventory form.
$search = trim($_GET["search"] ?? "");

// Read the selected vehicle status.
$statusFilter = trim($_GET["status"] ?? "");

// Read the selected vehicle category.
$categoryFilter = trim($_GET["category"] ?? "");

// Read the selected fuel type.
$fuelFilter = trim($_GET["fuel_type"] ?? "");

// Read the selected transmission type.
$transmissionFilter = trim($_GET["transmission"] ?? "");

// Read the minimum price filter.
$minPrice = trim($_GET["min_price"] ?? "");

// Read the maximum price filter.
$maxPrice = trim($_GET["max_price"] ?? "");

// Read the manufacturing year filter.
$yearFilter = trim($_GET["year"] ?? "");

// Read the maximum mileage filter.
$maxMileage = trim($_GET["max_mileage"] ?? "");

// Apply the search when the user has entered search text.
if ($search !== "") {
    // Search the VIN, make, model, and color fields.
    $conditions[] = "(vin LIKE ? OR make LIKE ? OR model LIKE ? OR color LIKE ?)";

    // Add the search value four times because the query has four placeholders.
    $searchValue = "%" . $search . "%";

    // Add the values in the same order as their SQL placeholders.
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
}

// Apply the status filter only when it matches an approved status.
if (in_array($statusFilter, $vehicleStatuses, true)) {
    // Add a condition to select vehicles with the chosen status.
    $conditions[] = "status = ?";

    // Add the selected status to the prepared-statement values.
    $parameters[] = $statusFilter;
}

// Apply the category filter when a category has been selected.
if ($categoryFilter !== "") {
    // Add a category condition to the SQL query.
    $conditions[] = "category = ?";

    // Add the category value safely as a query parameter.
    $parameters[] = $categoryFilter;
}

// Apply the fuel-type filter when a fuel type has been selected.
if ($fuelFilter !== "") {
    // Add a fuel-type condition to the SQL query.
    $conditions[] = "fuel_type = ?";

    // Add the fuel type as a query parameter.
    $parameters[] = $fuelFilter;
}

// Apply the transmission filter when a value has been selected.
if ($transmissionFilter !== "") {
    // Add a transmission condition to the SQL query.
    $conditions[] = "transmission = ?";

    // Add the transmission value as a query parameter.
    $parameters[] = $transmissionFilter;
}

// Apply the minimum price only when it is a valid non-negative number.
if ($minPrice !== "" && is_numeric($minPrice) && (float) $minPrice >= 0) {
    // Select vehicles whose prices are equal to or above the minimum.
    $conditions[] = "price >= ?";

    // Add the minimum price to the query parameters.
    $parameters[] = (float) $minPrice;
}

// Apply the maximum price only when it is a valid non-negative number.
if ($maxPrice !== "" && is_numeric($maxPrice) && (float) $maxPrice >= 0) {
    // Select vehicles whose prices are equal to or below the maximum.
    $conditions[] = "price <= ?";

    // Add the maximum price to the query parameters.
    $parameters[] = (float) $maxPrice;
}

// Apply the year filter only when it contains a valid four-digit year.
if ($yearFilter !== "" && ctype_digit($yearFilter) && (int) $yearFilter >= 1886 && (int) $yearFilter <= (int) date("Y") + 1) {
    // Select vehicles manufactured in the selected year.
    $conditions[] = "`year` = ?";

    // Add the year as an integer parameter.
    $parameters[] = (int) $yearFilter;
}

// Apply the maximum mileage only when it is a valid non-negative whole number.
if ($maxMileage !== "" && ctype_digit($maxMileage)) {
    // Select vehicles whose mileage does not exceed the entered value.
    $conditions[] = "mileage <= ?";

    // Add the maximum mileage as an integer parameter.
    $parameters[] = (int) $maxMileage;
}

// Join all search and filter conditions into one SQL WHERE expression.
$whereSql = implode(" AND ", $conditions);

// Prepare variables for the page results and error handling.
$vehicles = [];
$statusCounts = [];
$categories = [];
$fuelTypes = [];
$transmissions = [];
$totalVehicles = 0;
$databaseError = false;

// Try to retrieve the inventory information from MySQL.
try {
    // Retrieve the total count for each vehicle status.
    $countQuery = $pdo->query(
        "SELECT status, COUNT(*) AS total
         FROM vehicles
         WHERE is_active = 1
         GROUP BY status"
    );

    // Fetch all status counts as associative arrays.
    $countRows = $countQuery->fetchAll();

    // Initialize all five status counts to zero.
    foreach ($vehicleStatuses as $vehicleStatus) {
        // Store zero until the database provides a count.
        $statusCounts[$vehicleStatus] = 0;
    }

    // Replace zero with the actual count returned by MySQL.
    foreach ($countRows as $countRow) {
        // Store the database count under its matching status.
        $statusCounts[$countRow["status"]] = (int) $countRow["total"];
    }

    // Add the status counts to calculate the active inventory total.
    $totalVehicles = array_sum($statusCounts);

    // Retrieve the available vehicle categories for the filter.
    $categories = $pdo->query(
        "SELECT DISTINCT category
         FROM vehicles
         WHERE is_active = 1
         ORDER BY category"
    )->fetchAll(PDO::FETCH_COLUMN);

    // Retrieve the available fuel types for the filter.
    $fuelTypes = $pdo->query(
        "SELECT DISTINCT fuel_type
         FROM vehicles
         WHERE is_active = 1
         ORDER BY fuel_type"
    )->fetchAll(PDO::FETCH_COLUMN);

    // Retrieve the available transmission types for the filter.
    $transmissions = $pdo->query(
        "SELECT DISTINCT transmission
         FROM vehicles
         WHERE is_active = 1
         ORDER BY transmission"
    )->fetchAll(PDO::FETCH_COLUMN);

    // Build the inventory query using the selected search conditions.
    $vehicleSql = "
        SELECT vehicle_id, vin, make, model, `year`, category, price,
               mileage, fuel_type, transmission, color, status, image_path
        FROM vehicles
        WHERE $whereSql
        ORDER BY created_at DESC, vehicle_id DESC
    ";

    // Prepare the inventory query to protect against SQL injection.
    $vehicleQuery = $pdo->prepare($vehicleSql);

    // Execute the inventory query using the supplied search values.
    $vehicleQuery->execute($parameters);

    // Retrieve all matching vehicles from the database.
    $vehicles = $vehicleQuery->fetchAll();

    // Store the number of records matching the current filters.
    $matchingVehicles = count($vehicles);
} catch (PDOException $exception) {
    // Record that a database error occurred.
    $databaseError = true;

    // Store zero matching records when the query fails.
    $matchingVehicles = 0;

    // Log technical details privately instead of displaying them to users.
    error_log("VSMS vehicle inventory error: " . $exception->getMessage());
}

// Create a CSRF token if the existing session does not already contain one.
if (empty($_SESSION["csrf_token"])) {
    // Generate a secure random token for protected forms.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Store the CSRF token for use in the logout form.
$csrfToken = $_SESSION["csrf_token"];

// Define a helper function for vehicle status CSS classes.
function statusClass(string $status): string
{
    // Convert the status into a safe CSS class name.
    return match ($status) {
        "Available" => "status-available",
        "Reserved" => "status-reserved",
        "Sold" => "status-sold",
        "Under Maintenance" => "status-maintenance",
        "Unavailable" => "status-unavailable",
        default => "status-unavailable"
    };
}
?>
<!DOCTYPE html>
<!-- Declare this document as an HTML5 page. -->
<html lang="en">
<!-- Start the HTML document and identify its language. -->
<head>
    <!-- Set the character encoding so text displays correctly. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on desktop, tablet, and mobile devices. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Vehicle Inventory | VSMS</title>

    <!-- Load the existing dashboard stylesheet for the shared design. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Load the stylesheet dedicated to the vehicle inventory page. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">
</head>
<!-- Finish the document head. -->
<body>
    <!-- Create the main dashboard layout used by the VSMS application. -->
    <div class="dashboard-layout">

        <!-- Create the dark navigation sidebar. -->
        <aside class="sidebar">

            <!-- Display the VSMS brand at the top of the sidebar. -->
            <div class="brand">
                <div class="brand-logo">V</div>
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>
            </div>

            <!-- Group the navigation links together. -->
            
            <!-- Display all available application navigation links. -->
            <nav class="sidebar-navigation">

                <!-- Display the navigation section heading. -->
                <p class="navigation-heading">MAIN MENU</p>

                <!-- Link to the Dashboard. -->
                <a href="dashboard.php" class="nav-link">
                    <span class="nav-icon">▦</span>
                    <span>Dashboard</span>
                </a>

                <!-- Highlight the current Vehicles page. -->
                <a href="vehicles.php" class="nav-link active">
                    <span class="nav-icon">🚘</span>
                    <span>Vehicles</span>
                </a>

                <!-- Link to Customer Management. -->
                <a href="customers.php" class="nav-link">
                    <span class="nav-icon">♙</span>
                    <span>Customers</span>
                </a>

                <!-- Link to Reservation Management. -->
                <a href="reservations.php" class="nav-link">
                    <span class="nav-icon">▣</span>
                    <span>Reservations</span>
                </a>

                <!-- Link to Sales Management. -->
                <a href="sales.php" class="nav-link">
                    <span class="nav-icon">▤</span>
                    <span>Sales</span>
                </a>

                <!-- Link to Payment Management. -->
                <a href="payments.php" class="nav-link">
                    <span class="nav-icon">$</span>
                    <span>Payments</span>
                </a>
                <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
    <span class="nav-icon">◷</span>
    <span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
    <span class="nav-icon">▧</span>
    <span>Invoices</span>
</a>

                <!-- Show Employee Management to Administrator and Manager. -->
                <?php if (in_array($userRole, ["Administrator", "Manager"], true)): ?>
                    <a href="employees.php" class="nav-link">
                        <span class="nav-icon">♧</span>
                        <span>Employees</span>
                    </a>
                <?php endif; ?>
                <?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
    <span class="nav-icon">♙</span>
    <span>User Accounts</span>
</a>

<?php endif; ?>
                <!-- Show Reports to Administrator and Manager. -->
                <?php if (in_array($userRole, ["Administrator", "Manager"], true)): ?>
                    <a href="reports.php" class="nav-link">
                        <span class="nav-icon">▥</span>
                        <span>Reports</span>
                    </a>
                <?php endif; ?>

            </nav>
            <div class="sidebar-footer">
                <p>Vehicle Sales &amp; Management System</p>
                <span>Development version</span>
            </div>

        </aside>

        <!-- Create the main content area beside the sidebar. -->
        <main class="main-content">
        <header class="topbar">
        

<!-- Display the current page location. -->
<div class="breadcrumb">
<strong>Vehicle Inventory</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
        
    </div>

    <!-- Display the user's name and role. -->
    <div class="user-information">
    <a href="my_profile.php" class="profile-name-link">
                    <?= escapeHtml($user["full_name"]) ?>
</a>
                        <span><?= escapeHtml($userRole) ?></span>
    </div>

    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>

            <!-- Place the vehicle inventory page content in the workspace. -->
            <section class="page-content">

                <!-- Introduce the inventory page and its purpose. -->
                
<!-- Introduce the inventory page and its available actions. -->
<div class="page-heading">
    <!-- Display the inventory title and description. -->
    <div>
        <h1>Vehicle Inventory</h1>
        <p>View, search, and monitor vehicles registered in the dealership.</p>
    </div>

    <!-- Display the Add Vehicle action only for authorized roles. -->
    <?php if ($canManageVehicles): ?>
        <a href="add_vehicle.php" class="primary-button">
            + Add Vehicle
        </a>
    <?php else: ?>
        <!-- Explain that the current user has viewing permissions. -->
        <span class="permission-note">Inventory viewing access</span>
    <?php endif; ?>
</div>

<!-- Display a confirmation after a vehicle has been successfully added. -->
<?php if (isset($_GET["added"]) && $_GET["added"] === "1"): ?>
    <div class="inventory-message success-message">
        Vehicle added successfully to the inventory.
    </div>
    <?php endif; ?>
<?php if (isset($_GET["updated"]) && $_GET["updated"] === "1"): ?>
    <!-- Display a message after successfully updating a vehicle. -->
    <div class="success-message">
        Vehicle updated successfully.
    </div>
<?php endif; ?>





                <!-- Display a friendly database error instead of technical details. -->
                <?php if ($databaseError): ?>
                    <div class="inventory-message error-message">
                        Unable to load vehicle inventory. Please try again later.
                    </div>
                <?php else: ?>

                    <!-- Display live counts for all vehicle statuses. -->
                    <div class="inventory-summary">

                        <!-- Display the total number of active vehicle records. -->
                        <article class="summary-card">
                            <span class="summary-label">Total Vehicles</span>
                            <strong><?= $totalVehicles ?></strong>
                            <small>Active inventory records</small>
                        </article>

                        <!-- Display the number of available vehicles. -->
                        <article class="summary-card">
                            <span class="summary-label">Available</span>
                            <strong><?= $statusCounts["Available"] ?></strong>
                            <small>Ready for reservation or sale</small>
                        </article>

                        <!-- Display the number of reserved vehicles. -->
                        <article class="summary-card">
                            <span class="summary-label">Reserved</span>
                            <strong><?= $statusCounts["Reserved"] ?></strong>
                            <small>Currently reserved</small>
                        </article>

                        <!-- Display the number of sold vehicles. -->
                        <article class="summary-card">
                            <span class="summary-label">Sold</span>
                            <strong><?= $statusCounts["Sold"] ?></strong>
                            <small>Completed vehicle sales</small>
                        </article>

                        <!-- Display the number of vehicles under maintenance. -->
                        <article class="summary-card">
                            <span class="summary-label">Maintenance</span>
                            <strong><?= $statusCounts["Under Maintenance"] ?></strong>
                            <small>Under maintenance work</small>
                        </article>

                        <!-- Display the number of unavailable vehicles. -->
                        <article class="summary-card">
                            <span class="summary-label">Unavailable</span>
                            <strong><?= $statusCounts["Unavailable"] ?></strong>
                            <small>Not available for operations</small>
                        </article>
                    </div>

                    <!-- Create the search and filter card. -->
                    <section class="inventory-card">

                        <!-- Introduce the search and filter controls. -->
                        <div class="card-heading">
                            <div>
                                <h2>Search and Filter Vehicles</h2>
                                <p>Find vehicles using their details and inventory attributes.</p>
                            </div>
                        </div>

                        <!-- Submit search and filter values using the GET method. -->
                        <form action="vehicles.php" method="GET" class="filter-form">

                            <!-- Search VIN, manufacturer, model, or color. -->
                            <div class="filter-field search-field">
                                <label for="search">Search vehicles</label>
                                <input
                                    type="search"
                                    id="search"
                                    name="search"
                                    placeholder="VIN, make, model, or color"
                                    value="<?= escapeHtml($search) ?>"
                                >
                            </div>

                            <!-- Filter vehicles by their current status. -->
                            <div class="filter-field">
                                <label for="status">Status</label>
                                <select id="status" name="status">
                                    <option value="">All statuses</option>
                                    <?php foreach ($vehicleStatuses as $vehicleStatus): ?>
                                        <option
                                            value="<?= escapeHtml($vehicleStatus) ?>"
                                            <?= $statusFilter === $vehicleStatus ? "selected" : "" ?>
                                        >
                                            <?= escapeHtml($vehicleStatus) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Filter vehicles by category. -->
                            <div class="filter-field">
                                <label for="category">Category</label>
                                <select id="category" name="category">
                                    <option value="">All categories</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option
                                            value="<?= escapeHtml($category) ?>"
                                            <?= $categoryFilter === $category ? "selected" : "" ?>
                                        >
                                            <?= escapeHtml($category) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Filter vehicles by fuel type. -->
                            <div class="filter-field">
                                <label for="fuel_type">Fuel type</label>
                                <select id="fuel_type" name="fuel_type">
                                    <option value="">All fuel types</option>
                                    <?php foreach ($fuelTypes as $fuelType): ?>
                                        <option
                                            value="<?= escapeHtml($fuelType) ?>"
                                            <?= $fuelFilter === $fuelType ? "selected" : "" ?>
                                        >
                                            <?= escapeHtml($fuelType) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Filter vehicles by transmission type. -->
                            <div class="filter-field">
                                <label for="transmission">Transmission</label>
                                <select id="transmission" name="transmission">
                                    <option value="">All transmissions</option>
                                    <?php foreach ($transmissions as $transmission): ?>
                                        <option
                                            value="<?= escapeHtml($transmission) ?>"
                                            <?= $transmissionFilter === $transmission ? "selected" : "" ?>
                                        >
                                            <?= escapeHtml($transmission) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Filter vehicles by their minimum selling price. -->
                            <div class="filter-field">
                                <label for="min_price">Minimum price</label>
                                <input
                                    type="number"
                                    id="min_price"
                                    name="min_price"
                                    min="0"
                                    step="0.01"
                                    placeholder="Minimum"
                                    value="<?= escapeHtml($minPrice) ?>"
                                >
                            </div>

                            <!-- Filter vehicles by their maximum selling price. -->
                            <div class="filter-field">
                                <label for="max_price">Maximum price</label>
                                <input
                                    type="number"
                                    id="max_price"
                                    name="max_price"
                                    min="0"
                                    step="0.01"
                                    placeholder="Maximum"
                                    value="<?= escapeHtml($maxPrice) ?>"
                                >
                            </div>

                            <!-- Filter vehicles by manufacturing year. -->
                            <div class="filter-field">
                                <label for="year">Manufacturing year</label>
                                <input
                                    type="number"
                                    id="year"
                                    name="year"
                                    min="1886"
                                    max="<?= (int) date("Y") + 1 ?>"
                                    placeholder="Example: 2024"
                                    value="<?= escapeHtml($yearFilter) ?>"
                                >
                            </div>

                            <!-- Filter vehicles by maximum mileage. -->
                            <div class="filter-field">
                                <label for="max_mileage">Maximum mileage</label>
                                <input
                                    type="number"
                                    id="max_mileage"
                                    name="max_mileage"
                                    min="0"
                                    step="1"
                                    placeholder="Maximum mileage"
                                    value="<?= escapeHtml($maxMileage) ?>"
                                >
                            </div>

                            <!-- Group the search and reset actions together. -->
                            <div class="filter-actions">
                                <button type="submit" class="primary-button">Apply Filters</button>
                                <a href="vehicles.php" class="secondary-button">Clear Filters</a>
                            </div>
                        </form>
                    </section>

                    <!-- Display the vehicle records returned by the database. -->
                    <section class="inventory-card vehicle-list-card">

                        <!-- Show the number of vehicles matching the current filters. -->
                        <div class="card-heading vehicle-list-heading">
                            <div>
                                <h2>All Vehicles</h2>
                                <p><?= $matchingVehicles ?> matching vehicle record(s)</p>
                            </div>
                        </div>

                        <!-- Show the vehicle table when matching records exist. -->
                        <?php if (!empty($vehicles)): ?>
                            <div class="table-responsive">
                                <table class="vehicle-table">

                                    <!-- Define the headings for each vehicle column. -->
                                    <thead>
                                    <!-- Define the column headings for the vehicle inventory table. -->
<tr>
    <!-- Display the vehicle name and model. -->
    <th>Vehicle</th>

    <!-- Display the vehicle identification number. -->
    <th>VIN</th>

    <!-- Display the manufacturing year. -->
    <th>Year</th>

    <!-- Display the vehicle category. -->
    <th>Category</th>

    <!-- Display the vehicle selling price. -->
    <th>Price</th>

    <!-- Display the vehicle mileage. -->
    <th>Mileage</th>

    <!-- Display the current inventory status. -->
    <th>Status</th>

    <!-- Provide actions for each vehicle. -->
    <th>Actions</th>
</tr>
                                    </thead>

                                    <!-- Display each vehicle returned by MySQL. -->
                                    <tbody>
                                        <?php foreach ($vehicles as $vehicle): ?>
                                            <tr>

                                                <!-- Display the vehicle photograph or a clean placeholder. -->
                                                <td>
                                                    <div class="vehicle-identity">
                                                        <?php if (!empty($vehicle["image_path"])): ?>
                                                            <img
                                                                src="<?= escapeHtml($vehicle["image_path"]) ?>"
                                                                alt="<?= escapeHtml($vehicle["make"] . " " . $vehicle["model"]) ?>"
                                                                class="vehicle-thumbnail"
                                                            >
                                                        <?php else: ?>
                                                            <div class="vehicle-placeholder">CAR</div>
                                                        <?php endif; ?>

                                                        <div>
                                                            <strong>
                                                                <?= escapeHtml($vehicle["make"] . " " . $vehicle["model"]) ?>
                                                            </strong>
                                                            <small><?= escapeHtml($vehicle["color"]) ?></small>
                                                        </div>
                                                    </div>
                                                </td>

                                                <!-- Display the unique vehicle identification number. -->
                                                <td><?= escapeHtml($vehicle["vin"]) ?></td>

                                                <!-- Display the vehicle manufacturing year. -->
                                                <td><?= escapeHtml($vehicle["year"]) ?></td>

                                                <!-- Display the vehicle category. -->
                                                <td><?= escapeHtml($vehicle["category"]) ?></td>

                                                <!-- Display the vehicle selling price. -->
                                                <td class="price-cell">
                                                    <?= number_format((float) $vehicle["price"], 2) ?>
                                                </td>

                                                <!-- Display the vehicle mileage. -->
                                                <td><?= number_format((int) $vehicle["mileage"]) ?> km</td>

                                                <!-- Display the vehicle's current inventory status. -->
                                                <td>
                                                    <span class="status-badge <?= escapeHtml(statusClass($vehicle["status"])) ?>">
                                                        <?= escapeHtml($vehicle["status"]) ?>
                                                    </span>
                                                </td>
                                                <!-- Create the actions cell for the current vehicle. -->
                                                <td>
                                                    <!-- Open the details page using this vehicle's database ID. -->
                                                    <a
                                                        href="vehicle_details.php?id=<?= (int) $vehicle["vehicle_id"] ?>"
                                                        class="secondary-button"
                                                    >
                                                        View Details
                                                </a>
                                                <?php if ($canManageVehicles): ?>
                                                        <!-- Show the Edit link only to users who can manage vehicles. -->
                                                        <a
                                                          href="edit_vehicle.php?id=<?= (int) $vehicle["vehicle_id"] ?>"
                                                         class="secondary-button"
                                                        >
                                                            Edit
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                        <!-- Explain when the database contains no matching vehicles. -->
                        <?php else: ?>
                            <div class="empty-inventory">
                                <div class="empty-inventory-icon">🚘</div>
                                <h3>No vehicles found</h3>
                                <p>
                                    <?php if ($totalVehicles === 0): ?>
                                        Your inventory is currently empty. Add vehicles in the next development stage.
                                    <?php else: ?>
                                        No vehicles match your search or filters. Try changing your search criteria.
                                    <?php endif; ?>
                                </p>
                            </div>
                        <?php endif; ?>
                    </section>
                <?php endif; ?>
            </section>
        </main>
    </div>
</body>
<!-- Finish the HTML document. -->
</html>
