
<?php
// Load the existing authentication functions and database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to be logged in.
requireLogin();

// Get the currently logged-in user.
$user = currentUser();

// If the account is no longer active, return to login.
if ($user === null) {
    $_SESSION = [];
    session_destroy();
    redirect("login.php");
}

// Only Administrators can edit employee records.
if ($user["role_name"] !== "Administrator") {
    http_response_code(403);
    exit("Access denied. Only Administrators can edit employee records.");
}

// Escape values before displaying them in HTML.
function editEmployeeEscape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Count characters without requiring the PHP mbstring extension.
function editEmployeeLength(string $value): int
{
    $result = preg_match_all('/./us', $value, $matches);

    return $result !== false ? $result : strlen($value);
}

// Read and validate the employee ID from the URL.
$employeeId = $_GET["id"] ?? "";

if (!ctype_digit((string) $employeeId) || (int) $employeeId < 1) {
    http_response_code(404);
    exit("Employee not found. Please provide a valid employee ID.");
}

$employeeId = (int) $employeeId;

// Prepare the default page values.
$employee = null;
$availableUsers = [];
$errors = [];
$successMessage = "";
$databaseError = false;

// Load the employee and its currently linked account.
try {
    $employeeQuery = $pdo->prepare(
        "SELECT
            employee_id,
            user_id,
            full_name,
            phone,
            email,
            position,
            status
         FROM employees
         WHERE employee_id = ?
         LIMIT 1"
    );

    $employeeQuery->execute([$employeeId]);
    $employee = $employeeQuery->fetch(PDO::FETCH_ASSOC);

    // Return a not-found response if the employee does not exist.
    if (!$employee) {
        http_response_code(404);
        exit("The requested employee could not be found.");
    }

    // Load active user accounts that are not linked to another employee.
    // Also include this employee's currently linked account.
    $usersQuery = $pdo->prepare(
    "SELECT
        u.user_id,
        u.full_name,
        u.username,
        u.email,
        u.status,
        r.role_name
     FROM users AS u
     INNER JOIN roles AS r
        ON r.role_id = u.role_id
     WHERE
        (
            u.status = 'active'
            AND NOT EXISTS (
                SELECT 1
                FROM employees AS e
                WHERE e.user_id = u.user_id
                  AND e.employee_id <> ?
            )
        )
        OR u.user_id = ?
     ORDER BY u.full_name ASC"
);

    $usersQuery->execute([
        $employeeId,
        $employee["user_id"]
    ]);

    $availableUsers = $usersQuery->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {
    // Log technical details privately.
    error_log("VSMS edit employee loading error: " . $exception->getMessage());

    // Show a friendly error instead of database details.
    $databaseError = true;
}

// Prepare a CSRF token if one does not already exist.
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION["csrf_token"];

// Prepare form values using the existing employee information.
$formValues = [
    "full_name" => $employee["full_name"] ?? "",
    "phone" => $employee["phone"] ?? "",
    "email" => $employee["email"] ?? "",
    "position" => $employee["position"] ?? "",
    "user_id" => $employee["user_id"] ?? "",
    "status" => $employee["status"] ?? "Active"
];

// Process the form only when it is submitted using POST.
if ($_SERVER["REQUEST_METHOD"] === "POST" && !$databaseError) {

    // Read the submitted CSRF token.
    $submittedToken = $_POST["csrf_token"] ?? "";

    // Verify that the form belongs to the current session.
    if (!hash_equals($csrfToken, $submittedToken)) {
        $errors[] = "Your session verification failed. Please refresh and try again.";
    }

    // Collect and trim the submitted employee information.
    $formValues["full_name"] = trim($_POST["full_name"] ?? "");
    $formValues["phone"] = trim($_POST["phone"] ?? "");
    $formValues["email"] = trim($_POST["email"] ?? "");
    $formValues["position"] = trim($_POST["position"] ?? "");
    $formValues["user_id"] = $_POST["user_id"] ?? "";
    $formValues["status"] = $_POST["status"] ?? "";

    // Validate the employee's full name.
    if ($formValues["full_name"] === "") {
        $errors[] = "Employee full name is required.";
    } elseif (editEmployeeLength($formValues["full_name"]) > 150) {
        $errors[] = "Employee full name cannot exceed 150 characters.";
    }

    // Validate the employee's phone number.
    // It must contain exactly 10 digits and start with 07.
    if (!preg_match('/^07[0-9]{8}$/', $formValues["phone"])) {
        $errors[] = "Phone number must contain exactly 10 digits and start with 07.";
    }

    // Validate the optional email address.
    if ($formValues["email"] !== "") {
        if (!filter_var($formValues["email"], FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Please enter a valid email address.";
        } elseif (editEmployeeLength($formValues["email"]) > 150) {
            $errors[] = "Email address cannot exceed 150 characters.";
        }
    }

    // Validate the employee's position.
    if ($formValues["position"] === "") {
        $errors[] = "Employee position is required.";
    } elseif (editEmployeeLength($formValues["position"]) > 100) {
        $errors[] = "Employee position cannot exceed 100 characters.";
    }

    // Validate the employee status.
    if (!in_array($formValues["status"], ["Active", "Inactive"], true)) {
        $errors[] = "Please select a valid employee status.";
    }

    // Validate the optional linked user account.
    $selectedUserId = null;

    if ($formValues["user_id"] !== "") {

        // The selected account ID must be a positive integer.
        if (
            !ctype_digit((string) $formValues["user_id"])
            || (int) $formValues["user_id"] < 1
        ) {
            $errors[] = "Please select a valid system account.";
        } else {
            $selectedUserId = (int) $formValues["user_id"];
        }
    }

    // Save the employee only if all form validations pass.
    if (empty($errors)) {

        try {
            // Verify that the selected account exists and is available.
            if ($selectedUserId !== null) {

                $accountQuery = $pdo->prepare(
                    "SELECT
                        u.user_id,
                        u.status,
                        (
                            SELECT COUNT(*)
                            FROM employees AS e
                            WHERE e.user_id = u.user_id
                              AND e.employee_id <> ?
                        ) AS linked_elsewhere
                     FROM users AS u
                     WHERE u.user_id = ?
                     LIMIT 1"
                );

                $accountQuery->execute([
                    $employeeId,
                    $selectedUserId
                ]);

                $selectedAccount = $accountQuery->fetch(PDO::FETCH_ASSOC);

                // The account must exist.
                if (!$selectedAccount) {
                    $errors[] = "The selected system account does not exist.";
                }

                // A new linked account must be active.
                elseif (
                    $selectedAccount["status"] !== "active"
                    && (int) $selectedUserId !== (int) $employee["user_id"]
                ) {
                    $errors[] = "You can only link an active system account.";
                }

                // Do not allow an account linked to another employee.
                elseif ((int) $selectedAccount["linked_elsewhere"] > 0) {
                    $errors[] = "This system account is already linked to another employee.";
                }
            }

            // Update the employee only when account validation also passes.
            if (empty($errors)) {

                // Prepare a parameterized UPDATE statement.
                $updateQuery = $pdo->prepare(
                    "UPDATE employees
                     SET
                        full_name = :full_name,
                        phone = :phone,
                        email = :email,
                        position = :position,
                        user_id = :user_id,
                        status = :status
                     WHERE employee_id = :employee_id"
                );

                // Execute the update using safely bound values.
                $updateQuery->execute([
                    ":full_name" => $formValues["full_name"],
                    ":phone" => $formValues["phone"],
                    ":email" => $formValues["email"] !== ""
                        ? $formValues["email"]
                        : null,
                    ":position" => $formValues["position"],
                    ":user_id" => $selectedUserId,
                    ":status" => $formValues["status"],
                    ":employee_id" => $employeeId
                ]);

                // Return to the employee details page after a successful update.
                redirect("employee_details.php?id=" . $employeeId . "&updated=1");
            }

        } catch (PDOException $exception) {
            // Log technical details privately.
            error_log("VSMS edit employee update error: " . $exception->getMessage());

            // Show a friendly message to the Administrator.
            $errors[] = "Unable to update the employee. Please check the information and try again.";
        }
    }
}

// Prepare the employee's linked account ID for the dropdown.
$currentLinkedUserId = $employee["user_id"] ?? "";

// Display a success message when returning after an update.
if (isset($_GET["updated"]) && $_GET["updated"] === "1") {
    $successMessage = "Employee information was updated successfully.";
}
?>
<!DOCTYPE html>
<!-- Declare the page as an HTML5 document. -->
<html lang="en">

<head>
    <!-- Set the character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Edit Employee | VSMS</title>

    <!-- Load the existing dashboard styles. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Load the existing vehicle and form styles. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <!-- Add styles specifically for this form. -->
    <style>
        /* Keep the form at a readable width. */
        .employee-form-card {
            max-width: 900px;
            margin-top: 20px;
            padding: 26px;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
        }

        /* Arrange form fields in two columns. */
        .employee-form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
        }

        /* Arrange each label and input vertically. */
        .employee-form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        /* Make labels clear and readable. */
        .employee-form-group label {
            color: #172033;
            font-size: 14px;
            font-weight: 600;
        }

        /* Style the form inputs and dropdowns. */
        .employee-form-group input,
        .employee-form-group select {
            width: 100%;
            min-height: 44px;
            padding: 10px 12px;
            border: 1px solid #d1d5db;
            border-radius: 7px;
            background: #ffffff;
            color: #172033;
            font: inherit;
        }

        /* Highlight an input when the user selects it. */
        .employee-form-group input:focus,
        .employee-form-group select:focus {
            outline: 2px solid #f5a06a;
            border-color: #f0783c;
        }

        /* Explain optional fields. */
        .employee-form-help {
            color: #6b7280;
            font-size: 12px;
        }

        /* Make the form buttons appear in one row. */
        .employee-form-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 26px;
        }

        /* Style validation and success messages. */
        .employee-form-message {
            padding: 13px 16px;
            margin-bottom: 18px;
            border-radius: 8px;
        }

        /* Style the error message. */
        .employee-form-error {
            color: #991b1b;
            background: #fef2f2;
            border: 1px solid #fecaca;
        }

        /* Style the success message. */
        .employee-form-success {
            color: #166534;
            background: #f0fdf4;
            border: 1px solid #bbf7d0;
        }

        /* Make the form one column on smaller screens. */
        @media (max-width: 700px) {
            .employee-form-grid {
                grid-template-columns: 1fr;
            }

            .employee-form-card {
                padding: 18px;
            }
        }
    </style>
</head>

<body>
    <!-- Create the main dashboard layout. -->
    <div class="dashboard-layout">

        <!-- Create the left navigation sidebar. -->
        <aside class="sidebar">

<!-- Display the system logo and name. -->
<div class="brand">

    <!-- Display the short system name inside a logo box. -->
    <div class="brand-logo">V</div>

    <!-- Display the full system name. -->
    <div class="brand-text">
        <h2>VSMS</h2>
        <p>Vehicle Management</p>
    </div>

<!-- Close the brand section. -->
</div>

<!-- Display the main sidebar navigation. -->


<!-- Display all available system navigation links. -->
<nav class="sidebar-navigation">

    <!-- Display the navigation section heading. -->
    <p class="navigation-heading">MAIN MENU</p>

    <!-- Link to the Dashboard. -->
    <a href="dashboard.php" class="nav-link active">
        <span class="nav-icon">▦</span>
        <span>Dashboard</span>
    </a>

    <!-- Link to Vehicle Management. -->
    <a href="vehicles.php" class="nav-link">
        <span class="nav-icon">🚘</span>
        <span>Vehicles</span>
    </a>

    <!-- Link to Customer Management. -->
    <a href="customers.php" class="nav-link">
        <span class="nav-icon">♙</span>
        <span>Customers</span>
    </a>

    <!-- Link to Reservation Management. -->
    <a href="reservations.php" class="nav-link">
        <span class="nav-icon">▣</span>
        <span>Reservations</span>
    </a>

    <!-- Link to Sales Management. -->
    <a href="sales.php" class="nav-link">
        <span class="nav-icon">▤</span>
        <span>Sales</span>
    </a>

    <!-- Link to Payment Management. -->
    <a href="payments.php" class="nav-link">
        <span class="nav-icon">$</span>
        <span>Payments</span>
    </a>
    <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
<span class="nav-icon">◷</span>
<span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
<span class="nav-icon">▧</span>
<span>Invoices</span>
</a>

    <!-- Show employee management only to authorized management roles. -->
    <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

        <a href="employees.php" class="nav-link">
            <span class="nav-icon">♧</span>
            <span>Employees</span>
        </a>

    <?php endif; ?>
    <!-- Only Administrators can access User Account Management. -->
<?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
<span class="nav-icon">♙</span>
<span>User Accounts</span>
</a>

<?php endif; ?>

    <!-- Show reports only to authorized management roles. -->
    <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

        <a href="reports.php" class="nav-link">
            <span class="nav-icon">▥</span>
            <span>Reports</span>
        </a>

    <?php endif; ?>

<!-- Close the navigation section. -->
</nav>


<!-- Display a short project description at the bottom of the sidebar. -->
<div class="sidebar-footer">
    <p>Vehicle Sales &amp; Management System</p>
    <span>Development version</span>
</div>

<!-- Close the sidebar. -->
</aside>

        <!-- Create the main workspace. -->
        <main class="main-content">

            <!-- Display the page header. -->
            <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Edit Employee</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    <div class="user-information">
                    <a href="my_profile.php" class="profile-name-link"><?= editEmployeeEscape($user["full_name"]) ?></a>
                        <span><?= editEmployeeEscape($user["role_name"]) ?></span>
                    </div>

    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>
           

            <!-- Display the employee edit form. -->
            <section class="page-content">

                <div class="page-heading">
                    <div>
                        <h1>Edit Employee</h1>
                        <p>Update employee information and linked system account.</p>
                    </div>

                    <a
                        href="employee_details.php?id=<?= $employeeId ?>"
                        class="secondary-button"
                    >
                        Cancel
                    </a>
                </div>

                <!-- Display database loading errors. -->
                <?php if ($databaseError): ?>
                    <div class="employee-form-message employee-form-error">
                        Unable to load employee information. Please try again later.
                    </div>

                <?php else: ?>

                    <!-- Display any success message. -->
                    <?php if ($successMessage !== ""): ?>
                        <div class="employee-form-message employee-form-success">
                            <?= editEmployeeEscape($successMessage) ?>
                        </div>
                    <?php endif; ?>

                    <!-- Display all validation errors. -->
                    <?php if (!empty($errors)): ?>
                        <div class="employee-form-message employee-form-error">
                            <strong>Please correct the following:</strong>
                            <ul>
                                <?php foreach ($errors as $error): ?>
                                    <li><?= editEmployeeEscape($error) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <!-- Create the employee update form. -->
                    <form method="POST" action="edit_employee.php?id=<?= $employeeId ?>">

                        <!-- Place the form fields inside a white card. -->
                        <div class="employee-form-card">

                            <!-- Send the session CSRF token with the form. -->
                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= editEmployeeEscape($csrfToken) ?>"
                            >

                            <div class="employee-form-grid">

                                <!-- Employee full name. -->
                                <div class="employee-form-group">
                                    <label for="full_name">Full Name *</label>
                                    <input
                                        type="text"
                                        id="full_name"
                                        name="full_name"
                                        maxlength="150"
                                        value="<?= editEmployeeEscape($formValues["full_name"]) ?>"
                                        required
                                    >
                                </div>

                                <!-- Employee phone number. -->
                                <div class="employee-form-group">
                                    <label for="phone">Phone Number *</label>
                                    <input
    type="tel"
    id="phone"
    name="phone"
    inputmode="numeric"
    pattern="07[0-9]{8}"
    minlength="10"
    maxlength="10"
    value="<?= editEmployeeEscape($formValues["phone"]) ?>"
    placeholder="07XXXXXXXX"
    title="Enter exactly 10 digits starting with 07."
    required
>
                                </div>

                                <!-- Employee email address. -->
                                <div class="employee-form-group">
                                    <label for="email">Email Address</label>
                                    <input
                                        type="email"
                                        id="email"
                                        name="email"
                                        maxlength="150"
                                        value="<?= editEmployeeEscape($formValues["email"]) ?>"
                                    >
                                    <span class="employee-form-help">Optional field.</span>
                                </div>

                                <!-- Employee job position. -->
                                <div class="employee-form-group">
                                    <label for="position">Position *</label>
                                    <input
                                        type="text"
                                        id="position"
                                        name="position"
                                        maxlength="100"
                                        value="<?= editEmployeeEscape($formValues["position"]) ?>"
                                        required
                                    >
                                </div>

                                <!-- Link an existing system account if required. -->
                                <div class="employee-form-group">
                                    <label for="user_id">Linked System Account</label>

                                    <select id="user_id" name="user_id">
                                        <option value="">No linked account</option>

                                        <?php foreach ($availableUsers as $availableUser): ?>
                                            <option
                                                value="<?= (int) $availableUser["user_id"] ?>"
                                                <?= (string) $formValues["user_id"] === (string) $availableUser["user_id"] ? "selected" : "" ?>
                                            >
                                            <?= editEmployeeEscape(
    $availableUser["full_name"]
    . " (" . $availableUser["username"] . ")"
    . " - " . $availableUser["role_name"]
    . (
        $availableUser["status"] !== "active"
            ? " - Inactive account"
            : ""
    )
) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>

                                    <span class="employee-form-help">
                                        Only active accounts not linked to another employee can be newly selected.
                                    </span>
                                </div>

                                <!-- Set the employee's employment status. -->
                                <div class="employee-form-group">
                                    <label for="status">Employee Status *</label>

                                    <select id="status" name="status" required>
                                        <option
                                            value="Active"
                                            <?= $formValues["status"] === "Active" ? "selected" : "" ?>
                                        >
                                            Active
                                        </option>

                                        <option
                                            value="Inactive"
                                            <?= $formValues["status"] === "Inactive" ? "selected" : "" ?>
                                        >
                                            Inactive
                                        </option>
                                    </select>
                                </div>

                            </div>

                            <!-- Display the form actions. -->
                            <div class="employee-form-actions">

                                <button type="submit" class="primary-button">
                                    Save Changes
                                </button>

                                <a
                                    href="employee_details.php?id=<?= $employeeId ?>"
                                    class="secondary-button"
                                >
                                    Cancel
                                </a>

                            </div>
                        </div>
                    </form>

                <?php endif; ?>

            </section>
        </main>
    </div>
</body>
</html>
