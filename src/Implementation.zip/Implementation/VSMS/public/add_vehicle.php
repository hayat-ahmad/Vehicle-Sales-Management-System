
<?php
// Load the existing authentication functions and database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to log in before accessing this page.
requireLogin();

// Retrieve the current user's information from the database.
$user = currentUser();

// Check whether the account is still active.
if ($user === null) {
    // Clear the current session data.
    $_SESSION = [];

    // Destroy the current session.
    session_destroy();

    // Redirect the user to the login page.
    redirect("login.php");
}

// Store the current user's role.
$userRole = $user["role_name"];

// Allow only administrators and managers to add vehicles.
if (!in_array($userRole, ["Administrator", "Manager"], true)) {
    // Return an HTTP 403 Forbidden response.
    http_response_code(403);

    // Stop the page from continuing.
    exit("Access denied. You cannot add vehicle records.");
}

// Define a helper function to safely display submitted values.
function escapeVehicleValue($value): string
{
    // Convert special HTML characters into safe HTML entities.
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Define the permitted vehicle status values.
$allowedStatuses = [
    "Available",
    "Reserved",
    "Sold",
    "Under Maintenance",
    "Unavailable"
];

// Define the permitted image file types and their extensions.
$allowedImageTypes = [
    "image/jpeg" => "jpg",
    "image/png" => "png",
    "image/webp" => "webp"
];

// Define the maximum permitted image size as five megabytes.
$maximumImageSize = 5 * 1024 * 1024;

// Prepare an array to store form errors.
$errors = [];

// Prepare an array to retain submitted form values.
$formData = [
    "vin" => "",
    "make" => "",
    "model" => "",
    "year" => "",
    "category" => "",
    "price" => "",
    "mileage" => "",
    "fuel_type" => "",
    "transmission" => "",
    "color" => "",
    "status" => "Available",
    "description" => ""
];

// Generate a CSRF token if the session does not already contain one.
if (empty($_SESSION["csrf_token"])) {
    // Generate a secure random token.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Store the current session token for the form.
$csrfToken = $_SESSION["csrf_token"];

// Process the form only when the user submits it using POST.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Retrieve the submitted CSRF token.
    $submittedToken = $_POST["csrf_token"] ?? "";

    // Verify that the submitted token matches the session token.
    if (!is_string($submittedToken) || !hash_equals($csrfToken, $submittedToken)) {
        // Add an error when the token is missing or incorrect.
        $errors[] = "Your form session is invalid. Please reload the page and try again.";
    }

    // Read the VIN and remove unnecessary spaces.
    $formData["vin"] = strtoupper(trim($_POST["vin"] ?? ""));

    // Read the vehicle manufacturer.
    $formData["make"] = trim($_POST["make"] ?? "");

    // Read the vehicle model.
    $formData["model"] = trim($_POST["model"] ?? "");

    // Read the manufacturing year.
    $formData["year"] = trim($_POST["year"] ?? "");

    // Read the vehicle category.
    $formData["category"] = trim($_POST["category"] ?? "");

    // Read the vehicle selling price.
    $formData["price"] = trim($_POST["price"] ?? "");

    // Read the vehicle mileage.
    $formData["mileage"] = trim($_POST["mileage"] ?? "");

    // Read the vehicle fuel type.
    $formData["fuel_type"] = trim($_POST["fuel_type"] ?? "");

    // Read the vehicle transmission type.
    $formData["transmission"] = trim($_POST["transmission"] ?? "");

    // Read the vehicle exterior color.
    $formData["color"] = trim($_POST["color"] ?? "");

    // Read the requested vehicle status.
    $formData["status"] = trim($_POST["status"] ?? "Available");

    // Read the optional vehicle description.
    $formData["description"] = trim($_POST["description"] ?? "");

    // Check whether the VIN has been provided.
    if ($formData["vin"] === "") {
        // Require a VIN before saving the vehicle.
        $errors[] = "Vehicle identification number (VIN) is required.";
    } elseif (strlen($formData["vin"]) > 50) {
        // Prevent VIN values longer than the database column.
        $errors[] = "The VIN cannot exceed 50 characters.";
    }

    // Check whether the manufacturer has been provided.
    if ($formData["make"] === "") {
        // Require a vehicle manufacturer.
        $errors[] = "Vehicle make is required.";
    } elseif (strlen($formData["make"]) > 100) {
        // Prevent values longer than the database column.
        $errors[] = "Vehicle make cannot exceed 100 characters.";
    }

    // Check whether the model has been provided.
    if ($formData["model"] === "") {
        // Require a vehicle model.
        $errors[] = "Vehicle model is required.";
    } elseif (strlen($formData["model"]) > 100) {
        // Prevent values longer than the database column.
        $errors[] = "Vehicle model cannot exceed 100 characters.";
    }

    // Check whether the year is a valid whole number.
    if (
        $formData["year"] === "" ||
        !ctype_digit($formData["year"]) ||
        (int) $formData["year"] < 1886 ||
        (int) $formData["year"] > (int) date("Y") + 1
    ) {
        // Require a realistic manufacturing year.
        $errors[] = "Enter a valid vehicle year.";
    }

    // Check whether the vehicle category has been provided.
    if ($formData["category"] === "") {
        // Require a category.
        $errors[] = "Vehicle category is required.";
    } elseif (strlen($formData["category"]) > 50) {
        // Enforce the database column length.
        $errors[] = "Vehicle category cannot exceed 50 characters.";
    }

    // Check whether the price is a valid non-negative number.
    if (
        $formData["price"] === "" ||
        !is_numeric($formData["price"]) ||
        (float) $formData["price"] < 0 ||
        (float) $formData["price"] > 9999999999.99
    ) {
        // Require a valid price that fits the database column.
        $errors[] = "Enter a valid non-negative vehicle price.";
    }

    // Check whether mileage is a valid non-negative whole number.
    if ($formData["mileage"] === "" || !ctype_digit($formData["mileage"])) {
        // Require mileage as a whole number.
        $errors[] = "Enter mileage as a non-negative whole number.";
    } elseif ((float) $formData["mileage"] > 4294967295) {
        // Ensure mileage fits the database column.
        $errors[] = "The mileage value is too large.";
    }

    // Check whether the fuel type has been provided.
    if ($formData["fuel_type"] === "") {
        // Require a fuel type.
        $errors[] = "Fuel type is required.";
    } elseif (strlen($formData["fuel_type"]) > 50) {
        // Enforce the database column length.
        $errors[] = "Fuel type cannot exceed 50 characters.";
    }

    // Check whether the transmission type has been provided.
    if ($formData["transmission"] === "") {
        // Require a transmission type.
        $errors[] = "Transmission type is required.";
    } elseif (strlen($formData["transmission"]) > 50) {
        // Enforce the database column length.
        $errors[] = "Transmission cannot exceed 50 characters.";
    }

    // Check whether the exterior color has been provided.
    if ($formData["color"] === "") {
        // Require a vehicle color.
        $errors[] = "Vehicle color is required.";
    } elseif (strlen($formData["color"]) > 50) {
        // Enforce the database column length.
        $errors[] = "Vehicle color cannot exceed 50 characters.";
    }

    // Check whether the selected status belongs to the approved list.
    if (!in_array($formData["status"], $allowedStatuses, true)) {
        // Reject unsupported vehicle status values.
        $errors[] = "Please select a valid vehicle status.";
    }

    // Check whether the optional description is too long.
    if (strlen($formData["description"]) > 10000) {
        // Prevent excessively large descriptions.
        $errors[] = "The vehicle description is too long.";
    }

    // Prepare the uploaded image path as empty by default.
    $imagePath = null;

    // Check whether the user selected an image.
    if (isset($_FILES["vehicle_image"]) && $_FILES["vehicle_image"]["error"] !== UPLOAD_ERR_NO_FILE) {

        // Check whether PHP reported an upload error.
        if ($_FILES["vehicle_image"]["error"] !== UPLOAD_ERR_OK) {
            // Display a safe upload error.
            $errors[] = "The vehicle photograph could not be uploaded.";
        } elseif ($_FILES["vehicle_image"]["size"] > $maximumImageSize) {
            // Reject photographs larger than five megabytes.
            $errors[] = "The photograph must not exceed 5 MB.";
        } else {
            // Inspect the actual uploaded file type.
            $fileInfo = new finfo(FILEINFO_MIME_TYPE);

            // Read the MIME type from the uploaded file contents.
            $imageMimeType = $fileInfo->file($_FILES["vehicle_image"]["tmp_name"]);

            // Check whether the image type is permitted.
            if (!isset($allowedImageTypes[$imageMimeType])) {
                // Reject unsupported or potentially unsafe file types.
                $errors[] = "Only JPEG, PNG, and WebP photographs are allowed.";
            } else {
                // Check whether PHP can process the uploaded image.
                $imageDimensions = getimagesize($_FILES["vehicle_image"]["tmp_name"]);

                // Reject files that are not valid images.
                if ($imageDimensions === false) {
                    // Add an invalid-image error.
                    $errors[] = "The selected photograph is not a valid image.";
                }
            }
        }
    }

    // Save the vehicle only when all validations have passed.
    if (empty($errors)) {

        // Prepare the upload directory inside the public folder.
        $uploadDirectory = __DIR__ . "/uploads/vehicles/";

        // Prepare the relative image path for database storage.
        $imagePath = null;

        // Remember the physical image path in case the database insert fails.
        $savedImageFile = null;

        // Attempt to create the vehicle record.
        try {
            // Start with no uploaded image filename.
            $newImageName = null;

            // Process the image only when the user selected one.
            if (isset($_FILES["vehicle_image"]) && $_FILES["vehicle_image"]["error"] === UPLOAD_ERR_OK) {

                // Get the safe extension associated with the detected image type.
                $imageExtension = $allowedImageTypes[$imageMimeType];

                // Generate a random filename that does not reveal the original name.
                $newImageName = bin2hex(random_bytes(16)) . "." . $imageExtension;

                // Create the upload folder if it does not exist.
                if (!is_dir($uploadDirectory)) {
                    // Create the directory and allow the required parent directories.
                    if (!mkdir($uploadDirectory, 0755, true) && !is_dir($uploadDirectory)) {
                        // Stop the upload when the directory cannot be created.
                        throw new RuntimeException("Unable to create the vehicle image directory.");
                    }
                }

                // Build the complete destination path for the photograph.
                $savedImageFile = $uploadDirectory . $newImageName;

                // Move the uploaded photograph into the vehicle image directory.
                if (!move_uploaded_file($_FILES["vehicle_image"]["tmp_name"], $savedImageFile)) {
                    // Stop the operation when the image cannot be saved.
                    throw new RuntimeException("Unable to save the vehicle photograph.");
                }

                // Store the relative image location in the database.
                $imagePath = "uploads/vehicles/" . $newImageName;
            }

            // Prepare an SQL statement to insert the vehicle information.
            $insertQuery = $pdo->prepare(
                "INSERT INTO vehicles
                (vin, make, model, `year`, category, price, mileage,
                 fuel_type, transmission, color, status, description, image_path)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );

            // Execute the prepared statement with the validated vehicle values.
            $insertQuery->execute([
                $formData["vin"],
                $formData["make"],
                $formData["model"],
                (int) $formData["year"],
                $formData["category"],
                (float) $formData["price"],
                (int) $formData["mileage"],
                $formData["fuel_type"],
                $formData["transmission"],
                $formData["color"],
                $formData["status"],
                $formData["description"] !== "" ? $formData["description"] : null,
                $imagePath
            ]);

            // Redirect to the inventory page after a successful insert.
            redirect("vehicles.php?added=1");

        } catch (PDOException $exception) {
            // Remove the uploaded image if the database insert fails.
            if ($savedImageFile !== null && file_exists($savedImageFile)) {
                // Delete the unused image file.
                unlink($savedImageFile);
            }

            // Detect a duplicate VIN using MySQL's unique-key error code.
            if ($exception->getCode() === "23000") {
                // Explain that the VIN must be unique.
                $errors[] = "This VIN already exists. Each vehicle must have a unique VIN.";
            } else {
                // Log the technical database error privately.
                error_log("VSMS add vehicle database error: " . $exception->getMessage());

                // Display a general message to the user.
                $errors[] = "The vehicle could not be saved. Please try again.";
            }

        } catch (Throwable $exception) {
            // Remove an uploaded image if another error occurs.
            if ($savedImageFile !== null && file_exists($savedImageFile)) {
                // Delete the unused image file.
                unlink($savedImageFile);
            }

            // Log the technical error privately.
            error_log("VSMS add vehicle error: " . $exception->getMessage());

            // Display a safe error message.
            $errors[] = "The vehicle could not be added. Please check the server configuration.";
        }
    }
}
?>
<!DOCTYPE html>
<!-- Declare this page as an HTML5 document. -->
<html lang="en">
<!-- Start the English-language HTML document. -->
<head>
    <!-- Set the page character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the form responsive on different screen sizes. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Add Vehicle | VSMS</title>

    <!-- Reuse the existing dashboard layout and sidebar styling. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Reuse the vehicle inventory styles. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">
</head>
<!-- Finish the document head. -->
<body>
    <!-- Create the main VSMS dashboard layout. -->
    <div class="dashboard-layout">

        <!-- Display the existing navigation sidebar. -->
        <aside class="sidebar">

<!-- Display the system logo and name. -->
<div class="brand">

    <!-- Display the short system name inside a logo box. -->
    <div class="brand-logo">V</div>

    <!-- Display the full system name. -->
    <div class="brand-text">
        <h2>VSMS</h2>
        <p>Vehicle Management</p>
    </div>

<!-- Close the brand section. -->
</div>

<!-- Display the main sidebar navigation. -->


<!-- Display all available system navigation links. -->
<nav class="sidebar-navigation">

    <!-- Display the navigation section heading. -->
    <p class="navigation-heading">MAIN MENU</p>

    <!-- Link to the Dashboard. -->
    <a href="dashboard.php" class="nav-link active">
        <span class="nav-icon">▦</span>
        <span>Dashboard</span>
    </a>

    <!-- Link to Vehicle Management. -->
    <a href="vehicles.php" class="nav-link">
        <span class="nav-icon">🚘</span>
        <span>Vehicles</span>
    </a>

    <!-- Link to Customer Management. -->
    <a href="customers.php" class="nav-link">
        <span class="nav-icon">♙</span>
        <span>Customers</span>
    </a>

    <!-- Link to Reservation Management. -->
    <a href="reservations.php" class="nav-link">
        <span class="nav-icon">▣</span>
        <span>Reservations</span>
    </a>

    <!-- Link to Sales Management. -->
    <a href="sales.php" class="nav-link">
        <span class="nav-icon">▤</span>
        <span>Sales</span>
    </a>

    <!-- Link to Payment Management. -->
    <a href="payments.php" class="nav-link">
        <span class="nav-icon">$</span>
        <span>Payments</span>
    </a>
    <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
<span class="nav-icon">◷</span>
<span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
<span class="nav-icon">▧</span>
<span>Invoices</span>
</a>

    <!-- Show employee management only to authorized management roles. -->
    <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

        <a href="employees.php" class="nav-link">
            <span class="nav-icon">♧</span>
            <span>Employees</span>
        </a>

    <?php endif; ?>
    <!-- Only Administrators can access User Account Management. -->
<?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
<span class="nav-icon">♙</span>
<span>User Accounts</span>
</a>

<?php endif; ?>

    <!-- Show reports only to authorized management roles. -->
    <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

        <a href="reports.php" class="nav-link">
            <span class="nav-icon">▥</span>
            <span>Reports</span>
        </a>

    <?php endif; ?>

<!-- Close the navigation section. -->
</nav>


<!-- Display a short project description at the bottom of the sidebar. -->
<div class="sidebar-footer">
    <p>Vehicle Sales &amp; Management System</p>
    <span>Development version</span>
</div>

<!-- Close the sidebar. -->
</aside>


        <!-- Create the main content area. -->
        <main class="main-content">
        <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    <strong>Main Menu / Vehicles / Add Vehicle</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    <div class="user-information">
                    <a href="my_profile.php" class="profile-name-link"><?= escapeVehicleValue($user["full_name"]) ?></a>
                        <span><?= escapeVehicleValue($userRole) ?></span>
                    </div>

                    <!-- Provide the existing secure logout form. -->
                    <form action="logout.php" method="POST">
                        <!-- Include the CSRF token required by the logout page. -->
                        <input type="hidden" name="csrf_token" value="<?= escapeVehicleValue($csrfToken) ?>">

                        <!-- Submit the logout request. -->
                        <button type="submit" class="logout-button">Logout</button>
                    </form>

    <!-- Create a secure POST form for logging out. -->
   

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>

           

            <!-- Display the vehicle registration form. -->
            <section class="page-content">

                <!-- Introduce the purpose of the registration form. -->
                <div class="page-heading">
                    <div>
                        <h1>Add New Vehicle</h1>
                        <p>Enter the vehicle information to register it in the VSMS inventory.</p>
                    </div>

                    <!-- Provide a way to return to the inventory. -->
                    <a href="vehicles.php" class="secondary-button">Back to Inventory</a>
                </div>

                <!-- Display all validation and database errors. -->
                <?php if (!empty($errors)): ?>
                    <div class="inventory-message error-message">
                        <strong>Please correct the following:</strong>
                        <ul>
                            <?php foreach ($errors as $error): ?>
                                <li><?= escapeVehicleValue($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <!-- Submit vehicle information and an optional photograph securely. -->
                <form action="add_vehicle.php" method="POST" enctype="multipart/form-data" class="vehicle-form">

                    <!-- Include the CSRF token to protect the form against forged requests. -->
                    <input type="hidden" name="csrf_token" value="<?= escapeVehicleValue($csrfToken) ?>">

                    <!-- Create the vehicle information card. -->
                    <section class="inventory-card">

                        <!-- Introduce the basic vehicle details. -->
                        <div class="card-heading">
                            <div>
                                <h2>Basic Vehicle Information</h2>
                                <p>Enter the vehicle identification and manufacturer details.</p>
                            </div>
                        </div>

                        <!-- Arrange the basic vehicle fields in a grid. -->
                        <div class="vehicle-form-grid">

                            <!-- Collect the unique vehicle identification number. -->
                            <div class="filter-field">
                                <label for="vin">VIN <span class="required-mark">*</span></label>
                                <input
                                    type="text"
                                    id="vin"
                                    name="vin"
                                    maxlength="50"
                                    placeholder="Enter vehicle VIN"
                                    value="<?= escapeVehicleValue($formData["vin"]) ?>"
                                    required
                                >
                            </div>

                            <!-- Collect the vehicle manufacturer. -->
                            <div class="filter-field">
                                <label for="make">Make <span class="required-mark">*</span></label>
                                <input
                                    type="text"
                                    id="make"
                                    name="make"
                                    maxlength="100"
                                    placeholder="Example: Toyota"
                                    value="<?= escapeVehicleValue($formData["make"]) ?>"
                                    required
                                >
                            </div>

                            <!-- Collect the vehicle model. -->
                            <div class="filter-field">
                                <label for="model">Model <span class="required-mark">*</span></label>
                                <input
                                    type="text"
                                    id="model"
                                    name="model"
                                    maxlength="100"
                                    placeholder="Example: Corolla"
                                    value="<?= escapeVehicleValue($formData["model"]) ?>"
                                    required
                                >
                            </div>

                            <!-- Collect the vehicle manufacturing year. -->
                            <div class="filter-field">
                                <label for="year">Year <span class="required-mark">*</span></label>
                                <input
                                    type="number"
                                    id="year"
                                    name="year"
                                    min="1886"
                                    max="<?= (int) date("Y") + 1 ?>"
                                    placeholder="Example: 2024"
                                    value="<?= escapeVehicleValue($formData["year"]) ?>"
                                    required
                                >
                            </div>

                            <!-- Collect the vehicle category. -->
                            <div class="filter-field">
                                <label for="category">Category <span class="required-mark">*</span></label>
                                <input
                                    type="text"
                                    id="category"
                                    name="category"
                                    maxlength="50"
                                    placeholder="Example: SUV"
                                    value="<?= escapeVehicleValue($formData["category"]) ?>"
                                    required
                                >
                            </div>

                            <!-- Collect the vehicle exterior color. -->
                            <div class="filter-field">
                                <label for="color">Color <span class="required-mark">*</span></label>
                                <input
                                    type="text"
                                    id="color"
                                    name="color"
                                    maxlength="50"
                                    placeholder="Example: Black"
                                    value="<?= escapeVehicleValue($formData["color"]) ?>"
                                    required
                                >
                            </div>
                        </div>
                    </section>

                    <!-- Create the vehicle specifications card. -->
                    <section class="inventory-card">

                        <!-- Introduce the vehicle specifications. -->
                        <div class="card-heading">
                            <div>
                                <h2>Vehicle Specifications</h2>
                                <p>Enter the technical and financial information.</p>
                            </div>
                        </div>

                        <!-- Arrange the specification fields in a grid. -->
                        <div class="vehicle-form-grid">

                            <!-- Collect the vehicle selling price. -->
                            <div class="filter-field">
                                <label for="price">Selling Price <span class="required-mark">*</span></label>
                                <input
                                    type="number"
                                    id="price"
                                    name="price"
                                    min="0"
                                    max="9999999999.99"
                                    step="0.01"
                                    placeholder="Example: 25000.00"
                                    value="<?= escapeVehicleValue($formData["price"]) ?>"
                                    required
                                >
                            </div>

                            <!-- Collect the current vehicle mileage. -->
                            <div class="filter-field">
                                <label for="mileage">Mileage (km) <span class="required-mark">*</span></label>
                                <input
                                    type="number"
                                    id="mileage"
                                    name="mileage"
                                    min="0"
                                    max="4294967295"
                                    step="1"
                                    placeholder="Example: 45000"
                                    value="<?= escapeVehicleValue($formData["mileage"]) ?>"
                                    required
                                >
                            </div>

                            <!-- Collect the vehicle fuel type. -->
                            <div class="filter-field">
                                <label for="fuel_type">Fuel Type <span class="required-mark">*</span></label>
                                <select id="fuel_type" name="fuel_type" required>
                                    <option value="">Select fuel type</option>
                                    <option value="Petrol" <?= $formData["fuel_type"] === "Petrol" ? "selected" : "" ?>>Petrol</option>
                                    <option value="Diesel" <?= $formData["fuel_type"] === "Diesel" ? "selected" : "" ?>>Diesel</option>
                                    <option value="Electric" <?= $formData["fuel_type"] === "Electric" ? "selected" : "" ?>>Electric</option>
                                    <option value="Hybrid" <?= $formData["fuel_type"] === "Hybrid" ? "selected" : "" ?>>Hybrid</option>
                                    <option value="Plug-in Hybrid" <?= $formData["fuel_type"] === "Plug-in Hybrid" ? "selected" : "" ?>>Plug-in Hybrid</option>
                                    <option value="Other" <?= $formData["fuel_type"] === "Other" ? "selected" : "" ?>>Other</option>
                                </select>
                            </div>

                            <!-- Collect the vehicle transmission type. -->
                            <div class="filter-field">
                                <label for="transmission">Transmission <span class="required-mark">*</span></label>
                                <select id="transmission" name="transmission" required>
                                    <option value="">Select transmission</option>
                                    <option value="Manual" <?= $formData["transmission"] === "Manual" ? "selected" : "" ?>>Manual</option>
                                    <option value="Automatic" <?= $formData["transmission"] === "Automatic" ? "selected" : "" ?>>Automatic</option>
                                    <option value="CVT" <?= $formData["transmission"] === "CVT" ? "selected" : "" ?>>CVT</option>
                                    <option value="Other" <?= $formData["transmission"] === "Other" ? "selected" : "" ?>>Other</option>
                                </select>
                            </div>

                            <!-- Collect the vehicle inventory status. -->
                            <div class="filter-field">
                                <label for="status">Vehicle Status <span class="required-mark">*</span></label>
                                <select id="status" name="status" required>
                                    <?php foreach ($allowedStatuses as $allowedStatus): ?>
                                        <option
                                            value="<?= escapeVehicleValue($allowedStatus) ?>"
                                            <?= $formData["status"] === $allowedStatus ? "selected" : "" ?>
                                        >
                                            <?= escapeVehicleValue($allowedStatus) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </section>

                    <!-- Create the vehicle photograph and description card. -->
                    <section class="inventory-card">

                        <!-- Introduce the optional photograph and description fields. -->
                        <div class="card-heading">
                            <div>
                                <h2>Photograph and Description</h2>
                                <p>Add a relevant vehicle photograph and additional details.</p>
                            </div>
                        </div>

                        <!-- Collect the optional vehicle photograph. -->
                        <div class="filter-field vehicle-image-field">
                            <label for="vehicle_image">Vehicle Photograph</label>
                            <input
                                type="file"
                                id="vehicle_image"
                                name="vehicle_image"
                                accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                            >
                            <small>Accepted formats: JPEG, PNG, WebP. Maximum size: 5 MB.</small>
                        </div>

                        <!-- Collect the optional vehicle description. -->
                        <div class="filter-field vehicle-description-field">
                            <label for="description">Vehicle Description</label>
                            <textarea
                                id="description"
                                name="description"
                                rows="5"
                                maxlength="10000"
                                placeholder="Describe the vehicle's condition, features, and other relevant information..."
                            ><?= escapeVehicleValue($formData["description"]) ?></textarea>
                        </div>
                    </section>

                    <!-- Provide the form submission and cancellation actions. -->
                    <div class="vehicle-form-actions">

                        <!-- Return to inventory without saving the form. -->
                        <a href="vehicles.php" class="secondary-button">Cancel</a>

                        <!-- Submit the validated vehicle information to PHP. -->
                        <button type="submit" class="primary-button">Save Vehicle</button>
                    </div>
                </form>
            </section>
        </main>
    </div>
</body>
<!-- Finish the HTML document. -->
</html>
