
<?php
// Load the existing authentication functions and PDO database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the visitor to log in before accessing employee information.
requireLogin();

// Retrieve the current user's information from the database.
$user = currentUser();

// Check whether the user's account is still active.
if ($user === null) {
    // Clear the current session information.
    $_SESSION = [];

    // Destroy the current session.
    session_destroy();

    // Redirect the unavailable account to the login page.
    redirect("login.php");
}

// Store the current user's role.
$userRole = $user["role_name"];

// Allow only Administrators and Managers to view the employee directory.
$allowedRoles = ["Administrator", "Manager"];

// Check whether the current user's role is authorized.
if (!in_array($userRole, $allowedRoles, true)) {
    // Return HTTP 403 Forbidden.
    http_response_code(403);

    // Stop execution and display a friendly message.
    exit("Access denied. You cannot view the employee directory.");
}

// Only the Administrator can create or edit employee records.
$canManageEmployees = ($userRole === "Administrator");

// Create a function to safely display database values in HTML.
function escapeEmployeeHtml($value): string
{
    // Convert special characters to HTML entities.
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Define the employee statuses supported by the database.
$employeeStatuses = ["Active", "Inactive"];

// Read the search text submitted through the URL.
$search = trim($_GET["search"] ?? "");

// Read the selected employee status filter.
$statusFilter = trim($_GET["status"] ?? "");

// Prepare the SQL conditions for the employee search.
$conditions = [];

// Prepare the values that will be passed to the SQL query.
$parameters = [];

// Apply the search when the user enters search text.
if ($search !== "") {
    // Search employee information and linked login-account details.
    $conditions[] = "(
        e.full_name LIKE ?
        OR e.phone LIKE ?
        OR e.email LIKE ?
        OR e.position LIKE ?
        OR u.username LIKE ?
    )";

    // Add wildcard characters for partial matching.
    $searchValue = "%" . $search . "%";

    // Add one parameter for each SQL placeholder.
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
}

// Apply the status filter only when it is valid.
if (in_array($statusFilter, $employeeStatuses, true)) {
    // Add the selected employee status to the SQL conditions.
    $conditions[] = "e.status = ?";

    // Add the status value to the prepared-statement parameters.
    $parameters[] = $statusFilter;
}

// Build the WHERE clause only when filters have been selected.
$whereSql = !empty($conditions)
    ? "WHERE " . implode(" AND ", $conditions)
    : "";

// Initialize the employee records array.
$employees = [];

// Initialize the employee summary counts.
$totalEmployees = 0;
$activeEmployees = 0;
$inactiveEmployees = 0;

// Initialize the number of matching employee records.
$matchingEmployees = 0;

// Track whether a database error occurs.
$databaseError = false;

// Retrieve employee information and summary counts from MySQL.
try {
    // Count all employee records.
    $totalEmployees = (int) $pdo->query(
        "SELECT COUNT(*) FROM employees"
    )->fetchColumn();

    // Count employees whose status is Active.
    $activeEmployees = (int) $pdo->query(
        "SELECT COUNT(*) FROM employees WHERE status = 'Active'"
    )->fetchColumn();

    // Count employees whose status is Inactive.
    $inactiveEmployees = (int) $pdo->query(
        "SELECT COUNT(*) FROM employees WHERE status = 'Inactive'"
    )->fetchColumn();

    // Build the employee directory query.
    // LEFT JOIN ensures employees without linked login accounts still appear.
    $sql = "
        SELECT
            e.employee_id,
            e.full_name,
            e.phone,
            e.email,
            e.position,
            e.status,
            e.created_at,
            u.username,
            r.role_name
        FROM employees AS e
        LEFT JOIN users AS u
            ON e.user_id = u.user_id
        LEFT JOIN roles AS r
            ON u.role_id = r.role_id
        $whereSql
        ORDER BY e.created_at DESC, e.employee_id DESC
    ";

    // Prepare the SQL query to protect against SQL injection.
    $statement = $pdo->prepare($sql);

    // Execute the query using the search and filter values.
    $statement->execute($parameters);

    // Retrieve the matching employee records.
    $employees = $statement->fetchAll(PDO::FETCH_ASSOC);

    // Count the records returned by the query.
    $matchingEmployees = count($employees);

// Handle database errors without exposing technical details.
} catch (PDOException $exception) {
    // Record the technical error in the PHP server error log.
    error_log("VSMS employee directory error: " . $exception->getMessage());

    // Mark the page as having a database error.
    $databaseError = true;

    // Keep the matching-record count at zero.
    $matchingEmployees = 0;
}

// Create a CSRF token if the session does not already contain one.
if (empty($_SESSION["csrf_token"])) {
    // Generate a secure random token.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Prepare the CSRF token for the logout form.
$csrfToken = $_SESSION["csrf_token"];

// Safely prepare the current user's name for display.
$fullName = escapeEmployeeHtml($user["full_name"]);

// Safely prepare the current user's role for display.
$roleName = escapeEmployeeHtml($userRole);

?>
<!DOCTYPE html>
<!-- Tell the browser that this is an HTML5 document. -->
<html lang="en">

<head>
    <!-- Set the character encoding to UTF-8. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on different screen sizes. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Employees | VSMS</title>

    <!-- Load the existing shared dashboard design. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Load the existing vehicle styles for cards and tables. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <!-- Add employee-directory-specific styling. -->
    <style>
        /* Style the employee summary cards. */
        .employee-summary {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 24px;
        }

        /* Style the employee directory content card. */
        .employee-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 22px;
            margin-bottom: 24px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.04);
        }

        /* Arrange the search controls in a responsive grid. */
        .employee-filter-form {
            display: grid;
            grid-template-columns: minmax(220px, 1fr) 220px auto;
            align-items: end;
            gap: 15px;
        }

        /* Style the filter labels. */
        .employee-filter-form label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
        }

        /* Style the filter inputs and dropdown. */
        .employee-filter-form input,
        .employee-filter-form select {
            width: 100%;
            padding: 11px 12px;
            border: 1px solid #dce1e8;
            border-radius: 7px;
            background: #ffffff;
        }

        /* Arrange the search buttons horizontally. */
        .employee-filter-actions {
            display: flex;
            gap: 9px;
        }

        /* Style employee status labels. */
        .employee-status {
            display: inline-block;
            padding: 5px 11px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
        }

        /* Give active employees a green status label. */
        .employee-status-active {
            color: #176b43;
            background: #e4f5eb;
        }

        /* Give inactive employees a grey status label. */
        .employee-status-inactive {
            color: #626b78;
            background: #edf0f3;
        }

        /* Style the employee's name in the table. */
        .employee-name {
            font-weight: 700;
            color: #202b3c;
        }

        /* Display secondary employee information below the name. */
        .employee-secondary {
            display: block;
            margin-top: 4px;
            color: #7b8492;
            font-size: 12px;
        }

        /* Display a friendly message when no records match. */
        .employee-empty-state {
            padding: 45px 20px;
            text-align: center;
            color: #727d8c;
        }

        /* Keep the employee table readable on small screens. */
        .employee-table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        /* Give the table enough width for its information. */
        .employee-table {
            width: 100%;
            min-width: 850px;
            border-collapse: collapse;
        }

        /* Style the employee table headings and cells. */
        .employee-table th,
        .employee-table td {
            padding: 15px 12px;
            text-align: left;
            border-bottom: 1px solid #edf0f3;
        }

        /* Style the employee table headings. */
        .employee-table th {
            color: #687486;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.4px;
        }

        /* Style the employee action links. */
        .employee-action {
            display: inline-block;
            padding: 7px 11px;
            margin-right: 5px;
            border: 1px solid #dce1e8;
            border-radius: 6px;
            color: #25334a;
            text-decoration: none;
            font-size: 12px;
            font-weight: 600;
        }

        /* Change the action-link appearance when hovered. */
        .employee-action:hover {
            background: #f1f4f8;
        }

        /* Style the employee page messages. */
        .employee-message {
            padding: 13px 16px;
            margin-bottom: 20px;
            border-radius: 8px;
        }

        /* Style the successful registration message. */
        .employee-success {
            background: #e5f5eb;
            color: #176b43;
        }

        /* Style database error messages. */
        .employee-error {
            background: #fff0ed;
            color: #a33c2e;
        }

        /* Adjust the layout for tablets and smaller screens. */
        @media (max-width: 850px) {
            .employee-filter-form {
                grid-template-columns: 1fr 1fr;
            }

            .employee-filter-actions {
                grid-column: 1 / -1;
            }
        }

        /* Stack the cards and filters on mobile screens. */
        @media (max-width: 600px) {
            .employee-summary {
                grid-template-columns: 1fr;
            }

            .employee-filter-form {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>
    <!-- Create the main application layout. -->
    <div class="dashboard-layout">

        <!-- Create the dark navy sidebar. -->
        <aside class="sidebar">

            <!-- Display the VSMS brand. -->
            <div class="brand">
                <div class="brand-logo">V</div>
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>
            </div>

            <!-- Display the application navigation. -->
            <nav class="sidebar-navigation">

                <!-- Display the navigation heading. -->
                <p class="navigation-heading">MAIN MENU</p>

                <!-- Link to the dashboard. -->
                <a href="dashboard.php" class="nav-link">
                    <span class="nav-icon">▦</span>
                    <span>Dashboard</span>
                </a>

                <!-- Link to vehicle inventory. -->
                <a href="vehicles.php" class="nav-link">
                    <span class="nav-icon">🚘</span>
                    <span>Vehicles</span>
                </a>

                <!-- Link to customer management. -->
                <a href="customers.php" class="nav-link">
                    <span class="nav-icon">♙</span>
                    <span>Customers</span>
                </a>

                <!-- Link to reservation management. -->
                <a href="reservations.php" class="nav-link">
                    <span class="nav-icon">▣</span>
                    <span>Reservations</span>
                </a>

                <!-- Link to sales management. -->
                <a href="sales.php" class="nav-link">
                    <span class="nav-icon">▤</span>
                    <span>Sales</span>
                </a>

                <!-- Link to payment management. -->
                <a href="payments.php" class="nav-link">
                    <span class="nav-icon">$</span>
                    <span>Payments</span>
                </a>

                <!-- Link to outstanding balances. -->
                <a href="outstanding_balances.php" class="nav-link">
                    <span class="nav-icon">◷</span>
                    <span>Outstanding Balances</span>
                </a>

                <!-- Link to invoice management. -->
                <a href="invoices.php" class="nav-link">
                    <span class="nav-icon">▧</span>
                    <span>Invoices</span>
                </a>

                <!-- Highlight the current employee directory page. -->
                <a href="employees.php" class="nav-link active">
                    <span class="nav-icon">♧</span>
                    <span>Employees</span>
                </a>
                <?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
    <span class="nav-icon">♙</span>
    <span>User Accounts</span>
</a>

<?php endif; ?>

                <!-- Link to the Reports overview page. -->
<a href="reports.php" class="nav-link">
    <span class="nav-icon">▥</span>
    <span>Reports</span>
</a>

            </nav>
            <div class="sidebar-footer">
                <p>Vehicle Sales &amp; Management System</p>
                <span>Development version</span>
            </div>
        </aside>

        <!-- Create the main content area. -->
        <main class="main-content">

            <!-- Display the page header and current user. -->
            <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Employee Management</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    <div class="user-information">
    <a href="my_profile.php" class="profile-name-link">
        <?= $fullName ?>
                        </a>
                        <span><?= $roleName ?></span>
    </div>

    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>
           

            <!-- Display the employee directory workspace. -->
            <section class="page-content">

                <!-- Introduce the employee directory. -->
                <div class="page-heading">
                    <div>
                        <h1>Employee Directory</h1>
                        <p>Search and manage dealership employee records.</p>
                    </div>

                    <!-- Show Add Employee only to the Administrator. -->
                    <?php if ($canManageEmployees): ?>
                        <a href="add_employee.php" class="primary-button">
                            + Add Employee
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Display a success message after adding an employee. -->
                <?php if (isset($_GET["added"]) && $_GET["added"] === "1"): ?>
                    <div class="employee-message employee-success">
                        Employee registered successfully.
                    </div>
                <?php endif; ?>

                <!-- Display a success message after editing an employee. -->
                <?php if (isset($_GET["updated"]) && $_GET["updated"] === "1"): ?>
                    <div class="employee-message employee-success">
                        Employee information updated successfully.
                    </div>
                <?php endif; ?>

                <!-- Display the employee summary cards. -->
                <?php if (!$databaseError): ?>
                    <div class="employee-summary">

                        <!-- Display the total number of employee records. -->
                        <article class="summary-card">
                            <span class="summary-label">Total Employees</span>
                            <strong><?= $totalEmployees ?></strong>
                            <small>Registered employee records</small>
                        </article>

                        <!-- Display the number of active employees. -->
                        <article class="summary-card">
                            <span class="summary-label">Active Employees</span>
                            <strong><?= $activeEmployees ?></strong>
                            <small>Currently active employees</small>
                        </article>

                        <!-- Display the number of inactive employees. -->
                        <article class="summary-card">
                            <span class="summary-label">Inactive Employees</span>
                            <strong><?= $inactiveEmployees ?></strong>
                            <small>Currently inactive employees</small>
                        </article>

                    </div>
                <?php endif; ?>

                <!-- Display database errors without exposing technical details. -->
                <?php if ($databaseError): ?>
                    <div class="employee-message employee-error">
                        Unable to load employee information. Please try again later.
                    </div>
                <?php else: ?>

                    <!-- Create the employee search and filter card. -->
                    <section class="employee-card">

                        <!-- Introduce the search controls. -->
                        <div class="card-heading">
                            <div>
                                <h2>Search Employees</h2>
                                <p>Search by name, phone, email, position, or username.</p>
                            </div>
                        </div>

                        <!-- Submit search and filter values using GET. -->
                        <form
                            action="employees.php"
                            method="GET"
                            class="employee-filter-form"
                        >

                            <!-- Create the employee search field. -->
                            <div>
                                <label for="search">Search employees</label>
                                <input
                                    type="search"
                                    id="search"
                                    name="search"
                                    placeholder="Enter employee information..."
                                    value="<?= escapeEmployeeHtml($search) ?>"
                                >
                            </div>

                            <!-- Create the employee status filter. -->
                            <div>
                                <label for="status">Employee status</label>
                                <select id="status" name="status">
                                    <option value="">All statuses</option>

                                    <?php foreach ($employeeStatuses as $employeeStatus): ?>
                                        <option
                                            value="<?= escapeEmployeeHtml($employeeStatus) ?>"
                                            <?= $statusFilter === $employeeStatus ? "selected" : "" ?>
                                        >
                                            <?= escapeEmployeeHtml($employeeStatus) ?>
                                        </option>
                                    <?php endforeach; ?>

                                </select>
                            </div>

                            <!-- Display the search and reset buttons. -->
                            <div class="employee-filter-actions">
                                <button type="submit" class="primary-button">
                                    Search
                                </button>

                                <a href="employees.php" class="secondary-button">
                                    Clear
                                </a>
                            </div>

                        </form>
                    </section>

                    <!-- Display the employee directory table. -->
                    <section class="employee-card">

                        <!-- Display the table heading and matching-record count. -->
                        <div class="card-heading">
                            <div>
                                <h2>All Employees</h2>
                                <p><?= $matchingEmployees ?> matching employee record(s)</p>
                            </div>
                        </div>

                        <!-- Check whether employees were returned by the database. -->
                        <?php if (!empty($employees)): ?>

                            <!-- Allow the table to scroll horizontally on small screens. -->
                            <div class="employee-table-wrapper">

                                <!-- Create the employee information table. -->
                                <table class="employee-table">

                                    <!-- Define the employee table headings. -->
                                    <thead>
                                        <tr>
                                            <th>Employee</th>
                                            <th>Phone</th>
                                            <th>Email</th>
                                            <th>Position</th>
                                            <th>System Account</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>

                                    <!-- Display the employee records. -->
                                    <tbody>

                                        <?php foreach ($employees as $employee): ?>
                                            <tr>

                                                <!-- Display the employee's name and ID. -->
                                                <td>
                                                    <span class="employee-name">
                                                        <?= escapeEmployeeHtml($employee["full_name"]) ?>
                                                    </span>

                                                    <small class="employee-secondary">
                                                        Employee #<?= (int) $employee["employee_id"] ?>
                                                    </small>
                                                </td>

                                                <!-- Display the employee's phone number. -->
                                                <td>
                                                    <?= escapeEmployeeHtml($employee["phone"]) ?>
                                                </td>

                                                <!-- Display the employee's email or a placeholder. -->
                                                <td>
                                                    <?= !empty($employee["email"])
                                                        ? escapeEmployeeHtml($employee["email"])
                                                        : "Not provided" ?>
                                                </td>

                                                <!-- Display the employee's job position. -->
                                                <td>
                                                    <?= escapeEmployeeHtml($employee["position"]) ?>
                                                </td>

                                                <!-- Display the linked application account. -->
                                                <td>
                                                    <?php if (!empty($employee["username"])): ?>
                                                        <strong>
                                                            <?= escapeEmployeeHtml($employee["username"]) ?>
                                                        </strong>

                                                        <small class="employee-secondary">
                                                            <?= escapeEmployeeHtml($employee["role_name"] ?? "Role unavailable") ?>
                                                        </small>
                                                    <?php else: ?>
                                                        <span class="employee-secondary">
                                                            No linked account
                                                        </span>
                                                    <?php endif; ?>
                                                </td>

                                                <!-- Display the employee's current status. -->
                                                <td>
                                                    <?php if ($employee["status"] === "Active"): ?>
                                                        <span class="employee-status employee-status-active">
                                                            Active
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="employee-status employee-status-inactive">
                                                            Inactive
                                                        </span>
                                                    <?php endif; ?>
                                                </td>

                                                <!-- Display employee actions. -->
                                                <td>

                                                    <!-- Show Edit only to the Administrator. -->
                                                    <!-- Allow Administrators and Managers to view employee details. -->
<a
    href="employee_details.php?id=<?= (int) $employee["employee_id"] ?>"
    class="employee-action"
>
    View
</a>

<!-- Show Edit only to the Administrator. -->
<?php if ($canManageEmployees): ?>
    <a
        href="edit_employee.php?id=<?= (int) $employee["employee_id"] ?>"
        class="employee-action"
    >
        Edit
    </a>
<?php endif; ?>

                                                </td>

                                            </tr>
                                        <?php endforeach; ?>

                                    </tbody>
                                </table>

                            </div>

                        <?php else: ?>

                            <!-- Display a friendly message when no records match. -->
                            <div class="employee-empty-state">
                                <h3>No employees found</h3>
                                <p>
                                    <?php if ($totalEmployees === 0): ?>
                                        No employee records have been registered yet.
                                    <?php else: ?>
                                        No employees match your search or selected filter.
                                        Try changing your search criteria.
                                    <?php endif; ?>
                                </p>
                            </div>

                        <?php endif; ?>

                    </section>

                <?php endif; ?>

            </section>
        </main>
    </div>
</body>
</html>
