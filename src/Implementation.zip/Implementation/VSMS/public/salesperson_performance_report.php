
<?php
// Load authentication functions and the database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to be logged in.
requireLogin();

// Retrieve the current user's information.
$user = currentUser();

// Stop access if the account is no longer active.
if ($user === null) {
    // Clear the session.
    $_SESSION = [];

    // Destroy the current session.
    session_destroy();

    // Return the user to the login page.
    redirect("login.php");
}

// Only Administrators and Managers can view performance reports.
if (!in_array($user["role_name"], ["Administrator", "Manager"], true)) {
    http_response_code(403);
    exit("You do not have permission to access this report.");
}

// Safely escape values before displaying them in HTML.
function performanceEscape($value): string
{
    return htmlspecialchars((string) ($value ?? ""), ENT_QUOTES, "UTF-8");
}

// Format financial values to two decimal places.
function performanceMoney($amount): string
{
    return number_format((float) $amount, 2);
}

// Read the salesperson search value.
$search = trim($_GET["search"] ?? "");

// Read the selected date range.
$startDate = trim($_GET["start_date"] ?? "");
$endDate = trim($_GET["end_date"] ?? "");

// Prepare an array for validation errors.
$errors = [];

// Validate the start date.
if ($startDate !== "") {
    $date = DateTime::createFromFormat("!Y-m-d", $startDate);

    if (!$date || $date->format("Y-m-d") !== $startDate) {
        $errors[] = "The start date is invalid.";
    }
}

// Validate the end date.
if ($endDate !== "") {
    $date = DateTime::createFromFormat("!Y-m-d", $endDate);

    if (!$date || $date->format("Y-m-d") !== $endDate) {
        $errors[] = "The end date is invalid.";
    }
}

// Make sure the start date is not later than the end date.
if ($startDate !== "" && $endDate !== "" && $startDate > $endDate) {
    $errors[] = "The start date cannot be later than the end date.";
}

// Initialize the report records.
$performanceRows = [];

// Initialize report summary values.
$totalSales = 0;
$totalRevenue = 0;
$totalDiscounts = 0;
$totalAdditionalCharges = 0;
$totalSalespersons = 0;

// Track database errors.
$databaseError = false;

// Execute the report when there are no validation errors.
if (empty($errors)) {
    try {
        // Build the salesperson performance query.
        $sql = "
            SELECT
                u.user_id,
                u.full_name AS salesperson_name,
                u.username,
                u.email,

                COUNT(s.sale_id) AS completed_sales,

                COALESCE(SUM(s.final_amount), 0) AS total_revenue,

                COALESCE(SUM(s.discount_amount), 0) AS total_discounts,

                COALESCE(SUM(s.additional_charges), 0) AS total_additional_charges,

                COALESCE(AVG(s.final_amount), 0) AS average_sale_value,

                MAX(s.sale_date) AS last_sale_date

            FROM users u

            INNER JOIN roles r
                ON u.role_id = r.role_id

            INNER JOIN sales s
                ON u.user_id = s.salesperson_id

            WHERE r.role_name = 'Salesperson'
                AND u.status = 'active'
                AND s.sale_status = 'Completed'
        ";

        // Prepare the SQL parameter array.
        $parameters = [];

        // Add salesperson search conditions when search is provided.
        if ($search !== "") {
            $sql .= "
                AND (
                    u.full_name LIKE ?
                    OR u.username LIKE ?
                    OR u.email LIKE ?
                )
            ";

            // Prepare the search value.
            $searchValue = "%" . $search . "%";

            // Add the search value for all three conditions.
            $parameters[] = $searchValue;
            $parameters[] = $searchValue;
            $parameters[] = $searchValue;
        }

        // Apply the start date filter.
        if ($startDate !== "") {
            $sql .= " AND s.sale_date >= ?";
            $parameters[] = $startDate . " 00:00:00";
        }

        // Apply the end date filter.
        if ($endDate !== "") {
            $sql .= " AND s.sale_date <= ?";
            $parameters[] = $endDate . " 23:59:59";
        }

        // Group completed sales by salesperson.
        $sql .= "
            GROUP BY
                u.user_id,
                u.full_name,
                u.username,
                u.email

            ORDER BY total_revenue DESC, completed_sales DESC
        ";

        // Prepare the SQL statement.
        $statement = $pdo->prepare($sql);

        // Execute the query safely.
        $statement->execute($parameters);

        // Retrieve the salesperson performance records.
        $performanceRows = $statement->fetchAll(PDO::FETCH_ASSOC);

        // Calculate summary values from the report records.
        foreach ($performanceRows as $row) {
            // Add completed sales to the total.
            $totalSales += (int) $row["completed_sales"];

            // Add revenue to the total.
            $totalRevenue += (float) $row["total_revenue"];

            // Add discounts to the total.
            $totalDiscounts += (float) $row["total_discounts"];

            // Add additional charges to the total.
            $totalAdditionalCharges += (float) $row["total_additional_charges"];

            // Count salespersons with completed sales.
            $totalSalespersons++;
        }

    } catch (PDOException $exception) {
        // Record technical details privately in the PHP error log.
        error_log("VSMS salesperson performance report error: " . $exception->getMessage());

        // Display a safe error message.
        $databaseError = true;
    }
}

// Calculate the average sale value across all filtered sales.
$overallAverageSale = $totalSales > 0
    ? $totalRevenue / $totalSales
    : 0;

// Safely prepare the logged-in user's name.
$fullName = performanceEscape($user["full_name"]);

// Safely prepare the logged-in user's role.
$roleName = performanceEscape($user["role_name"]);

// Create a CSRF token if one does not already exist.
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Safely prepare the CSRF token for the logout form.
$csrfToken = performanceEscape($_SESSION["csrf_token"]);
?>

<!DOCTYPE html>
<!-- Declare the document as HTML5. -->
<html lang="en">

<head>
    <!-- Set the character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Salesperson Performance | VSMS</title>

    <!-- Load the shared dashboard stylesheet. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Load the existing vehicle and report styles. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <style>
        /* Add spacing around the report content. */
        .report-content {
            padding: 25px;
        }

        /* Arrange the report heading and actions. */
        .report-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 22px;
        }

        /* Style the report title. */
        .report-heading h1 {
            margin: 0 0 6px;
            color: #172033;
            font-size: 25px;
        }

        /* Style the report description. */
        .report-heading p {
            margin: 0;
            color: #64748b;
        }

        /* Arrange the summary cards. */
        .report-summary {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 16px;
            margin-bottom: 22px;
        }

        /* Style each summary card. */
        .summary-card {
            padding: 18px;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04);
        }

        /* Style summary labels. */
        .summary-card p {
            margin: 0 0 9px;
            color: #64748b;
            font-size: 13px;
        }

        /* Style summary values. */
        .summary-card h2 {
            margin: 0;
            color: #172033;
            font-size: 23px;
        }

        /* Arrange the filter controls. */
        .report-filter {
            display: flex;
            flex-wrap: wrap;
            align-items: end;
            gap: 12px;
            padding: 18px;
            margin-bottom: 20px;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
        }

        /* Arrange filter labels and fields vertically. */
        .filter-field {
            display: flex;
            flex-direction: column;
            gap: 6px;
            min-width: 160px;
        }

        /* Style filter labels. */
        .filter-field label {
            color: #475569;
            font-size: 13px;
            font-weight: 600;
        }

        /* Style filter inputs. */
        .filter-field input {
            min-height: 40px;
            padding: 8px 10px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            background: #ffffff;
        }

        /* Style report buttons. */
        .report-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 40px;
            padding: 9px 15px;
            border: none;
            border-radius: 6px;
            background: #f26b4f;
            color: #ffffff;
            text-decoration: none;
            font-weight: 600;
            cursor: pointer;
        }

        /* Style secondary buttons. */
        .report-button.secondary {
            background: #64748b;
        }

        /* Style the report table container. */
        .report-table-card {
            overflow: hidden;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
        }

        /* Style the report table heading. */
        .report-table-heading {
            padding: 18px;
            border-bottom: 1px solid #e5e7eb;
        }

        /* Style the report table title. */
        .report-table-heading h2 {
            margin: 0;
            color: #172033;
            font-size: 18px;
        }

        /* Allow wide tables to scroll horizontally. */
        .report-table-wrapper {
            overflow-x: auto;
        }

        /* Style the performance table. */
        .report-table {
            width: 100%;
            min-width: 1050px;
            border-collapse: collapse;
        }

        /* Style table cells. */
        .report-table th,
        .report-table td {
            padding: 13px 14px;
            border-bottom: 1px solid #edf0f4;
            text-align: left;
            white-space: nowrap;
            font-size: 13px;
        }

        /* Style table headings. */
        .report-table th {
            background: #f8fafc;
            color: #475569;
            font-weight: 700;
        }

        /* Highlight a row when hovered. */
        .report-table tbody tr:hover {
            background: #fafbfc;
        }

        /* Highlight the salesperson ranking number. */
        .rank-number {
            display: inline-flex;
            justify-content: center;
            align-items: center;
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background: #eef2ff;
            color: #3730a3;
            font-weight: 700;
        }

        /* Style empty report messages. */
        .empty-report {
            padding: 35px;
            text-align: center;
            color: #64748b;
        }

        /* Style error messages. */
        .report-message {
            padding: 14px 16px;
            margin-bottom: 18px;
            border-radius: 7px;
        }

        /* Give errors a clear background. */
        .report-error {
            background: #fee2e2;
            color: #991b1b;
        }

        /* Adapt summary cards to medium screens. */
        @media (max-width: 1000px) {
            .report-summary {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        /* Adapt the page to mobile screens. */
        @media (max-width: 600px) {
            .report-summary {
                grid-template-columns: 1fr;
            }

            .report-content {
                padding: 15px;
            }
        }

        /* Hide navigation and filters when printing. */
        @media print {
            .sidebar,
            .topbar,
            .report-filter,
            .report-actions {
                display: none !important;
            }

            .dashboard-layout {
                display: block !important;
            }

            .main-content,
            .report-content {
                width: 100% !important;
                padding: 0 !important;
                margin: 0 !important;
            }

            .report-table {
                min-width: 0;
            }

            .report-table th,
            .report-table td {
                font-size: 9px;
                padding: 6px;
            }
        }
    </style>
</head>

<body>

    <!-- Create the main application layout. -->
    <div class="dashboard-layout">

        <!-- Create the left navigation sidebar. -->
        <aside class="sidebar">

            <!-- Display the VSMS brand. -->
            <div class="brand">
                <div class="brand-logo">V</div>
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>
            </div>

            <!-- Display the application navigation. -->
            <nav class="sidebar-navigation">

                <p class="navigation-heading">MAIN MENU</p>

                <a href="dashboard.php" class="nav-link">
                    <span class="nav-icon">▦</span>
                    <span>Dashboard</span>
                </a>

                <a href="vehicles.php" class="nav-link">
                    <span class="nav-icon">🚘</span>
                    <span>Vehicles</span>
                </a>

                <a href="customers.php" class="nav-link">
                    <span class="nav-icon">♙</span>
                    <span>Customers</span>
                </a>

                <a href="reservations.php" class="nav-link">
                    <span class="nav-icon">▣</span>
                    <span>Reservations</span>
                </a>

                <a href="sales.php" class="nav-link">
                    <span class="nav-icon">↗</span>
                    <span>Sales</span>
                </a>

                <a href="payments.php" class="nav-link">
                    <span class="nav-icon">$</span>
                    <span>Payments</span>
                </a>

                <a href="outstanding_balances.php" class="nav-link">
                    <span class="nav-icon">≡</span>
                    <span>Outstanding Balances</span>
                </a>

                <a href="invoices.php" class="nav-link">
                    <span class="nav-icon">▤</span>
                    <span>Invoices</span>
                </a>

                <a href="employees.php" class="nav-link">
                    <span class="nav-icon">♧</span>
                    <span>Employees</span>
                </a>
                <?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
    <span class="nav-icon">♙</span>
    <span>User Accounts</span>
</a>

<?php endif; ?>
                <!-- Highlight the Reports section. -->
                <a href="inventory_report.php" class="nav-link active">
                    <span class="nav-icon">▥</span>
                    <span>Reports</span>
                </a>

            </nav>
        </aside>

        <!-- Create the main report workspace. -->
        <main class="main-content">

            <!-- Display the top header. -->
            <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Salesperson Performance Report</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    
    <div class="user-info">
                    <a href="my_profile.php" class="profile-name-link"><?= $fullName ?></a><br>
                        <span><?= $roleName ?></span>
                    </div>

    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>

          
            <!-- Start the report content. -->
            <section class="report-content">

                <!-- Display the report title and print button. -->
                <div class="report-heading">

                    <div>
                        <h1>Salesperson Performance Report</h1>
                        <p>Compare sales results and revenue generated by each salesperson.</p>
                    </div>

                    <div class="report-actions">
                        <button type="button" class="report-button" onclick="window.print()">
                            Print Report
                        </button>
                    </div>

                </div>

                <!-- Display validation errors. -->
                <?php foreach ($errors as $error): ?>
                    <div class="report-message report-error">
                        <?= performanceEscape($error) ?>
                    </div>
                <?php endforeach; ?>

                <!-- Display a safe database error message. -->
                <?php if ($databaseError): ?>
                    <div class="report-message report-error">
                        The performance report could not be loaded. Please try again later.
                    </div>
                <?php endif; ?>

                <!-- Display the performance summary cards. -->
                <div class="report-summary">

                    <div class="summary-card">
                        <p>Salespersons with Completed Sales</p>
                        <h2><?= number_format($totalSalespersons) ?></h2>
                    </div>

                    <div class="summary-card">
                        <p>Total Completed Sales</p>
                        <h2><?= number_format($totalSales) ?></h2>
                    </div>

                    <div class="summary-card">
                        <p>Total Revenue</p>
                        <h2><?= performanceMoney($totalRevenue) ?></h2>
                    </div>

                    <div class="summary-card">
                        <p>Average Sale Value</p>
                        <h2><?= performanceMoney($overallAverageSale) ?></h2>
                    </div>

                    <div class="summary-card">
                        <p>Total Discounts</p>
                        <h2><?= performanceMoney($totalDiscounts) ?></h2>
                    </div>

                    <div class="summary-card">
                        <p>Additional Charges</p>
                        <h2><?= performanceMoney($totalAdditionalCharges) ?></h2>
                    </div>

                </div>

                <!-- Create the report filters. -->
                <form method="GET" action="salesperson_performance_report.php" class="report-filter">

                    <div class="filter-field">
                        <label for="search">Search Salesperson</label>
                        <input
                            type="text"
                            id="search"
                            name="search"
                            placeholder="Name, username or email..."
                            value="<?= performanceEscape($search) ?>"
                        >
                    </div>

                    <div class="filter-field">
                        <label for="start_date">Start Date</label>
                        <input
                            type="date"
                            id="start_date"
                            name="start_date"
                            value="<?= performanceEscape($startDate) ?>"
                        >
                    </div>

                    <div class="filter-field">
                        <label for="end_date">End Date</label>
                        <input
                            type="date"
                            id="end_date"
                            name="end_date"
                            value="<?= performanceEscape($endDate) ?>"
                        >
                    </div>

                    <button type="submit" class="report-button">
                        Apply Filters
                    </button>

                    <a href="salesperson_performance_report.php" class="report-button secondary">
                        Reset
                    </a>

                </form>

                <!-- Display the salesperson performance table. -->
                <div class="report-table-card">

                    <div class="report-table-heading">
                        <h2>Salesperson Performance Details</h2>
                    </div>

                    <div class="report-table-wrapper">

                        <table class="report-table">

                            <thead>
                                <tr>
                                    <th>Rank</th>
                                    <th>Salesperson</th>
                                    <th>Username</th>
                                    <th>Completed Sales</th>
                                    <th>Total Revenue</th>
                                    <th>Average Sale Value</th>
                                    <th>Total Discounts</th>
                                    <th>Additional Charges</th>
                                    <th>Last Sale Date</th>
                                </tr>
                            </thead>

                            <tbody>

                                <?php if (empty($performanceRows)): ?>

                                    <tr>
                                        <td colspan="9" class="empty-report">
                                            No salesperson performance records were found.
                                        </td>
                                    </tr>

                                <?php else: ?>

                                    <?php foreach ($performanceRows as $index => $row): ?>

                                        <tr>

                                            <td>
                                                <span class="rank-number">
                                                    <?= $index + 1 ?>
                                                </span>
                                            </td>

                                            <td>
                                                <?= performanceEscape($row["salesperson_name"]) ?>
                                            </td>

                                            <td>
                                                <?= performanceEscape($row["username"]) ?>
                                            </td>

                                            <td>
                                                <?= number_format((int) $row["completed_sales"]) ?>
                                            </td>

                                            <td>
                                                <?= performanceMoney($row["total_revenue"]) ?>
                                            </td>

                                            <td>
                                                <?= performanceMoney($row["average_sale_value"]) ?>
                                            </td>

                                            <td>
                                                <?= performanceMoney($row["total_discounts"]) ?>
                                            </td>

                                            <td>
                                                <?= performanceMoney($row["total_additional_charges"]) ?>
                                            </td>

                                            <td>
                                                <?php if (!empty($row["last_sale_date"])): ?>
                                                    <?= performanceEscape(date("d M Y", strtotime($row["last_sale_date"]))) ?>
                                                <?php else: ?>
                                                    —
                                                <?php endif; ?>
                                            </td>

                                        </tr>

                                    <?php endforeach; ?>

                                <?php endif; ?>

                            </tbody>

                        </table>

                    </div>
                </div>

            </section>
        </main>
    </div>
</body>
</html>
