
<?php
// Protect this page so only signed-in users can access it.
require_once __DIR__ . '/../includes/auth.php';

// Require the user to be logged in.
requireLogin();

// Only Administrators and Managers may view reports.
if (!hasRole('Administrator') && !hasRole('Manager')) {
    http_response_code(403);
    exit('Access denied. You are not authorized to view this report.');
}

// Get the current user's information for the page header.
$currentUser = currentUser();

// Escape output before displaying it in HTML.
function escapeCustomerReport($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

// Format monetary values consistently.
function formatCustomerReportMoney($amount): string
{
    return number_format((float) $amount, 2);
}

// Read the search and date filters from the URL.
$search = trim($_GET['search'] ?? '');
$startDate = trim($_GET['start_date'] ?? '');
$endDate = trim($_GET['end_date'] ?? '');

// Prepare filter conditions.
$whereConditions = [];
$params = [];

// Search customer and purchase information.
if ($search !== '') {
    $whereConditions[] = "(
        c.full_name LIKE :search_name
        OR c.phone LIKE :search_phone
        OR c.email LIKE :search_email
        OR v.make LIKE :search_make
        OR v.model LIKE :search_model
        OR v.vin LIKE :search_vin
        OR CAST(s.sale_id AS CHAR) LIKE :search_sale_id
    )";

    // Use separate placeholders for compatibility with PDO settings.
    $searchValue = '%' . $search . '%';

    $params[':search_name'] = $searchValue;
    $params[':search_phone'] = $searchValue;
    $params[':search_email'] = $searchValue;
    $params[':search_make'] = $searchValue;
    $params[':search_model'] = $searchValue;
    $params[':search_vin'] = $searchValue;
    $params[':search_sale_id'] = $searchValue;
}

// Validate the start date.
if ($startDate !== '') {
    $dateObject = DateTime::createFromFormat('!Y-m-d', $startDate);

    if (!$dateObject || $dateObject->format('Y-m-d') !== $startDate) {
        exit('Invalid start date. Please return and enter a valid date.');
    }

    $whereConditions[] = 's.sale_date >= :start_date';
    $params[':start_date'] = $startDate . ' 00:00:00';
}

// Validate the end date.
if ($endDate !== '') {
    $dateObject = DateTime::createFromFormat('!Y-m-d', $endDate);

    if (!$dateObject || $dateObject->format('Y-m-d') !== $endDate) {
        exit('Invalid end date. Please return and enter a valid date.');
    }

    // Use the next day as an exclusive limit to include the full end date.
    $endDateObject = new DateTime($endDate);
    $endDateObject->modify('+1 day');

    $whereConditions[] = 's.sale_date < :end_date';
    $params[':end_date'] = $endDateObject->format('Y-m-d') . ' 00:00:00';
}

// Do not allow a start date later than the end date.
if ($startDate !== '' && $endDate !== '' && $startDate > $endDate) {
    exit('Invalid date range. The start date cannot be later than the end date.');
}

// Only completed sales count as customer purchases.
$whereConditions[] = "s.sale_status = 'Completed'";

// Build the WHERE clause.
$whereSQL = 'WHERE ' . implode(' AND ', $whereConditions);

try {
    // Retrieve completed purchases with their customer and vehicle information.
    // Payment totals are calculated separately to prevent duplicate sale rows.
    $sql = "
        SELECT
            s.sale_id,
            s.sale_date,
            s.vehicle_price,
            s.discount_amount,
            s.additional_charges,
            s.final_amount,

            c.customer_id,
            c.full_name AS customer_name,
            c.phone AS customer_phone,
            c.email AS customer_email,

            v.make,
            v.model,
            v.year,
            v.vin,

            u.full_name AS salesperson_name,

            COALESCE(payment_totals.total_paid, 0) AS total_paid

        FROM sales s

        INNER JOIN customers c
            ON s.customer_id = c.customer_id

        INNER JOIN vehicles v
            ON s.vehicle_id = v.vehicle_id

        INNER JOIN users u
            ON s.salesperson_id = u.user_id

        LEFT JOIN (
            SELECT
                sale_id,
                SUM(payment_amount) AS total_paid
            FROM payments
            WHERE payment_status = 'Completed'
            GROUP BY sale_id
        ) payment_totals
            ON payment_totals.sale_id = s.sale_id

        $whereSQL

        ORDER BY s.sale_date DESC, s.sale_id DESC
    ";

    // Prepare and execute the database query securely.
    $statement = $pdo->prepare($sql);
    $statement->execute($params);

    // Get all matching purchase records.
    $purchases = $statement->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {
    // Log technical details without showing database information to users.
    error_log('Customer report error: ' . $exception->getMessage());

    exit('Unable to load the customer purchase report. Please try again later.');
}

// Calculate report summary values.
$totalPurchases = count($purchases);
$totalCustomers = [];
$totalRevenue = 0;
$totalPaid = 0;
$totalOutstanding = 0;

// Calculate totals from the filtered purchase records.
foreach ($purchases as $purchase) {
    // Store each customer ID only once.
    $totalCustomers[$purchase['customer_id']] = true;

    // Add the completed sale amount.
    $totalRevenue += (float) $purchase['final_amount'];

    // Add completed payments.
    $totalPaid += (float) $purchase['total_paid'];

    // Calculate the remaining amount for this purchase.
    $balance = (float) $purchase['final_amount']
        - (float) $purchase['total_paid'];

    $totalOutstanding += max(0, $balance);
}

// Count unique customers with completed purchases.
$customerCount = count($totalCustomers);

// Get the current date for the report heading.
$reportDate = date('d M Y');

// Get the current user's name safely.
$userName = $currentUser['full_name'] ?? 'User';
$userRole = $currentUser['role_name'] ?? '';

// Determine whether filters are currently active.
$filtersApplied = (
    $search !== ''
    || $startDate !== ''
    || $endDate !== ''
);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <!-- Make the report responsive on different screen sizes. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Customer Purchase Report | VSMS</title>

    <!-- Reuse the existing application stylesheets. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <style>
        /* Report page layout and spacing. */
        .report-container {
            padding: 25px;
        }

        .report-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 25px;
        }

        .report-heading h1 {
            margin: 0 0 7px;
        }

        .report-heading p {
            margin: 0;
            color: #718096;
        }

        /* Summary cards. */
        .report-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
            gap: 18px;
            margin-bottom: 25px;
        }

        .report-card {
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            border: 1px solid #edf0f4;
        }

        .report-card h3 {
            margin: 0 0 12px;
            color: #718096;
            font-size: 14px;
            font-weight: 500;
        }

        .report-card .amount {
            font-size: 23px;
            font-weight: 700;
            color: #1a202c;
        }

        /* Search and filter section. */
        .report-filter {
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .report-filter h3 {
            margin-top: 0;
            margin-bottom: 15px;
        }

        .filter-grid {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr auto auto;
            gap: 12px;
            align-items: end;
        }

        .filter-field label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 7px;
            color: #4a5568;
        }

        .filter-field input {
            width: 100%;
            min-height: 42px;
            padding: 9px 11px;
            border: 1px solid #dce2e8;
            border-radius: 6px;
            box-sizing: border-box;
        }

        .filter-button {
            min-height: 42px;
            padding: 0 17px;
            border: none;
            border-radius: 6px;
            background: #f47b45;
            color: #ffffff;
            font-weight: 600;
            cursor: pointer;
        }

        .reset-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 42px;
            padding: 0 17px;
            border-radius: 6px;
            background: #edf0f4;
            color: #2d3748;
            text-decoration: none;
            font-weight: 600;
        }

        /* Purchase history table. */
        .report-table-container {
            background: #ffffff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            overflow-x: auto;
        }

        .report-table-container h3 {
            margin-top: 0;
        }

        .report-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1050px;
        }

        .report-table th,
        .report-table td {
            padding: 13px 12px;
            text-align: left;
            border-bottom: 1px solid #edf0f4;
            font-size: 13px;
        }

        .report-table th {
            background: #f7f9fc;
            color: #4a5568;
            font-weight: 700;
            white-space: nowrap;
        }

        .report-table tbody tr:hover {
            background: #fafbfc;
        }

        .customer-name {
            font-weight: 700;
            color: #2d3748;
        }

        .muted-text {
            color: #718096;
            font-size: 12px;
            margin-top: 4px;
        }

        .report-link {
            color: #e76f3c;
            text-decoration: none;
            font-weight: 600;
        }

        .report-link:hover {
            text-decoration: underline;
        }

        .empty-report {
            padding: 35px 15px;
            text-align: center;
            color: #718096;
        }

        .report-footer {
            margin-top: 18px;
            color: #718096;
            font-size: 12px;
        }

        /* Print only the report content. */
        @media print {
            .sidebar,
            .sidebar-wrapper,
            .topbar,
            .report-filter,
            .report-actions,
            .report-link {
                display: none !important;
            }

            body {
                background: #ffffff !important;
            }

            .report-container {
                padding: 0;
            }

            .report-card,
            .report-table-container {
                box-shadow: none;
                border: 1px solid #dddddd;
            }

            .report-table {
                min-width: 0;
            }

            .report-table th,
            .report-table td {
                font-size: 10px;
                padding: 7px;
            }
        }

        /* Stack the filters on smaller screens. */
        @media (max-width: 900px) {
            .filter-grid {
                grid-template-columns: 1fr 1fr;
            }
        }

        @media (max-width: 550px) {
            .filter-grid {
                grid-template-columns: 1fr;
            }

            .report-container {
                padding: 15px;
            }
        }
    </style>
</head>

<body>

<!-- Main application layout. -->
<div class="dashboard-layout">
    <!-- Sidebar navigation. -->
    <aside class="sidebar">
    <div class="brand">
                <div class="brand-logo">V</div>

                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>
            </div>

        <nav class="sidebar-nav">

            <a href="dashboard.php" class="nav-link">
                Dashboard
            </a>

            <a href="vehicles.php" class="nav-link">
                Vehicles
            </a>

            <a href="customers.php" class="nav-link">
                Customers
            </a>

            <a href="reservations.php" class="nav-link">
                Reservations
            </a>

            <a href="sales.php" class="nav-link">
                Sales
            </a>

            <a href="payments.php" class="nav-link">
                Payments
            </a>

            <a href="outstanding_balances.php" class="nav-link">
                Outstanding Balances
            </a>

            <a href="invoices.php" class="nav-link">
                Invoices
            </a>

            <a href="employees.php" class="nav-link">
                Employees
            </a>
            <?php if ($currentUser["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
    <span class="nav-icon">♙</span>
    <span>User Accounts</span>
</a>

<?php endif; ?>
            <a href="inventory_report.php" class="nav-link active">
                Reports
            </a>

        </nav>
    </aside>

    <!-- Main report workspace. -->
    <main class="main-content">

        <!-- Current user information. -->
        <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Customer Purchase Report</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($currentUser["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    
                    <div class="user-information">
                    <a href="my_profile.php" class="profile-name-link">
        <?= $userName ?>
    </a>
                        <span><?= $userRole ?></span>
                    </div>

    <!-- Create a secure POST form for logging out. -->
    

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>
       

        <section class="report-container">

            <!-- Report title and print action. -->
            <div class="report-heading">

                <div>
                    <h1>Customer Purchase History Report</h1>

                    <p>
                        Completed vehicle purchases and customer transaction history.
                    </p>
                </div>

                <div class="report-actions">
                    <button
                        type="button"
                        class="filter-button"
                        onclick="window.print()"
                    >
                        Print Report
                    </button>
                </div>

            </div>

            <!-- Summary cards for the filtered purchase records. -->
            <div class="report-summary">

                <div class="report-card">
                    <h3>Customers with Purchases</h3>

                    <div class="amount">
                        <?= number_format($customerCount) ?>
                    </div>
                </div>

                <div class="report-card">
                    <h3>Completed Purchases</h3>

                    <div class="amount">
                        <?= number_format($totalPurchases) ?>
                    </div>
                </div>

                <div class="report-card">
                    <h3>Total Purchase Value</h3>

                    <div class="amount">
                        <?= formatCustomerReportMoney($totalRevenue) ?>
                    </div>
                </div>

                <div class="report-card">
                    <h3>Total Amount Paid</h3>

                    <div class="amount">
                        <?= formatCustomerReportMoney($totalPaid) ?>
                    </div>
                </div>

                <div class="report-card">
                    <h3>Outstanding Amount</h3>

                    <div class="amount">
                        <?= formatCustomerReportMoney($totalOutstanding) ?>
                    </div>
                </div>

            </div>

            <!-- Search and date filters. -->
            <div class="report-filter">

                <h3>Search and Filter Purchases</h3>

                <form method="GET" action="customer_report.php">

                    <div class="filter-grid">

                        <div class="filter-field">
                            <label for="search">
                                Search
                            </label>

                            <input
                                type="text"
                                id="search"
                                name="search"
                                placeholder="Customer, phone, vehicle, VIN or sale ID"
                                value="<?= escapeCustomerReport($search) ?>"
                            >
                        </div>

                        <div class="filter-field">
                            <label for="start_date">
                                Start Date
                            </label>

                            <input
                                type="date"
                                id="start_date"
                                name="start_date"
                                value="<?= escapeCustomerReport($startDate) ?>"
                            >
                        </div>

                        <div class="filter-field">
                            <label for="end_date">
                                End Date
                            </label>

                            <input
                                type="date"
                                id="end_date"
                                name="end_date"
                                value="<?= escapeCustomerReport($endDate) ?>"
                            >
                        </div>

                        <button type="submit" class="filter-button">
                            Apply Filters
                        </button>

                        <a href="customer_report.php" class="reset-button">
                            Reset
                        </a>

                    </div>

                </form>

            </div>

            <!-- Completed purchase history table. -->
            <div class="report-table-container">

                <h3>Customer Purchase Records</h3>

                <?php if (empty($purchases)): ?>

                    <!-- Display a clear message when no records match. -->
                    <div class="empty-report">
                        <h3>No Purchase Records Found</h3>

                        <p>
                            No completed purchases match the selected search or date filters.
                        </p>
                    </div>

                <?php else: ?>

                    <table class="report-table">

                        <thead>
                            <tr>
                                <th>Sale ID / Date</th>
                                <th>Customer</th>
                                <th>Vehicle</th>
                                <th>Salesperson</th>
                                <th>Purchase Value</th>
                                <th>Amount Paid</th>
                                <th>Balance</th>
                                <th>Customer Details</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php foreach ($purchases as $purchase): ?>

                                <?php
                                // Calculate the balance for the current purchase.
                                $purchaseBalance = max(
                                    0,
                                    (float) $purchase['final_amount']
                                    - (float) $purchase['total_paid']
                                );
                                ?>

                                <tr>

                                    <td>
                                        <strong>
                                            #<?= (int) $purchase['sale_id'] ?>
                                        </strong>

                                        <div class="muted-text">
                                            <?= date(
                                                'd M Y',
                                                strtotime($purchase['sale_date'])
                                            ) ?>
                                        </div>
                                    </td>

                                    <td>
                                        <div class="customer-name">
                                            <?= escapeCustomerReport(
                                                $purchase['customer_name']
                                            ) ?>
                                        </div>

                                        <div class="muted-text">
                                            <?= escapeCustomerReport(
                                                $purchase['customer_phone']
                                            ) ?>
                                        </div>

                                        <div class="muted-text">
                                            <?= escapeCustomerReport(
                                                $purchase['customer_email']
                                            ) ?>
                                        </div>
                                    </td>

                                    <td>
                                        <strong>
                                            <?= escapeCustomerReport(
                                                $purchase['make']
                                            ) ?>
                                            <?= escapeCustomerReport(
                                                $purchase['model']
                                            ) ?>
                                        </strong>

                                        <div class="muted-text">
                                            <?= (int) $purchase['year'] ?>
                                        </div>

                                        <div class="muted-text">
                                            VIN:
                                            <?= escapeCustomerReport(
                                                $purchase['vin']
                                            ) ?>
                                        </div>
                                    </td>

                                    <td>
                                        <?= escapeCustomerReport(
                                            $purchase['salesperson_name']
                                        ) ?>
                                    </td>

                                    <td>
                                        <?= formatCustomerReportMoney(
                                            $purchase['final_amount']
                                        ) ?>
                                    </td>

                                    <td>
                                        <?= formatCustomerReportMoney(
                                            $purchase['total_paid']
                                        ) ?>
                                    </td>

                                    <td>
                                        <?= formatCustomerReportMoney(
                                            $purchaseBalance
                                        ) ?>
                                    </td>

                                    <td>
                                        <a
                                            href="customer_details.php?id=<?= (int) $purchase['customer_id'] ?>"
                                            class="report-link"
                                        >
                                            View Customer
                                        </a>
                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>

                    </table>

                <?php endif; ?>

                <!-- Report information. -->
                <div class="report-footer">

                    <p>
                        Report generated: <?= escapeCustomerReport($reportDate) ?>
                    </p>

                    <p>
                        This report includes completed sales only.
                        Amount paid includes completed payments recorded against each sale.
                    </p>

                    <?php if ($filtersApplied): ?>
                        <p>
                            Search and date filters have been applied.
                        </p>
                    <?php endif; ?>

                </div>

            </div>

        </section>

    </main>

</div>

</body>
</html>
