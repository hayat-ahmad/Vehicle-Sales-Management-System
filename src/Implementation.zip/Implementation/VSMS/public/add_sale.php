
<?php
// Load the existing authentication functions and PDO database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to log in before accessing the sales page.
requireLogin();

// Retrieve the current user's information.
$user = currentUser();

// Check whether the account is still active.
if ($user === null) {
    // Clear the current session information.
    $_SESSION = [];

    // Destroy the current session.
    session_destroy();

    // Redirect the user to the login page.
    redirect("login.php");
}

// Store the current user's role.
$userRole = $user["role_name"];

// Allow all three authorized VSMS roles to register sales.
$allowedRoles = ["Administrator", "Manager", "Salesperson"];

// Check whether the user's role is permitted.
if (!in_array($userRole, $allowedRoles, true)) {
    // Return an HTTP 403 Forbidden response.
    http_response_code(403);

    // Stop the page for unauthorized users.
    exit("Access denied. You cannot register sales.");
}

// Define a helper function to safely display HTML values.
function escapeSaleValue($value): string
{
    // Convert special characters into safe HTML entities.
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Initialize the form error messages.
$errors = [];

// Initialize the customer, vehicle, and salesperson lists.
$customers = [];
$vehicles = [];
$salespeople = [];

// Initialize the database error flag.
$databaseError = false;

// Prepare the form values so submitted values can be retained.
$formData = [
    "customer_id" => "",
    "vehicle_id" => "",
    "salesperson_id" => (string) $user["user_id"],
    "discount_amount" => "0.00",
    "additional_charges" => "0.00"
];

// Generate a CSRF token if the session does not already have one.
if (empty($_SESSION["csrf_token"])) {
    // Generate a secure random token.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Store the current CSRF token for the form.
$csrfToken = $_SESSION["csrf_token"];

// Initialize the newly created sale ID.
$createdSaleId = 0;

// Check whether the page was opened after a successful sale registration.
if (isset($_GET["created"]) && ctype_digit((string) $_GET["created"])) {
    // Convert the sale ID into an integer.
    $createdSaleId = (int) $_GET["created"];
}

// Retrieve the information required by the sales form.
try {
    // Retrieve all registered customers.
    $customerQuery = $pdo->query(
        "SELECT customer_id, full_name, phone
         FROM customers
         ORDER BY full_name ASC"
    );

    // Store the customer records.
    $customers = $customerQuery->fetchAll(PDO::FETCH_ASSOC);

    // Retrieve active vehicles that can be considered for a sale.
    // Reserved vehicles are included only when they have an active reservation.
    $vehicleQuery = $pdo->query(
        "SELECT
            v.vehicle_id,
            v.vin,
            v.make,
            v.model,
            v.`year`,
            v.price,
            v.status,
            r.reservation_id,
            c.full_name AS reserved_customer_name
         FROM vehicles AS v
         LEFT JOIN reservations AS r
            ON v.vehicle_id = r.vehicle_id
            AND r.reservation_status = 'Active'
         LEFT JOIN customers AS c
            ON r.customer_id = c.customer_id
         WHERE v.is_active = 1
            AND (
                v.status = 'Available'
                OR (
                    v.status = 'Reserved'
                    AND r.reservation_id IS NOT NULL
                )
            )
         ORDER BY v.make ASC, v.model ASC"
    );

    // Store the eligible vehicle records.
    $vehicles = $vehicleQuery->fetchAll(PDO::FETCH_ASSOC);

    // Retrieve active salesperson accounts for Administrator and Manager.
    if (in_array($userRole, ["Administrator", "Manager"], true)) {
        // Prepare the query for active users with the Salesperson role.
        // Retrieve only active salesperson employees with active accounts.
        $salespersonQuery = $pdo->query(
            "SELECT u.user_id, u.full_name
             FROM users AS u
             INNER JOIN roles AS r
                ON u.role_id = r.role_id
             INNER JOIN employees AS e
                ON e.user_id = u.user_id
               AND e.status = 'Active'
             WHERE u.status = 'active'
                AND r.role_name = 'Salesperson'
             ORDER BY u.full_name ASC"
        );

        // Store the salesperson records.
        $salespeople = $salespersonQuery->fetchAll(PDO::FETCH_ASSOC);
    }

// Handle errors while loading the form information.
} catch (PDOException $exception) {
    // Mark the page as having a database error.
    $databaseError = true;

    // Log technical information privately.
    error_log("VSMS add sale loading error: " . $exception->getMessage());
}

// Process the form when the user submits it.
if ($_SERVER["REQUEST_METHOD"] === "POST" && !$databaseError) {

    // Retrieve the submitted CSRF token.
    $submittedToken = $_POST["csrf_token"] ?? "";

    // Verify that the submitted token matches the session token.
    if (
        !is_string($submittedToken)
        || !hash_equals($csrfToken, $submittedToken)
    ) {
        // Add an error if the token is invalid.
        $errors[] = "Your form session is invalid. Please reload the page.";
    }

    // Retrieve and validate the selected customer ID.
    $formData["customer_id"] = trim((string) ($_POST["customer_id"] ?? ""));

    // Retrieve and validate the selected vehicle ID.
    $formData["vehicle_id"] = trim((string) ($_POST["vehicle_id"] ?? ""));

    // Retrieve the selected salesperson ID.
    $submittedSalespersonId = trim(
        (string) ($_POST["salesperson_id"] ?? "")
    );

    // Always assign the logged-in salesperson to their own sales.
    if ($userRole === "Salesperson") {
        // Prevent a salesperson from assigning a sale to another user.
        $formData["salesperson_id"] = (string) $user["user_id"];
    } else {
        // Allow Administrator and Manager to select a salesperson.
        $formData["salesperson_id"] = $submittedSalespersonId;
    }

    // Retrieve the discount amount.
    $formData["discount_amount"] = trim(
        (string) ($_POST["discount_amount"] ?? "0")
    );

    // Retrieve additional charges.
    $formData["additional_charges"] = trim(
        (string) ($_POST["additional_charges"] ?? "0")
    );

    // Validate the customer ID.
    if (
        !ctype_digit($formData["customer_id"])
        || (int) $formData["customer_id"] < 1
    ) {
        // Add an error when no valid customer is selected.
        $errors[] = "Please select a valid customer.";
    }

    // Validate the vehicle ID.
    if (
        !ctype_digit($formData["vehicle_id"])
        || (int) $formData["vehicle_id"] < 1
    ) {
        // Add an error when no valid vehicle is selected.
        $errors[] = "Please select a valid vehicle.";
    }

    // Validate the salesperson ID.
    if (
        !ctype_digit($formData["salesperson_id"])
        || (int) $formData["salesperson_id"] < 1
    ) {
        // Add an error when the salesperson selection is invalid.
        $errors[] = "Please select a valid salesperson.";
    }

    // Check that the discount is a valid non-negative decimal amount.
    if (
        !is_numeric($formData["discount_amount"])
        || (float) $formData["discount_amount"] < 0
    ) {
        // Add an error for an invalid discount.
        $errors[] = "Discount must be a valid amount greater than or equal to zero.";
    }

    // Check that additional charges are a valid non-negative amount.
    if (
        !is_numeric($formData["additional_charges"])
        || (float) $formData["additional_charges"] < 0
    ) {
        // Add an error for invalid additional charges.
        $errors[] = "Additional charges must be a valid non-negative amount.";
    }

    // Convert valid monetary inputs into decimal values.
    $discountAmount = is_numeric($formData["discount_amount"])
        ? round((float) $formData["discount_amount"], 2)
        : 0.00;

    // Convert the additional charges into a decimal value.
    $additionalCharges = is_numeric($formData["additional_charges"])
        ? round((float) $formData["additional_charges"], 2)
        : 0.00;

    // Continue only when the initial form validation succeeds.
    if (empty($errors)) {

        // Start a transaction so related database operations remain consistent.
        try {
            // Begin the database transaction.
            $pdo->beginTransaction();

            // Lock the selected vehicle while checking its current status.
            $vehicleCheck = $pdo->prepare(
                "SELECT vehicle_id, price, status, is_active
                 FROM vehicles
                 WHERE vehicle_id = ?
                 FOR UPDATE"
            );

            // Execute the vehicle query using the submitted ID.
            $vehicleCheck->execute([
                (int) $formData["vehicle_id"]
            ]);

            // Retrieve the selected vehicle.
            $selectedVehicle = $vehicleCheck->fetch(PDO::FETCH_ASSOC);

            // Confirm that the selected vehicle exists and is active.
            if (
                !$selectedVehicle
                || (int) $selectedVehicle["is_active"] !== 1
            ) {
                // Reject vehicles that do not exist or are inactive.
                throw new RuntimeException(
                    "The selected vehicle does not exist or is inactive."
                );
            }

            // Read the vehicle's current status.
            $vehicleStatus = $selectedVehicle["status"];

            // Store the reservation ID when the vehicle is reserved.
            $reservationId = null;

            // Accept only Available or Reserved vehicles.
            if (!in_array($vehicleStatus, ["Available", "Reserved"], true)) {
                // Reject vehicles that cannot currently be sold.
                throw new RuntimeException(
                    "The selected vehicle is no longer available for a sale."
                );
            }

            // Check whether this vehicle has an active reservation.
            $reservationQuery = $pdo->prepare(
                "SELECT reservation_id, customer_id
                 FROM reservations
                 WHERE vehicle_id = ?
                    AND reservation_status = 'Active'
                 LIMIT 1
                 FOR UPDATE"
            );

            // Execute the reservation query for the selected vehicle.
            $reservationQuery->execute([
                (int) $formData["vehicle_id"]
            ]);

            // Retrieve the active reservation, if one exists.
            $activeReservation = $reservationQuery->fetch(PDO::FETCH_ASSOC);

            // If the vehicle is reserved, it must have an active reservation.
            if ($vehicleStatus === "Reserved") {

                // Reject the vehicle if its active reservation is missing.
                if (!$activeReservation) {
                    throw new RuntimeException(
                        "This vehicle is marked Reserved but has no active reservation."
                    );
                }

                // Ensure the sale customer matches the reservation customer.
                if (
                    (int) $activeReservation["customer_id"]
                    !== (int) $formData["customer_id"]
                ) {
                    throw new RuntimeException(
                        "This vehicle is reserved for a different customer."
                    );
                }

                // Link the sale to its existing reservation.
                $reservationId = (int) $activeReservation["reservation_id"];
            }

            // Check that the selected customer exists.
            $customerCheck = $pdo->prepare(
                "SELECT customer_id
                 FROM customers
                 WHERE customer_id = ?
                 LIMIT 1"
            );

            // Execute the customer check.
            $customerCheck->execute([
                (int) $formData["customer_id"]
            ]);

            // Reject an invalid customer selection.
            if (!$customerCheck->fetchColumn()) {
                throw new RuntimeException(
                    "The selected customer could not be found."
                );
            }

            // Check that the selected salesperson is active and has the correct role.
            // Verify that the salesperson has an active employee record and account.
            // Check that the salesperson has an active employee record.
            $salespersonCheck = $pdo->prepare(
                "SELECT u.user_id
                 FROM users AS u
                 INNER JOIN roles AS r
                    ON u.role_id = r.role_id
                 INNER JOIN employees AS e
                    ON e.user_id = u.user_id
                   AND e.status = 'Active'
                 WHERE u.user_id = ?
                    AND u.status = 'active'
                    AND r.role_name = 'Salesperson'
                 LIMIT 1"
            );

            // Execute the salesperson check.
            $salespersonCheck->execute([
                (int) $formData["salesperson_id"]
            ]);

            // Reject an invalid or inactive salesperson.
            if (!$salespersonCheck->fetchColumn()) {
                throw new RuntimeException(
                    "The selected salesperson is not an active salesperson."
                );
            }

            // Prevent a salesperson from assigning the sale to another user.
            if (
                $userRole === "Salesperson"
                && (int) $formData["salesperson_id"] !== (int) $user["user_id"]
            ) {
                throw new RuntimeException(
                    "You can register sales only under your own salesperson account."
                );
            }

            // Check whether the vehicle already has a Pending or Completed sale.
            $existingSaleCheck = $pdo->prepare(
                "SELECT sale_id
                 FROM sales
                 WHERE vehicle_id = ?
                    AND sale_status IN ('Pending', 'Completed')
                 LIMIT 1"
            );

            // Execute the duplicate-sale check.
            $existingSaleCheck->execute([
                (int) $formData["vehicle_id"]
            ]);

            // Reject a vehicle that already has an active or completed sale.
            if ($existingSaleCheck->fetchColumn()) {
                throw new RuntimeException(
                    "A Pending or Completed sale already exists for this vehicle."
                );
            }

            // Read the original vehicle price from the database.
            $vehiclePrice = round((float) $selectedVehicle["price"], 2);

            // Prevent the discount from exceeding the vehicle price.
            if ($discountAmount > $vehiclePrice) {
                throw new RuntimeException(
                    "The discount cannot exceed the vehicle price."
                );
            }

            // Calculate the final amount on the server.
            $finalAmount = round(
                $vehiclePrice - $discountAmount + $additionalCharges,
                2
            );

            // Prepare the new Pending sale record.
            $insertSale = $pdo->prepare(
                "INSERT INTO sales (
                    customer_id,
                    vehicle_id,
                    salesperson_id,
                    reservation_id,
                    vehicle_price,
                    discount_amount,
                    additional_charges,
                    final_amount,
                    sale_status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending')"
            );

            // Insert the new sale using validated database values.
            $insertSale->execute([
                (int) $formData["customer_id"],
                (int) $formData["vehicle_id"],
                (int) $formData["salesperson_id"],
                $reservationId,
                $vehiclePrice,
                $discountAmount,
                $additionalCharges,
                $finalAmount
            ]);

            // Retrieve the ID generated for the new sale.
            $newSaleId = (int) $pdo->lastInsertId();

            // Commit the transaction after successful insertion.
            $pdo->commit();

            // Redirect to prevent the form from being submitted twice.
            header("Location: add_sale.php?created=" . $newSaleId);

            // Stop the script after the redirect.
            exit;

        } catch (RuntimeException $exception) {
            // Roll back the transaction if it is still active.
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            // Display the business validation message.
            $errors[] = $exception->getMessage();

        } catch (PDOException $exception) {
            // Roll back the transaction if a database error occurs.
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            // Log technical information privately.
            error_log("VSMS sale registration error: " . $exception->getMessage());

            // Display a friendly database error.
            $errors[] = "The sale could not be registered because of a database error.";
        }
    }
}
?>

<!DOCTYPE html>
<!-- Declare the document as an HTML5 page. -->
<html lang="en">

<head>
    <!-- Set the page character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on different devices. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Register New Sale | VSMS</title>

    <!-- Load the existing dashboard stylesheet. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Reuse the existing vehicle-management stylesheet. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <!-- Add styles specifically for the sale registration form. -->
    <style>
        /* Style the main sale form card. */
        .sale-form-card {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            padding: 25px;
            margin-top: 20px;
            max-width: 950px;
        }

        /* Arrange form fields in two responsive columns. */
        .sale-form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
        }

        /* Keep each field and its label together. */
        .sale-form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        /* Style form labels. */
        .sale-form-group label {
            color: #374151;
            font-size: 14px;
            font-weight: 600;
        }

        /* Style form inputs and dropdowns. */
        .sale-form-group input,
        .sale-form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #d1d5db;
            border-radius: 7px;
            font-size: 14px;
            background: #ffffff;
        }

        /* Highlight the field when the user selects it. */
        .sale-form-group input:focus,
        .sale-form-group select:focus {
            outline: none;
            border-color: #f47755;
            box-shadow: 0 0 0 3px rgba(244, 119, 85, 0.12);
        }

        /* Style the explanation shown below form fields. */
        .sale-help-text {
            color: #6b7280;
            font-size: 12px;
            line-height: 1.5;
        }

        /* Style the sale calculation information area. */
        .sale-information {
            background: #f8fafc;
            border: 1px solid #e5e7eb;
            border-radius: 9px;
            padding: 18px;
            margin-top: 22px;
        }

        /* Style the information area heading. */
        .sale-information h3 {
            margin: 0 0 10px;
            color: #172033;
            font-size: 16px;
        }

        /* Style the information area description. */
        .sale-information p {
            margin: 0;
            color: #64748b;
            font-size: 13px;
            line-height: 1.6;
        }

        /* Arrange the form action buttons. */
        .sale-form-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 24px;
        }

        /* Style success and error messages. */
        .sale-message {
            padding: 14px 16px;
            border-radius: 8px;
            margin-top: 18px;
            line-height: 1.5;
        }

        /* Give successful registration messages a green appearance. */
        .sale-message.success {
            background: #ecfdf5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }

        /* Give error messages a red appearance. */
        .sale-message.error {
            background: #fef2f2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }

        /* Stack the form fields on smaller screens. */
        @media (max-width: 700px) {
            .sale-form-grid {
                grid-template-columns: 1fr;
            }

            .sale-form-card {
                padding: 18px;
            }
        }
    </style>
</head>

<body>
    <!-- Create the main dashboard layout. -->
    <div class="dashboard-layout">

        <!-- Create the navigation sidebar. -->
        <aside class="sidebar">

<!-- Display the system logo and name. -->
<div class="brand">

    <!-- Display the short system name inside a logo box. -->
    <div class="brand-logo">V</div>

    <!-- Display the full system name. -->
    <div class="brand-text">
        <h2>VSMS</h2>
        <p>Vehicle Management</p>
    </div>

<!-- Close the brand section. -->
</div>

<!-- Display the main sidebar navigation. -->


<!-- Display all available system navigation links. -->
<nav class="sidebar-navigation">

    <!-- Display the navigation section heading. -->
    <p class="navigation-heading">MAIN MENU</p>

    <!-- Link to the Dashboard. -->
    <a href="dashboard.php" class="nav-link active">
        <span class="nav-icon">▦</span>
        <span>Dashboard</span>
    </a>

    <!-- Link to Vehicle Management. -->
    <a href="vehicles.php" class="nav-link">
        <span class="nav-icon">🚘</span>
        <span>Vehicles</span>
    </a>

    <!-- Link to Customer Management. -->
    <a href="customers.php" class="nav-link">
        <span class="nav-icon">♙</span>
        <span>Customers</span>
    </a>

    <!-- Link to Reservation Management. -->
    <a href="reservations.php" class="nav-link">
        <span class="nav-icon">▣</span>
        <span>Reservations</span>
    </a>

    <!-- Link to Sales Management. -->
    <a href="sales.php" class="nav-link">
        <span class="nav-icon">▤</span>
        <span>Sales</span>
    </a>

    <!-- Link to Payment Management. -->
    <a href="payments.php" class="nav-link">
        <span class="nav-icon">$</span>
        <span>Payments</span>
    </a>
    <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
<span class="nav-icon">◷</span>
<span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
<span class="nav-icon">▧</span>
<span>Invoices</span>
</a>

    <!-- Show employee management only to authorized management roles. -->
    <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

        <a href="employees.php" class="nav-link">
            <span class="nav-icon">♧</span>
            <span>Employees</span>
        </a>

    <?php endif; ?>
    <!-- Only Administrators can access User Account Management. -->
<?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
<span class="nav-icon">♙</span>
<span>User Accounts</span>
</a>

<?php endif; ?>

    <!-- Show reports only to authorized management roles. -->
    <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

        <a href="reports.php" class="nav-link">
            <span class="nav-icon">▥</span>
            <span>Reports</span>
        </a>

    <?php endif; ?>

<!-- Close the navigation section. -->
</nav>


<!-- Display a short project description at the bottom of the sidebar. -->
<div class="sidebar-footer">
    <p>Vehicle Sales &amp; Management System</p>
    <span>Development version</span>
</div>

<!-- Close the sidebar. -->
</aside>


        <!-- Create the main workspace. -->
        <main class="main-content">

            <!-- Display the page header. -->
            <header class="topbar">

                <!-- Display the page title and breadcrumb. -->
                <div class="topbar-left">
                    <span class="breadcrumb">Main Menu / Sales / New Sale</span>
                    <h2>Register New Sale</h2>
                </div>

                <!-- Display the logged-in user and logout action. -->
                <div class="topbar-right">

                    <!-- Show the current user's name and role. -->
                    <div class="user-information">
                    <a href="my_profile.php" class="profile-name-link"><?= escapeSaleValue($user["full_name"]) ?></a>
                        <span><?= escapeSaleValue($userRole) ?></span>
                    </div>

                    <!-- Submit logout using the POST method. -->
                    <form action="logout.php" method="POST">

                        <!-- Include the session CSRF token. -->
                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= escapeSaleValue($csrfToken) ?>"
                        >

                        <!-- Display the logout button. -->
                        <button type="submit" class="logout-button">Logout</button>
                    </form>
                </div>
            </header>

            <!-- Display the sale registration workspace. -->
            <section class="page-content">

                <!-- Introduce the new sale form. -->
                <div class="page-heading">
                    <div>
                        <h1>Register New Sale</h1>
                        <p>Choose a customer and eligible vehicle to create a pending sale.</p>
                    </div>

                    <!-- Provide a link back to the dashboard. -->
                    <a href="dashboard.php" class="secondary-button">
                        Back to Dashboard
                    </a>
                </div>

                <!-- Display a database loading error when necessary. -->
                <?php if ($databaseError): ?>

                    <div class="sale-message error">
                        Unable to load the sale registration form. Please try again later.
                    </div>

                <?php else: ?>

                    <!-- Display the successful registration message. -->
                    <?php if ($createdSaleId > 0): ?>

                        <div class="sale-message success">
                            Sale #<?= $createdSaleId ?> has been registered successfully
                            with Pending status.

                            <br>

                            The vehicle has not yet been marked as Sold.
                        </div>

                    <?php endif; ?>

                    <!-- Display validation and processing errors. -->
                    <?php if (!empty($errors)): ?>

                        <div class="sale-message error">
                            <strong>Please correct the following:</strong>

                            <ul>
                                <?php foreach ($errors as $error): ?>
                                    <li><?= escapeSaleValue($error) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>

                    <?php endif; ?>

                    <!-- Display the sale registration form card. -->
                    <div class="sale-form-card">

                        <!-- Submit the form to the current page using POST. -->
                        <form action="add_sale.php" method="POST">

                            <!-- Include the CSRF token to protect the form. -->
                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= escapeSaleValue($csrfToken) ?>"
                            >

                            <!-- Arrange the sale fields in a two-column grid. -->
                            <div class="sale-form-grid">

                                <!-- Customer selection field. -->
                                <div class="sale-form-group">

                                    <label for="customer_id">Select Customer *</label>

                                    <select
                                        id="customer_id"
                                        name="customer_id"
                                        required
                                    >
                                        <option value="">Choose a customer</option>

                                        <?php foreach ($customers as $customer): ?>

                                            <option
                                                value="<?= (int) $customer["customer_id"] ?>"
                                                <?= $formData["customer_id"] === (string) $customer["customer_id"] ? "selected" : "" ?>
                                            >
                                                <?= escapeSaleValue($customer["full_name"]) ?>
                                                - <?= escapeSaleValue($customer["phone"]) ?>
                                            </option>

                                        <?php endforeach; ?>
                                    </select>

                                    <span class="sale-help-text">
                                        Select the customer purchasing the vehicle.
                                    </span>
                                </div>

                                <!-- Vehicle selection field. -->
                                <div class="sale-form-group">

                                    <label for="vehicle_id">Select Vehicle *</label>

                                    <select
                                        id="vehicle_id"
                                        name="vehicle_id"
                                        required
                                    >
                                        <option value="">Choose a vehicle</option>

                                        <?php foreach ($vehicles as $vehicle): ?>

                                            <option
                                                value="<?= (int) $vehicle["vehicle_id"] ?>"
                                                <?= $formData["vehicle_id"] === (string) $vehicle["vehicle_id"] ? "selected" : "" ?>
                                            >
                                                <?= escapeSaleValue(
                                                    $vehicle["year"] . " " .
                                                    $vehicle["make"] . " " .
                                                    $vehicle["model"]
                                                ) ?>

                                                - <?= number_format((float) $vehicle["price"], 2) ?>

                                                (<?= escapeSaleValue($vehicle["status"]) ?>)

                                                <?php if ($vehicle["status"] === "Reserved"): ?>
                                                    - Reserved for <?= escapeSaleValue($vehicle["reserved_customer_name"]) ?>
                                                <?php endif; ?>
                                            </option>

                                        <?php endforeach; ?>
                                    </select>

                                    <span class="sale-help-text">
                                        Available vehicles and vehicles reserved for the selected customer are eligible.
                                    </span>
                                </div>

                                <!-- Salesperson selection for Administrator and Manager. -->
                                <?php if (in_array($userRole, ["Administrator", "Manager"], true)): ?>

                                    <div class="sale-form-group">

                                        <label for="salesperson_id">Assigned Salesperson *</label>

                                        <select
                                            id="salesperson_id"
                                            name="salesperson_id"
                                            required
                                        >
                                            <option value="">Choose a salesperson</option>

                                            <?php foreach ($salespeople as $salesperson): ?>

                                                <option
                                                    value="<?= (int) $salesperson["user_id"] ?>"
                                                    <?= $formData["salesperson_id"] === (string) $salesperson["user_id"] ? "selected" : "" ?>
                                                >
                                                    <?= escapeSaleValue($salesperson["full_name"]) ?>
                                                </option>

                                            <?php endforeach; ?>
                                        </select>

                                        <span class="sale-help-text">
                                            Select the salesperson responsible for this transaction.
                                        </span>
                                    </div>

                                <?php else: ?>

                                    <!-- Keep the salesperson ID fixed to the logged-in salesperson. -->
                                    <input
                                        type="hidden"
                                        name="salesperson_id"
                                        value="<?= (int) $user["user_id"] ?>"
                                    >

                                    <div class="sale-form-group">
                                        <label>Assigned Salesperson</label>
                                        <input
                                            type="text"
                                            value="<?= escapeSaleValue($user["full_name"]) ?>"
                                            disabled
                                        >
                                        <span class="sale-help-text">
                                            Your account will automatically be assigned to this sale.
                                        </span>
                                    </div>

                                <?php endif; ?>

                                <!-- Discount amount field. -->
                                <div class="sale-form-group">

                                    <label for="discount_amount">Discount Amount</label>

                                    <input
                                        type="number"
                                        id="discount_amount"
                                        name="discount_amount"
                                        min="0"
                                        step="0.01"
                                        value="<?= escapeSaleValue($formData["discount_amount"]) ?>"
                                        required
                                    >

                                    <span class="sale-help-text">
                                        Enter the discount amount. It cannot exceed the vehicle price.
                                    </span>
                                </div>

                                <!-- Additional charges field. -->
                                <div class="sale-form-group">

                                    <label for="additional_charges">Additional Charges</label>

                                    <input
                                        type="number"
                                        id="additional_charges"
                                        name="additional_charges"
                                        min="0"
                                        step="0.01"
                                        value="<?= escapeSaleValue($formData["additional_charges"]) ?>"
                                        required
                                    >

                                    <span class="sale-help-text">
                                        Enter any additional charges associated with the sale.
                                    </span>
                                </div>

                            </div>

                            <!-- Explain how the sale amount is calculated. -->
                            <div class="sale-information">

                                <h3>Sale Amount Calculation</h3>

                                <p>
                                    Final Amount = Vehicle Price - Discount + Additional Charges.
                                    The vehicle price is retrieved directly from the database.
                                    The final amount is calculated and validated by PHP when the form is submitted.
                                </p>

                            </div>

                            <!-- Display the form action buttons. -->
                            <div class="sale-form-actions">

                                <!-- Submit the new sale registration form. -->
                                <button type="submit" class="primary-button">
                                    Register Pending Sale
                                </button>

                                <!-- Provide a link to return to the dashboard. -->
                                <a href="dashboard.php" class="secondary-button">
                                    Cancel
                                </a>

                            </div>

                        </form>
                    </div>

                <?php endif; ?>

            </section>
        </main>
    </div>
</body>
</html>
