
<?php
// Load authentication functions and the database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to log in.
requireLogin();

// Retrieve the current user's information.
$user = currentUser();

// Check whether the user's account is active.
if ($user === null) {
    // Clear the session information.
    $_SESSION = [];

    // Destroy the session.
    session_destroy();

    // Redirect to the login page.
    redirect("login.php");
}

// Store the user's role.
$userRole = $user["role_name"];

// Allow only Administrators and Salespersons to edit customers.
if (!in_array($userRole, ["Administrator", "Salesperson"], true)) {
    // Return an HTTP 403 Forbidden response.
    http_response_code(403);

    // Stop the page from continuing.
    exit("Access denied. Only Administrators and Salespersons can edit customers.");
}

// Define a function to safely display values in HTML.
function escapeEditCustomer($value): string
{
    // Convert special characters into safe HTML entities.
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Retrieve the customer ID from the URL.
$customerId = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

// Check that the customer ID is valid.
if (!$customerId || $customerId < 1) {
    // Return an HTTP 400 response.
    http_response_code(400);

    // Stop execution.
    exit("Invalid customer ID.");
}

// Initialize the customer record.
$customer = null;

// Initialize the validation errors array.
$errors = [];

// Retrieve the customer record from the database.
try {

    // Prepare a query to find the requested customer.
    $customerQuery = $pdo->prepare(
        "SELECT
            customer_id,
            full_name,
            phone,
            email,
            address
         FROM customers
         WHERE customer_id = ?
         LIMIT 1"
    );

    // Execute the query using the customer ID.
    $customerQuery->execute([$customerId]);

    // Retrieve the customer information.
    $customer = $customerQuery->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {

    // Record the technical error privately.
    error_log(
        "VSMS edit customer fetch error: " . $exception->getMessage()
    );

    // Return an HTTP 500 response.
    http_response_code(500);

    // Display a safe error message.
    exit("Unable to load customer information. Please try again.");
}

// Check whether the customer exists.
if (!$customer) {
    // Return an HTTP 404 response.
    http_response_code(404);

    // Stop execution.
    exit("The requested customer was not found.");
}

// Initialize the form fields with the existing customer information.
$formData = [
    "full_name" => $customer["full_name"],
    "phone" => $customer["phone"],
    "email" => $customer["email"] ?? "",
    "address" => $customer["address"] ?? ""
];

// Generate a CSRF token if one does not exist.
if (empty($_SESSION["csrf_token"])) {
    // Generate a secure random token.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Store the CSRF token.
$csrfToken = $_SESSION["csrf_token"];

// Check whether the form has been submitted.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Retrieve the submitted CSRF token.
    $submittedToken = $_POST["csrf_token"] ?? "";

    // Verify the submitted token.
    if (
        !is_string($submittedToken) ||
        !hash_equals($csrfToken, $submittedToken)
    ) {
        // Add an error if the token is invalid.
        $errors[] = "Your form session is invalid. Please reload the page and try again.";
    }

    // Read the submitted customer name.
    $formData["full_name"] = trim($_POST["full_name"] ?? "");

    // Read the submitted phone number.
    $formData["phone"] = trim($_POST["phone"] ?? "");

    // Read the submitted email address.
    $formData["email"] = trim($_POST["email"] ?? "");

    // Read the submitted address.
    $formData["address"] = trim($_POST["address"] ?? "");

    // Validate the customer's full name.
    if ($formData["full_name"] === "") {
        // Require a customer name.
        $errors[] = "Customer full name is required.";
    } elseif (strlen($formData["full_name"]) > 150) {
        // Enforce the database column length.
        $errors[] = "Customer name cannot exceed 150 characters.";
    }

    // Validate the customer's phone number.
// It must contain exactly 10 digits and start with 07.
if (!preg_match('/^07[0-9]{8}$/', $formData["phone"])) {
    $errors[] = "Phone number must contain exactly 10 digits and start with 07.";
}

    // Validate the email address when one is provided.
    if ($formData["email"] !== "") {

        // Check the email address format.
        if (!filter_var($formData["email"], FILTER_VALIDATE_EMAIL)) {
            // Add an error for an invalid email.
            $errors[] = "Please enter a valid email address.";
        } elseif (strlen($formData["email"]) > 150) {
            // Enforce the database column length.
            $errors[] = "Email address cannot exceed 150 characters.";
        }
    }

    // Check the maximum permitted address length.
    if (strlen($formData["address"]) > 65535) {
        // Prevent an excessively long address.
        $errors[] = "Customer address is too long.";
    }

    // Update the customer only when validation succeeds.
    if (empty($errors)) {

        try {

            // Prepare the SQL query to update the customer.
            $updateQuery = $pdo->prepare(
                "UPDATE customers
                 SET
                    full_name = ?,
                    phone = ?,
                    email = ?,
                    address = ?
                 WHERE customer_id = ?"
            );

            // Execute the update using the validated form values.
            $updateQuery->execute([
                $formData["full_name"],
                $formData["phone"],
                $formData["email"] !== "" ? $formData["email"] : null,
                $formData["address"] !== "" ? $formData["address"] : null,
                $customerId
            ]);

            // Redirect to the details page after a successful update.
            redirect("customer_details.php?id=" . $customerId . "&updated=1");

        } catch (PDOException $exception) {

            // Record the technical error privately.
            error_log(
                "VSMS customer update error: " . $exception->getMessage()
            );

            // Display a safe error message.
            $errors[] = "The customer information could not be updated. Please try again.";
        }
    }
}

// Safely prepare the logged-in user's name.
$safeUserName = escapeEditCustomer($user["full_name"]);

// Safely prepare the user's role.
$safeUserRole = escapeEditCustomer($userRole);

// Safely prepare the CSRF token.
$safeCsrfToken = escapeEditCustomer($csrfToken);

?>
<!DOCTYPE html>
<!-- Declare this page as an HTML5 document. -->
<html lang="en">

<!-- Start the document head. -->
<head>

    <!-- Set the page character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on different devices. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Edit Customer | VSMS</title>

    <!-- Load the existing dashboard styles. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Load the existing vehicle and form styles. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

</head>

<!-- Start the visible page. -->
<body>

    <!-- Create the main dashboard layout. -->
    <div class="dashboard-layout">

        <!-- Display the application sidebar. -->
        <aside class="sidebar">

            <!-- Display the system logo and name. -->
            <div class="brand">

                <!-- Display the short system name inside a logo box. -->
                <div class="brand-logo">V</div>

                <!-- Display the full system name. -->
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>

            <!-- Close the brand section. -->
            </div>

            <!-- Display the main sidebar navigation. -->
            

<!-- Display all available system navigation links. -->
            <nav class="sidebar-navigation">

                <!-- Display the navigation section heading. -->
                <p class="navigation-heading">MAIN MENU</p>

                <!-- Link to the Dashboard. -->
                <a href="dashboard.php" class="nav-link active">
                    <span class="nav-icon">▦</span>
                    <span>Dashboard</span>
                </a>

                <!-- Link to Vehicle Management. -->
                <a href="vehicles.php" class="nav-link">
                    <span class="nav-icon">🚘</span>
                    <span>Vehicles</span>
                </a>

                <!-- Link to Customer Management. -->
                <a href="customers.php" class="nav-link">
                    <span class="nav-icon">♙</span>
                    <span>Customers</span>
                </a>

                <!-- Link to Reservation Management. -->
                <a href="reservations.php" class="nav-link">
                    <span class="nav-icon">▣</span>
                    <span>Reservations</span>
                </a>

                <!-- Link to Sales Management. -->
                <a href="sales.php" class="nav-link">
                    <span class="nav-icon">▤</span>
                    <span>Sales</span>
                </a>

                <!-- Link to Payment Management. -->
                <a href="payments.php" class="nav-link">
                    <span class="nav-icon">$</span>
                    <span>Payments</span>
                </a>
                <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
    <span class="nav-icon">◷</span>
    <span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
    <span class="nav-icon">▧</span>
    <span>Invoices</span>
</a>

                <!-- Show employee management only to authorized management roles. -->
                <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

                    <a href="employees.php" class="nav-link">
                        <span class="nav-icon">♧</span>
                        <span>Employees</span>
                    </a>

                <?php endif; ?>
                <!-- Only Administrators can access User Account Management. -->
<?php if ($user["role_name"] === "Administrator"): ?>

    <a href="users.php" class="nav-link">
        <span class="nav-icon">♙</span>
        <span>User Accounts</span>
    </a>

<?php endif; ?>

                <!-- Show reports only to authorized management roles. -->
                <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

                    <a href="reports.php" class="nav-link">
                        <span class="nav-icon">▥</span>
                        <span>Reports</span>
                    </a>

                <?php endif; ?>

            <!-- Close the navigation section. -->
            </nav>


            <!-- Display a short project description at the bottom of the sidebar. -->
            <div class="sidebar-footer">
                <p>Vehicle Sales &amp; Management System</p>
                <span>Development version</span>
            </div>

        <!-- Close the sidebar. -->
        </aside>

        <!-- Create the main page content area. -->
        <main class="main-content">

            <!-- Display the page header. -->
            <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Customer Management</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    
                    <div class="user-information">
                    <a href="my_profile.php" class="profile-name-link">
        <?= $safeUserName ?>
    </a>
                        <span><?= $safeUserRole ?></span>
                    </div>

    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>
           

            <!-- Display the customer editing content. -->
            <section class="page-content">

                <!-- Display the page heading and navigation. -->
                <div class="page-heading">

                    <div>
                        <h1>Edit Customer</h1>
                        <p>
                            Update the information for customer
                            #<?= (int) $customerId ?>.
                        </p>
                    </div>

                    <!-- Return to the customer's details page. -->
                    <a
                        href="customer_details.php?id=<?= (int) $customerId ?>"
                        class="secondary-button"
                    >
                        Back to Details
                    </a>

                </div>

                <!-- Display validation errors. -->
                <?php if (!empty($errors)): ?>

                    <div class="inventory-message error-message">
                        <ul>

                            <!-- Display each validation error. -->
                            <?php foreach ($errors as $error): ?>

                                <li><?= escapeEditCustomer($error) ?></li>

                            <?php endforeach; ?>

                        </ul>
                    </div>

                <?php endif; ?>

                <!-- Start the customer editing form. -->
                <form action="edit_customer.php?id=<?= (int) $customerId ?>" method="POST" class="vehicle-form">

                    <!-- Include the CSRF token. -->
                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= escapeEditCustomer($csrfToken) ?>"
                    >

                    <!-- Create the customer information card. -->
                    <section class="inventory-card">

                        <!-- Display the card heading. -->
                        <div class="card-heading">
                            <div>
                                <h2>Customer Information</h2>
                                <p>Update the customer's contact information.</p>
                            </div>
                        </div>

                        <!-- Arrange the customer fields in a responsive grid. -->
                        <div class="vehicle-form-grid">

                            <!-- Customer full name field. -->
                            <div class="filter-field">

                                <label for="full_name">
                                    Full Name <span class="required-mark">*</span>
                                </label>

                                <input
                                    type="text"
                                    id="full_name"
                                    name="full_name"
                                    maxlength="150"
                                    value="<?= escapeEditCustomer($formData["full_name"]) ?>"
                                    autocomplete="name"
                                    required
                                >

                            </div>

                            <!-- Customer phone number field. -->
                            <div class="filter-field">

                                <label for="phone">
                                    Phone Number <span class="required-mark">*</span>
                                </label>

                                <input
    type="tel"
    id="phone"
    name="phone"
    inputmode="numeric"
    pattern="07[0-9]{8}"
    minlength="10"
    maxlength="10"
    value="<?= escapeEditCustomer($formData["phone"]) ?>"
    autocomplete="tel"
    placeholder="07XXXXXXXX"
    title="Enter exactly 10 digits starting with 07."
    required
>

                            </div>

                            <!-- Customer email address field. -->
                            <div class="filter-field">

                                <label for="email">Email Address</label>

                                <input
                                    type="email"
                                    id="email"
                                    name="email"
                                    maxlength="150"
                                    value="<?= escapeEditCustomer($formData["email"]) ?>"
                                    autocomplete="email"
                                    placeholder="Enter email address (optional)"
                                >

                            </div>

                        </div>
                    </section>

                    <!-- Create the customer address card. -->
                    <section class="inventory-card">

                        <!-- Display the address card heading. -->
                        <div class="card-heading">
                            <div>
                                <h2>Address Information</h2>
                                <p>Update the customer's address if necessary.</p>
                            </div>
                        </div>

                        <!-- Display the customer address field. -->
                        <div class="filter-field vehicle-description-field">

                            <label for="address">Customer Address</label>

                            <textarea
                                id="address"
                                name="address"
                                rows="4"
                                placeholder="Enter customer's address (optional)"
                            ><?= escapeEditCustomer($formData["address"]) ?></textarea>

                        </div>
                    </section>

                    <!-- Display the form action buttons. -->
                    <div class="vehicle-form-actions">

                        <!-- Cancel editing and return to customer details. -->
                        <a
                            href="customer_details.php?id=<?= (int) $customerId ?>"
                            class="secondary-button"
                        >
                            Cancel
                        </a>

                        <!-- Submit the updated customer information. -->
                        <button type="submit" class="primary-button">
                            Save Changes
                        </button>

                    </div>

                </form>

            </section>
        </main>
    </div>
</body>
</html>
