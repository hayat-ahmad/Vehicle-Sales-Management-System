
<?php

// Load the authentication functions and start the session.
require_once __DIR__ . "/../includes/auth.php";

// Allow logout requests only through the POST method.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    // Return an HTTP 405 status for unsupported request methods.
    http_response_code(405);

    // Stop execution and explain the required request method.
    exit("Method not allowed.");
}

// Retrieve the CSRF token submitted by the logout form.
$submitted_token = $_POST["csrf_token"] ?? "";

// Check whether the submitted token is valid.
if (
    !is_string($submitted_token) ||
    !isset($_SESSION["csrf_token"]) ||
    !hash_equals($_SESSION["csrf_token"], $submitted_token)
) {

    // Return an HTTP 403 status for an invalid CSRF token.
    http_response_code(403);

    // Stop execution if the logout request is not valid.
    exit("Invalid logout request.");
}

// Remove all information stored in the current session.
$_SESSION = [];

// Check whether PHP uses cookies to store session identifiers.
if (ini_get("session.use_cookies")) {

    // Retrieve the current session cookie settings.
    $cookie_parameters = session_get_cookie_params();

    // Expire the session cookie in the user's browser.
    setcookie(
        session_name(),
        "",
        [
            // Set the expiration time to a past time.
            "expires" => time() - 42000,

            // Preserve the original cookie path.
            "path" => $cookie_parameters["path"],

            // Preserve the original cookie domain.
            "domain" => $cookie_parameters["domain"],

            // Preserve the original secure-cookie setting.
            "secure" => $cookie_parameters["secure"],

            // Preserve the HTTP-only cookie setting.
            "httponly" => $cookie_parameters["httponly"],

            // Preserve the SameSite cookie protection setting.
            "samesite" => $cookie_parameters["samesite"] ?? "Lax"
        ]
    );
}

// Destroy the current PHP session on the server.
session_destroy();

// Redirect the user to the login page after logout.
redirect("login.php?logged_out=1");
