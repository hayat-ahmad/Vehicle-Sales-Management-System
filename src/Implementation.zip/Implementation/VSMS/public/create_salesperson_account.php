
<?php

// Load authentication and database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require an Administrator account.
requireRole("Administrator");

// Retrieve the logged-in Administrator.
$user = currentUser();

// Stop if the account is no longer available.
if ($user === null) {
    redirect("login.php");
}

// Safely display text in HTML.
function escapeAccountHtml($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Create a CSRF token if one does not exist.
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Store the CSRF token for the form.
$csrfToken = $_SESSION["csrf_token"];

// Initialize messages.
$errors = [];
$successMessage = "";

// Store submitted values for redisplay.
$selectedEmployeeId = "";
$selectedRole = "Salesperson";
$fullNameInput = "";
$username = "";
$email = "";

// Process the form submission.
// Process the account creation form.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Read and validate the selected system role.
    $roleInput = $_POST["role_name"] ?? "";
    $selectedRole = is_string($roleInput) ? trim($roleInput) : "";

    // Read the full name for standalone Administrator and Manager accounts.
    $nameInput = $_POST["full_name"] ?? "";
    $fullNameInput = is_string($nameInput) ? trim($nameInput) : "";

    // Read the selected employee ID.
    $employeeInput = $_POST["employee_id"] ?? "";
    $selectedEmployeeId = is_string($employeeInput)
        ? trim($employeeInput)
        : "";

    // Read the username.
    $usernameInput = $_POST["username"] ?? "";
    $username = is_string($usernameInput)
        ? trim($usernameInput)
        : "";

    // Read the email.
    $emailInput = $_POST["email"] ?? "";
    $email = is_string($emailInput) ? trim($emailInput) : "";

    // Read the password without trimming it.
    $passwordInput = $_POST["password"] ?? "";
    $password = is_string($passwordInput) ? $passwordInput : "";

    // Read the password confirmation.
    $confirmInput = $_POST["confirm_password"] ?? "";
    $confirmPassword = is_string($confirmInput)
        ? $confirmInput
        : "";

    // Read the submitted CSRF token.
    $submittedToken = $_POST["csrf_token"] ?? "";

    // Verify the CSRF token.
    if (
        !is_string($submittedToken) ||
        !hash_equals($csrfToken, $submittedToken)
    ) {
        $errors[] = "Invalid request. Refresh the page and try again.";
    }

    // Accept only the three roles defined in the SRS.
    $allowedRoles = [
        "Administrator",
        "Manager",
        "Salesperson"
    ];

    if (!in_array($selectedRole, $allowedRoles, true)) {
        $errors[] = "Please select a valid system role.";
    }

    // Validate the full name for standalone accounts.
    if ($selectedRole !== "Salesperson") {
        if (
            $fullNameInput === "" ||
            mb_strlen($fullNameInput, "UTF-8") > 100
        ) {
            $errors[] = "Enter a full name of no more than 100 characters.";
        }
    }

    // A Salesperson account must be linked to an eligible employee.
    if ($selectedRole === "Salesperson") {
        if (
            $selectedEmployeeId === "" ||
            !ctype_digit($selectedEmployeeId) ||
            (int) $selectedEmployeeId < 1
        ) {
            $errors[] = "Please select a valid Salesperson employee.";
        }
    }

    // Validate the username.
    if (
        $username === "" ||
        !preg_match('/^[a-zA-Z0-9_.-]{3,50}$/', $username)
    ) {
        $errors[] =
            "Username must be 3–50 characters and may contain letters, numbers, dots, underscores, and hyphens.";
    }

    // Validate the email.
    if (
        $email === "" ||
        !filter_var($email, FILTER_VALIDATE_EMAIL) ||
        strlen($email) > 150
    ) {
        $errors[] = "Please enter a valid email address.";
    }

    // Use the same minimum password length as the profile page.
    if (strlen($password) < 12) {
        $errors[] = "Password must contain at least 12 characters.";
    }

    // Confirm both passwords match.
    if ($password !== $confirmPassword) {
        $errors[] = "The passwords do not match.";
    }

    // Continue only when validation succeeds.
    if (empty($errors)) {

        try {

            // Start a transaction for account creation and employee linking.
            $pdo->beginTransaction();

            // Find the selected role in the database.
            $roleQuery = $pdo->prepare(
                "SELECT role_id
                 FROM roles
                 WHERE role_name = ?
                 LIMIT 1"
            );

            $roleQuery->execute([$selectedRole]);

            $roleId = $roleQuery->fetchColumn();

            if (!$roleId) {
                throw new RuntimeException(
                    "The selected system role does not exist."
                );
            }

            // Check whether the username or email is already registered.
            $duplicateQuery = $pdo->prepare(
                "SELECT user_id
                 FROM users
                 WHERE username = ? OR email = ?
                 LIMIT 1"
            );

            $duplicateQuery->execute([$username, $email]);

            if ($duplicateQuery->fetch()) {
                throw new RuntimeException(
                    "This username or email address is already registered."
                );
            }

            // Determine the account's full name.
            $accountFullName = $fullNameInput;
            $employee = null;

            // Salesperson accounts must be linked to an eligible employee.
            if ($selectedRole === "Salesperson") {

                // Lock the employee record while creating the account.
                $employeeQuery = $pdo->prepare(
                    "SELECT employee_id, full_name, position, status, user_id
                     FROM employees
                     WHERE employee_id = ?
                     FOR UPDATE"
                );

                $employeeQuery->execute([
                    (int) $selectedEmployeeId
                ]);

                $employee = $employeeQuery->fetch(PDO::FETCH_ASSOC);

                // Verify that the employee exists.
                if (!$employee) {
                    throw new RuntimeException(
                        "The selected employee was not found."
                    );
                }

                // Verify the employee's position and employment status.
                if (
                    $employee["position"] !== "Salesperson" ||
                    $employee["status"] !== "Active"
                ) {
                    throw new RuntimeException(
                        "Only active Salesperson employees can receive a Salesperson account."
                    );
                }

                // Prevent a duplicate employee-account association.
                if ($employee["user_id"] !== null) {
                    throw new RuntimeException(
                        "This employee already has a linked login account."
                    );
                }

                // Use the employee's registered name.
                $accountFullName = $employee["full_name"];
            }

            // Securely hash the password.
            $passwordHash = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            // Create the new active login account.
            $insertUser = $pdo->prepare(
                "INSERT INTO users
                    (full_name, username, email, password_hash, role_id, status)
                 VALUES (?, ?, ?, ?, ?, 'active')"
            );

            $insertUser->execute([
                $accountFullName,
                $username,
                $email,
                $passwordHash,
                (int) $roleId
            ]);

            // Retrieve the newly created user ID.
            $newUserId = (int) $pdo->lastInsertId();

            // Link the employee only for a Salesperson account.
            if ($selectedRole === "Salesperson") {

                $linkEmployee = $pdo->prepare(
                    "UPDATE employees
                     SET user_id = ?
                     WHERE employee_id = ?
                       AND user_id IS NULL
                       AND status = 'Active'
                       AND position = 'Salesperson'"
                );

                $linkEmployee->execute([
                    $newUserId,
                    (int) $selectedEmployeeId
                ]);

                // Ensure the employee was linked successfully.
                if ($linkEmployee->rowCount() !== 1) {
                    throw new RuntimeException(
                        "The Salesperson account could not be linked to the employee."
                    );
                }
            }

            // Commit the account creation and employee association.
            $pdo->commit();

            // Display a role-specific success message.
            $successMessage =
                $selectedRole .
                " account for " .
                $accountFullName .
                " was created successfully.";

            if ($selectedRole === "Salesperson") {
                $successMessage .= " The account was linked to the employee record.";
            }

            // Clear submitted values.
            $selectedEmployeeId = "";
            $selectedRole = "Salesperson";
            $fullNameInput = "";
            $username = "";
            $email = "";

        } catch (RuntimeException $exception) {

            // Roll back all changes if an application error occurs.
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            $errors[] = $exception->getMessage();

        } catch (PDOException $exception) {

            // Roll back all changes if a database error occurs.
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            // Log technical details privately.
            error_log(
                "VSMS account creation error: " .
                $exception->getMessage()
            );

            // Display a safe error message.
            $errors[] =
                "The account could not be created. Check the username and email, then try again.";
        }
    }
}

// Retrieve active Salesperson employees without linked accounts.
$employees = [];

try {

    $employeeListQuery = $pdo->query(
        "SELECT employee_id, full_name
         FROM employees
         WHERE position = 'Salesperson'
           AND status = 'Active'
           AND user_id IS NULL
         ORDER BY full_name ASC"
    );

    $employees = $employeeListQuery->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {

    error_log(
        "VSMS salesperson employee list error: " .
        $exception->getMessage()
    );

    $errors[] = "Unable to load the available salesperson employees.";
}

// Safely prepare the Administrator's information.
$fullName = escapeAccountHtml($user["full_name"]);
$roleName = escapeAccountHtml($user["role_name"]);

?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Create Login Account | VSMS</title>

    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <style>
        .account-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 25px;
            max-width: 720px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.04);
        }

        .account-form {
            display: grid;
            gap: 18px;
        }

        .account-form label {
            display: block;
            margin-bottom: 7px;
            font-weight: 600;
        }

        .account-form input,
        .account-form select {
            width: 100%;
            padding: 12px;
            border: 1px solid #dce1e8;
            border-radius: 7px;
            background: #ffffff;
        }

        .account-message {
            padding: 13px 16px;
            border-radius: 8px;
            margin-bottom: 18px;
        }

        .account-success {
            color: #176b43;
            background: #e4f5eb;
        }

        .account-error {
            color: #9b2929;
            background: #fdeaea;
        }

        .account-note {
            color: #647084;
            font-size: 13px;
            line-height: 1.6;
        }

        .account-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 5px;
        }

        @media (max-width: 600px) {
            .account-card {
                padding: 17px;
            }
        }
    </style>

</head>

<body>

<div class="dashboard-layout">

    <aside class="sidebar">

    <div class="brand">

<!-- Display the letter V inside the logo box. -->
<div class="brand-logo">V</div>

<!-- Display the system name and description. -->
<div class="brand-text">
    <h2>VSMS</h2>
    <p>Vehicle Management</p>
</div>

</div>

        <nav class="sidebar-navigation">

            <p class="navigation-heading">MAIN MENU</p>

            <a href="dashboard.php" class="nav-link">
                <span class="nav-icon">▦</span>
                <span>Dashboard</span>
            </a>

            <a href="vehicles.php" class="nav-link">
                <span class="nav-icon">🚘</span>
                <span>Vehicles</span>
            </a>

            <a href="customers.php" class="nav-link">
                <span class="nav-icon">♙</span>
                <span>Customers</span>
            </a>

            <a href="reservations.php" class="nav-link">
                <span class="nav-icon">▣</span>
                <span>Reservations</span>
            </a>

            <a href="sales.php" class="nav-link">
                <span class="nav-icon">▤</span>
                <span>Sales</span>
            </a>

            <a href="payments.php" class="nav-link">
                <span class="nav-icon">$</span>
                <span>Payments</span>
            </a>

            <a href="outstanding_balances.php" class="nav-link">
                <span class="nav-icon">◷</span>
                <span>Outstanding Balances</span>
            </a>

            <a href="invoices.php" class="nav-link">
                <span class="nav-icon">▧</span>
                <span>Invoices</span>
            </a>

            <!-- Show Employees to Administrators and Managers only. -->
<!-- Only Administrators can access User Accounts. -->
<?php if ($user["role_name"] === "Administrator"): ?>

    <a href="employees.php" class="nav-link ">
        <span class="nav-icon">♧</span>
        <span>Employees</span>
    </a>

<?php endif; ?>

<!-- Show User Accounts to Administrators and Managers. -->
<?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

    <a href="users.php" class="nav-link active">
        <span class="nav-icon">♙</span>
        <span>User Accounts</span>
    </a>

<?php endif; ?>

<!-- Show Reports to Administrators and Managers only. -->
<?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

    <a href="reports.php" class="nav-link">
        <span class="nav-icon">▥</span>
        <span>Reports</span>
    </a>

<?php endif; ?>
        </nav>

        <div class="sidebar-footer">
            <p>Vehicle Sales &amp; Management System</p>
            <span>Development version</span>
        </div>

    </aside>

    <main class="main-content">
    <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Create Login Account</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    <div class="user-information">
    <a href="my_profile.php" class="profile-name-link">
        <?= $fullName ?>
                        </a>
                        <span><?= $roleName ?></span>
    </div>

    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>
       

        <section class="page-content">

            <div class="page-heading">
                <div>
                    <h1>Create Login Account</h1>
                    <p>
                        Create a secure system account for an existing
                        active salesperson employee.
                    </p>
                </div>
            </div>

            <?php if ($successMessage !== ""): ?>

                <div class="account-message account-success">
                    <?= escapeAccountHtml($successMessage) ?>
                </div>

            <?php endif; ?>

            <?php if (!empty($errors)): ?>

                <div class="account-message account-error">
                    <?php foreach ($errors as $error): ?>
                        <p><?= escapeAccountHtml($error) ?></p>
                    <?php endforeach; ?>
                </div>

            <?php endif; ?>

            <section class="account-card">

                <form
                    action="create_salesperson_account.php"
                    method="POST"
                    class="account-form"
                >

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= escapeAccountHtml($csrfToken) ?>"
                    >

                    <!-- Select the system role for the new account. -->
<div>
    <label for="role_name">System Role</label>

    <select
        id="role_name"
        name="role_name"
        required
    >
        <option
            value="Administrator"
            <?= $selectedRole === "Administrator" ? "selected" : "" ?>
        >
            Administrator
        </option>

        <option
            value="Manager"
            <?= $selectedRole === "Manager" ? "selected" : "" ?>
        >
            Manager
        </option>

        <option
            value="Salesperson"
            <?= $selectedRole === "Salesperson" ? "selected" : "" ?>
        >
            Salesperson
        </option>
    </select>

    <p class="account-note">
        Select one of the three system roles defined in the SRS.
        Customer accounts are not supported.
    </p>
</div>

<!-- Full name is required for standalone Administrator and Manager accounts. -->
<div id="full_name_group">
    <label for="full_name">Full Name</label>

    <input
        type="text"
        id="full_name"
        name="full_name"
        maxlength="100"
        value="<?= escapeAccountHtml($fullNameInput) ?>"
        placeholder="Enter the full name"
    >
</div>

<!-- Salesperson accounts must be connected to an existing employee. -->
<div id="employee_group">
    <label for="employee_id">Select Salesperson Employee</label>

    <select
        id="employee_id"
        name="employee_id"
    >
        <option value="">Choose a salesperson</option>

        <?php foreach ($employees as $employee): ?>

            <option
                value="<?= (int) $employee["employee_id"] ?>"
                <?= $selectedEmployeeId == $employee["employee_id"]
                    ? "selected"
                    : "" ?>
            >
                <?= escapeAccountHtml($employee["full_name"]) ?>
            </option>

        <?php endforeach; ?>
    </select>

    <p class="account-note">
        Only active Salesperson employees without an existing login account are shown.
    </p>
</div>

<!-- Enter the new username. -->
<div>
    <label for="username">Username</label>

    <input
        type="text"
        id="username"
        name="username"
        value="<?= escapeAccountHtml($username) ?>"
        minlength="3"
        maxlength="50"
        pattern="[a-zA-Z0-9_.-]+"
        placeholder="Example: ahmadullah"
        required
    >
</div>

<!-- Enter the new email address. -->
<div>
    <label for="email">Email Address</label>

    <input
        type="email"
        id="email"
        name="email"
        value="<?= escapeAccountHtml($email) ?>"
        maxlength="150"
        placeholder="Enter the email address"
        required
    >
</div>

<!-- Enter the new password. -->
<div>
    <label for="password">Password</label>

    <input
        type="password"
        id="password"
        name="password"
        minlength="12"
        autocomplete="new-password"
        required
    >

    <p class="account-note">
        Use at least 12 characters. The password will be securely hashed.
    </p>
</div>

<!-- Confirm the new password. -->
<div>
    <label for="confirm_password">Confirm Password</label>

    <input
        type="password"
        id="confirm_password"
        name="confirm_password"
        minlength="12"
        autocomplete="new-password"
        required
    >
</div>

                    <div>
                        <label for="username">Username</label>

                        <input
                            type="text"
                            id="username"
                            name="username"
                            value="<?= escapeAccountHtml($username) ?>"
                            minlength="3"
                            maxlength="50"
                            pattern="[a-zA-Z0-9_.-]+"
                            placeholder="Example: hewad"
                            required
                        >
                    </div>

                    <div>
                        <label for="email">Email Address</label>

                        <input
                            type="email"
                            id="email"
                            name="email"
                            value="<?= escapeAccountHtml($email) ?>"
                            maxlength="150"
                            placeholder="Enter the employee's email"
                            required
                        >
                    </div>

                    <div>
                        <label for="password">Password</label>

                        <input
                            type="password"
                            id="password"
                            name="password"
                            minlength="8"
                            autocomplete="new-password"
                            required
                        >

                        <p class="account-note">
                            Use at least 8 characters. The password
                            will be securely hashed before storage.
                        </p>
                    </div>

                    <div>
                        <label for="confirm_password">
                            Confirm Password
                        </label>

                        <input
                            type="password"
                            id="confirm_password"
                            name="confirm_password"
                            minlength="8"
                            autocomplete="new-password"
                            required
                        >
                    </div>

                    <div>
                        <label>Assigned System Role</label>
                        <input
                            type="text"
                            value="Salesperson"
                            readonly
                        >
                    </div>

                    <div class="account-actions">

                        <button type="submit" class="primary-button">
                            Create Account
                        </button>

                        <a
                            href="employees.php"
                            class="secondary-button"
                        >
                            Cancel
                        </a>

                    </div>

                </form>

            </section>

        </section>

    </main>

</div>
<script>
// Get the role selection dropdown.
const roleSelect = document.getElementById("role_name");

// Get the full-name form section.
const fullNameGroup = document.getElementById("full_name_group");

// Get the employee selection form section.
const employeeGroup = document.getElementById("employee_group");

// Get the employee selection field.
const employeeSelect = document.getElementById("employee_id");

// Get the full-name field.
const fullNameField = document.getElementById("full_name");

// Update the visible fields according to the selected role.
function updateAccountFields() {

    // Check whether the selected role is Salesperson.
    const isSalesperson = roleSelect.value === "Salesperson";

    // Salesperson accounts use an existing employee's full name.
    fullNameGroup.style.display = isSalesperson ? "none" : "block";

    // Only Salesperson accounts require employee selection.
    employeeGroup.style.display = isSalesperson ? "block" : "none";

    // Apply the correct required-field rules.
    employeeSelect.required = isSalesperson;
    fullNameField.required = !isSalesperson;
}

// Update fields when the selected role changes.
roleSelect.addEventListener("change", updateAccountFields);

// Set the correct initial form appearance.
updateAccountFields();
</script>
</body>

</html>
