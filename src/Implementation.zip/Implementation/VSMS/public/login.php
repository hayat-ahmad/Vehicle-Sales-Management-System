
<?php

// Load the authentication functions and database connection.
require_once __DIR__ . "/../includes/auth.php";

// Check whether a user is already logged in.
if (isLoggedIn()) {

    // Redirect an already authenticated user to the dashboard.
    redirect("dashboard.php");
}

// Create a CSRF token when one does not already exist.
if (empty($_SESSION["csrf_token"])) {

    // Generate a secure random token for form protection.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Create an empty variable for login error messages.
$error_message = "";

// Check whether the browser submitted the login form.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Retrieve the submitted username or email address.
    $login_identifier = trim($_POST["login_identifier"] ?? "");

    // Retrieve the submitted password without changing it.
    $password = $_POST["password"] ?? "";

    // Retrieve the submitted CSRF token.
    $submitted_token = $_POST["csrf_token"] ?? "";

    // Check whether the submitted CSRF token matches the session token.
    if (
        !is_string($submitted_token) ||
        !hash_equals($_SESSION["csrf_token"], $submitted_token)
    ) {

        // Display an error if the form token is invalid.
        $error_message = "Invalid request. Please refresh the page and try again.";

    // Check whether the username/email or password is empty.
    } elseif ($login_identifier === "" || $password === "") {

        // Display an error when required fields are missing.
        $error_message = "Please enter your username/email and password.";

    } else {

        // Prepare a query to find the account using its username or email.
        // Find the account and check its linked employee status.
        $login_query = $pdo->prepare(
            "SELECT u.user_id, u.full_name, u.username, u.email,
                    u.password_hash, u.status, r.role_name
             FROM users AS u
             INNER JOIN roles AS r ON u.role_id = r.role_id

             WHERE (u.username = ? OR u.email = ?)

               AND (
                    r.role_name <> 'Salesperson'
                    OR EXISTS (
                        SELECT 1
                        FROM employees AS e
                        WHERE e.user_id = u.user_id
                          AND e.status = 'Active'
                    )
               )

               AND NOT EXISTS (
                    SELECT 1
                    FROM employees AS e
                    WHERE e.user_id = u.user_id
                      AND e.status = 'Inactive'
               )

             LIMIT 1"
        );

        // Execute the query using the submitted username or email twice.
        $login_query->execute([$login_identifier, $login_identifier]);

        // Retrieve the matching account from the database.
        $user = $login_query->fetch();

        // Check whether the account exists and is active.
        if ($user && $user["status"] === "active") {

            // Verify the submitted password against the stored password hash.
            if (password_verify($password, $user["password_hash"])) {

                // Generate a new session ID after successful authentication.
                session_regenerate_id(true);

                // Store the authenticated user's ID in the session.
                $_SESSION["user_id"] = $user["user_id"];

                // Store the authenticated user's full name in the session.
                $_SESSION["full_name"] = $user["full_name"];

                // Store the authenticated user's role in the session.
                $_SESSION["role_name"] = $user["role_name"];

                // Generate a new CSRF token after successful login.
                $_SESSION["csrf_token"] = bin2hex(random_bytes(32));

                // Redirect the authenticated user to the dashboard.
                redirect("dashboard.php");

            } else {

                // Display a general error for an incorrect password.
                $error_message = "Invalid username/email or password.";
            }

        } else {

            // Display the same general error for unavailable accounts.
            $error_message = "Invalid username/email or password.";
        }
    }
}

// Prepare the login identifier for safe display in the form.
$safe_login_identifier = htmlspecialchars(
    $login_identifier ?? "",
    ENT_QUOTES,
    "UTF-8"
);

?>
<!DOCTYPE html>
<!-- Tell the browser that this document uses HTML5. -->
<html lang="en">
<!-- Set the language of the page to English. -->
<head>
    <!-- Set the character encoding to UTF-8. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on phones, tablets, and computers. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the title displayed in the browser tab. -->
    <title>VSMS | Login</title>

    <!-- Load the external login stylesheet. -->
    <link rel="stylesheet" href="assets/css/login.css">
</head>
<body>
    <!-- Create the main container for the complete login interface. -->
    <main class="login-container">

        <!-- Create the left branding panel. -->
        <section class="brand-panel">

            <!-- Display the system logo using text initials.
            <div class="brand-logo">V<span>S</span>MS</div> -->

            <!-- Display the main system heading. -->
            <h1>Vehicle Sales Management System</h1>

            <!-- Explain the purpose of the application. -->
            <!-- <p class="brand-description">
                Manage vehicles, customers, reservations, sales, and payments
                from one organized platform.
            </p> -->
            <div class="login-page-image">
            <img src="/uploads/vehicles/login-car-image.jpg" alt="Login Car">
            </div>

            <!-- Display a short system statement. -->
            <div class="brand-message">
                <h2>Manage smarter. Sell better.</h2>
                <p>Your business operations, connected in one place.</p>
            </div>

            <!-- Display the system footer. -->
            <!-- <p class="brand-footer">VSMS Management Platform</p> -->

        </section>

        <!-- Create the right panel containing the login form. -->
        <section class="form-panel">

            <!-- Group the login heading and description. -->
            
<!-- Group the login heading and description. -->
<div class="form-heading">

    <!-- Display the login heading. -->
    <h2>Welcome Back</h2>

    <!-- Ask the user to enter their account information. -->
    <p>Please sign in to access your account.</p>

    <!-- Check whether the user has just logged out. -->
    <?php if (isset($_GET["logged_out"]) && $_GET["logged_out"] === "1"): ?>

        <!-- Display a successful logout message. -->
        <p class="success-message">You have successfully logged out.</p>

    <!-- End the logout-message condition. -->
    <?php endif; ?>

</div>


            <!-- Display the login error only when an error exists. -->
            <?php if ($error_message !== ""): ?>

                <!-- Create a visible error message container. -->
                <div class="error-message" role="alert">
                    <!-- Display the safely escaped error message. -->
                    <?= htmlspecialchars($error_message, ENT_QUOTES, "UTF-8") ?>
                </div>

            <!-- End the conditional error-message section. -->
            <?php endif; ?>

            <!-- Create the login form and send its information to this PHP page. -->
            <form action="login.php" method="POST">

                <!-- Create the hidden CSRF field to protect form submissions. -->
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= htmlspecialchars($_SESSION["csrf_token"], ENT_QUOTES, "UTF-8") ?>"
                >

                <!-- Create the username/email field group. -->
                <div class="form-group">

                    <!-- Connect the label to the username/email input. -->
                    <label for="login_identifier">Username or Email</label>

                    <!-- Allow the user to enter their username or email. -->
                    <input
                        type="text"
                        id="login_identifier"
                        name="login_identifier"
                        placeholder="Enter your username or email"
                        value="<?= $safe_login_identifier ?>"
                        autocomplete="username"
                        required
                    >

                </div>

                <!-- Create the password field group. -->
                <div class="form-group">

                    <!-- Connect the label to the password input. -->
                    <label for="password">Password</label>

                    <!-- Group the password input and visibility button. -->
                    <div class="password-wrapper">

                        <!-- Create the password input field. -->
                        <input
                            type="password"
                            id="password"
                            name="password"
                            placeholder="Enter your password"
                            autocomplete="current-password"
                            required
                        >

                        <!-- Create a button that will show or hide the password. -->
                        <button
                            type="button"
                            id="togglePassword"
                            class="toggle-password"
                            aria-label="Show password"
                        >
                            Show
                        </button>

                    </div>

                </div>

                <!-- Create the login submission button. -->
                <button type="submit" class="login-button">
                    Sign In
                </button>

            </form>

            <!-- Display a message about authorized system access. -->
            <p class="security-note">
                Authorized users only. Please keep your account credentials secure.
            </p>

        </section>

    </main>

    <!-- Load the JavaScript file after the login page content. -->
    <script src="assets/js/login.js"></script>
</body>
</html>
