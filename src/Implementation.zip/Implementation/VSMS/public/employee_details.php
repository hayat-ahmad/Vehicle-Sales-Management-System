
<?php
// Load the existing authentication functions and database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to log in before viewing employee information.
requireLogin();

// Retrieve the currently logged-in user's information.
$user = currentUser();

// Check whether the account is still active.
if ($user === null) {
    // Clear the session information.
    $_SESSION = [];

    // Destroy the current session.
    session_destroy();

    // Redirect to the login page.
    redirect("login.php");
}

// Store the current user's role.
$userRole = $user["role_name"];

// Only Administrators and Managers may view employee details.
if (!in_array($userRole, ["Administrator", "Manager"], true)) {
    // Return HTTP 403 Forbidden.
    http_response_code(403);

    // Stop execution and display a friendly message.
    exit("Access denied. You cannot view employee details.");
}

// Only the Administrator may edit employee records.
$canManageEmployees = ($userRole === "Administrator");

// Create a helper function to safely display HTML values.
function escapeEmployeeDetail($value): string
{
    // Convert special HTML characters into safe HTML entities.
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Read the employee ID from the URL.
$employeeId = $_GET["id"] ?? "";

// Check that the employee ID is a positive whole number.
if (!ctype_digit((string) $employeeId) || (int) $employeeId < 1) {
    // Return HTTP 400 Bad Request.
    http_response_code(400);

    // Stop execution because the employee ID is invalid.
    exit("Invalid employee ID.");
}

// Convert the employee ID into an integer.
$employeeId = (int) $employeeId;

// Initialize the employee information variable.
$employee = null;

// Initialize the sales performance information.
$salesCount = 0;
$salesRevenue = 0.00;
$recentSales = [];

// Track whether a database error occurs.
$databaseError = false;

// Track whether the employee record exists.
$employeeNotFound = false;

// Retrieve the employee and linked account information.
try {
    // Prepare a query that retrieves the employee record.
    // LEFT JOIN keeps employees visible even without a linked user account.
    $employeeQuery = $pdo->prepare(
        "SELECT
            e.employee_id,
            e.user_id,
            e.full_name,
            e.phone,
            e.email,
            e.position,
            e.status,
            e.created_at,
            e.updated_at,
            u.username,
            u.email AS account_email,
            u.status AS account_status,
            r.role_name
         FROM employees AS e
         LEFT JOIN users AS u
            ON e.user_id = u.user_id
         LEFT JOIN roles AS r
            ON u.role_id = r.role_id
         WHERE e.employee_id = ?
         LIMIT 1"
    );

    // Execute the query using the selected employee ID.
    $employeeQuery->execute([$employeeId]);

    // Retrieve the employee information.
    $employee = $employeeQuery->fetch(PDO::FETCH_ASSOC);

    // Check whether the employee exists.
    if (!$employee) {
        // Remember that the requested employee was not found.
        $employeeNotFound = true;
    } else {
        // Check whether the employee has a linked system account.
        if (!empty($employee["user_id"])) {

            // Count the employee's completed sales and calculate revenue.
            $performanceQuery = $pdo->prepare(
                "SELECT
                    COUNT(*) AS completed_sales,
                    COALESCE(SUM(final_amount), 0) AS total_revenue
                 FROM sales
                 WHERE salesperson_id = ?
                   AND sale_status = 'Completed'"
            );

            // Execute the performance query using the linked user ID.
            $performanceQuery->execute([(int) $employee["user_id"]]);

            // Retrieve the completed sales statistics.
            $performance = $performanceQuery->fetch(PDO::FETCH_ASSOC);

            // Store the completed sales count.
            $salesCount = (int) $performance["completed_sales"];

            // Store the completed sales revenue.
            $salesRevenue = (float) $performance["total_revenue"];

            // Retrieve the employee's five most recent sales.
            $recentSalesQuery = $pdo->prepare(
                "SELECT
                    s.sale_id,
                    s.sale_date,
                    s.final_amount,
                    s.sale_status,
                    c.full_name AS customer_name,
                    v.make,
                    v.model
                 FROM sales AS s
                 INNER JOIN customers AS c
                    ON s.customer_id = c.customer_id
                 INNER JOIN vehicles AS v
                    ON s.vehicle_id = v.vehicle_id
                 WHERE s.salesperson_id = ?
                 ORDER BY s.sale_date DESC, s.sale_id DESC
                 LIMIT 5"
            );

            // Execute the recent sales query.
            $recentSalesQuery->execute([(int) $employee["user_id"]]);

            // Retrieve the recent sales records.
            $recentSales = $recentSalesQuery->fetchAll(PDO::FETCH_ASSOC);
        }
    }

// Handle database errors without displaying technical information.
} catch (PDOException $exception) {
    // Log the technical database error privately.
    error_log("VSMS employee details error: " . $exception->getMessage());

    // Mark the page as having a database error.
    $databaseError = true;
}

// Create a CSRF token for the logout form if needed.
if (empty($_SESSION["csrf_token"])) {
    // Generate a secure random token.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Prepare the token for the logout form.
$csrfToken = $_SESSION["csrf_token"];

// Safely prepare the current user's name for display.
$currentUserName = escapeEmployeeDetail($user["full_name"]);

// Safely prepare the current user's role for display.
$currentUserRole = escapeEmployeeDetail($userRole);

// Prepare the employee status CSS class when the record exists.
$employeeStatusClass = "";

if ($employee !== null) {
    // Use a green style for active employees and grey for inactive employees.
    $employeeStatusClass = $employee["status"] === "Active"
        ? "employee-status-active"
        : "employee-status-inactive";
}

?>
<!DOCTYPE html>
<!-- Declare this document as an HTML5 page. -->
<html lang="en">

<head>
    <!-- Set the page character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on desktop and mobile devices. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Employee Details | VSMS</title>

    <!-- Load the existing dashboard stylesheet. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Load the existing vehicle stylesheet for shared cards and buttons. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <!-- Add styling specific to employee details. -->
    <style>
        /* Arrange the employee information cards in two columns. */
        .employee-detail-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
            margin-bottom: 22px;
        }

        /* Style the employee detail cards. */
        .employee-detail-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 22px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.04);
        }

        /* Style the employee information headings. */
        .employee-detail-card h2 {
            margin: 0 0 18px;
            color: #202b3c;
            font-size: 18px;
        }

        /* Arrange each employee information label and value. */
        .employee-information-row {
            display: grid;
            grid-template-columns: 145px 1fr;
            gap: 12px;
            padding: 12px 0;
            border-bottom: 1px solid #edf0f3;
        }

        /* Remove the border from the last information row. */
        .employee-information-row:last-child {
            border-bottom: none;
        }

        /* Style employee information labels. */
        .employee-information-label {
            color: #7b8492;
            font-size: 13px;
        }

        /* Style employee information values. */
        .employee-information-value {
            color: #263449;
            font-weight: 600;
            overflow-wrap: anywhere;
        }

        /* Style the employee status labels. */
        .employee-status {
            display: inline-block;
            padding: 5px 11px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
        }

        /* Use green for active employees. */
        .employee-status-active {
            color: #176b43;
            background: #e4f5eb;
        }

        /* Use grey for inactive employees. */
        .employee-status-inactive {
            color: #626b78;
            background: #edf0f3;
        }

        /* Arrange the employee performance cards. */
        .employee-performance-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 16px;
            margin-bottom: 22px;
        }

        /* Style each performance summary card. */
        .employee-performance-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.04);
        }

        /* Style performance labels. */
        .employee-performance-card span {
            display: block;
            color: #7b8492;
            font-size: 13px;
        }

        /* Style performance values. */
        .employee-performance-card strong {
            display: block;
            margin-top: 9px;
            color: #202b3c;
            font-size: 25px;
        }

        /* Keep the sales table readable on smaller screens. */
        .employee-sales-table-wrapper {
            overflow-x: auto;
        }

        /* Style the recent sales table. */
        .employee-sales-table {
            width: 100%;
            min-width: 650px;
            border-collapse: collapse;
        }

        /* Style the sales table headings and cells. */
        .employee-sales-table th,
        .employee-sales-table td {
            padding: 13px 11px;
            text-align: left;
            border-bottom: 1px solid #edf0f3;
        }

        /* Style the sales table headings. */
        .employee-sales-table th {
            color: #687486;
            font-size: 12px;
            text-transform: uppercase;
        }

        /* Style the page action buttons. */
        .employee-detail-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 22px;
        }

        /* Style the information and error messages. */
        .employee-detail-message {
            background: #fff0ed;
            color: #a33c2e;
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        /* Style the empty recent-sales message. */
        .employee-detail-empty {
            padding: 28px 15px;
            text-align: center;
            color: #7b8492;
        }

        /* Stack the information cards on smaller screens. */
        @media (max-width: 750px) {
            .employee-detail-grid {
                grid-template-columns: 1fr;
            }
        }

        /* Make performance cards and information rows mobile friendly. */
        @media (max-width: 500px) {
            .employee-performance-grid {
                grid-template-columns: 1fr;
            }

            .employee-information-row {
                grid-template-columns: 1fr;
                gap: 5px;
            }
        }
    </style>
</head>

<body>
    <!-- Create the main dashboard layout. -->
    <div class="dashboard-layout">

        <!-- Create the dark navigation sidebar. -->
        <aside class="sidebar">

<!-- Display the system logo and name. -->
<div class="brand">

    <!-- Display the short system name inside a logo box. -->
    <div class="brand-logo">V</div>

    <!-- Display the full system name. -->
    <div class="brand-text">
        <h2>VSMS</h2>
        <p>Vehicle Management</p>
    </div>

<!-- Close the brand section. -->
</div>

<!-- Display the main sidebar navigation. -->


<!-- Display all available system navigation links. -->
<nav class="sidebar-navigation">

    <!-- Display the navigation section heading. -->
    <p class="navigation-heading">MAIN MENU</p>

    <!-- Link to the Dashboard. -->
    <a href="dashboard.php" class="nav-link active">
        <span class="nav-icon">▦</span>
        <span>Dashboard</span>
    </a>

    <!-- Link to Vehicle Management. -->
    <a href="vehicles.php" class="nav-link">
        <span class="nav-icon">🚘</span>
        <span>Vehicles</span>
    </a>

    <!-- Link to Customer Management. -->
    <a href="customers.php" class="nav-link">
        <span class="nav-icon">♙</span>
        <span>Customers</span>
    </a>

    <!-- Link to Reservation Management. -->
    <a href="reservations.php" class="nav-link">
        <span class="nav-icon">▣</span>
        <span>Reservations</span>
    </a>

    <!-- Link to Sales Management. -->
    <a href="sales.php" class="nav-link">
        <span class="nav-icon">▤</span>
        <span>Sales</span>
    </a>

    <!-- Link to Payment Management. -->
    <a href="payments.php" class="nav-link">
        <span class="nav-icon">$</span>
        <span>Payments</span>
    </a>
    <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
<span class="nav-icon">◷</span>
<span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
<span class="nav-icon">▧</span>
<span>Invoices</span>
</a>

    <!-- Show employee management only to authorized management roles. -->
    <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

        <a href="employees.php" class="nav-link">
            <span class="nav-icon">♧</span>
            <span>Employees</span>
        </a>

    <?php endif; ?>
    <!-- Only Administrators can access User Account Management. -->
<?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
<span class="nav-icon">♙</span>
<span>User Accounts</span>
</a>

<?php endif; ?>

    <!-- Show reports only to authorized management roles. -->
    <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

        <a href="reports.php" class="nav-link">
            <span class="nav-icon">▥</span>
            <span>Reports</span>
        </a>

    <?php endif; ?>

<!-- Close the navigation section. -->
</nav>


<!-- Display a short project description at the bottom of the sidebar. -->
<div class="sidebar-footer">
    <p>Vehicle Sales &amp; Management System</p>
    <span>Development version</span>
</div>

<!-- Close the sidebar. -->
</aside>

        <!-- Create the main content area. -->
        <main class="main-content">

            <!-- Display the current user and logout action. -->
            <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Employee Details</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    <div class="user-information">
                    <a href="my_profile.php" class="profile-name-link"><?= $currentUserName ?></a>
                        <span><?= $currentUserRole ?></span>
                    </div>

    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>
           

            <!-- Display the employee details workspace. -->
            <section class="page-content">

                <?php if ($databaseError): ?>

                    <!-- Display a friendly database error message. -->
                    <div class="employee-detail-message">
                        Unable to load employee information. Please try again later.
                    </div>

                    <!-- Provide a link back to the employee directory. -->
                    <a href="employees.php" class="secondary-button">
                        Back to Employees
                    </a>

                <?php elseif ($employeeNotFound): ?>

                    <!-- Explain that the requested employee does not exist. -->
                    <div class="employee-detail-message">
                        The requested employee record could not be found.
                    </div>

                    <!-- Return to the employee directory. -->
                    <a href="employees.php" class="secondary-button">
                        Back to Employees
                    </a>

                <?php else: ?>

                    <!-- Introduce the selected employee. -->
                    <div class="page-heading">
                        <div>
                            <h1>
                                <?= escapeEmployeeDetail($employee["full_name"]) ?>
                            </h1>

                            <p>
                                Employee record #<?= (int) $employee["employee_id"] ?>
                            </p>
                        </div>
                    </div>

                    <!-- Display the employee page actions. -->
                    <div class="employee-detail-actions">

                        <!-- Return to the employee directory. -->
                        <a href="employees.php" class="secondary-button">
                            ← Back to Employees
                        </a>

                        <!-- Allow only the Administrator to edit employee information. -->
                        <?php if ($canManageEmployees): ?>
                            <a
                                href="edit_employee.php?id=<?= (int) $employee["employee_id"] ?>"
                                class="primary-button"
                            >
                                Edit Employee
                            </a>
                        <?php endif; ?>

                    </div>

                    <!-- Display the employee's main information cards. -->
                    <div class="employee-detail-grid">

                        <!-- Display personal and employment information. -->
                        <section class="employee-detail-card">

                            <h2>Employee Information</h2>

                            <!-- Display the employee's full name. -->
                            <div class="employee-information-row">
                                <span class="employee-information-label">Full Name</span>
                                <span class="employee-information-value">
                                    <?= escapeEmployeeDetail($employee["full_name"]) ?>
                                </span>
                            </div>

                            <!-- Display the employee's phone number. -->
                            <div class="employee-information-row">
                                <span class="employee-information-label">Phone</span>
                                <span class="employee-information-value">
                                    <?= escapeEmployeeDetail($employee["phone"]) ?>
                                </span>
                            </div>

                            <!-- Display the employee's email address. -->
                            <div class="employee-information-row">
                                <span class="employee-information-label">Email</span>
                                <span class="employee-information-value">
                                    <?= !empty($employee["email"])
                                        ? escapeEmployeeDetail($employee["email"])
                                        : "Not provided" ?>
                                </span>
                            </div>

                            <!-- Display the employee's job position. -->
                            <div class="employee-information-row">
                                <span class="employee-information-label">Position</span>
                                <span class="employee-information-value">
                                    <?= escapeEmployeeDetail($employee["position"]) ?>
                                </span>
                            </div>

                            <!-- Display the employee's current status. -->
                            <div class="employee-information-row">
                                <span class="employee-information-label">Employment Status</span>
                                <span class="employee-information-value">
                                    <span class="employee-status <?= $employeeStatusClass ?>">
                                        <?= escapeEmployeeDetail($employee["status"]) ?>
                                    </span>
                                </span>
                            </div>

                            <!-- Display the employee's registration date. -->
                            <div class="employee-information-row">
                                <span class="employee-information-label">Registered</span>
                                <span class="employee-information-value">
                                    <?= escapeEmployeeDetail($employee["created_at"]) ?>
                                </span>
                            </div>

                            <!-- Display the last employee record update date. -->
                            <div class="employee-information-row">
                                <span class="employee-information-label">Last Updated</span>
                                <span class="employee-information-value">
                                    <?= escapeEmployeeDetail($employee["updated_at"]) ?>
                                </span>
                            </div>

                        </section>

                        <!-- Display linked system-account information. -->
                        <section class="employee-detail-card">

                            <h2>System Account</h2>

                            <?php if (!empty($employee["user_id"])): ?>

                                <!-- Display the linked username. -->
                                <div class="employee-information-row">
                                    <span class="employee-information-label">Username</span>
                                    <span class="employee-information-value">
                                        <?= escapeEmployeeDetail($employee["username"]) ?>
                                    </span>
                                </div>

                                <!-- Display the system account's email. -->
                                <div class="employee-information-row">
                                    <span class="employee-information-label">Account Email</span>
                                    <span class="employee-information-value">
                                        <?= escapeEmployeeDetail($employee["account_email"]) ?>
                                    </span>
                                </div>

                                <!-- Display the linked account role. -->
                                <div class="employee-information-row">
                                    <span class="employee-information-label">System Role</span>
                                    <span class="employee-information-value">
                                        <?= escapeEmployeeDetail($employee["role_name"] ?? "Not available") ?>
                                    </span>
                                </div>

                                <!-- Display the login account's status. -->
                                <div class="employee-information-row">
                                    <span class="employee-information-label">Account Status</span>
                                    <span class="employee-information-value">
                                        <?= escapeEmployeeDetail($employee["account_status"]) ?>
                                    </span>
                                </div>

                            <?php else: ?>

                                <!-- Explain that this employee has no linked login account. -->
                                <div class="employee-detail-empty">
                                    <h3>No linked account</h3>
                                    <p>
                                        This employee record is not currently connected
                                        to a VSMS login account.
                                    </p>
                                </div>

                            <?php endif; ?>

                        </section>

                    </div>

                    <!-- Display sales performance only when a system account is linked. -->
                    <?php if (!empty($employee["user_id"])): ?>

                        <!-- Display the employee's completed sales performance. -->
                        <div class="employee-performance-grid">

                            <!-- Display the number of completed sales. -->
                            <article class="employee-performance-card">
                                <span>Completed Sales</span>
                                <strong><?= number_format($salesCount) ?></strong>
                            </article>

                            <!-- Display the total revenue from completed sales. -->
                            <article class="employee-performance-card">
                                <span>Completed Sales Revenue</span>
                                <strong><?= number_format($salesRevenue, 2) ?></strong>
                            </article>

                        </div>

                        <!-- Display the employee's recent sales records. -->
                        <section class="employee-detail-card">

                            <h2>Recent Sales</h2>

                            <?php if (!empty($recentSales)): ?>

                                <!-- Allow horizontal scrolling on small screens. -->
                                <div class="employee-sales-table-wrapper">

                                    <!-- Create the recent sales table. -->
                                    <table class="employee-sales-table">

                                        <!-- Define the sales table headings. -->
                                        <thead>
                                            <tr>
                                                <th>Sale ID</th>
                                                <th>Customer</th>
                                                <th>Vehicle</th>
                                                <th>Date</th>
                                                <th>Amount</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>

                                        <!-- Display the employee's recent sales. -->
                                        <tbody>

                                            <?php foreach ($recentSales as $sale): ?>
                                                <tr>

                                                    <!-- Display the sale identification number. -->
                                                    <td>#<?= (int) $sale["sale_id"] ?></td>

                                                    <!-- Display the customer name. -->
                                                    <td>
                                                        <?= escapeEmployeeDetail($sale["customer_name"]) ?>
                                                    </td>

                                                    <!-- Display the vehicle make and model. -->
                                                    <td>
                                                        <?= escapeEmployeeDetail(
                                                            $sale["make"] . " " . $sale["model"]
                                                        ) ?>
                                                    </td>

                                                    <!-- Display the sale date. -->
                                                    <td>
                                                        <?= escapeEmployeeDetail($sale["sale_date"]) ?>
                                                    </td>

                                                    <!-- Display the sale amount. -->
                                                    <td>
                                                        <?= number_format((float) $sale["final_amount"], 2) ?>
                                                    </td>

                                                    <!-- Display the sale status. -->
                                                    <td>
                                                        <?= escapeEmployeeDetail($sale["sale_status"]) ?>
                                                    </td>

                                                </tr>
                                            <?php endforeach; ?>

                                        </tbody>
                                    </table>

                                </div>

                            <?php else: ?>

                                <!-- Explain that there are no sales for this employee. -->
                                <div class="employee-detail-empty">
                                    <p>No sales records are currently available for this employee.</p>
                                </div>

                            <?php endif; ?>

                        </section>

                    <?php endif; ?>

                <?php endif; ?>

            </section>
        </main>
    </div>
</body>
</html>
