
<?php
// Load authentication, session handling, and the database connection.
require_once __DIR__ . "/../includes/auth.php";

// Only Administrators can change user roles.
requireRole("Administrator");

// Retrieve the logged-in Administrator.
$currentUser = currentUser();

// Redirect if the account is no longer available.
if ($currentUser === null) {
    redirect("login.php");
}

// Safely display database values in HTML.
function escapeRoleChangeHtml($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Create a CSRF token if one does not already exist.
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION["csrf_token"];

// Read and validate the target user ID.
$userId = filter_var(
    $_GET["id"] ?? $_POST["user_id"] ?? "",
    FILTER_VALIDATE_INT,
    ["options" => ["min_range" => 1]]
);

// Stop if the ID is invalid.
if ($userId === false) {
    http_response_code(400);
    exit("Invalid user account ID.");
}

// Initialize page variables.
$errors = [];
$successMessage = "";
$selectedRole = "";
$selectedEmployeeId = "";

// Retrieve the selected account and its linked employee.
try {
    $accountQuery = $pdo->prepare(
        "SELECT
            u.user_id,
            u.full_name,
            u.username,
            u.email,
            u.status,
            u.role_id,
            r.role_name,
            e.employee_id,
            e.full_name AS employee_name,
            e.position AS employee_position,
            e.status AS employee_status
         FROM users AS u
         INNER JOIN roles AS r
            ON r.role_id = u.role_id
         LEFT JOIN employees AS e
            ON e.user_id = u.user_id
         WHERE u.user_id = ?
         LIMIT 1"
    );

    $accountQuery->execute([$userId]);
    $account = $accountQuery->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {
    error_log("VSMS role change account load error: " . $exception->getMessage());
    http_response_code(500);
    exit("The user account could not be loaded.");
}

// Stop if the account does not exist.
if (!$account) {
    http_response_code(404);
    exit("The selected user account was not found.");
}

// Set the initial selected values.
$selectedRole = $account["role_name"];
$selectedEmployeeId = $account["employee_id"] !== null
    ? (string) $account["employee_id"]
    : "";

// Process the submitted form.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Read the submitted CSRF token.
    $submittedToken = $_POST["csrf_token"] ?? "";

    // Read the requested role.
    $roleInput = $_POST["role_name"] ?? "";
    $selectedRole = is_string($roleInput)
        ? trim($roleInput)
        : "";

    // Read the selected employee ID.
    $employeeInput = $_POST["employee_id"] ?? "";
    $selectedEmployeeId = is_string($employeeInput)
        ? trim($employeeInput)
        : "";

    // Verify the CSRF token.
    if (
        !is_string($submittedToken) ||
        !hash_equals($csrfToken, $submittedToken)
    ) {
        $errors[] = "Invalid request. Refresh the page and try again.";
    }

    // Accept only the three roles defined in the SRS.
    $allowedRoles = [
        "Administrator",
        "Manager",
        "Salesperson"
    ];

    if (!in_array($selectedRole, $allowedRoles, true)) {
        $errors[] = "Please select a valid system role.";
    }

    // Prevent an Administrator from changing their own role.
    if ((int) $userId === (int) $currentUser["user_id"]) {
        $errors[] = "You cannot change your own system role.";
    }

    // A Salesperson account must have a valid employee selected.
    if ($selectedRole === "Salesperson") {
        if (
            $selectedEmployeeId === "" ||
            !ctype_digit($selectedEmployeeId) ||
            (int) $selectedEmployeeId < 1
        ) {
            $errors[] = "Please select an eligible Salesperson employee.";
        }
    } else {
        // Other roles must not have an employee selected.
        $selectedEmployeeId = "";
    }

    // Continue only when basic validation succeeds.
    if (empty($errors)) {

        try {
            // Start a transaction for the role and employee-link updates.
            $pdo->beginTransaction();

            // Lock the selected user account.
            $lockUserQuery = $pdo->prepare(
                "SELECT
                    u.user_id,
                    u.status,
                    u.role_id,
                    r.role_name
                 FROM users AS u
                 INNER JOIN roles AS r
                    ON r.role_id = u.role_id
                 WHERE u.user_id = ?
                 FOR UPDATE"
            );

            $lockUserQuery->execute([$userId]);
            $lockedUser = $lockUserQuery->fetch(PDO::FETCH_ASSOC);

            if (!$lockedUser) {
                throw new RuntimeException(
                    "The selected user account no longer exists."
                );
            }

            // Check the current role again using the database record.
            $oldRole = $lockedUser["role_name"];

            // Prevent self-role changes even if the request was manipulated.
            if ((int) $userId === (int) $currentUser["user_id"]) {
                throw new RuntimeException(
                    "You cannot change your own system role."
                );
            }

            // Prevent demoting the last active Administrator.
            if (
                $oldRole === "Administrator" &&
                $selectedRole !== "Administrator" &&
                $lockedUser["status"] === "active"
            ) {
                $adminCountQuery = $pdo->query(
                    "SELECT COUNT(*)
                     FROM users AS u
                     INNER JOIN roles AS r
                        ON r.role_id = u.role_id
                     WHERE r.role_name = 'Administrator'
                       AND u.status = 'active'"
                );

                $activeAdminCount = (int) $adminCountQuery->fetchColumn();

                if ($activeAdminCount <= 1) {
                    throw new RuntimeException(
                        "You cannot change the role of the last active Administrator."
                    );
                }
            }

            // Find the requested role in the roles table.
            $roleQuery = $pdo->prepare(
                "SELECT role_id
                 FROM roles
                 WHERE role_name = ?
                 LIMIT 1"
            );

            $roleQuery->execute([$selectedRole]);
            $newRoleId = $roleQuery->fetchColumn();

            if (!$newRoleId) {
                throw new RuntimeException(
                    "The selected system role does not exist."
                );
            }

            // Lock the employee currently linked to this account, if any.
            $currentEmployeeQuery = $pdo->prepare(
                "SELECT employee_id
                 FROM employees
                 WHERE user_id = ?
                 FOR UPDATE"
            );

            $currentEmployeeQuery->execute([$userId]);
            $currentEmployeeId = $currentEmployeeQuery->fetchColumn();

            // Validate and lock the selected employee for Salesperson accounts.
            if ($selectedRole === "Salesperson") {

                $employeeQuery = $pdo->prepare(
                    "SELECT
                        employee_id,
                        full_name,
                        position,
                        status,
                        user_id
                     FROM employees
                     WHERE employee_id = ?
                     FOR UPDATE"
                );

                $employeeQuery->execute([
                    (int) $selectedEmployeeId
                ]);

                $employee = $employeeQuery->fetch(PDO::FETCH_ASSOC);

                // Verify that the selected employee exists.
                if (!$employee) {
                    throw new RuntimeException(
                        "The selected employee was not found."
                    );
                }

                // Only active Salesperson employees are eligible.
                if (
                    $employee["position"] !== "Salesperson" ||
                    $employee["status"] !== "Active"
                ) {
                    throw new RuntimeException(
                        "Only active employees with the Salesperson position can be linked to a Salesperson account."
                    );
                }

                // Prevent linking an employee who belongs to another account.
                if (
                    $employee["user_id"] !== null &&
                    (int) $employee["user_id"] !== (int) $userId
                ) {
                    throw new RuntimeException(
                        "This employee is already linked to another login account."
                    );
                }
            }

            // Remove the previous employee link, if one exists.
            if ($currentEmployeeId !== false) {

                $unlinkQuery = $pdo->prepare(
                    "UPDATE employees
                     SET user_id = NULL
                     WHERE user_id = ?"
                );

                $unlinkQuery->execute([$userId]);
            }

            // Update the user's role.
            $updateRoleQuery = $pdo->prepare(
                "UPDATE users
                 SET role_id = ?
                 WHERE user_id = ?"
            );

            $updateRoleQuery->execute([
                (int) $newRoleId,
                $userId
            ]);

            // Link the selected employee if the new role is Salesperson.
            if ($selectedRole === "Salesperson") {

                $linkEmployeeQuery = $pdo->prepare(
                    "UPDATE employees
                     SET user_id = ?
                     WHERE employee_id = ?
                       AND user_id IS NULL
                       AND position = 'Salesperson'
                       AND status = 'Active'"
                );

                $linkEmployeeQuery->execute([
                    $userId,
                    (int) $selectedEmployeeId
                ]);

                // Ensure the employee was linked successfully.
                if ($linkEmployeeQuery->rowCount() !== 1) {
                    throw new RuntimeException(
                        "The employee could not be linked. Please refresh the page and try again."
                    );
                }
            }

            // Commit the role and employee-link changes together.
            $pdo->commit();

            // Prepare a success message.
            $successMessage =
                "The account role was successfully changed from " .
                $oldRole .
                " to " .
                $selectedRole .
                ".";

            if ($selectedRole === "Salesperson") {
                $successMessage .=
                    " The account is linked to the selected employee.";
            } elseif ($currentEmployeeId !== false) {
                $successMessage .=
                    " The previous employee link has been removed.";
            }

            // Reload the account information after the change.
            $accountQuery->execute([$userId]);
            $account = $accountQuery->fetch(PDO::FETCH_ASSOC);

            // Update the selected values.
            $selectedRole = $account["role_name"];
            $selectedEmployeeId = $account["employee_id"] !== null
                ? (string) $account["employee_id"]
                : "";

        } catch (RuntimeException $exception) {

            // Roll back all changes if validation fails.
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            $errors[] = $exception->getMessage();

        } catch (PDOException $exception) {

            // Roll back all changes if a database error occurs.
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            // Record technical details privately.
            error_log("VSMS role change update error: " . $exception->getMessage());

            $errors[] =
                "The account role could not be changed. Please try again.";
        }
    }
}

// Retrieve eligible Salesperson employees.
// Include the employee already linked to this account, if applicable.
$employees = [];

try {
    $employeeListQuery = $pdo->prepare(
        "SELECT employee_id, full_name, user_id
         FROM employees
         WHERE position = 'Salesperson'
           AND status = 'Active'
           AND (user_id IS NULL OR user_id = ?)
         ORDER BY full_name ASC"
    );

    $employeeListQuery->execute([$userId]);
    $employees = $employeeListQuery->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {
    error_log("VSMS role change employee list error: " . $exception->getMessage());

    $errors[] =
        "The available Salesperson employees could not be loaded.";
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Change User Role | VSMS</title>

    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <style>
        .role-page {
            padding: 28px;
        }

        .role-card {
            background: #ffffff;
            max-width: 720px;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.04);
        }

        .role-card h2 {
            margin-top: 0;
            margin-bottom: 20px;
        }

        .role-form {
            display: grid;
            gap: 18px;
        }

        .role-form label {
            display: block;
            margin-bottom: 7px;
            font-weight: 600;
        }

        .role-form input,
        .role-form select {
            width: 100%;
            padding: 12px;
            border: 1px solid #dce1e8;
            border-radius: 7px;
            background: #ffffff;
            font: inherit;
        }

        .role-message {
            padding: 13px 16px;
            border-radius: 8px;
            margin-bottom: 18px;
        }

        .role-success {
            color: #176b43;
            background: #e4f5eb;
        }

        .role-error {
            color: #9b2929;
            background: #fdeaea;
        }

        .role-note {
            color: #647084;
            font-size: 13px;
            line-height: 1.6;
        }

        .role-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 5px;
        }

        .role-actions a {
            display: inline-block;
            text-decoration: none;
            padding: 11px 16px;
            border-radius: 7px;
            background: #edf0f4;
            color: #26364b;
        }

        @media (max-width: 600px) {
            .role-page {
                padding: 16px;
            }

            .role-card {
                padding: 17px;
            }
        }
    </style>
</head>

<body>

<div class="dashboard-layout">

    <main class="main-content">

        <div class="role-page">

            <div class="page-header">
                <div>
                    <h1>Change User Role</h1>
                    <p>Manage the system role assigned to this login account.</p>
                </div>
            </div>

            <div class="role-card">

                <h2>Account Information</h2>

                <?php if (!empty($errors)): ?>
                    <div class="role-message role-error">
                        <?php foreach ($errors as $error): ?>
                            <p><?= escapeRoleChangeHtml($error) ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($successMessage !== ""): ?>
                    <div class="role-message role-success">
                        <?= escapeRoleChangeHtml($successMessage) ?>
                    </div>
                <?php endif; ?>

                <form
                    method="POST"
                    action="change_user_role.php?id=<?= (int) $userId ?>"
                    class="role-form"
                >

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= escapeRoleChangeHtml($csrfToken) ?>"
                    >

                    <input
                        type="hidden"
                        name="user_id"
                        value="<?= (int) $userId ?>"
                    >

                    <div>
                        <label>Full Name</label>
                        <input
                            type="text"
                            value="<?= escapeRoleChangeHtml($account["full_name"]) ?>"
                            readonly
                        >
                    </div>

                    <div>
                        <label>Username</label>
                        <input
                            type="text"
                            value="<?= escapeRoleChangeHtml($account["username"]) ?>"
                            readonly
                        >
                    </div>

                    <div>
                        <label>Email Address</label>
                        <input
                            type="email"
                            value="<?= escapeRoleChangeHtml($account["email"]) ?>"
                            readonly
                        >
                    </div>

                    <div>
                        <label for="role_name">System Role</label>

                        <select
                            name="role_name"
                            id="role_name"
                            required
                        >
                            <option
                                value="Administrator"
                                <?= $selectedRole === "Administrator" ? "selected" : "" ?>
                            >
                                Administrator
                            </option>

                            <option
                                value="Manager"
                                <?= $selectedRole === "Manager" ? "selected" : "" ?>
                            >
                                Manager
                            </option>

                            <option
                                value="Salesperson"
                                <?= $selectedRole === "Salesperson" ? "selected" : "" ?>
                            >
                                Salesperson
                            </option>
                        </select>
                    </div>

                    <div id="employee-selection">

                        <label for="employee_id">
                            Link to Salesperson Employee
                        </label>

                        <select
                            name="employee_id"
                            id="employee_id"
                        >
                            <option value="">Select an employee</option>

                            <?php foreach ($employees as $employee): ?>
                                <option
                                    value="<?= (int) $employee["employee_id"] ?>"
                                    <?= $selectedEmployeeId === (string) $employee["employee_id"] ? "selected" : "" ?>
                                >
                                    <?= escapeRoleChangeHtml($employee["full_name"]) ?>
                                    (ID: <?= (int) $employee["employee_id"] ?>)
                                </option>
                            <?php endforeach; ?>

                        </select>

                        <p class="role-note">
                            A Salesperson login account must be linked to an
                            active employee whose position is Salesperson.
                        </p>

                        <?php if (empty($employees)): ?>
                            <p class="role-note">
                                No eligible unlinked Salesperson employees are
                                currently available.
                            </p>
                        <?php endif; ?>

                    </div>

                    <div>
                        <p class="role-note">
                            Changing an account from Salesperson to another
                            role will remove its employee link. The employee
                            record itself will not be deleted.
                        </p>
                    </div>

                    <div class="role-actions">

                        <button type="submit" class="btn btn-primary">
                            Save Role Change
                        </button>

                        <a href="users.php">
                            Back to User Management
                        </a>

                    </div>

                </form>

            </div>

        </div>

    </main>

</div>

<script>
    // Get the role selector and employee-selection section.
    const roleSelector = document.getElementById("role_name");
    const employeeSection = document.getElementById("employee-selection");
    const employeeSelector = document.getElementById("employee_id");

    // Show employee selection only when the Salesperson role is selected.
    function updateEmployeeVisibility() {

        if (roleSelector.value === "Salesperson") {
            employeeSection.style.display = "block";
            employeeSelector.required = true;
        } else {
            employeeSection.style.display = "none";
            employeeSelector.required = false;
        }
    }

    // Update the employee section when the role changes.
    roleSelector.addEventListener("change", updateEmployeeVisibility);

    // Set the correct initial display.
    updateEmployeeVisibility();
</script>

</body>
</html>
