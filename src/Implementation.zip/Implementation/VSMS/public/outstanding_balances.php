
<?php
// Load the existing authentication functions and PDO database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to log in before viewing financial information.
requireLogin();

// Retrieve the currently logged-in user's information.
$user = currentUser();

// Check whether the user's account is still active.
if ($user === null) {
    // Clear the current session data.
    $_SESSION = [];

    // Destroy the current session.
    session_destroy();

    // Redirect the unavailable account to the login page.
    redirect("login.php");
}

// Store the user's role for permission checks and display.
$userRole = $user["role_name"];

// Define the roles allowed to view outstanding balances.
$allowedRoles = ["Administrator", "Manager", "Salesperson"];

// Block users whose roles are not approved for this page.
if (!in_array($userRole, $allowedRoles, true)) {
    // Return the HTTP Forbidden status.
    http_response_code(403);

    // Stop execution with a friendly message.
    exit("Access denied. Your role cannot view outstanding balances.");
}

// Convert the current user's ID to an integer for database queries.
$currentUserId = (int) $user["user_id"];

// Create a helper function to safely display text in HTML.
function escapeBalanceHtml($value): string
{
    // Escape special HTML characters to prevent cross-site scripting.
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Create a helper function that formats payment-status CSS classes.
function balanceStatusClass(string $status): string
{
    // Return the CSS class matching the calculated payment status.
    return match ($status) {
        "Unpaid" => "status-unavailable",
        "Partially Paid" => "status-reserved",
        "Fully Paid" => "status-available",
        default => "status-unavailable"
    };
}

// Read the search text submitted through the GET form.
$search = trim($_GET["search"] ?? "");

// Read the selected payment-status filter.
$balanceStatusFilter = trim($_GET["balance_status"] ?? "");

// Accept only the three payment statuses used on this page.
$validBalanceStatuses = ["Unpaid", "Partially Paid", "Fully Paid"];

// Remove any invalid status value supplied through the URL.
if (!in_array($balanceStatusFilter, $validBalanceStatuses, true)) {
    $balanceStatusFilter = "";
}

// Initialize the result variables.
$balanceRecords = [];
$summary = [
    "total_sales" => 0,
    "total_sales_amount" => 0,
    "total_received" => 0,
    "total_outstanding" => 0,
    "unpaid_count" => 0,
    "partial_count" => 0,
    "paid_count" => 0
];

// Track whether a database error occurs.
$databaseError = false;

// Build a role-based condition for the sales query.
$roleCondition = "";

// Store the role-based query parameters separately.
$roleParameters = [];

// Restrict salespersons to their own sales.
if ($userRole === "Salesperson") {
    // Add a condition that matches the logged-in salesperson.
    $roleCondition = " AND s.salesperson_id = ? ";

    // Add the current user's ID as a prepared-statement parameter.
    $roleParameters[] = $currentUserId;
}

// Build the shared query that calculates payment totals and balances.
// Only completed sales and completed payments are included.
$balanceBaseSql = "
    SELECT
        s.sale_id,
        s.sale_date,
        s.final_amount,
        c.full_name AS customer_name,
        c.phone AS customer_phone,
        v.make,
        v.model,
        v.`year`,
        v.vin,
        u.full_name AS salesperson_name,
        COALESCE(payment_totals.total_paid, 0.00) AS total_paid,
        GREATEST(
            s.final_amount - COALESCE(payment_totals.total_paid, 0.00),
            0.00
        ) AS outstanding_balance
    FROM sales AS s
    INNER JOIN customers AS c
        ON c.customer_id = s.customer_id
    INNER JOIN vehicles AS v
        ON v.vehicle_id = s.vehicle_id
    INNER JOIN users AS u
        ON u.user_id = s.salesperson_id
    LEFT JOIN (
        SELECT
            sale_id,
            SUM(payment_amount) AS total_paid
        FROM payments
        WHERE payment_status = 'Completed'
        GROUP BY sale_id
    ) AS payment_totals
        ON payment_totals.sale_id = s.sale_id
    WHERE s.sale_status = 'Completed'
    $roleCondition
";

// Try to retrieve the financial summaries and matching sales.
try {
    // Calculate summary values using the same role restrictions.
    $summarySql = "
        SELECT
            COUNT(*) AS total_sales,
            COALESCE(SUM(final_amount), 0.00) AS total_sales_amount,
            COALESCE(SUM(total_paid), 0.00) AS total_received,
            COALESCE(SUM(outstanding_balance), 0.00) AS total_outstanding,
            COALESCE(SUM(CASE WHEN total_paid = 0 THEN 1 ELSE 0 END), 0) AS unpaid_count,
            COALESCE(SUM(CASE
                WHEN total_paid > 0 AND total_paid < final_amount
                THEN 1 ELSE 0
            END), 0) AS partial_count,
            COALESCE(SUM(CASE
                WHEN total_paid >= final_amount
                THEN 1 ELSE 0
            END), 0) AS paid_count
        FROM ($balanceBaseSql) AS balance_data
    ";

    // Prepare the summary query.
    $summaryStatement = $pdo->prepare($summarySql);

    // Execute the summary query with the role restriction.
    $summaryStatement->execute($roleParameters);

    // Retrieve the calculated summary values.
    $summaryResult = $summaryStatement->fetch();

    // Replace the default summary values with database results.
    if ($summaryResult) {
        // Convert count values to integers.
        $summary["total_sales"] = (int) $summaryResult["total_sales"];
        $summary["unpaid_count"] = (int) $summaryResult["unpaid_count"];
        $summary["partial_count"] = (int) $summaryResult["partial_count"];
        $summary["paid_count"] = (int) $summaryResult["paid_count"];

        // Convert financial values to floating-point numbers.
        $summary["total_sales_amount"] = (float) $summaryResult["total_sales_amount"];
        $summary["total_received"] = (float) $summaryResult["total_received"];
        $summary["total_outstanding"] = (float) $summaryResult["total_outstanding"];
    }

    // Start the main query using the shared balance calculation.
    $recordsSql = "
        SELECT
            balance_data.*,
            CASE
                WHEN total_paid = 0 THEN 'Unpaid'
                WHEN total_paid >= final_amount THEN 'Fully Paid'
                ELSE 'Partially Paid'
            END AS balance_status
        FROM ($balanceBaseSql) AS balance_data
        WHERE 1 = 1
    ";

    // Start with the role parameters used by the inner query.
    $recordsParameters = $roleParameters;

    // Add search conditions when the user entered search text.
    if ($search !== "") {
        // Search across sale, customer, vehicle, VIN, and salesperson details.
        $recordsSql .= "
            AND (
                CAST(sale_id AS CHAR) LIKE ?
                OR customer_name LIKE ?
                OR customer_phone LIKE ?
                OR make LIKE ?
                OR model LIKE ?
                OR vin LIKE ?
                OR salesperson_name LIKE ?
            )
        ";

        // Add wildcard characters to find partial matches.
        $searchValue = "%" . $search . "%";

        // Add one parameter for each search placeholder.
        for ($i = 0; $i < 7; $i++) {
            $recordsParameters[] = $searchValue;
        }
    }

    // Apply the selected payment-status filter.
    if ($balanceStatusFilter === "Unpaid") {
        // Select sales that have received no completed payments.
        $recordsSql .= " AND total_paid = 0 ";
    } elseif ($balanceStatusFilter === "Partially Paid") {
        // Select sales with some payment but a remaining balance.
        $recordsSql .= " AND total_paid > 0 AND total_paid < final_amount ";
    } elseif ($balanceStatusFilter === "Fully Paid") {
        // Select sales whose completed payments cover the final amount.
        $recordsSql .= " AND total_paid >= final_amount ";
    }

    // Display the newest completed sales first.
    $recordsSql .= " ORDER BY sale_date DESC, sale_id DESC ";

    // Prepare the main balance-record query.
    $recordsStatement = $pdo->prepare($recordsSql);

    // Execute the query using the role and search parameters.
    $recordsStatement->execute($recordsParameters);

    // Retrieve all matching balance records.
    $balanceRecords = $recordsStatement->fetchAll();

} catch (PDOException $exception) {
    // Remember that the database information could not be loaded.
    $databaseError = true;

    // Log technical details privately for troubleshooting.
    error_log("VSMS outstanding balances error: " . $exception->getMessage());
}

// Create a CSRF token if the current session does not already contain one.
if (empty($_SESSION["csrf_token"])) {
    // Generate a secure random token.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Store the session token for the logout form.
$csrfToken = $_SESSION["csrf_token"];
?>

<!DOCTYPE html>
<!-- Declare this document as an HTML5 page. -->
<html lang="en">
<!-- Start the HTML document and identify its language. -->
<head>
    <!-- Set the character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on different screen sizes. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Outstanding Balances | VSMS</title>

    <!-- Load the shared dashboard styling. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Reuse the existing inventory table and card styling. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">
</head>
<!-- Finish the document head. -->

<body>
    <!-- Create the main dashboard layout. -->
    <div class="dashboard-layout">

        <!-- Create the dark navigation sidebar. -->
        <aside class="sidebar">

            <!-- Display the VSMS brand. -->
            <div class="brand">
                <div class="brand-logo">V</div>
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>
            </div>

            <!-- Display the main navigation links. -->
            
<nav class="sidebar-navigation">
    <p class="navigation-heading">MAIN MENU</p>

    <!-- Dashboard -->
    <a href="dashboard.php" class="nav-link">
        <span class="nav-icon">▦</span>
        <span>Dashboard</span>
    </a>

    <!-- Vehicles -->
    <a href="vehicles.php" class="nav-link">
        <span class="nav-icon">🚘</span>
        <span>Vehicles</span>
    </a>

    <!-- Customers -->
    <a href="customers.php" class="nav-link">
        <span class="nav-icon">♙</span>
        <span>Customers</span>
    </a>

    <!-- Reservations -->
    <a href="reservations.php" class="nav-link">
        <span class="nav-icon">▣</span>
        <span>Reservations</span>
    </a>

    <!-- Sales -->
    <a href="sales.php" class="nav-link">
        <span class="nav-icon">▤</span>
        <span>Sales</span>
    </a>

    <!-- Payments -->
    <a href="payments.php" class="nav-link">
        <span class="nav-icon">$</span>
        <span>Payments</span>
    </a>

    <!-- Outstanding Balances: current page -->
    <a href="outstanding_balances.php" class="nav-link active">
        <span class="nav-icon">◷</span>
        <span>Outstanding Balances</span>
    </a>
    <a href="invoices.php" class="nav-link">
        <span class="nav-icon">▧</span>
        <span>Invoices</span>
    </a>
    <!-- Employees: Administrator and Manager only -->
    <?php if (hasRole('Administrator') || hasRole('Manager')): ?>
        <a href="employees.php" class="nav-link">
            <span class="nav-icon">♧</span>
            <span>Employees</span>
        </a>
        <?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
    <span class="nav-icon">♙</span>
    <span>User Accounts</span>
</a>

<?php endif; ?>
        <!-- Reports -->
        <a href="reports.php" class="nav-link">
            <span class="nav-icon">▥</span>
            <span>Reports</span>
        </a>
    <?php endif; ?>

</nav>
<div class="sidebar-footer">
                <p>Vehicle Sales &amp; Management System</p>
                <span>Development version</span>
            </div>

        </aside>

        <!-- Create the main content area. -->
        <main class="main-content">

            <!-- Display the page heading and current user information. -->
            <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Outstanding Balances</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    <div class="user-information">
                    
                    <a href="my_profile.php" class="profile-name-link">
                    <?= escapeBalanceHtml($user["full_name"]) ?>
</a>
                        <span><?= escapeBalanceHtml($userRole) ?></span>
                    </div>
    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>

          

            <!-- Place the balance page content inside the workspace. -->
            <section class="page-content">

                <!-- Introduce the page and its purpose. -->
                <div class="page-heading">
                    <div>
                        <h1>Outstanding Balances</h1>
                        <p>
                            Monitor completed sales, payments received, and remaining customer balances.
                        </p>
                    </div>
                </div>

                <!-- Display a friendly message if the database query fails. -->
                <?php if ($databaseError): ?>
                    <div class="inventory-message error-message">
                        Unable to load outstanding balances. Please try again later.
                    </div>
                <?php else: ?>

                    <!-- Display the financial summary cards. -->
                    <div class="inventory-summary">

                        <!-- Show the number of completed sales. -->
                        <article class="summary-card">
                            <span class="summary-label">Completed Sales</span>
                            <strong><?= number_format($summary["total_sales"]) ?></strong>
                            <small>Sales included in this report</small>
                        </article>

                        <!-- Show the total value of completed sales. -->
                        <article class="summary-card">
                            <span class="summary-label">Total Sales Amount</span>
                            <strong><?= number_format($summary["total_sales_amount"], 2) ?></strong>
                            <small>Total value of completed sales</small>
                        </article>

                        <!-- Show the amount received through completed payments. -->
                        <article class="summary-card">
                            <span class="summary-label">Total Received</span>
                            <strong><?= number_format($summary["total_received"], 2) ?></strong>
                            <small>Completed payments only</small>
                        </article>

                        <!-- Show the remaining amount customers owe. -->
                        <article class="summary-card">
                            <span class="summary-label">Outstanding Balance</span>
                            <strong><?= number_format($summary["total_outstanding"], 2) ?></strong>
                            <small>Amount still to be collected</small>
                        </article>

                        <!-- Show the number of sales with no completed payments. -->
                        <article class="summary-card">
                            <span class="summary-label">Unpaid Sales</span>
                            <strong><?= number_format($summary["unpaid_count"]) ?></strong>
                            <small>No completed payments received</small>
                        </article>

                        <!-- Show the number of sales with partial payments. -->
                        <article class="summary-card">
                            <span class="summary-label">Partially Paid</span>
                            <strong><?= number_format($summary["partial_count"]) ?></strong>
                            <small>Payment received, balance remains</small>
                        </article>
                    </div>

                    <!-- Create the search and filter card. -->
                    <section class="inventory-card">

                        <!-- Introduce the search and filter controls. -->
                        <div class="card-heading">
                            <div>
                                <h2>Search and Filter Balances</h2>
                                <p>Find completed sales and check their payment status.</p>
                            </div>
                        </div>

                        <!-- Submit search and filter values using GET. -->
                        <form action="outstanding_balances.php" method="GET" class="filter-form">

                            <!-- Search sale, customer, vehicle, or salesperson information. -->
                            <div class="filter-field search-field">
                                <label for="search">Search records</label>
                                <input
                                    type="search"
                                    id="search"
                                    name="search"
                                    placeholder="Sale ID, customer, phone, vehicle, VIN..."
                                    value="<?= escapeBalanceHtml($search) ?>"
                                >
                            </div>

                            <!-- Filter records by payment status. -->
                            <div class="filter-field">
                                <label for="balance_status">Payment status</label>
                                <select id="balance_status" name="balance_status">
                                    <option value="">All payment statuses</option>
                                    <option
                                        value="Unpaid"
                                        <?= $balanceStatusFilter === "Unpaid" ? "selected" : "" ?>
                                    >
                                        Unpaid
                                    </option>
                                    <option
                                        value="Partially Paid"
                                        <?= $balanceStatusFilter === "Partially Paid" ? "selected" : "" ?>
                                    >
                                        Partially Paid
                                    </option>
                                    <option
                                        value="Fully Paid"
                                        <?= $balanceStatusFilter === "Fully Paid" ? "selected" : "" ?>
                                    >
                                        Fully Paid
                                    </option>
                                </select>
                            </div>

                            <!-- Group the filter and reset buttons. -->
                            <div class="filter-actions">
                                <button type="submit" class="primary-button">Apply Filters</button>
                                <a href="outstanding_balances.php" class="secondary-button">
                                    Clear Filters
                                </a>
                            </div>
                        </form>
                    </section>

                    <!-- Display the completed sales and their balances. -->
                    <section class="inventory-card vehicle-list-card">

                        <!-- Show the number of matching records. -->
                        <div class="card-heading vehicle-list-heading">
                            <div>
                                <h2>Sales and Customer Balances</h2>
                                <p>
                                    <?= count($balanceRecords) ?> matching record(s)
                                </p>
                            </div>
                        </div>

                        <!-- Display the table when matching records exist. -->
                        <?php if (!empty($balanceRecords)): ?>
                            <div class="table-responsive">
                                <table class="vehicle-table">

                                    <!-- Define the table column headings. -->
                                    <thead>
                                        <tr>
                                            <th>Sale ID</th>
                                            <th>Sale Date</th>
                                            <th>Customer</th>
                                            <th>Vehicle</th>
                                            <th>Salesperson</th>
                                            <th>Sale Amount</th>
                                            <th>Paid</th>
                                            <th>Balance</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>

                                    <!-- Display each completed sale. -->
                                    <tbody>
                                        <?php foreach ($balanceRecords as $record): ?>
                                            <tr>

                                                <!-- Display the sale's database ID. -->
                                                <td>#<?= (int) $record["sale_id"] ?></td>

                                                <!-- Display the date of the completed sale. -->
                                                <td>
                                                    <?= escapeBalanceHtml(
                                                        date("d M Y", strtotime($record["sale_date"]))
                                                    ) ?>
                                                </td>

                                                <!-- Display the customer's name and phone number. -->
                                                <td>
                                                    <strong>
                                                        <?= escapeBalanceHtml($record["customer_name"]) ?>
                                                    </strong>
                                                    <br>
                                                    <small>
                                                        <?= escapeBalanceHtml($record["customer_phone"]) ?>
                                                    </small>
                                                </td>

                                                <!-- Display the vehicle's make, model, year, and VIN. -->
                                                <td>
                                                    <strong>
                                                        <?= escapeBalanceHtml(
                                                            $record["make"] . " " . $record["model"]
                                                        ) ?>
                                                    </strong>
                                                    <br>
                                                    <small>
                                                        <?= escapeBalanceHtml($record["year"]) ?>
                                                        · <?= escapeBalanceHtml($record["vin"]) ?>
                                                    </small>
                                                </td>

                                                <!-- Display the salesperson responsible for the sale. -->
                                                <td>
                                                    <?= escapeBalanceHtml($record["salesperson_name"]) ?>
                                                </td>

                                                <!-- Display the final sale amount. -->
                                                <td class="price-cell">
                                                    <?= number_format((float) $record["final_amount"], 2) ?>
                                                </td>

                                                <!-- Display the total amount received. -->
                                                <td class="price-cell">
                                                    <?= number_format((float) $record["total_paid"], 2) ?>
                                                </td>

                                                <!-- Display the remaining customer balance. -->
                                                <td class="price-cell">
                                                    <strong>
                                                        <?= number_format(
                                                            (float) $record["outstanding_balance"],
                                                            2
                                                        ) ?>
                                                    </strong>
                                                </td>

                                                <!-- Display the calculated payment status. -->
                                                <td>
                                                    <span class="status-badge <?= escapeBalanceHtml(
                                                        balanceStatusClass($record["balance_status"])
                                                    ) ?>">
                                                        <?= escapeBalanceHtml($record["balance_status"]) ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                        <!-- Explain when no records match the search or filter. -->
                        <?php else: ?>
                            <div class="empty-inventory">
                                <div class="empty-inventory-icon">◷</div>
                                <h3>No balance records found</h3>
                                <p>
                                    No completed sales match your search or selected payment status.
                                </p>
                            </div>
                        <?php endif; ?>
                    </section>
                <?php endif; ?>
            </section>
        </main>
    </div>
</body>
<!-- Finish the HTML document. -->
</html>
