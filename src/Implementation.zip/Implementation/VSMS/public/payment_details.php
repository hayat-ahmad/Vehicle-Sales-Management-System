
<?php
// Load authentication functions and the database connection.
require_once __DIR__ . '/../includes/auth.php';

// Ensure the user is logged in.
requireLogin();

// Retrieve the logged-in user's information.
$user = currentUser();

// Allow only authorized system roles to view payment details.
if (
    !hasRole('Administrator') &&
    !hasRole('Manager') &&
    !hasRole('Salesperson')
) {
    http_response_code(403);
    exit('Access denied. You are not authorized to view payment details.');
}

// Check whether the logged-in user is a salesperson.
$isSalesperson = hasRole('Salesperson');

// Get the logged-in user's ID.
$currentUserId = (int) $user['user_id'];

// Create a helper function to safely display values in HTML.
function paymentDetailsEscape($value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

// Read and validate the payment ID from the URL.
$paymentId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

// Stop if the payment ID is missing or invalid.
if (!$paymentId || $paymentId <= 0) {
    http_response_code(400);
    exit('Invalid payment ID.');
}

// Prepare the payment details variable.
$payment = null;

// Prepare an error message.
$pageError = '';

try {

    // Build the query to retrieve the payment and related information.
    $sql = "
        SELECT
            p.payment_id,
            p.sale_id,
            p.payment_amount,
            p.payment_method,
            p.transaction_reference,
            p.payment_date,
            p.payment_status,
            p.notes,
            p.created_at,
            p.updated_at,

            c.customer_id,
            c.full_name AS customer_name,
            c.phone AS customer_phone,
            c.email AS customer_email,
            c.address AS customer_address,

            v.vehicle_id,
            v.make,
            v.model,
            v.year,
            v.vin,
            v.category,
            v.color,
            v.fuel_type,
            v.transmission,

            s.sale_date,
            s.vehicle_price,
            s.discount_amount,
            s.additional_charges,
            s.final_amount,
            s.sale_status,

            salesperson.user_id AS salesperson_id,
            salesperson.full_name AS salesperson_name,

            payment_user.full_name AS recorded_by

        FROM payments AS p

        INNER JOIN sales AS s
            ON p.sale_id = s.sale_id

        INNER JOIN customers AS c
            ON s.customer_id = c.customer_id

        INNER JOIN vehicles AS v
            ON s.vehicle_id = v.vehicle_id

        INNER JOIN users AS salesperson
            ON s.salesperson_id = salesperson.user_id

        INNER JOIN users AS payment_user
            ON p.created_by = payment_user.user_id

        WHERE p.payment_id = :payment_id
    ";

    // Salespersons can access only payments for their own sales.
    if ($isSalesperson) {
        $sql .= " AND s.salesperson_id = :current_user_id";
    }

    // Prepare the SQL statement.
    $statement = $pdo->prepare($sql);

    // Bind the payment ID securely.
    $statement->bindValue(
        ':payment_id',
        $paymentId,
        PDO::PARAM_INT
    );

    // Bind the salesperson ID when necessary.
    if ($isSalesperson) {
        $statement->bindValue(
            ':current_user_id',
            $currentUserId,
            PDO::PARAM_INT
        );
    }

    // Execute the query.
    $statement->execute();

    // Retrieve the payment record.
    $payment = $statement->fetch(PDO::FETCH_ASSOC);

    // Show a not-found response if no accessible payment exists.
    if (!$payment) {
        http_response_code(404);
        exit('Payment not found or you are not authorized to view it.');
    }

    // Calculate the total completed payments for the related sale.
    $balanceSql = "
        SELECT
            COALESCE(SUM(payment_amount), 0) AS total_paid
        FROM payments
        WHERE sale_id = :sale_id
          AND payment_status = 'Completed'
    ";

    // Prepare the payment total query.
    $balanceStatement = $pdo->prepare($balanceSql);

    // Bind the related sale ID.
    $balanceStatement->execute([
        ':sale_id' => (int) $payment['sale_id']
    ]);

    // Retrieve the total amount received for the sale.
    $totalPaid = (float) $balanceStatement->fetchColumn();

    // Calculate the outstanding balance.
    $outstandingBalance = max(
        0,
        (float) $payment['final_amount'] - $totalPaid
    );

} catch (PDOException $exception) {

    // Log technical details for troubleshooting.
    error_log('Payment details error: ' . $exception->getMessage());

    // Display a safe error message.
    $pageError = 'Unable to load payment details. Please try again.';
}

// Prepare a CSS class for the payment status.
$statusClass = '';

if ($payment) {
    $statusClass = match ($payment['payment_status']) {
        'Completed' => 'payment-status-completed',
        'Pending' => 'payment-status-pending',
        'Failed' => 'payment-status-failed',
        'Refunded' => 'payment-status-refunded',
        default => ''
    };
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Define the character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on different devices. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Payment Details | VSMS</title>

    <!-- Reuse the existing application stylesheets. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <!-- Add styles specific to payment details. -->
    <style>
        .payment-details-page {
            padding: 24px;
            color: #263445;
        }

        .payment-details-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 16px;
            margin-bottom: 24px;
        }

        .payment-details-header h1 {
            margin: 0 0 6px;
            font-size: 25px;
        }

        .payment-details-header p {
            margin: 0;
            color: #748091;
        }

        .payment-details-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .payment-details-button {
            display: inline-block;
            padding: 10px 16px;
            border: none;
            border-radius: 7px;
            background: #f47755;
            color: #ffffff;
            text-decoration: none;
            font-weight: 600;
        }

        .payment-details-button:hover {
            background: #df6546;
            color: #ffffff;
        }

        .payment-details-button-secondary {
            background: #263b56;
        }

        .payment-details-button-secondary:hover {
            background: #1b2d43;
        }

        .payment-details-card {
            background: #ffffff;
            border: 1px solid #e7ebf0;
            border-radius: 10px;
            padding: 22px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(25, 42, 62, 0.04);
        }

        .payment-details-card h2 {
            margin: 0 0 18px;
            color: #263b56;
            font-size: 18px;
        }

        .payment-details-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 20px;
        }

        .payment-detail-item {
            min-width: 0;
        }

        .payment-detail-item span {
            display: block;
            margin-bottom: 6px;
            color: #748091;
            font-size: 12px;
        }

        .payment-detail-item strong {
            display: block;
            color: #263445;
            font-size: 14px;
            overflow-wrap: anywhere;
        }

        .payment-detail-item.full-width {
            grid-column: 1 / -1;
        }

        .payment-highlight {
            color: #df6546 !important;
            font-size: 21px !important;
        }

        .payment-status {
            display: inline-block;
            padding: 6px 11px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
        }

        .payment-status-completed {
            background: #dff5e8;
            color: #197344 !important;
        }

        .payment-status-pending {
            background: #fff1d6;
            color: #986300 !important;
        }

        .payment-status-failed {
            background: #fde5e5;
            color: #b33b3b !important;
        }

        .payment-status-refunded {
            background: #e8e8f7;
            color: #56569a !important;
        }

        .payment-details-error {
            padding: 14px 16px;
            background: #fff0f0;
            color: #a52c2c;
            border-radius: 7px;
        }

        @media (max-width: 850px) {
            .payment-details-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 550px) {
            .payment-details-page {
                padding: 14px;
            }

            .payment-details-grid {
                grid-template-columns: 1fr;
            }

            .payment-detail-item.full-width {
                grid-column: auto;
            }
        }
    </style>

</head>

<body>

<div class="payment-details-page">

    <!-- Page heading and navigation buttons. -->
    <div class="payment-details-header">

        <div>
            <h1>Payment Details</h1>
            <p>View the payment record and its related sale information.</p>
        </div>

        <div class="payment-details-actions">

            <!-- Return to the payment history page. -->
            <a
                href="payments.php"
                class="payment-details-button payment-details-button-secondary"
            >
                Payment History
            </a>

            <!-- Return to the sales history page. -->
            <a
                href="sales.php"
                class="payment-details-button"
            >
                Sales History
            </a>

        </div>

    </div>

    <!-- Display an error if payment details could not be loaded. -->
    <?php if ($pageError !== ''): ?>

        <div class="payment-details-error">
            <?= paymentDetailsEscape($pageError) ?>
        </div>

    <?php elseif ($payment): ?>

        <!-- Payment information section. -->
        <div class="payment-details-card">

            <h2>Payment Information</h2>

            <div class="payment-details-grid">

                <div class="payment-detail-item">
                    <span>Payment ID</span>
                    <strong>
                        #<?= (int) $payment['payment_id'] ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Related Sale ID</span>
                    <strong>
                        #<?= (int) $payment['sale_id'] ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Payment Status</span>
                    <strong>
                        <span class="payment-status <?= $statusClass ?>">
                            <?= paymentDetailsEscape($payment['payment_status']) ?>
                        </span>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Payment Amount</span>
                    <strong class="payment-highlight">
                        $<?= number_format(
                            (float) $payment['payment_amount'],
                            2
                        ) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Payment Method</span>
                    <strong>
                        <?= paymentDetailsEscape($payment['payment_method']) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Payment Date</span>
                    <strong>
                        <?= paymentDetailsEscape(
                            date(
                                'd M Y, h:i A',
                                strtotime($payment['payment_date'])
                            )
                        ) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Transaction Reference</span>
                    <strong>
                        <?= $payment['transaction_reference']
                            ? paymentDetailsEscape($payment['transaction_reference'])
                            : 'Not provided'
                        ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Recorded By</span>
                    <strong>
                        <?= paymentDetailsEscape($payment['recorded_by']) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Salesperson</span>
                    <strong>
                        <?= paymentDetailsEscape($payment['salesperson_name']) ?>
                    </strong>
                </div>

                <div class="payment-detail-item full-width">
                    <span>Payment Notes</span>
                    <strong>
                        <?= $payment['notes']
                            ? nl2br(paymentDetailsEscape($payment['notes']))
                            : 'No additional notes'
                        ?>
                    </strong>
                </div>

            </div>

        </div>

        <!-- Customer information section. -->
        <div class="payment-details-card">

            <h2>Customer Information</h2>

            <div class="payment-details-grid">

                <div class="payment-detail-item">
                    <span>Customer ID</span>
                    <strong>
                        #<?= (int) $payment['customer_id'] ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Customer Name</span>
                    <strong>
                        <?= paymentDetailsEscape($payment['customer_name']) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Phone Number</span>
                    <strong>
                        <?= paymentDetailsEscape($payment['customer_phone']) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Email Address</span>
                    <strong>
                        <?= $payment['customer_email']
                            ? paymentDetailsEscape($payment['customer_email'])
                            : 'Not provided'
                        ?>
                    </strong>
                </div>

                <div class="payment-detail-item full-width">
                    <span>Address</span>
                    <strong>
                        <?= $payment['customer_address']
                            ? nl2br(paymentDetailsEscape($payment['customer_address']))
                            : 'Not provided'
                        ?>
                    </strong>
                </div>

            </div>

        </div>

        <!-- Vehicle information section. -->
        <div class="payment-details-card">

            <h2>Vehicle Information</h2>

            <div class="payment-details-grid">

                <div class="payment-detail-item">
                    <span>Vehicle ID</span>
                    <strong>
                        #<?= (int) $payment['vehicle_id'] ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Vehicle</span>
                    <strong>
                        <?= paymentDetailsEscape(
                            $payment['year'] . ' ' .
                            $payment['make'] . ' ' .
                            $payment['model']
                        ) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>VIN</span>
                    <strong>
                        <?= paymentDetailsEscape($payment['vin']) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Category</span>
                    <strong>
                        <?= paymentDetailsEscape($payment['category']) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Color</span>
                    <strong>
                        <?= paymentDetailsEscape($payment['color']) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Fuel Type</span>
                    <strong>
                        <?= paymentDetailsEscape($payment['fuel_type']) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Transmission</span>
                    <strong>
                        <?= paymentDetailsEscape($payment['transmission']) ?>
                    </strong>
                </div>

            </div>

        </div>

        <!-- Related sale financial information. -->
        <div class="payment-details-card">

            <h2>Related Sale and Balance</h2>

            <div class="payment-details-grid">

                <div class="payment-detail-item">
                    <span>Sale Date</span>
                    <strong>
                        <?= paymentDetailsEscape(
                            date(
                                'd M Y, h:i A',
                                strtotime($payment['sale_date'])
                            )
                        ) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Sale Status</span>
                    <strong>
                        <?= paymentDetailsEscape($payment['sale_status']) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Vehicle Price</span>
                    <strong>
                        $<?= number_format(
                            (float) $payment['vehicle_price'],
                            2
                        ) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Discount</span>
                    <strong>
                        $<?= number_format(
                            (float) $payment['discount_amount'],
                            2
                        ) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Additional Charges</span>
                    <strong>
                        $<?= number_format(
                            (float) $payment['additional_charges'],
                            2
                        ) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Final Sale Amount</span>
                    <strong>
                        $<?= number_format(
                            (float) $payment['final_amount'],
                            2
                        ) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Total Completed Payments</span>
                    <strong>
                        $<?= number_format($totalPaid, 2) ?>
                    </strong>
                </div>

                <div class="payment-detail-item">
                    <span>Outstanding Balance</span>
                    <strong class="payment-highlight">
                        $<?= number_format($outstandingBalance, 2) ?>
                    </strong>
                </div>

            </div>

        </div>

    <?php endif; ?>

</div>

</body>
</html>
