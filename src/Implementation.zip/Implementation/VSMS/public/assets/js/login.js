
// Find the password input element in the login form.
const passwordInput = document.getElementById("password");

// Find the button used to show or hide the password.
const togglePasswordButton = document.getElementById("togglePassword");

// Check that both elements exist before adding an event.
if (passwordInput && togglePasswordButton) {

    // Listen for clicks on the show/hide password button.
    togglePasswordButton.addEventListener("click", function () {

        // Check whether the password is currently hidden.
        const isPasswordHidden = passwordInput.type === "password";

        // Show the password when it is hidden, or hide it when it is visible.
        passwordInput.type = isPasswordHidden ? "text" : "password";

        // Change the button text to describe the next available action.
        togglePasswordButton.textContent = isPasswordHidden ? "Hide" : "Show";

        // Update the button's accessible label for screen readers.
        togglePasswordButton.setAttribute(
            "aria-label",
            isPasswordHidden ? "Hide password" : "Show password"
        );

    });
}
