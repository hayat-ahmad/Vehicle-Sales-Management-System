
<?php
// Load authentication functions and the database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to log in.
requireLogin();

// Retrieve the current user's information.
$user = currentUser();

// Check whether the user's account is active.
if ($user === null) {
    // Clear the session data.
    $_SESSION = [];

    // Destroy the session.
    session_destroy();

    // Redirect to the login page.
    redirect("login.php");
}

// Store the user's role.
$userRole = $user["role_name"];

// Define the roles allowed to view customer information.
$allowedRoles = ["Administrator", "Manager", "Salesperson"];

// Check the user's authorization.
if (!in_array($userRole, $allowedRoles, true)) {
    // Return an HTTP 403 response.
    http_response_code(403);

    // Stop execution.
    exit("Access denied. You are not allowed to view customers.");
}

// Define a function to safely display values in HTML.
function escapeCustomerDetails($value): string
{
    // Convert special characters into safe HTML entities.
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Retrieve the customer ID from the URL.
$customerId = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

// Check that the customer ID is a positive integer.
if (!$customerId || $customerId < 1) {
    // Return an HTTP 400 response for an invalid ID.
    http_response_code(400);

    // Stop execution.
    exit("Invalid customer ID.");
}

// Initialize the customer record.
$customer = null;

// Try to retrieve the requested customer.
try {

    // Prepare a query to find the customer by ID.
    $customerQuery = $pdo->prepare(
        "SELECT
            customer_id,
            full_name,
            phone,
            email,
            address,
            registration_date,
            updated_at
         FROM customers
         WHERE customer_id = ?
         LIMIT 1"
    );

    // Execute the query using the customer ID.
    $customerQuery->execute([$customerId]);

    // Retrieve the customer record.
    $customer = $customerQuery->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {

    // Record the technical error privately.
    error_log(
        "VSMS customer details error: " . $exception->getMessage()
    );

    // Return an HTTP 500 response.
    http_response_code(500);

    // Display a safe error message.
    exit("Unable to load customer information. Please try again.");
}

// Check whether the requested customer exists.
if (!$customer) {
    // Return an HTTP 404 response.
    http_response_code(404);

    // Stop execution.
    exit("The requested customer was not found.");
}
// Initialize the customer's purchase history as an empty array.
$purchaseHistory = [];

// Retrieve completed purchases and their payment information.
try {

    // Prepare a query that retrieves each completed sale.
    $purchaseHistoryQuery = $pdo->prepare(
        "SELECT
            s.sale_id,
            s.sale_date,
            s.final_amount,
            v.make,
            v.model,
            v.year,
            v.vin,
            COALESCE(payment_totals.total_paid, 0) AS paid_amount,
            COALESCE(payment_totals.payment_count, 0) AS payment_count,
            GREATEST(
                0,
                s.final_amount - COALESCE(payment_totals.total_paid, 0)
            ) AS outstanding_balance,
            i.invoice_id,
            i.invoice_number
         FROM sales s

         INNER JOIN vehicles v
            ON s.vehicle_id = v.vehicle_id

         LEFT JOIN (
            SELECT
                sale_id,
                SUM(payment_amount) AS total_paid,
                COUNT(*) AS payment_count
            FROM payments
            WHERE payment_status = 'Completed'
            GROUP BY sale_id
         ) payment_totals
            ON s.sale_id = payment_totals.sale_id

         LEFT JOIN invoices i
            ON s.sale_id = i.sale_id

         WHERE s.customer_id = ?
           AND s.sale_status = 'Completed'

         ORDER BY s.sale_date DESC, s.sale_id DESC"
    );

    // Execute the query for the current customer.
    $purchaseHistoryQuery->execute([$customerId]);

    // Retrieve all completed purchases.
    $purchaseHistory = $purchaseHistoryQuery->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {

    // Record the technical error privately.
    error_log(
        "VSMS customer purchase history error: " . $exception->getMessage()
    );

    // Return a safe error message.
    http_response_code(500);

    // Stop execution without exposing database details.
    exit("Unable to load customer purchase history. Please try again.");
}

// Generate a CSRF token if one does not exist.
if (empty($_SESSION["csrf_token"])) {
    // Generate a secure random token.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Store the CSRF token.
$csrfToken = $_SESSION["csrf_token"];

// Safely prepare the logged-in user's name.
$safeUserName = escapeCustomerDetails($user["full_name"]);

// Safely prepare the user's role.
$safeUserRole = escapeCustomerDetails($userRole);

// Safely prepare the CSRF token.
$safeCsrfToken = escapeCustomerDetails($csrfToken);

// Format the registration date for display.
$registrationDate = date(
    "d M Y, h:i A",
    strtotime($customer["registration_date"])
);

// Format the last updated date for display.
$updatedDate = date(
    "d M Y, h:i A",
    strtotime($customer["updated_at"])
);

?>
<!DOCTYPE html>
<!-- Declare this page as an HTML5 document. -->
<html lang="en">

<!-- Start the document head. -->
<head>

    <!-- Set the page character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on different devices. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Customer Details | VSMS</title>

    <!-- Load the existing dashboard styles. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Load the existing vehicle and card styles. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

</head>

<!-- Start the visible page. -->
<body>

    <!-- Create the main dashboard layout. -->
    <div class="dashboard-layout">

        <!-- Display the application sidebar. -->
        <aside class="sidebar">

            <!-- Display the system logo and name. -->
            <div class="brand">

                <!-- Display the short system name inside a logo box. -->
                <div class="brand-logo">V</div>

                <!-- Display the full system name. -->
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>

            <!-- Close the brand section. -->
            </div>

            <!-- Display the main sidebar navigation. -->
            

<!-- Display all available system navigation links. -->
            <nav class="sidebar-navigation">

                <!-- Display the navigation section heading. -->
                <p class="navigation-heading">MAIN MENU</p>

                <!-- Link to the Dashboard. -->
                <a href="dashboard.php" class="nav-link active">
                    <span class="nav-icon">▦</span>
                    <span>Dashboard</span>
                </a>

                <!-- Link to Vehicle Management. -->
                <a href="vehicles.php" class="nav-link">
                    <span class="nav-icon">🚘</span>
                    <span>Vehicles</span>
                </a>

                <!-- Link to Customer Management. -->
                <a href="customers.php" class="nav-link">
                    <span class="nav-icon">♙</span>
                    <span>Customers</span>
                </a>

                <!-- Link to Reservation Management. -->
                <a href="reservations.php" class="nav-link">
                    <span class="nav-icon">▣</span>
                    <span>Reservations</span>
                </a>

                <!-- Link to Sales Management. -->
                <a href="sales.php" class="nav-link">
                    <span class="nav-icon">▤</span>
                    <span>Sales</span>
                </a>

                <!-- Link to Payment Management. -->
                <a href="payments.php" class="nav-link">
                    <span class="nav-icon">$</span>
                    <span>Payments</span>
                </a>
                <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
    <span class="nav-icon">◷</span>
    <span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
    <span class="nav-icon">▧</span>
    <span>Invoices</span>
</a>

                <!-- Show employee management only to authorized management roles. -->
                <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

                    <a href="employees.php" class="nav-link">
                        <span class="nav-icon">♧</span>
                        <span>Employees</span>
                    </a>

                <?php endif; ?>
                <!-- Only Administrators can access User Account Management. -->
<?php if ($user["role_name"] === "Administrator"): ?>

    <a href="users.php" class="nav-link">
        <span class="nav-icon">♙</span>
        <span>User Accounts</span>
    </a>

<?php endif; ?>

                <!-- Show reports only to authorized management roles. -->
                <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

                    <a href="reports.php" class="nav-link">
                        <span class="nav-icon">▥</span>
                        <span>Reports</span>
                    </a>

                <?php endif; ?>

            <!-- Close the navigation section. -->
            </nav>


            <!-- Display a short project description at the bottom of the sidebar. -->
            <div class="sidebar-footer">
                <p>Vehicle Sales &amp; Management System</p>
                <span>Development version</span>
            </div>

        <!-- Close the sidebar. -->
        </aside>


        <!-- Create the main page content area. -->
        <main class="main-content">
        <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Customer Management</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    
                    <div class="user-information">
                    <a href="my_profile.php" class="profile-name-link">
        <?= $safeUserName ?>
    </a>
                        <span><?= $safeUserRole ?></span>
                    </div>

    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>
            <!-- Display the page header. -->
           
            <!-- Display the customer details content. -->
            <section class="page-content">

                <!-- Display the page heading and navigation. -->
                <div class="page-heading">

                    <div>
                        <h1>Customer Details</h1>
                        <p>View the complete information for this customer.</p>
                    </div>

                    <!-- Return to the customer directory. -->
                    <!-- Provide navigation back to the customer directory. -->
                    <a href="customers.php" class="secondary-button">
                    Back to Customers
                    </a>

                    <!-- Show the edit button only to Administrators and Salespersons. -->
                    <?php if (in_array($userRole, ["Administrator", "Salesperson"], true)): ?>

                        <a
                            href="edit_customer.php?id=<?= (int) $customer["customer_id"] ?>"
                            class="primary-button"
                        >
                                Edit Customer
                        </a>

                    <?php endif; ?>                 
                </div>
                <!-- Display a message after successfully updating customer information. -->
                <?php if (isset($_GET["updated"]) && $_GET["updated"] === "1"): ?>

                    <div class="inventory-message success-message">
                     Customer information updated successfully.
                 </div>

                <?php endif; ?>

                <!-- Display the customer's main information. -->
                <section class="inventory-card">

                    <!-- Display the customer information heading. -->
                    <div class="card-heading">
                        <div>
                            <h2>
                                <?= escapeCustomerDetails($customer["full_name"]) ?>
                            </h2>

                            <p>
                                Customer ID:
                                #<?= (int) $customer["customer_id"] ?>
                            </p>
                        </div>
                    </div>

                    <!-- Arrange the customer details in a responsive grid. -->
                    <div class="vehicle-form-grid">

                        <!-- Display the customer's full name. -->
                        <div class="filter-field">
                            <label>Full Name</label>
                            <p>
                                <?= escapeCustomerDetails($customer["full_name"]) ?>
                            </p>
                        </div>

                        <!-- Display the customer's phone number. -->
                        <div class="filter-field">
                            <label>Phone Number</label>
                            <p>
                                <?= escapeCustomerDetails($customer["phone"]) ?>
                            </p>
                        </div>

                        <!-- Display the customer's email address. -->
                        <div class="filter-field">
                            <label>Email Address</label>
                            <p>
                                <?= !empty($customer["email"])
                                    ? escapeCustomerDetails($customer["email"])
                                    : "Not provided" ?>
                            </p>
                        </div>

                        <!-- Display the customer's registration date. -->
                        <div class="filter-field">
                            <label>Registration Date</label>
                            <p>
                                <?= escapeCustomerDetails($registrationDate) ?>
                            </p>
                        </div>

                    </div>
                </section>

                <!-- Display the customer's address information. -->
                <section class="inventory-card">

                    <!-- Display the address section heading. -->
                    <div class="card-heading">
                        <div>
                            <h2>Address Information</h2>
                            <p>Customer's registered address.</p>
                        </div>
                    </div>

                    <!-- Display the customer's address. -->
                    <div class="filter-field">
                        <label>Address</label>

                        <p>
                            <?= !empty($customer["address"])
                                ? nl2br(escapeCustomerDetails($customer["address"]))
                                : "No address provided." ?>
                        </p>
                    </div>

                </section>

                <!-- Display the record information. -->
                <section class="inventory-card">

                    <!-- Display the record information heading. -->
                    <div class="card-heading">
                        <div>
                            <h2>Record Information</h2>
                            <p>System record creation and update information.</p>
                        </div>
                    </div>

                    <!-- Display the last updated date. -->
                    <div class="filter-field">
                        <label>Last Updated</label>
                        <p><?= escapeCustomerDetails($updatedDate) ?></p>
                    </div>

                </section>

                <!-- Display the future purchase history section. -->
                <!-- Display the customer's completed purchase history. -->
<section class="inventory-card">

    <!-- Display the purchase history heading. -->
    <div class="card-heading">
        <div>
            <h2>Purchase History</h2>
            <p>Completed vehicle purchases and payment information.</p>
        </div>
    </div>

    <?php if (empty($purchaseHistory)): ?>

        <!-- Display a message when the customer has no completed purchases. -->
        <div class="empty-inventory">
            <h3>No Purchase History</h3>

            <p>
                This customer does not have any completed vehicle purchases yet.
            </p>
        </div>

    <?php else: ?>

        <!-- Display the purchase history in a horizontally scrollable table. -->
        <div style="width: 100%; overflow-x: auto;">

            <table style="width: 100%; border-collapse: collapse; min-width: 850px;">

                <!-- Define the purchase history table headings. -->
                <thead>
                    <tr style="text-align: left; border-bottom: 1px solid #e5e7eb;">

                        <th style="padding: 14px 10px;">Sale Details</th>

                        <th style="padding: 14px 10px;">Vehicle</th>

                        <th style="padding: 14px 10px;">Sale Amount</th>

                        <th style="padding: 14px 10px;">Paid</th>

                        <th style="padding: 14px 10px;">Outstanding</th>

                        <th style="padding: 14px 10px;">Payments</th>

                        <th style="padding: 14px 10px;">Invoice</th>

                    </tr>
                </thead>

                <!-- Display each completed purchase. -->
                <tbody>

                    <?php foreach ($purchaseHistory as $purchase): ?>

                        <tr style="border-bottom: 1px solid #e5e7eb;">

                            <!-- Display the sale reference and date. -->
                            <td style="padding: 14px 10px;">
                                <strong>
                                    #<?= (int) $purchase["sale_id"] ?>
                                </strong>

                                <br>

                                <small>
                                    <?= escapeCustomerDetails(
                                        date("d M Y", strtotime($purchase["sale_date"]))
                                    ) ?>
                                </small>
                            </td>

                            <!-- Display the purchased vehicle. -->
                            <td style="padding: 14px 10px;">
                                <strong>
                                    <?= escapeCustomerDetails(
                                        $purchase["make"] . " " . $purchase["model"]
                                    ) ?>
                                </strong>

                                <br>

                                <small>
                                    Year: <?= (int) $purchase["year"] ?>
                                </small>

                                <br>

                                <small>
                                    VIN: <?= escapeCustomerDetails($purchase["vin"]) ?>
                                </small>
                            </td>

                            <!-- Display the final sale amount. -->
                            <td style="padding: 14px 10px;">
                                <?= number_format((float) $purchase["final_amount"], 2) ?>
                            </td>

                            <!-- Display the total completed payments. -->
                            <td style="padding: 14px 10px;">
                                <?= number_format((float) $purchase["paid_amount"], 2) ?>
                            </td>

                            <!-- Display the outstanding balance. -->
                            <td style="padding: 14px 10px;">
                                <strong>
                                    <?= number_format(
                                        (float) $purchase["outstanding_balance"],
                                        2
                                    ) ?>
                                </strong>
                            </td>

                            <!-- Display the number of completed payments. -->
                            <td style="padding: 14px 10px;">
                                <?= (int) $purchase["payment_count"] ?>
                            </td>

                            <!-- Display an invoice link when an invoice exists. -->
                            <td style="padding: 14px 10px;">

                                <?php if (!empty($purchase["invoice_id"])): ?>

                                    <a
                                        href="generate_invoice.php?invoice_id=<?= (int) $purchase["invoice_id"] ?>"
                                        class="secondary-button"
                                    >
                                        View Invoice
                                    </a>

                                    <br>

                                    <small>
                                        <?= escapeCustomerDetails(
                                            $purchase["invoice_number"]
                                        ) ?>
                                    </small>

                                <?php else: ?>

                                    <span>Not generated</span>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                </tbody>

            </table>

        </div>

    <?php endif; ?>

</section>

            </section>
        </main>
    </div>
</body>
</html>
