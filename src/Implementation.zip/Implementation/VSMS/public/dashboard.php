
<?php // Start the PHP section and explain the purpose of this file.

// Load the authentication functions and database connection.
require_once __DIR__ . "/../includes/auth.php";

// Make sure the visitor has logged in.
requireLogin();

// Retrieve the current user's latest information from the database.
$user = currentUser();

// Check whether the account is still active and available.
if ($user === null) {

    // Remove all information stored in the current session.
    $_SESSION = [];

    // Destroy the current session on the server.
    session_destroy();

    // Send the user back to the login page.
    redirect("login.php");
}

// Initialize the active-user count before querying the database.

// Initialize the active-user count before querying the database.
$activeUserCount = 0;

// Initialize the total active-vehicle count.
$totalVehicleCount = 0;

// Initialize the count of available vehicles.
$availableVehicleCount = 0;

// Initialize the count of reserved vehicles.
$reservedVehicleCount = 0;

// Initialize the count of sold vehicles.
$soldVehicleCount = 0;

// Initialize the count of vehicles under maintenance.
$maintenanceVehicleCount = 0;

// Initialize the count of unavailable vehicles.
$unavailableVehicleCount = 0;

// Track whether any dashboard statistics query fails.
$statisticsError = false;
// Track errors when retrieving sales information.
$salesDataError = false;
// Store the monthly sales chart data.
$monthlySalesLabels = [];
$monthlySalesCounts = [];
$monthlySalesRevenue = [];

// Store the latest sales records.
$recentSales = [];

// Store the monthly sales results indexed by month.
$monthlySalesMap = [];

// Prepare the first day of the month 11 months ago.
$chartStartDate = (new DateTimeImmutable("first day of this month"))
    ->modify("-11 months")
    ->format("Y-m-d");

// Prepare the first day of next month as the exclusive end date.
$chartEndDate = (new DateTimeImmutable("first day of next month"))
    ->format("Y-m-d");
    // Prepare a filter so salespersons only see their own sales.

// Try to retrieve all dashboard statistics from MySQL.
try {

    // Count all active user accounts.
    $userStatement = $pdo->query("SELECT COUNT(*) FROM users WHERE status = 'active'");

    // Save the active-user count as an integer.
    $activeUserCount = (int) $userStatement->fetchColumn();

    // Count active vehicles grouped by their current status.
    $vehicleStatement = $pdo->query(
        "SELECT status, COUNT(*) AS total
         FROM vehicles
         WHERE is_active = 1
         GROUP BY status"
    );

    // Retrieve each vehicle-status count as an associative array.
    $vehicleStatusRows = $vehicleStatement->fetchAll(PDO::FETCH_ASSOC);

    // Process every vehicle status returned by the database.
    foreach ($vehicleStatusRows as $vehicleStatusRow) {

        // Read the vehicle status from the current database row.
        $vehicleStatus = $vehicleStatusRow["status"];

        // Convert the returned vehicle count into an integer.
        $vehicleCount = (int) $vehicleStatusRow["total"];

        // Add this count to the total active-vehicle count.
        $totalVehicleCount += $vehicleCount;

        // Save the count in the matching status variable.
        if ($vehicleStatus === "Available") {
            $availableVehicleCount = $vehicleCount;
        } elseif ($vehicleStatus === "Reserved") {
            $reservedVehicleCount = $vehicleCount;
        } elseif ($vehicleStatus === "Sold") {
            $soldVehicleCount = $vehicleCount;
        } elseif ($vehicleStatus === "Under Maintenance") {
            $maintenanceVehicleCount = $vehicleCount;
        } elseif ($vehicleStatus === "Unavailable") {
            $unavailableVehicleCount = $vehicleCount;
        }
    }
    // Handle sales-data errors separately from dashboard statistics.
try {

    // Prepare a filter so salespersons only see their own sales.
    $salespersonFilter = "";

    // Prepare the query parameters.
    $salesParameters = [
        ":start_date" => $chartStartDate,
        ":end_date" => $chartEndDate
    ];

    // Restrict the results for salesperson accounts.
    if ($user["role_name"] === "Salesperson") {
        $salespersonFilter = " AND salesperson_id = :salesperson_id";
        $salesParameters[":salesperson_id"] = $user["user_id"];
    }

    // Retrieve monthly completed sales and revenue.
    $monthlySalesStatement = $pdo->prepare(
        "SELECT
            DATE_FORMAT(sale_date, '%Y-%m') AS sale_month,
            COUNT(*) AS total_sales,
            COALESCE(SUM(final_amount), 0) AS total_revenue
         FROM sales
         WHERE sale_status = 'Completed'
           AND sale_date >= :start_date
           AND sale_date < :end_date
           $salespersonFilter
         GROUP BY DATE_FORMAT(sale_date, '%Y-%m')
         ORDER BY sale_month ASC"
    );

    // Execute the monthly sales query.
    $monthlySalesStatement->execute($salesParameters);

    // Retrieve the monthly sales results.
    $monthlySalesRows = $monthlySalesStatement->fetchAll(PDO::FETCH_ASSOC);

    // Organize the results by month.
    foreach ($monthlySalesRows as $monthlySalesRow) {
        $monthlySalesMap[$monthlySalesRow["sale_month"]] = $monthlySalesRow;
    }

    // Prepare labels and values for the latest 12 months.
    $chartMonth = new DateTimeImmutable("first day of this month");
    $chartMonth = $chartMonth->modify("-11 months");

    // Generate all 12 months, including months without sales.
    for ($monthIndex = 0; $monthIndex < 12; $monthIndex++) {

        // Get the month key in YYYY-MM format.
        $monthKey = $chartMonth->format("Y-m");

        // Add the readable month label.
        $monthlySalesLabels[] = $chartMonth->format("M Y");

        // Add the sales count, or zero if no sales exist.
        $monthlySalesCounts[] = isset($monthlySalesMap[$monthKey])
            ? (int) $monthlySalesMap[$monthKey]["total_sales"]
            : 0;

        // Add the revenue, or zero if no sales exist.
        $monthlySalesRevenue[] = isset($monthlySalesMap[$monthKey])
            ? (float) $monthlySalesMap[$monthKey]["total_revenue"]
            : 0;

        // Move to the next month.
        $chartMonth = $chartMonth->modify("+1 month");
    }

    // Retrieve the latest eight sales records.
    $recentSalesStatement = $pdo->prepare(
        "SELECT
            s.sale_id,
            c.full_name AS customer_name,
            v.make,
            v.model,
            s.sale_date,
            s.final_amount,
            s.sale_status AS status
         FROM sales s
         INNER JOIN customers c ON s.customer_id = c.customer_id
         INNER JOIN vehicles v ON s.vehicle_id = v.vehicle_id
         WHERE 1 = 1
         " . ($user["role_name"] === "Salesperson"
                ? " AND s.salesperson_id = :recent_salesperson_id"
                : "") . "
         ORDER BY s.sale_date DESC, s.sale_id DESC
         LIMIT 8"
    );

    // Execute the recent-sales query.
    if ($user["role_name"] === "Salesperson") {
        $recentSalesStatement->execute([
            ":recent_salesperson_id" => $user["user_id"]
        ]);
    } else {
        $recentSalesStatement->execute();
    }

    // Store the latest sales records.
    $recentSales = $recentSalesStatement->fetchAll(PDO::FETCH_ASSOC);
    // Handle sales-data errors without hiding the vehicle and user counts.
} catch (PDOException $exception) {

    // Record the technical error in the PHP server log.
    error_log("VSMS dashboard sales data error: " . $exception->getMessage());

    // Keep the original dashboard statistics available.
    $salesDataError = true;
}

// Handle database errors without displaying technical details to users.
} catch (PDOException $exception) {

    // Record the technical error in the PHP server error log.
    error_log("VSMS dashboard statistics error: " . $exception->getMessage());

    // Mark the dashboard statistics as unavailable.
    $statisticsError = true;
}

// Safely prepare the user's full name for display in HTML.
$fullName = htmlspecialchars($user["full_name"], ENT_QUOTES, "UTF-8");

// Safely prepare the user's role for display in HTML.
$roleName = htmlspecialchars($user["role_name"], ENT_QUOTES, "UTF-8");

// Safely prepare the session's CSRF token for the logout form.
$csrfToken = htmlspecialchars($_SESSION["csrf_token"] ?? "", ENT_QUOTES, "UTF-8");

?>
<!-- Tell the browser that this document uses HTML5. -->
<!DOCTYPE html>

<!-- Start the HTML document and set its language to English. -->
<html lang="en">

<!-- Start the document's head section. -->
<head>

    <!-- Set the character encoding to UTF-8. -->
    <meta charset="UTF-8">

    <!-- Make the layout responsive on mobile devices. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the title displayed in the browser tab. -->
    <title>Dashboard | VSMS</title>

    <!-- Load the CSS file responsible for dashboard styling. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

<!-- Close the head section. -->
</head>

<!-- Start the visible page content. -->
<body>

    <!-- Create the main dashboard layout. -->
    <div class="dashboard-layout">

        <!-- Create the left navigation sidebar. -->
        <aside class="sidebar">

            <!-- Display the system logo and name. -->
            <div class="brand">

                <!-- Display the short system name inside a logo box. -->
                <div class="brand-logo">V</div>

                <!-- Display the full system name. -->
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>

            <!-- Close the brand section. -->
            </div>

            <!-- Display the main sidebar navigation. -->
            

<!-- Display all available system navigation links. -->
            <nav class="sidebar-navigation">

                <!-- Display the navigation section heading. -->
                <p class="navigation-heading">MAIN MENU</p>

                <!-- Link to the Dashboard. -->
                <a href="dashboard.php" class="nav-link active">
                    <span class="nav-icon">▦</span>
                    <span>Dashboard</span>
                </a>

                <!-- Link to Vehicle Management. -->
                <a href="vehicles.php" class="nav-link">
                    <span class="nav-icon">🚘</span>
                    <span>Vehicles</span>
                </a>

                <!-- Link to Customer Management. -->
                <a href="customers.php" class="nav-link">
                    <span class="nav-icon">♙</span>
                    <span>Customers</span>
                </a>

                <!-- Link to Reservation Management. -->
                <a href="reservations.php" class="nav-link">
                    <span class="nav-icon">▣</span>
                    <span>Reservations</span>
                </a>

                <!-- Link to Sales Management. -->
                <a href="sales.php" class="nav-link">
                    <span class="nav-icon">▤</span>
                    <span>Sales</span>
                </a>

                <!-- Link to Payment Management. -->
                <a href="payments.php" class="nav-link">
                    <span class="nav-icon">$</span>
                    <span>Payments</span>
                </a>
                <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
    <span class="nav-icon">◷</span>
    <span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
    <span class="nav-icon">▧</span>
    <span>Invoices</span>
</a>

                <!-- Show employee management only to authorized management roles. -->
                <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

                    <a href="employees.php" class="nav-link">
                        <span class="nav-icon">♧</span>
                        <span>Employees</span>
                    </a>

                <?php endif; ?>
                <!-- Only Administrators can access User Account Management. -->
<?php if ($user["role_name"] === "Administrator"): ?>

    <a href="users.php" class="nav-link">
        <span class="nav-icon">♙</span>
        <span>User Accounts</span>
    </a>

<?php endif; ?>

                <!-- Show reports only to authorized management roles. -->
                <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

                    <a href="reports.php" class="nav-link">
                        <span class="nav-icon">▥</span>
                        <span>Reports</span>
                    </a>

                <?php endif; ?>

            <!-- Close the navigation section. -->
            </nav>


            <!-- Display a short project description at the bottom of the sidebar. -->
            <div class="sidebar-footer">
                <p>Vehicle Sales &amp; Management System</p>
                <span>Development version</span>
            </div>

        <!-- Close the sidebar. -->
        </aside>

        <!-- Create the main workspace beside the sidebar. -->
        <main class="main-content">

            <!-- Create the top header of the dashboard. -->
            <header class="topbar">

                <!-- Display the current page location. -->
                <div class="breadcrumb">
                    
                    <strong>Dashboard</strong>
                </div>

                <!-- Display the logged-in user's information and logout button. -->
                <div class="topbar-user">

                    <!-- Display the first letter of the user's name. -->
                    <div class="user-avatar">
                    <a href="my_profile.php" class="profile-name-link">
                        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
                    </div>

                    <!-- Display the user's name and role. -->
                    <div class="user-information">
                    <a href="my_profile.php" class="profile-name-link">
                        <?= $fullName ?>
                                        </a>
                                        <span><?= $roleName ?></span>
                    </div>

                    <!-- Create a secure POST form for logging out. -->
                    <form action="logout.php" method="POST">

                        <!-- Send the current session's CSRF token to the logout script. -->
                        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

                        <!-- Submit the logout request. -->
                        <button type="submit" class="logout-button">Logout</button>

                    <!-- Close the logout form. -->
                    </form>

                <!-- Close the user information section. -->
                </div>

            <!-- Close the top header. -->
            </header>

            <!-- Create the main dashboard page content. -->
            <section class="page-content">

                <!-- Display the dashboard heading and welcome message. -->
                <div class="page-heading">
                    <div>
                        <p class="eyebrow">OVERVIEW</p>
                        <h1>Dashboard</h1>
                        <p>Welcome back, <?= $fullName ?>. Here is your system overview.</p>
                    </div>
                    <span class="role-label"><?= $roleName ?></span>
                </div>

                <!-- Create the summary cards section. -->
                
<!-- Create the dashboard summary cards section. -->
<section class="statistics-grid">

    <!-- Display the number of active system users. -->
    <article class="stat-card">
        <!-- Arrange the card label and icon. -->
        <div class="stat-card-top">
            <!-- Display the statistic name. -->
            <span class="stat-label">Active Users</span>
            <!-- Display the user icon. -->
            <span class="stat-icon users-icon">♙</span>
        <!-- Close the card heading. -->
        </div>
        <!-- Display the database count or an error placeholder. -->
        <h2><?= !$statisticsError ? number_format($activeUserCount) : "--" ?></h2>
        <!-- Explain what the number represents. -->
        <p>Registered active accounts</p>
    <!-- Close the active-users card. -->
    </article>

    <!-- Display the total number of active vehicles. -->
    <article class="stat-card">
        <!-- Arrange the card label and icon. -->
        <div class="stat-card-top">
            <!-- Display the statistic name. -->
            <span class="stat-label">Total Vehicles</span>
            <!-- Display the vehicle icon. -->
            <span class="stat-icon vehicles-icon">🚙</span>
        <!-- Close the card heading. -->
        </div>
        <!-- Display the total active-vehicle count. -->
        <h2><?= !$statisticsError ? number_format($totalVehicleCount) : "--" ?></h2>
        <!-- Explain what the number represents. -->
        <p>Active inventory records</p>
    <!-- Close the total-vehicles card. -->
    </article>

    <!-- Display the number of available vehicles. -->
    <article class="stat-card">
        <!-- Arrange the card label and icon. -->
        <div class="stat-card-top">
            <!-- Display the statistic name. -->
            <span class="stat-label">Available Vehicles</span>
            <!-- Display the available-vehicle icon. -->
            <span class="stat-icon reservations-icon">✓</span>
        <!-- Close the card heading. -->
        </div>
        <!-- Display the available-vehicle count. -->
        <h2><?= !$statisticsError ? number_format($availableVehicleCount) : "--" ?></h2>
        <!-- Explain what the number represents. -->
        <p>Ready for customers</p>
    <!-- Close the available-vehicles card. -->
    </article>

    <!-- Display the number of sold vehicles. -->
    <article class="stat-card">
        <!-- Arrange the card label and icon. -->
        <div class="stat-card-top">
            <!-- Display the statistic name. -->
            <span class="stat-label">Sold Vehicles</span>
            <!-- Display the sold-vehicle icon. -->
            <span class="stat-icon sales-icon">↗</span>
        <!-- Close the card heading. -->
        </div>
        <!-- Display the sold-vehicle count. -->
        <h2><?= !$statisticsError ? number_format($soldVehicleCount) : "--" ?></h2>
        <!-- Explain what the number represents. -->
        <p>Vehicles marked as sold</p>
    <!-- Close the sold-vehicles card. -->
    </article>

<!-- Close the dashboard summary cards section. -->
</section>


                <!-- Create the main dashboard panels. -->
                <section class="dashboard-panels">

                   
                    <!-- Sales performance chart panel. -->
<article class="dashboard-panel sales-panel">

    <div class="panel-heading">
        <div>
            <h2>Sales Performance</h2>
            <p>Monthly completed sales and revenue for the last 12 months.</p>
        </div>
        <span class="panel-tag">Live data</span>
    </div>

    <!-- Chart.js will draw the sales chart inside this canvas. -->
    <div class="dashboard-chart-container">
        <canvas id="salesPerformanceChart"></canvas>
    </div>

</article>

                    
<!-- Create the inventory status panel. -->
<!-- Inventory status doughnut chart panel. -->
<article class="dashboard-panel inventory-panel">

    <div class="panel-heading">
        <div>
            <h2>Inventory Status</h2>
            <p>Current active vehicle inventory.</p>
        </div>
        <span class="panel-tag">Live data</span>
    </div>

    <!-- Chart.js will draw the inventory chart here. -->
    <div class="inventory-chart-container">
        <canvas id="inventoryStatusChart"></canvas>
    </div>

    <!-- Display the actual inventory counts below the chart. -->
    <div class="inventory-chart-summary">

        <div>
            <span>Available</span>
            <strong><?= !$statisticsError ? number_format($availableVehicleCount) : "--" ?></strong>
        </div>

        <div>
            <span>Reserved</span>
            <strong><?= !$statisticsError ? number_format($reservedVehicleCount) : "--" ?></strong>
        </div>

        <div>
            <span>Sold</span>
            <strong><?= !$statisticsError ? number_format($soldVehicleCount) : "--" ?></strong>
        </div>

        <div>
            <span>Under Maintenance</span>
            <strong><?= !$statisticsError ? number_format($maintenanceVehicleCount) : "--" ?></strong>
        </div>

        <div>
            <span>Unavailable</span>
            <strong><?= !$statisticsError ? number_format($unavailableVehicleCount) : "--" ?></strong>
        </div>

    </div>

</article>


                <!-- Close the dashboard panels section. -->
                </section>

                <!-- Create the recent-sales table panel. -->
                <section class="dashboard-panel recent-sales-panel">

                    <!-- Display the recent-sales table heading. -->
                    <div class="panel-heading">
                        <div>
                            <h2>Recent Sales</h2>
                            <p>The latest vehicle sales recorded in the system.</p>
                        </div>
                        <span class="panel-tag">Live data</span>
                    </div>

                    <!-- Display the table structure before sales records are available. -->
                    <div class="table-wrapper">
                        <table class="recent-sales-table">

                            <!-- Define the table column headings. -->
                            <thead>
                                <tr>
                                    <th>Sale ID</th>
                                    <th>Customer</th>
                                    <th>Vehicle</th>
                                    <th>Sale Date</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>

                            <!-- Display a message because no sales table exists yet. -->
                            <tbody>

<?php if (!empty($recentSales)): ?>

    <?php foreach ($recentSales as $sale): ?>

        <?php
            // Safely prepare the sale status for its CSS class.
            $statusClass = strtolower(
                str_replace(" ", "-", $sale["status"])
            );
        ?>

        <tr>

            <!-- Display the sale ID. -->
            <td>#<?= (int) $sale["sale_id"] ?></td>

            <!-- Display the customer name safely. -->
            <td>
                <?= htmlspecialchars(
                    $sale["customer_name"],
                    ENT_QUOTES,
                    "UTF-8"
                ) ?>
            </td>

            <!-- Display the vehicle make and model safely. -->
            <td>
                <?= htmlspecialchars(
                    $sale["make"] . " " . $sale["model"],
                    ENT_QUOTES,
                    "UTF-8"
                ) ?>
            </td>

            <!-- Display the sale date. -->
            <td>
                <?= date("d M Y", strtotime($sale["sale_date"])) ?>
            </td>

            <!-- Display the final sale amount. -->
            <td>
                <?= number_format((float) $sale["final_amount"], 2) ?>
            </td>

            <!-- Display the sale status. -->
            <td>
                <span class="sale-status <?= htmlspecialchars($statusClass, ENT_QUOTES, "UTF-8") ?>">
                    <?= htmlspecialchars(
                        $sale["status"],
                        ENT_QUOTES,
                        "UTF-8"
                    ) ?>
                </span>
            </td>

        </tr>

    <?php endforeach; ?>

<?php else: ?>

    <tr>
        <td colspan="6" class="empty-table-message">
            <?php if (!empty($salesDataError)): ?>
                Sales information could not be loaded.
            <?php else: ?>
                No sales records are available yet.
            <?php endif; ?>
        </td>
    </tr>

<?php endif; ?>

</tbody>

                        <!-- Close the recent-sales table. -->
                        </table>
                    <!-- Close the table wrapper. -->
                    </div>

                <!-- Close the recent-sales panel. -->
                </section>

            <!-- Close the main page content. -->
            </section>

        <!-- Close the main workspace. -->
        </main>

    <!-- Close the dashboard layout. -->
    </div>
    <!-- Load Chart.js to create interactive dashboard charts. -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
document.addEventListener("DOMContentLoaded", function () {

    // Stop chart initialization if the Chart.js library did not load.
    if (typeof Chart === "undefined") {
        console.error("Chart.js could not be loaded.");
        return;
    }

    // Receive monthly chart data safely from PHP.
    const monthlyLabels = <?= json_encode(
        $monthlySalesLabels,
        JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT
    ) ?>;

    const monthlySales = <?= json_encode(
        $monthlySalesCounts,
        JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT
    ) ?>;

    const monthlyRevenue = <?= json_encode(
        $monthlySalesRevenue,
        JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT
    ) ?>;

    // Identify whether the sales queries failed.
    const salesDataError = <?= !empty($salesDataError) ? "true" : "false" ?>;

    // Receive the vehicle inventory counts from PHP.
    const inventoryLabels = [
        "Available",
        "Reserved",
        "Sold",
        "Under Maintenance",
        "Unavailable"
    ];

    const inventoryValues = [
        <?= (int) $availableVehicleCount ?>,
        <?= (int) $reservedVehicleCount ?>,
        <?= (int) $soldVehicleCount ?>,
        <?= (int) $maintenanceVehicleCount ?>,
        <?= (int) $unavailableVehicleCount ?>
    ];

    // Find the sales chart canvas.
    const salesCanvas = document.getElementById("salesPerformanceChart");

    // Create the monthly sales and revenue chart.
    if (salesCanvas && !salesDataError) {

        new Chart(salesCanvas, {
            type: "line",

            data: {
                labels: monthlyLabels,

                datasets: [
                    {
                        label: "Completed Sales",
                        data: monthlySales,
                        yAxisID: "salesAxis",
                        borderColor: "#f0785a",
                        backgroundColor: "rgba(240, 120, 90, 0.12)",
                        borderWidth: 3,
                        pointRadius: 4,
                        pointHoverRadius: 6,
                        tension: 0.35,
                        fill: true
                    },
                    {
                        label: "Revenue",
                        data: monthlyRevenue,
                        yAxisID: "revenueAxis",
                        borderColor: "#263b63",
                        backgroundColor: "rgba(38, 59, 99, 0.08)",
                        borderWidth: 3,
                        pointRadius: 4,
                        pointHoverRadius: 6,
                        tension: 0.35,
                        fill: false
                    }
                ]
            },

            options: {
                responsive: true,
                maintainAspectRatio: false,

                interaction: {
                    mode: "index",
                    intersect: false
                },

                plugins: {
                    legend: {
                        display: true,
                        position: "bottom"
                    },

                    tooltip: {
                        callbacks: {
                            label: function (context) {

                                const value = Number(context.raw || 0);

                                if (context.dataset.yAxisID === "revenueAxis") {
                                    return " Revenue: " + value.toLocaleString(
                                        "en-US",
                                        {
                                            minimumFractionDigits: 2,
                                            maximumFractionDigits: 2
                                        }
                                    );
                                }

                                return " Completed Sales: " + value.toLocaleString("en-US");
                            }
                        }
                    }
                },

                scales: {
                    salesAxis: {
                        type: "linear",
                        position: "left",
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: "Number of Sales"
                        },
                        ticks: {
                            precision: 0
                        }
                    },

                    revenueAxis: {
                        type: "linear",
                        position: "right",
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: "Revenue"
                        },
                        grid: {
                            drawOnChartArea: false
                        }
                    }
                }
            }
        });

    } else if (salesCanvas) {

        salesCanvas.parentElement.innerHTML =
            '<p class="chart-empty-message">Sales chart data could not be loaded.</p>';
    }

    // Find the inventory chart canvas.
    const inventoryCanvas = document.getElementById("inventoryStatusChart");

    // Create the vehicle inventory doughnut chart.
    if (inventoryCanvas) {

        new Chart(inventoryCanvas, {
            type: "doughnut",

            data: {
                labels: inventoryLabels,

                datasets: [{
                    data: inventoryValues,

                    backgroundColor: [
                        "#35a879",
                        "#e7a944",
                        "#263b63",
                        "#8b91a0",
                        "#e0785a"
                    ],

                    borderWidth: 2,
                    borderColor: "#ffffff",
                    hoverOffset: 7
                }]
            },

            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: "65%",

                plugins: {
                    legend: {
                        display: true,
                        position: "bottom"
                    },

                    tooltip: {
                        callbacks: {
                            label: function (context) {

                                const value = Number(context.raw || 0);

                                return " " + context.label + ": " +
                                    value.toLocaleString("en-US");
                            }
                        }
                    }
                }
            }
        });
    }

});
</script>

<!-- Close the HTML document. -->
</body>

</html>
