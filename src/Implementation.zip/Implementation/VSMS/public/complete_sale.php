
<?php
// Load the existing authentication system and database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to be logged in.
requireLogin();

// Retrieve the logged-in user's information.
$user = currentUser();

// Reject inactive or unavailable user accounts.
if ($user === null) {
    // Clear the session data.
    $_SESSION = [];

    // Destroy the current session.
    session_destroy();

    // Redirect to the login page.
    redirect("login.php");
}

// Store the user's role.
$userRole = $user["role_name"];

// Define the roles allowed to complete sales.
$allowedRoles = ["Administrator", "Manager", "Salesperson"];

// Check the user's role.
if (!in_array($userRole, $allowedRoles, true)) {
    // Return an HTTP 403 response.
    http_response_code(403);

    // Stop unauthorized access.
    exit("Access denied.");
}

// Helper function to safely display values in HTML.
function escapeCompleteSale($value): string
{
    // Escape special HTML characters.
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Initialize the error message.
$error = "";

// Initialize the success message.
$success = "";

// Initialize the sale information.
$sale = null;

// Generate a CSRF token when one does not exist.
if (empty($_SESSION["csrf_token"])) {
    // Generate a cryptographically secure token.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Store the session token.
$csrfToken = $_SESSION["csrf_token"];

// Get the sale ID from the URL or submitted form.
$saleId = $_SERVER["REQUEST_METHOD"] === "POST"
    ? trim((string) ($_POST["sale_id"] ?? ""))
    : trim((string) ($_GET["id"] ?? ""));

// Validate the sale ID.
if (!ctype_digit($saleId) || (int) $saleId < 1) {
    // Stop processing if the sale ID is invalid.
    http_response_code(400);
    exit("Invalid sale ID.");
}

// Convert the sale ID into an integer.
$saleId = (int) $saleId;

// Handle the confirmation form submission.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Retrieve the submitted CSRF token.
    $submittedToken = $_POST["csrf_token"] ?? "";

    // Verify the CSRF token.
    if (
        !is_string($submittedToken)
        || !hash_equals($csrfToken, $submittedToken)
    ) {
        // Reject invalid form submissions.
        $error = "Your session has expired. Please reload the page.";
    } else {

        // Start the database transaction.
        try {
            // Begin a transaction to protect all related updates.
            $pdo->beginTransaction();

            // Lock the pending sale record.
            $saleQuery = $pdo->prepare(
                "SELECT
                    sale_id,
                    customer_id,
                    vehicle_id,
                    salesperson_id,
                    reservation_id,
                    sale_status,
                    final_amount
                 FROM sales
                 WHERE sale_id = ?
                 FOR UPDATE"
            );

            // Execute the query using the sale ID.
            $saleQuery->execute([$saleId]);

            // Retrieve the sale.
            $lockedSale = $saleQuery->fetch(PDO::FETCH_ASSOC);

            // Check that the sale exists.
            if (!$lockedSale) {
                throw new RuntimeException("The requested sale was not found.");
            }

            // Restrict Salesperson access to their own sales.
            if (
                $userRole === "Salesperson"
                && (int) $lockedSale["salesperson_id"] !== (int) $user["user_id"]
            ) {
                throw new RuntimeException(
                    "You can complete only sales assigned to your account."
                );
            }

            // Allow completion only when the sale is Pending.
            if ($lockedSale["sale_status"] !== "Pending") {
                throw new RuntimeException(
                    "Only Pending sales can be completed. Current status: "
                    . $lockedSale["sale_status"]
                );
            }

            // Lock the selected vehicle record.
            $vehicleQuery = $pdo->prepare(
                "SELECT vehicle_id, status, is_active
                 FROM vehicles
                 WHERE vehicle_id = ?
                 FOR UPDATE"
            );

            // Execute the vehicle query.
            $vehicleQuery->execute([
                (int) $lockedSale["vehicle_id"]
            ]);

            // Retrieve the vehicle.
            $lockedVehicle = $vehicleQuery->fetch(PDO::FETCH_ASSOC);

            // Check that the vehicle exists and is active.
            if (
                !$lockedVehicle
                || (int) $lockedVehicle["is_active"] !== 1
            ) {
                throw new RuntimeException(
                    "The vehicle does not exist or is no longer active."
                );
            }

            // Prevent the vehicle from being sold more than once.
            $duplicateSaleQuery = $pdo->prepare(
                "SELECT sale_id
                 FROM sales
                 WHERE vehicle_id = ?
                    AND sale_status = 'Completed'
                    AND sale_id <> ?
                 LIMIT 1"
            );

            // Execute the duplicate completed-sale check.
            $duplicateSaleQuery->execute([
                (int) $lockedSale["vehicle_id"],
                $saleId
            ]);

            // Reject a vehicle that already has a completed sale.
            if ($duplicateSaleQuery->fetchColumn()) {
                throw new RuntimeException(
                    "This vehicle already has a completed sale."
                );
            }

            // Check whether the sale is linked to a reservation.
            if ($lockedSale["reservation_id"] !== null) {

                // Lock the linked reservation.
                $reservationQuery = $pdo->prepare(
                    "SELECT
                        reservation_id,
                        customer_id,
                        vehicle_id,
                        reservation_status
                     FROM reservations
                     WHERE reservation_id = ?
                     FOR UPDATE"
                );

                // Execute the reservation query.
                $reservationQuery->execute([
                    (int) $lockedSale["reservation_id"]
                ]);

                // Retrieve the reservation.
                $lockedReservation = $reservationQuery->fetch(PDO::FETCH_ASSOC);

                // Confirm that the reservation exists.
                if (!$lockedReservation) {
                    throw new RuntimeException(
                        "The linked reservation could not be found."
                    );
                }

                // Ensure the reservation belongs to the same customer and vehicle.
                if (
                    (int) $lockedReservation["customer_id"] !== (int) $lockedSale["customer_id"]
                    || (int) $lockedReservation["vehicle_id"] !== (int) $lockedSale["vehicle_id"]
                ) {
                    throw new RuntimeException(
                        "The linked reservation does not match this sale."
                    );
                }

                // Only an active reservation can be completed with this sale.
                if ($lockedReservation["reservation_status"] !== "Active") {
                    throw new RuntimeException(
                        "The linked reservation is no longer Active."
                    );
                }

                // A reserved vehicle must still have Reserved status.
                if ($lockedVehicle["status"] !== "Reserved") {
                    throw new RuntimeException(
                        "The reserved vehicle status has changed. Please review the inventory."
                    );
                }

                // Update the reservation to Completed.
                $completeReservation = $pdo->prepare(
                    "UPDATE reservations
                     SET reservation_status = 'Completed'
                     WHERE reservation_id = ?
                       AND reservation_status = 'Active'"
                );

                // Execute the reservation update.
                $completeReservation->execute([
                    (int) $lockedSale["reservation_id"]
                ]);

                // Ensure that exactly one reservation was updated.
                if ($completeReservation->rowCount() !== 1) {
                    throw new RuntimeException(
                        "The reservation could not be completed."
                    );
                }

            } else {

                // An unreserved sale can proceed only when the vehicle is Available.
                if ($lockedVehicle["status"] !== "Available") {
                    throw new RuntimeException(
                        "This vehicle is not Available. Please review its reservation or inventory status."
                    );
                }

                // Check that no active reservation exists for this vehicle.
                $activeReservationQuery = $pdo->prepare(
                    "SELECT reservation_id
                     FROM reservations
                     WHERE vehicle_id = ?
                       AND reservation_status = 'Active'
                     LIMIT 1
                     FOR UPDATE"
                );

                // Execute the active reservation check.
                $activeReservationQuery->execute([
                    (int) $lockedSale["vehicle_id"]
                ]);

                // Reject a vehicle with an active reservation.
                if ($activeReservationQuery->fetchColumn()) {
                    throw new RuntimeException(
                        "This vehicle now has an active reservation. Please review the sale."
                    );
                }
            }

            // Update the vehicle status to Sold.
            $updateVehicle = $pdo->prepare(
                "UPDATE vehicles
                 SET status = 'Sold'
                 WHERE vehicle_id = ?
                   AND status IN ('Available', 'Reserved')"
            );

            // Execute the vehicle update.
            $updateVehicle->execute([
                (int) $lockedSale["vehicle_id"]
            ]);

            // Confirm that the vehicle was updated.
            if ($updateVehicle->rowCount() !== 1) {
                throw new RuntimeException(
                    "The vehicle status could not be updated to Sold."
                );
            }

            // Update the sale status to Completed.
            $updateSale = $pdo->prepare(
                "UPDATE sales
                 SET sale_status = 'Completed'
                 WHERE sale_id = ?
                   AND sale_status = 'Pending'"
            );

            // Execute the sale update.
            $updateSale->execute([$saleId]);

            // Confirm that the sale was updated.
            if ($updateSale->rowCount() !== 1) {
                throw new RuntimeException(
                    "The sale could not be marked as Completed."
                );
            }

            // Commit all related changes together.
            $pdo->commit();

            // Redirect to avoid accidental repeated submissions.
            header("Location: complete_sale.php?id=" . $saleId . "&completed=1");

            // Stop script execution after redirect.
            exit;

        } catch (RuntimeException $exception) {

            // Roll back all changes if a business rule fails.
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            // Display the business error.
            $error = $exception->getMessage();

        } catch (PDOException $exception) {

            // Roll back the transaction after a database error.
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            // Log the technical error privately.
            error_log(
                "VSMS sale completion error: " . $exception->getMessage()
            );

            // Display a friendly message.
            $error = "The sale could not be completed because of a database error.";
        }
    }
}

// Load the sale information for the confirmation screen.
try {

    // Retrieve the sale and its related customer, vehicle, and salesperson.
    $displayQuery = $pdo->prepare(
        "SELECT
            s.sale_id,
            s.sale_date,
            s.vehicle_price,
            s.discount_amount,
            s.additional_charges,
            s.final_amount,
            s.sale_status,
            s.salesperson_id,
            s.reservation_id,
            c.full_name AS customer_name,
            c.phone AS customer_phone,
            v.make,
            v.model,
            v.`year`,
            v.vin,
            v.status AS vehicle_status,
            u.full_name AS salesperson_name
         FROM sales AS s
         INNER JOIN customers AS c
            ON s.customer_id = c.customer_id
         INNER JOIN vehicles AS v
            ON s.vehicle_id = v.vehicle_id
         INNER JOIN users AS u
            ON s.salesperson_id = u.user_id
         WHERE s.sale_id = ?
         LIMIT 1"
    );

    // Execute the display query.
    $displayQuery->execute([$saleId]);

    // Retrieve the sale information.
    $sale = $displayQuery->fetch(PDO::FETCH_ASSOC);

    // Stop if the sale does not exist.
    if (!$sale) {
        http_response_code(404);
        exit("Sale not found.");
    }

    // Restrict Salesperson access to their own sale.
    if (
        $userRole === "Salesperson"
        && (int) $sale["salesperson_id"] !== (int) $user["user_id"]
    ) {
        http_response_code(403);
        exit("You cannot access this sale.");
    }

    // Show the success message after the redirect.
    if (
        isset($_GET["completed"])
        && $_GET["completed"] === "1"
        && $sale["sale_status"] === "Completed"
    ) {
        $success = "Sale #" . $saleId . " has been completed successfully. The vehicle status is now Sold.";
    }

} catch (PDOException $exception) {

    // Log the technical database error privately.
    error_log(
        "VSMS sale details loading error: " . $exception->getMessage()
    );

    // Display a friendly message.
    $error = "Unable to load the sale information. Please try again.";
}
?>

<!DOCTYPE html>
<!-- Declare the document as HTML5. -->
<html lang="en">

<head>
    <!-- Set the document character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Complete Sale | VSMS</title>

    <!-- Load the existing dashboard stylesheet. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Reuse the existing vehicle-management stylesheet. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <!-- Add styles specific to sale confirmation. -->
    <style>
        /* Style the main confirmation card. */
        .completion-card {
            max-width: 850px;
            margin-top: 22px;
            padding: 25px;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
        }

        /* Arrange sale details in two columns. */
        .completion-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
            margin-top: 20px;
        }

        /* Style each sale detail. */
        .completion-detail {
            padding: 14px;
            background: #f8fafc;
            border-radius: 8px;
        }

        /* Style the detail labels. */
        .completion-detail span {
            display: block;
            margin-bottom: 6px;
            color: #64748b;
            font-size: 12px;
        }

        /* Style the detail values. */
        .completion-detail strong {
            color: #172033;
            font-size: 14px;
        }

        /* Emphasize the final sale amount. */
        .completion-total {
            margin-top: 20px;
            padding: 20px;
            background: #fff7ed;
            border: 1px solid #fed7aa;
            border-radius: 9px;
        }

        /* Style the total amount label. */
        .completion-total span {
            display: block;
            color: #9a3412;
            font-size: 13px;
        }

        /* Style the final amount. */
        .completion-total strong {
            display: block;
            margin-top: 5px;
            color: #9a3412;
            font-size: 25px;
        }

        /* Style the confirmation warning. */
        .completion-warning {
            margin-top: 20px;
            padding: 15px;
            background: #fffbeb;
            border: 1px solid #fde68a;
            border-radius: 8px;
            color: #92400e;
            font-size: 13px;
            line-height: 1.6;
        }

        /* Arrange confirmation buttons. */
        .completion-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 22px;
        }

        /* Style feedback messages. */
        .completion-message {
            margin-top: 18px;
            padding: 14px 16px;
            border-radius: 8px;
            line-height: 1.5;
        }

        /* Style success feedback. */
        .completion-message.success {
            color: #065f46;
            background: #ecfdf5;
            border: 1px solid #a7f3d0;
        }

        /* Style error feedback. */
        .completion-message.error {
            color: #991b1b;
            background: #fef2f2;
            border: 1px solid #fecaca;
        }

        /* Stack details on small screens. */
        @media (max-width: 650px) {
            .completion-grid {
                grid-template-columns: 1fr;
            }

            .completion-card {
                padding: 17px;
            }
        }
    </style>
</head>

<body>
    <!-- Create the dashboard layout. -->
    <div class="dashboard-layout">

        <!-- Create the navigation sidebar. -->
        <aside class="sidebar">

            <!-- Display the VSMS brand. -->
            <div class="brand">
                <div class="brand-mark">V</div>
                <div class="brand-text">
                    <strong>VSMS</strong>
                    <span>Vehicle Management</span>
                </div>
            </div>

            <!-- Display the main navigation. -->
            <nav class="sidebar-navigation">

                <!-- Display the navigation heading. -->
                <p class="navigation-heading">MAIN MENU</p>

                <!-- Dashboard link. -->
                <a href="dashboard.php" class="nav-link">
                    <span class="nav-icon">▦</span>
                    <span>Dashboard</span>
                </a>

                <!-- Vehicle inventory link. -->
                <a href="vehicles.php" class="nav-link">
                    <span class="nav-icon">🚘</span>
                    <span>Vehicles</span>
                </a>

                <!-- Customer management link. -->
                <a href="customers.php" class="nav-link">
                    <span class="nav-icon">♙</span>
                    <span>Customers</span>
                </a>

                <!-- Reservation management link. -->
                <a href="reservations.php" class="nav-link">
                    <span class="nav-icon">▣</span>
                    <span>Reservations</span>
                </a>

                <!-- Sales link. -->
                <a href="add_sale.php" class="nav-link active">
                    <span class="nav-icon">▤</span>
                    <span>Sales</span>
                </a>

                <!-- Payments placeholder. -->
                <span class="nav-link nav-disabled">
                    <span class="nav-icon">$</span>
                    <span>Payments</span>
                    <small class="coming-soon">Soon</small>
                </span>

                <!-- Employees placeholder. -->
                <span class="nav-link nav-disabled">
                    <span class="nav-icon">♧</span>
                    <span>Employees</span>
                    <small class="coming-soon">Soon</small>
                </span>
                <?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
    <span class="nav-icon">♙</span>
    <span>User Accounts</span>
</a>

<?php endif; ?>

                <!-- Reports placeholder. -->
                <span class="nav-link nav-disabled">
                    <span class="nav-icon">▥</span>
                    <span>Reports</span>
                    <small class="coming-soon">Soon</small>
                </span>

            </nav>
        </aside>

        <!-- Create the main workspace. -->
        <main class="main-content">

            <!-- Display the page header. -->
            <header class="topbar">

                <!-- Display the page title. -->
                <div class="topbar-left">
                    <span class="breadcrumb">Main Menu / Sales / Complete Sale</span>
                    <h2>Complete Sale</h2>
                </div>

                <!-- Display the logged-in user. -->
                <div class="topbar-right">

                    <!-- Show the user's name and role. -->
                    <div class="user-information">
                    <a href="my_profile.php" class="profile-name-link"><?= escapeCompleteSale($user["full_name"]) ?></a>
                        <span><?= escapeCompleteSale($userRole) ?></span>
                    </div>

                    <!-- Submit logout using POST. -->
                    <form action="logout.php" method="POST">

                        <!-- Include the CSRF token. -->
                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= escapeCompleteSale($csrfToken) ?>"
                        >

                        <!-- Display the logout button. -->
                        <button type="submit" class="logout-button">Logout</button>
                    </form>
                </div>
            </header>

            <!-- Display the sale confirmation content. -->
            <section class="page-content">

                <!-- Display the page heading. -->
                <div class="page-heading">
                    <div>
                        <h1>Sale Confirmation</h1>
                        <p>Review the transaction before completing it.</p>
                    </div>

                    <!-- Return to the dashboard. -->
                    <a href="dashboard.php" class="secondary-button">
                        Back to Dashboard
                    </a>
                </div>

                <!-- Display a success message when the sale is completed. -->
                <?php if ($success !== ""): ?>

                    <div class="completion-message success">
                        <?= escapeCompleteSale($success) ?>
                    </div>

                <?php endif; ?>

                <!-- Display any errors. -->
                <?php if ($error !== ""): ?>

                    <div class="completion-message error">
                        <?= escapeCompleteSale($error) ?>
                    </div>

                <?php endif; ?>

                <!-- Display the sale information. -->
                <?php if ($sale !== null): ?>

                    <div class="completion-card">

                        <!-- Display the sale identifier and status. -->
                        <h2>Sale #<?= (int) $sale["sale_id"] ?></h2>

                        <p>
                            Current Status:
                            <strong>
                                <?= escapeCompleteSale($sale["sale_status"]) ?>
                            </strong>
                        </p>

                        <!-- Display the customer, vehicle, and salesperson details. -->
                        <div class="completion-grid">

                            <!-- Customer information. -->
                            <div class="completion-detail">
                                <span>Customer</span>
                                <strong>
                                    <?= escapeCompleteSale($sale["customer_name"]) ?>
                                </strong>
                            </div>

                            <!-- Customer phone. -->
                            <div class="completion-detail">
                                <span>Customer Phone</span>
                                <strong>
                                    <?= escapeCompleteSale($sale["customer_phone"]) ?>
                                </strong>
                            </div>

                            <!-- Vehicle information. -->
                            <div class="completion-detail">
                                <span>Vehicle</span>
                                <strong>
                                    <?= escapeCompleteSale(
                                        $sale["year"] . " " .
                                        $sale["make"] . " " .
                                        $sale["model"]
                                    ) ?>
                                </strong>
                            </div>

                            <!-- Vehicle identification number. -->
                            <div class="completion-detail">
                                <span>VIN</span>
                                <strong>
                                    <?= escapeCompleteSale($sale["vin"]) ?>
                                </strong>
                            </div>

                            <!-- Salesperson information. -->
                            <div class="completion-detail">
                                <span>Salesperson</span>
                                <strong>
                                    <?= escapeCompleteSale($sale["salesperson_name"]) ?>
                                </strong>
                            </div>

                            <!-- Vehicle inventory status. -->
                            <div class="completion-detail">
                                <span>Vehicle Status</span>
                                <strong>
                                    <?= escapeCompleteSale($sale["vehicle_status"]) ?>
                                </strong>
                            </div>

                            <!-- Sale date. -->
                            <div class="completion-detail">
                                <span>Sale Registration Date</span>
                                <strong>
                                    <?= escapeCompleteSale($sale["sale_date"]) ?>
                                </strong>
                            </div>

                            <!-- Reservation information. -->
                            <div class="completion-detail">
                                <span>Reservation</span>
                                <strong>
                                    <?= $sale["reservation_id"] !== null
                                        ? "Reservation #" . (int) $sale["reservation_id"]
                                        : "No reservation" ?>
                                </strong>
                            </div>

                        </div>

                        <!-- Display the financial calculation. -->
                        <div class="completion-total">

                            <span>Vehicle Price</span>
                            <strong>
                                <?= number_format((float) $sale["vehicle_price"], 2) ?>
                            </strong>

                            <p>
                                Discount:
                                <?= number_format((float) $sale["discount_amount"], 2) ?>
                            </p>

                            <p>
                                Additional Charges:
                                <?= number_format((float) $sale["additional_charges"], 2) ?>
                            </p>

                            <span>Final Sale Amount</span>
                            <strong>
                                <?= number_format((float) $sale["final_amount"], 2) ?>
                            </strong>

                        </div>

                        <!-- Display the confirmation action only for Pending sales. -->
                        <?php if ($sale["sale_status"] === "Pending"): ?>

                            <div class="completion-warning">
                                <strong>Important:</strong>
                                Completing this sale will permanently change its status
                                to Completed and the vehicle status to Sold.

                                <?php if ($sale["reservation_id"] !== null): ?>
                                    The linked reservation will also become Completed.
                                <?php endif; ?>

                                Please review the information before confirming.
                            </div>

                            <!-- Submit the completion request using POST. -->
                            <form action="complete_sale.php" method="POST">

                                <!-- Include the CSRF token. -->
                                <input
                                    type="hidden"
                                    name="csrf_token"
                                    value="<?= escapeCompleteSale($csrfToken) ?>"
                                >

                                <!-- Include the sale ID. -->
                                <input
                                    type="hidden"
                                    name="sale_id"
                                    value="<?= (int) $sale["sale_id"] ?>"
                                >

                                <!-- Display the action buttons. -->
                                <div class="completion-actions">

                                    <!-- Confirm and complete the sale. -->
                                    <button
                                        type="submit"
                                        class="primary-button"
                                        onclick="return confirm('Are you sure you want to complete this sale and mark the vehicle as Sold?');"
                                    >
                                        Confirm and Complete Sale
                                    </button>

                                    <!-- Return to the new sale page. -->
                                    <a href="add_sale.php" class="secondary-button">
                                        Back
                                    </a>

                                </div>
                            </form>

                        <?php else: ?>

                            <!-- Explain that the sale can no longer be completed. -->
                            <div class="completion-warning">
                                This sale is no longer Pending. No further completion
                                action is available.
                            </div>

                            <!-- Return to the dashboard. -->
                            <div class="completion-actions">
                                <a href="dashboard.php" class="secondary-button">
                                    Back to Dashboard
                                </a>
                            </div>

                        <?php endif; ?>

                    </div>

                <?php endif; ?>

            </section>
        </main>
    </div>
</body>
</html>
