
<?php
// Load authentication, session and database connection.
require_once __DIR__ . '/../includes/auth.php';

// Only logged-in users can access this page.
requireLogin();

// Get the logged-in user's information.
$loggedInUser = currentUser();
$userId = (int) ($loggedInUser['user_id'] ?? 0);

// Stop if the user ID is unavailable.
if ($userId <= 0) {
    redirect('login.php');
}

// Generate a CSRF token.
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['csrf_token'];

$successMessage = '';
$errorMessage = '';

// Escape output before displaying it in HTML.
function profileEscape($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

// Retrieve the user's profile and linked employee information.
function getProfile(PDO $pdo, int $userId): array
{
    $sql = "
        SELECT
            u.user_id,
            u.full_name,
            u.username,
            u.email,
            u.status AS account_status,
            u.created_at AS account_created,
            r.role_name,
            e.employee_id,
            e.phone,
            e.position,
            e.status AS employment_status
        FROM users u
        INNER JOIN roles r ON u.role_id = r.role_id
        LEFT JOIN employees e ON e.user_id = u.user_id
        WHERE u.user_id = :user_id
        LIMIT 1
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(['user_id' => $userId]);

    $profile = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$profile) {
        throw new RuntimeException('Your profile could not be found.');
    }

    return $profile;
}

try {
    // Process profile updates.
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        // Verify CSRF token.
        $submittedToken = $_POST['csrf_token'] ?? '';

        if (!hash_equals($csrfToken, $submittedToken)) {
            throw new RuntimeException(
                'Your session verification failed. Please refresh the page and try again.'
            );
        }

        // Read submitted information.
        $fullName = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        // Read password fields.
$currentPassword = $_POST['current_password'] ?? '';
$newPassword = $_POST['new_password'] ?? '';
$confirmPassword = $_POST['confirm_password'] ?? '';

// Determine whether the user wants to change their password.
$passwordChanged = (
    $currentPassword !== '' ||
    $newPassword !== '' ||
    $confirmPassword !== ''
);

// Validate password change if any password field is filled.
if ($passwordChanged) {

    if (
        $currentPassword === '' ||
        $newPassword === '' ||
        $confirmPassword === ''
    ) {
        throw new RuntimeException(
            'Please complete all three password fields to change your password.'
        );
    }

    if (strlen($newPassword) < 12) {
        throw new RuntimeException(
            'Your new password must contain at least 12 characters.'
        );
    }

    if (strlen($newPassword) > 72) {
        throw new RuntimeException(
            'Your new password must not exceed 72 characters.'
        );
    }

    if ($newPassword !== $confirmPassword) {
        throw new RuntimeException(
            'The new password and confirmation do not match.'
        );
    }

    // Retrieve the current password hash from the database.
    $passwordQuery = $pdo->prepare("
        SELECT password_hash
        FROM users
        WHERE user_id = :user_id
        LIMIT 1
    ");

    $passwordQuery->execute(['user_id' => $userId]);

    $storedPassword = $passwordQuery->fetchColumn();

    // Verify the current password.
    if (!$storedPassword || !password_verify($currentPassword, $storedPassword)) {
        throw new RuntimeException('Your current password is incorrect.');
    }
}

        // Validate full name.
        if ($fullName === '' || strlen($fullName) > 150) {
            throw new RuntimeException(
                'Please enter a valid full name (maximum 150 characters).'
            );
        }

        // Validate email when provided.
        if ($email === '') {
    throw new RuntimeException('Email address is required.');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    throw new RuntimeException('Please enter a valid email address.');
}

        if (strlen($email) > 150) {
            throw new RuntimeException('The email address is too long.');
        }

        // Get the current profile to check whether an employee record exists.
        $currentProfile = getProfile($pdo, $userId);

        // Update account and employee information together.
        $pdo->beginTransaction();

        try {
            $updateUser = $pdo->prepare("
                UPDATE users
                SET full_name = :full_name,
                    email = :email
                WHERE user_id = :user_id
            ");

            $updateUser->execute([
                'full_name' => $fullName,
                'email' => $email,
                'user_id' => $userId
            ]);
            // Update password only when the user requested a password change.
if ($passwordChanged) {

    // Generate a secure password hash.
    $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);

    $updatePassword = $pdo->prepare("
        UPDATE users
        SET password_hash = :password_hash
        WHERE user_id = :user_id
    ");

    $updatePassword->execute([
        'password_hash' => $newPasswordHash,
        'user_id' => $userId
    ]);
}

            // Update contact information only if an employee record is linked.
            if (!empty($currentProfile['employee_id'])) {

            // Validate the employee's phone number.
            // It must contain exactly 10 digits and start with 07.
            if (!preg_match('/^07[0-9]{8}$/', $phone)) {
                throw new RuntimeException(
                    'Phone number must contain exactly 10 digits and start with 07.'
                );
            }

                $updateEmployee = $pdo->prepare("
                    UPDATE employees
                    SET full_name = :full_name,
                        email = :email,
                        phone = :phone
                    WHERE employee_id = :employee_id
                      AND user_id = :user_id
                ");

                $updateEmployee->execute([
                    'full_name' => $fullName,
                    'email' => $email,
                    'phone' => $phone,
                    'employee_id' => $currentProfile['employee_id'],
                    'user_id' => $userId
                ]);
            }

            $pdo->commit();

// Regenerate session ID after a successful password change.
if ($passwordChanged) {
    session_regenerate_id(true);
}

$successMessage = $passwordChanged
    ? 'Your profile and password have been updated successfully.'
    : 'Your profile has been updated successfully.';

        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            throw $e;
        }
    }

    // Always retrieve the latest profile information.
    $profile = getProfile($pdo, $userId);

} catch (PDOException $e) {
    // Avoid exposing database details to users.
    if ($e->getCode() === '23000') {
        $errorMessage = 'This email address may already be registered to another account.';
    } else {
        $errorMessage = 'A database error occurred. Please try again.';
    }

    $profile = getProfile($pdo, $userId);

} catch (Throwable $e) {
    $errorMessage = $e->getMessage();

    if (!isset($profile)) {
        $profile = getProfile($pdo, $userId);
    }
}

// Format account creation date.
$createdDate = !empty($profile['account_created'])
    ? date('d M Y', strtotime($profile['account_created']))
    : 'Not available';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile | VSMS</title>

    <link rel="stylesheet" href="assets/css/dashboard.css">

    <style>
        .profile-page {
            padding: 20px;
            max-width: 1050px;
            margin: 0 auto;
        }

        .profile-heading {
            margin-bottom: 24px;
        }

        .profile-heading h1 {
            margin-bottom: 6px;
        }

        .profile-card {
            background: #fff;
            border-radius: 12px;
            padding: 26px;
            margin-bottom: 22px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.04);
        }

        .profile-card h2 {
            font-size: 18px;
            margin: 0 0 22px;
            color: #17243a;
        }

        .profile-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
        }

        .profile-field label {
            display: block;
            font-size: 13px;
            color: #687386;
            margin-bottom: 7px;
        }

        .profile-field input {
            width: 100%;
            padding: 12px 13px;
            border: 1px solid #dce1e8;
            border-radius: 7px;
            font-size: 14px;
            box-sizing: border-box;
        }

        .profile-field input:focus {
            outline: none;
            border-color: #f07852;
            box-shadow: 0 0 0 3px rgba(240, 120, 82, 0.12);
        }

        .profile-field input[readonly] {
            background: #f3f5f8;
            color: #687386;
            cursor: not-allowed;
        }

        .profile-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 24px;
        }

        .profile-button {
            display: inline-block;
            border: none;
            border-radius: 7px;
            padding: 12px 20px;
            background: #f07852;
            color: #fff;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
        }

        .profile-button:hover {
            background: #dc6542;
        }

        .profile-message {
            padding: 13px 16px;
            border-radius: 7px;
            margin-bottom: 20px;
        }

        .profile-success {
            background: #e8f7ee;
            color: #176b3a;
        }

        .profile-error {
            background: #fdecec;
            color: #a52a2a;
        }

        .profile-note {
            font-size: 13px;
            color: #687386;
            margin-top: 16px;
        }

        @media (max-width: 650px) {
            .profile-grid {
                grid-template-columns: 1fr;
            }

            .profile-card {
                padding: 18px;
            }
        }
    </style>
</head>

<body>

<div class="dashboard-layout">

    <aside class="sidebar">
    <div class="brand">

<!-- Display the short system name inside a logo box. -->
<div class="brand-logo">V</div>

<!-- Display the full system name. -->
<div class="brand-text">
    <h2>VSMS</h2>
    <p>Vehicle Management</p>
</div>

<!-- Close the brand section. -->
</div>

<nav class="sidebar-navigation">

<!-- Display the navigation section heading. -->
<p class="navigation-heading">MAIN MENU</p>

<!-- Link to the Dashboard. -->
<a href="dashboard.php" class="nav-link active">
    <span class="nav-icon">▦</span>
    <span>Dashboard</span>
</a>

<!-- Link to Vehicle Management. -->
<a href="vehicles.php" class="nav-link">
    <span class="nav-icon">🚘</span>
    <span>Vehicles</span>
</a>

<!-- Link to Customer Management. -->
<a href="customers.php" class="nav-link">
    <span class="nav-icon">♙</span>
    <span>Customers</span>
</a>

<!-- Link to Reservation Management. -->
<a href="reservations.php" class="nav-link">
    <span class="nav-icon">▣</span>
    <span>Reservations</span>
</a>

<!-- Link to Sales Management. -->
<a href="sales.php" class="nav-link">
    <span class="nav-icon">▤</span>
    <span>Sales</span>
</a>

<!-- Link to Payment Management. -->
<a href="payments.php" class="nav-link">
    <span class="nav-icon">$</span>
    <span>Payments</span>
</a>
<!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
<span class="nav-icon">◷</span>
<span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
<span class="nav-icon">▧</span>
<span>Invoices</span>
</a>
<?php if (hasRole('Administrator') || hasRole('Manager')): ?>
                <a href="employees.php" class="nav-link">
                <span class="nav-icon">♙</span>
                    <span>Employees</span>

                </a>
                

                <a href="reports.php" class="nav-link">
                <span class="nav-icon">▤</span>
                    <span>Reports</span>
                </a>
            <?php endif; ?>




<!-- Close the navigation section. -->
</nav>
        
        
    </aside>

    <main class="main-content">
        
   

<!-- Close the top header. -->
</header>

        <header class="topbar">
            <div class="breadcrumb">
                <strong>My Profile</strong>
            </div>

            <div class="topbar-user">
            <div class="user-avatar">
    <!-- <a href="my_profile.php" class="profile-name-link"> -->
        <?= htmlspecialchars(strtoupper(substr($profile["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>
    <div class="user-information">
    <!-- <a href="my_profile.php" class="profile-name-link"> -->
    <?= profileEscape($profile['full_name']) ?>
                        </a>
                        <span>
                    <?= profileEscape($profile['role_name']) ?>
                </span>
    </div>
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

               
                
            </div>
        </header>

        <div class="profile-page">

            <div class="profile-heading">
                <h1>My Profile</h1>
                <p>View and manage your personal account information.</p>
            </div>

            <?php if ($successMessage): ?>
                <div class="profile-message profile-success">
                    <?= profileEscape($successMessage) ?>
                </div>
            <?php endif; ?>

            <?php if ($errorMessage): ?>
                <div class="profile-message profile-error">
                    <?= profileEscape($errorMessage) ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="my_profile.php" id="profileForm">

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= profileEscape($csrfToken) ?>"
                >

                <section class="profile-card">
                    <h2>Account Information</h2>

                    <div class="profile-grid">

                        <div class="profile-field">
                            <label>Full Name</label>
                            <input
                                type="text"
                                name="full_name"
                                value="<?= profileEscape($profile['full_name']) ?>"
                                maxlength="150"
                                required
                            >
                        </div>

                        <div class="profile-field">
                            <label>Username</label>
                            <input
                                type="text"
                                value="<?= profileEscape($profile['username']) ?>"
                                readonly
                            >
                        </div>

                        <div class="profile-field">
                            <label>Email Address</label>
                            <input
                                type="email"
                                name="email"
                                value="<?= profileEscape($profile['email']) ?>"
                                maxlength="150"
                                required
                            >
                        </div>

                        <div class="profile-field">
                            <label>Role</label>
                            <input
                                type="text"
                                value="<?= profileEscape($profile['role_name']) ?>"
                                readonly
                            >
                        </div>

                        <div class="profile-field">
                            <label>Account Status</label>
                            <input
                                type="text"
                                value="<?= profileEscape($profile['account_status']) ?>"
                                readonly
                            >
                        </div>

                        <div class="profile-field">
                            <label>Account Created</label>
                            <input
                                type="text"
                                value="<?= profileEscape($createdDate) ?>"
                                readonly
                            >
                        </div>

                    </div>

                    <p class="profile-note">
                        Your username, role and account status cannot be changed from this page.
                    </p>
                </section>

                <?php if (!empty($profile['employee_id'])): ?>

                    <section class="profile-card">
                        <h2>Employee Information</h2>

                        <div class="profile-grid">

                            <div class="profile-field">
                                <label>Employee ID</label>
                                <input
                                    type="text"
                                    value="<?= profileEscape($profile['employee_id']) ?>"
                                    readonly
                                >
                            </div>

                            <div class="profile-field">
                                <label>Position</label>
                                <input
                                    type="text"
                                    value="<?= profileEscape($profile['position']) ?>"
                                    readonly
                                >
                            </div>

                            <div class="profile-field">
                                <label>Phone Number</label>
                                <input
    type="tel"
    name="phone"
    inputmode="numeric"
    value="<?= profileEscape($profile['phone']) ?>"
    pattern="07[0-9]{8}"
    minlength="10"
    maxlength="10"
    placeholder="07XXXXXXXX"
    title="Enter exactly 10 digits starting with 07."
    required
>
                            </div>

                            <div class="profile-field">
                                <label>Employment Status</label>
                                <input
                                    type="text"
                                    value="<?= profileEscape($profile['employment_status']) ?>"
                                    readonly
                                >
                            </div>

                        </div>

                        <p class="profile-note">
                            You can update your phone number, but your position and employment status
                            are managed by the Administrator.
                        </p>
                    </section>

                <?php else: ?>

                    <section class="profile-card">
                        <h2>Employee Information</h2>
                        <p class="profile-note">
                            No employee record is currently linked to this login account.
                        </p>
                    </section>

                <?php endif; ?>
                <!-- Password Management Section -->
<section class="profile-card">

    <h2>Change Password</h2>

    <p class="profile-note">
        Leave these fields empty if you do not want to change your password.
    </p>

    <div class="profile-grid">

        <div class="profile-field">
            <label for="current_password">Current Password</label>

            <input
                type="password"
                id="current_password"
                name="current_password"
                autocomplete="current-password"
                placeholder="Enter your current password"
            >
        </div>

        <div class="profile-field">
            <label for="new_password">New Password</label>

            <input
                type="password"
                id="new_password"
                name="new_password"
                autocomplete="new-password"
                minlength="12"
                maxlength="72"
                placeholder="Enter your new password"
            >
        </div>

        <div class="profile-field">
            <label for="confirm_password">Confirm New Password</label>

            <input
                type="password"
                id="confirm_password"
                name="confirm_password"
                autocomplete="new-password"
                minlength="12"
                maxlength="72"
                placeholder="Confirm your new password"
            >
        </div>

    </div>

    <p class="profile-note">
        Your new password must contain at least 12 characters.
        Your current password is required to authorize the change.
    </p>

</section>

                <div class="profile-actions">
                    <a href="dashboard.php" class="profile-button">
                        Back to Dashboard
                    </a>

                    <button type="submit" class="profile-button">
                        Save Changes
                    </button>
                </div>

            </form>

        </div>

    </main>

</div>
<script>
document.getElementById('profileForm').addEventListener('submit', function(event) {

    const newPassword = document.getElementById('new_password').value;
    const confirmPassword = document.getElementById('confirm_password').value;

    // Check password length only when the user enters a new password.
    if (newPassword !== '' && newPassword.length < 12) {
        event.preventDefault();

        alert('Your new password must contain at least 12 characters.');

        document.getElementById('new_password').focus();
        return;
    }

    // Check that both passwords match.
    if (newPassword !== '' && newPassword !== confirmPassword) {
        event.preventDefault();

        alert('Your new password and confirmation do not match.');

        document.getElementById('confirm_password').focus();
    }
});
</script>

</body>
</html>
