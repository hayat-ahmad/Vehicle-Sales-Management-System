
<?php
// Load authentication, session handling, and the PDO database connection.
require_once __DIR__ . "/../includes/auth.php";

// Only logged-in users can access this page.
requireLogin();

// Only the Administrator can register employees.
requireRole("Administrator");

// Retrieve the currently logged-in user's information.
$user = currentUser();

// Create a CSRF token if the session does not already have one.
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Prepare variables used by the form and feedback messages.
$errors = [];
$successMessage = "";
$formData = [
    "full_name" => "",
    "phone" => "",
    "email" => "",
    "position" => "",
    "user_id" => ""
];

// Convert output into safe HTML to prevent cross-site scripting.
function escapeEmployeeValue($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}
// Count the number of characters in a string, including Unicode characters.
// This works even when the PHP mbstring extension is not enabled.
function employeeStringLength($value)
{
    // Count Unicode characters using a regular expression.
    $length = preg_match_all('/./us', $value);

    // Return the character count if successful.
    // Otherwise, use the standard PHP string-length function.
    return ($length !== false) ? $length : strlen($value);
}

// Retrieve login accounts that are not already linked to employees.
$availableUsersQuery = "
    SELECT
        u.user_id,
        u.full_name,
        u.username,
        r.role_name
    FROM users AS u
    INNER JOIN roles AS r
        ON r.role_id = u.role_id
    LEFT JOIN employees AS e
        ON e.user_id = u.user_id
    WHERE
        u.status = 'active'
        AND e.employee_id IS NULL
    ORDER BY u.full_name ASC
";

// Execute the query and store the available accounts.
$availableUsersStatement = $pdo->query($availableUsersQuery);
$availableUsers = $availableUsersStatement->fetchAll(PDO::FETCH_ASSOC);

// Process the form only when it is submitted using POST.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Read and verify the submitted CSRF token.
    $submittedToken = $_POST["csrf_token"] ?? "";

    // Stop the request if the token is missing or incorrect.
    if (
        !is_string($submittedToken) ||
        !hash_equals($_SESSION["csrf_token"], $submittedToken)
    ) {
        $errors[] = "Invalid form submission. Please refresh the page and try again.";
    }

    // Collect and clean the submitted employee information.
    $formData["full_name"] = trim($_POST["full_name"] ?? "");
    $formData["phone"] = trim($_POST["phone"] ?? "");
    $formData["email"] = trim($_POST["email"] ?? "");
    $formData["position"] = trim($_POST["position"] ?? "");
    $formData["user_id"] = trim($_POST["user_id"] ?? "");

    // Validate the employee's full name.
    if ($formData["full_name"] === "") {
        $errors[] = "Employee full name is required.";
    } elseif (employeeStringLength($formData["full_name"]) > 150) {
        $errors[] = "Employee name cannot exceed 150 characters.";
    }

    // Validate the employee's phone number.
// It must contain exactly 10 digits and start with 07.
if (!preg_match('/^07[0-9]{8}$/', $formData["phone"])) {
    $errors[] = "Phone number must contain exactly 10 digits and start with 07.";
}
    // Validate the email address only when one is provided.
    if ($formData["email"] !== "") {
        if (!filter_var($formData["email"], FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Please enter a valid email address.";
        } elseif (employeeStringLength($formData["email"]) > 150) {
            $errors[] = "Email address cannot exceed 150 characters.";
        }
    }

    // Validate the employee's position.
    if ($formData["position"] === "") {
        $errors[] = "Employee position is required.";
    } elseif (employeeStringLength($formData["position"]) > 100) {
        $errors[] = "Position cannot exceed 100 characters.";
    }

    // Convert an empty account selection into NULL.
    $linkedUserId = null;

    // Validate the selected login account when one is provided.
    if ($formData["user_id"] !== "") {

        // Make sure the submitted account ID is a positive integer.
        $validatedUserId = filter_var(
            $formData["user_id"],
            FILTER_VALIDATE_INT,
            ["options" => ["min_range" => 1]]
        );

        if ($validatedUserId === false) {
            $errors[] = "Please select a valid login account.";
        } else {

            // Confirm that the account exists, is active, and is not linked.
            $checkUserStatement = $pdo->prepare("
                SELECT u.user_id
                FROM users AS u
                LEFT JOIN employees AS e
                    ON e.user_id = u.user_id
                WHERE
                    u.user_id = :user_id
                    AND u.status = 'active'
                    AND e.employee_id IS NULL
                LIMIT 1
            ");

            // Execute the validation query using a prepared statement.
            $checkUserStatement->execute([
                "user_id" => $validatedUserId
            ]);

            // Reject accounts that cannot be linked.
            if (!$checkUserStatement->fetchColumn()) {
                $errors[] = "The selected login account is unavailable or already linked.";
            } else {
                $linkedUserId = $validatedUserId;
            }
        }
    }

    // Insert the employee only when all validations have passed.
    if (empty($errors)) {
        try {

            // Prepare a secure INSERT statement for the employee record.
            $insertStatement = $pdo->prepare("
                INSERT INTO employees (
                    user_id,
                    full_name,
                    phone,
                    email,
                    position,
                    status
                ) VALUES (
                    :user_id,
                    :full_name,
                    :phone,
                    :email,
                    :position,
                    'Active'
                )
            ");

            // Execute the INSERT with the validated employee information.
            $insertStatement->execute([
                "user_id" => $linkedUserId,
                "full_name" => $formData["full_name"],
                "phone" => $formData["phone"],
                "email" => $formData["email"] !== ""
                    ? $formData["email"]
                    : null,
                "position" => $formData["position"]
            ]);

            // Display a success message after the database confirms insertion.
            $successMessage = "Employee registered successfully.";

            // Clear the form after successful registration.
            $formData = [
                "full_name" => "",
                "phone" => "",
                "email" => "",
                "position" => "",
                "user_id" => ""
            ];

            // Generate a fresh CSRF token for the next form submission.
            $_SESSION["csrf_token"] = bin2hex(random_bytes(32));

            // Refresh the available account list after creating the employee.
            $availableUsersStatement = $pdo->query($availableUsersQuery);
            $availableUsers = $availableUsersStatement->fetchAll(PDO::FETCH_ASSOC);

        } catch (PDOException $exception) {

            // Log technical details on the server without exposing them to users.
            error_log("Employee registration error: " . $exception->getMessage());

            // Show a safe error message in the application.
            $errors[] = "The employee could not be registered. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Set the character encoding for the page. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on mobile and desktop screens. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Add Employee | VSMS</title>

    <!-- Load the existing dashboard stylesheet. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Load the existing vehicle stylesheet for shared form styling. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <!-- Add page-specific styles while retaining the VSMS visual direction. -->
    <style>
        /* Give the page a light grey workspace background. */
        body {
            background: #f4f6f9;
        }

        /* Keep the employee form centered and readable. */
        .employee-page {
            max-width: 1000px;
            margin: 35px auto;
            padding: 0 24px 40px;
        }

        /* Arrange the page heading and back link. */
        .employee-page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            margin-bottom: 24px;
        }

        /* Style the main page heading. */
        .employee-page-header h1 {
            margin: 0 0 7px;
            color: #17233d;
            font-size: 27px;
        }

        /* Style the small explanatory text. */
        .employee-page-header p {
            margin: 0;
            color: #718096;
        }

        /* Style the main white form card. */
        .employee-form-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 28px;
            box-shadow: 0 3px 15px rgba(20, 35, 60, 0.06);
        }

        /* Arrange form fields in two columns on larger screens. */
        .employee-form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
        }

        /* Keep labels and inputs together. */
        .employee-field {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        /* Make form labels clear and readable. */
        .employee-field label {
            color: #26344d;
            font-weight: 600;
        }

        /* Apply consistent styling to form controls. */
        .employee-field input,
        .employee-field select {
            width: 100%;
            box-sizing: border-box;
            padding: 12px 13px;
            border: 1px solid #d9e0e9;
            border-radius: 7px;
            background: #ffffff;
            color: #26344d;
            font: inherit;
        }

        /* Highlight a field when the user selects it. */
        .employee-field input:focus,
        .employee-field select:focus {
            outline: none;
            border-color: #f07855;
            box-shadow: 0 0 0 3px rgba(240, 120, 85, 0.12);
        }

        /* Explain the optional login-account field. */
        .employee-help-text {
            color: #718096;
            font-size: 13px;
            line-height: 1.5;
        }

        /* Place the form action buttons together. */
        .employee-form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 28px;
            padding-top: 22px;
            border-top: 1px solid #edf0f4;
        }

        /* Style the primary Save button. */
        .employee-save-button {
            border: none;
            border-radius: 7px;
            padding: 12px 22px;
            background: #ed7957;
            color: #ffffff;
            font-weight: 600;
            cursor: pointer;
        }

        /* Darken the Save button slightly when hovered. */
        .employee-save-button:hover {
            background: #d96543;
        }

        /* Style the secondary Cancel link. */
        .employee-cancel-button,
        .employee-back-link {
            display: inline-block;
            padding: 11px 16px;
            border: 1px solid #d9e0e9;
            border-radius: 7px;
            color: #34445f;
            background: #ffffff;
            text-decoration: none;
            font-weight: 600;
        }

        /* Display success and validation messages clearly. */
        .employee-alert {
            margin-bottom: 20px;
            padding: 13px 16px;
            border-radius: 7px;
        }

        /* Use green styling for successful registration. */
        .employee-alert-success {
            background: #eaf7ef;
            color: #23663b;
        }

        /* Use red styling for validation or registration errors. */
        .employee-alert-error {
            background: #fff0ee;
            color: #a6372c;
        }

        /* Stack fields on narrow screens. */
        @media (max-width: 650px) {
            .employee-form-grid {
                grid-template-columns: 1fr;
            }

            .employee-page-header {
                align-items: flex-start;
                flex-direction: column;
            }

            .employee-form-card {
                padding: 20px;
            }

            .employee-form-actions {
                flex-direction: column-reverse;
            }

            .employee-save-button,
            .employee-cancel-button {
                text-align: center;
                width: 100%;
                box-sizing: border-box;
            }
        }
    </style>
</head>
<body>

    <!-- Main page container. -->
    <main class="employee-page">

        <!-- Page heading and navigation back to the dashboard. -->
        <div class="employee-page-header">
            <div>
                <h1>Add Employee</h1>
                <p>Register a new employee in the vehicle sales management system.</p>
            </div>

            <!-- Return to the dashboard without submitting the form. -->
            <a class="primary-button" href="employees.php">
                Back to Employee
            </a>
        </div>

        <!-- Show the success message after a successful database insertion. -->
        <?php if ($successMessage !== ""): ?>
            <div class="employee-alert employee-alert-success">
                <?= escapeEmployeeValue($successMessage) ?>
            </div>
        <?php endif; ?>

        <!-- Display all validation or registration errors. -->
        <?php if (!empty($errors)): ?>
            <div class="employee-alert employee-alert-error">
                <strong>Please correct the following:</strong>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= escapeEmployeeValue($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Main employee registration form card. -->
        <section class="employee-form-card">

            <!-- Submit employee information to this same PHP page. -->
            <form method="POST" action="add_employee.php">

                <!-- Include the CSRF token to protect the form submission. -->
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= escapeEmployeeValue($_SESSION["csrf_token"]) ?>"
                >

                <!-- Group employee information into a responsive grid. -->
                <div class="employee-form-grid">

                    <!-- Collect the employee's full name. -->
                    <div class="employee-field">
                        <label for="full_name">Full Name *</label>
                        <input
                            type="text"
                            id="full_name"
                            name="full_name"
                            maxlength="150"
                            placeholder="Enter employee full name"
                            value="<?= escapeEmployeeValue($formData["full_name"]) ?>"
                            required
                        >
                    </div>

                    <!-- Collect the employee's contact phone number. -->
                    <div class="employee-field">
                        <label for="phone">Phone Number *</label>
                        <input
    type="tel"
    id="phone"
    name="phone"
    inputmode="numeric"
    pattern="07[0-9]{8}"
    minlength="10"
    maxlength="10"
    placeholder="07XXXXXXXX"
    value="<?= escapeEmployeeValue($formData["phone"]) ?>"
    title="Enter exactly 10 digits starting with 07."
    required
>
                    </div>

                    <!-- Collect the employee's optional email address. -->
                    <div class="employee-field">
                        <label for="email">Email Address</label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            maxlength="150"
                            placeholder="Enter email address (optional)"
                            value="<?= escapeEmployeeValue($formData["email"]) ?>"
                        >
                    </div>

                    <!-- Collect the employee's job position. -->
                    <div class="employee-field">
                        <label for="position">Position *</label>
                        <input
                            type="text"
                            id="position"
                            name="position"
                            maxlength="100"
                            placeholder="Example: Salesperson or Manager"
                            value="<?= escapeEmployeeValue($formData["position"]) ?>"
                            required
                        >
                    </div>

                    <!-- Allow an employee to be linked to an existing login account. -->
                    <div class="employee-field">
                        <label for="user_id">Link Login Account (Optional)</label>

                        <select id="user_id" name="user_id">
                            <option value="">No login account linked</option>

                            <!-- Display only active accounts that are not already linked. -->
                            <?php foreach ($availableUsers as $availableUser): ?>
                                <option
                                    value="<?= (int) $availableUser["user_id"] ?>"
                                    <?= (string) $formData["user_id"] === (string) $availableUser["user_id"] ? "selected" : "" ?>
                                >
                                    <?= escapeEmployeeValue($availableUser["full_name"]) ?>
                                    (<?= escapeEmployeeValue($availableUser["username"]) ?>)
                                    - <?= escapeEmployeeValue($availableUser["role_name"]) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>

                        <!-- Explain the purpose of linking an account. -->
                        <small class="employee-help-text">
                            Select an existing account if this employee already has permission
                            to log in to VSMS. This does not create a new login account.
                        </small>
                    </div>

                </div>

                <!-- Provide the form submission and cancellation actions. -->
                <div class="employee-form-actions">

                    <!-- Return to the dashboard without saving. -->
                    <a class="employee-cancel-button" href="dashboard.php">
                        Cancel
                    </a>

                    <!-- Submit the employee registration form. -->
                    <button class="employee-save-button" type="submit">
                        Save Employee
                    </button>

                </div>
            </form>
        </section>
    </main>

</body>
</html>
