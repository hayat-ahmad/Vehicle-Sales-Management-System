
<?php
// Load the existing authentication functions and database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require users to log in before viewing reservations.
requireLogin();

// Retrieve the currently logged-in user's information.
$user = currentUser();

// If the account is no longer active, clear the session and redirect.
if ($user === null) {
    $_SESSION = [];
    session_destroy();
    redirect("login.php");
}

// Store the user's role for permission checks and display.
$userRole = $user["role_name"];

// Allow only the three approved VSMS roles to view reservations.
$allowedRoles = ["Administrator", "Manager", "Salesperson"];

// Block users whose roles are not permitted.
if (!in_array($userRole, $allowedRoles, true)) {
    http_response_code(403);
    exit("Access denied. Your role cannot view reservations.");
}

// Define a helper function to safely display database values.
function escapeHtml($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Define the reservation statuses supported by the database.
$reservationStatuses = ["Active", "Cancelled", "Completed"];

// Read the search text entered by the user.
$search = trim($_GET["search"] ?? "");

// Read the selected reservation status filter.
$statusFilter = trim($_GET["status"] ?? "");

// Prepare an empty list of SQL conditions.
// Prepare an empty list of SQL conditions.
$conditions = [];

// Prepare the values that will be passed to the SQL query.
$parameters = [];

// Salespersons can see only reservations assigned to their accounts.
if ($userRole === "Salesperson") {
    $conditions[] = "r.salesperson_id = ?";
    $parameters[] = (int) $user["user_id"];
}

// Apply the search when the user enters search text.
if ($search !== "") {
    // Search reservation ID, customer, vehicle, VIN, and salesperson.
    $conditions[] = "(
        CAST(r.reservation_id AS CHAR) LIKE ?
        OR c.full_name LIKE ?
        OR c.phone LIKE ?
        OR v.make LIKE ?
        OR v.model LIKE ?
        OR v.vin LIKE ?
        OR u.full_name LIKE ?
    )";

    // Add wildcard characters to search for partial matches.
    $searchValue = "%" . $search . "%";

    // Add one search value for each SQL placeholder.
    for ($i = 0; $i < 7; $i++) {
        $parameters[] = $searchValue;
    }
}

// Apply the status filter only when it is a valid status.
if (in_array($statusFilter, $reservationStatuses, true)) {
    // Add the selected reservation status to the SQL conditions.
    $conditions[] = "r.reservation_status = ?";

    // Add the selected status to the query parameters.
    $parameters[] = $statusFilter;
}

// Build the WHERE clause only when filters are selected.
$whereSql = "";

if (!empty($conditions)) {
    $whereSql = "WHERE " . implode(" AND ", $conditions);
}

// Initialize the page data and error status.
$reservations = [];
$statusCounts = [
    "Active" => 0,
    "Cancelled" => 0,
    "Completed" => 0
];
$totalReservations = 0;
$matchingReservations = 0;
$databaseError = false;

// Retrieve reservation counts and matching records.
try {
    // Count reservations grouped by their current status.
    // Prepare the reservation count query.
$countSql = "
    SELECT reservation_status, COUNT(*) AS total
    FROM reservations
";

// Restrict salesperson counts to their own reservations.
if ($userRole === "Salesperson") {
    $countSql .= " WHERE salesperson_id = ?";
}

$countSql .= " GROUP BY reservation_status";

$countQuery = $pdo->prepare($countSql);

// Execute with the salesperson ID when required.
if ($userRole === "Salesperson") {
    $countQuery->execute([(int) $user["user_id"]]);
} else {
    $countQuery->execute();
}
    // Retrieve the grouped count records.
    $countRows = $countQuery->fetchAll();

    // Store each status count in the summary array.
    foreach ($countRows as $countRow) {
        $status = $countRow["reservation_status"];

        if (array_key_exists($status, $statusCounts)) {
            $statusCounts[$status] = (int) $countRow["total"];
        }
    }

    // Calculate the total number of reservations.
    $totalReservations = array_sum($statusCounts);

    // Retrieve reservations with their related customer, vehicle, and salesperson.
    $reservationSql = "
        SELECT
            r.reservation_id,
            r.reservation_date,
            r.expiration_date,
            r.reservation_status,
            c.full_name AS customer_name,
            c.phone AS customer_phone,
            v.make,
            v.model,
            v.`year`,
            v.vin,
            u.full_name AS salesperson_name
        FROM reservations AS r
        INNER JOIN customers AS c
            ON r.customer_id = c.customer_id
        INNER JOIN vehicles AS v
            ON r.vehicle_id = v.vehicle_id
        INNER JOIN users AS u
            ON r.salesperson_id = u.user_id
        $whereSql
        ORDER BY r.reservation_date DESC, r.reservation_id DESC
    ";

    // Prepare the reservation query.
    $reservationQuery = $pdo->prepare($reservationSql);

    // Execute the query using the search and filter values.
    $reservationQuery->execute($parameters);

    // Retrieve all matching reservation records.
    $reservations = $reservationQuery->fetchAll();

    // Count the records returned by the filtered query.
    $matchingReservations = count($reservations);

} catch (PDOException $exception) {
    // Record that a database error occurred.
    $databaseError = true;

    // Log technical details privately for troubleshooting.
    error_log("VSMS reservations list error: " . $exception->getMessage());
}

// Generate a CSRF token if the session does not already have one.
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Store the CSRF token for the logout form.
$csrfToken = $_SESSION["csrf_token"];

// Convert reservation statuses into CSS class names.
function reservationStatusClass(string $status): string
{
    return match ($status) {
        "Active" => "status-reserved",
        "Cancelled" => "status-unavailable",
        "Completed" => "status-available",
        default => "status-unavailable"
    };
}
?>
<!DOCTYPE html>
<!-- Declare this document as an HTML5 page. -->
<html lang="en">
<head>
    <!-- Set the character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on different screen sizes. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Reservations | VSMS</title>

    <!-- Load the existing dashboard design. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Reuse the existing inventory table and card styles. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">
</head>

<body>
    <!-- Create the main dashboard layout. -->
    <div class="dashboard-layout">

        <!-- Create the dark navigation sidebar. -->
        <aside class="sidebar">

            <!-- Display the VSMS brand. -->
            <div class="brand">
                <div class="brand-logo">V</div>
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>
            </div>

            <!-- Display the application navigation links. -->
            
<!-- Display the main sidebar navigation. -->
<nav class="sidebar-navigation">

    <!-- Display the navigation heading. -->
    <p class="navigation-heading">MAIN MENU</p>

    <!-- Link to the dashboard. -->
    <a href="dashboard.php" class="nav-link">
        <span class="nav-icon">▦</span>
        <span>Dashboard</span>
    </a>

    <!-- Link to vehicle inventory. -->
    <a href="vehicles.php" class="nav-link">
        <span class="nav-icon">🚘</span>
        <span>Vehicles</span>
    </a>

    <!-- Link to customer management. -->
    <a href="customers.php" class="nav-link">
        <span class="nav-icon">♙</span>
        <span>Customers</span>
    </a>

    <!-- Highlight the current Reservations page. -->
    <a href="reservations.php" class="nav-link active">
        <span class="nav-icon">▣</span>
        <span>Reservations</span>
    </a>

    <!-- Link to sales management. -->
    <a href="sales.php" class="nav-link">
        <span class="nav-icon">▤</span>
        <span>Sales</span>
    </a>

    <!-- Link to payments. -->
    <a href="payments.php" class="nav-link">
        <span class="nav-icon">$</span>
        <span>Payments</span>
    </a>
    <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
    <span class="nav-icon">◷</span>
    <span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
    <span class="nav-icon">▧</span>
    <span>Invoices</span>
</a>

    <!-- Show Employees only to Administrators and Managers. -->
    <?php if (hasRole('Administrator') || hasRole('Manager')): ?>
        <a href="employees.php" class="nav-link">
            <span class="nav-icon">♧</span>
            <span>Employees</span>
        </a>
    <?php endif; ?>
    <?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
    <span class="nav-icon">♙</span>
    <span>User Accounts</span>
</a>

<?php endif; ?>

    <!-- Show Reports only to Administrators and Managers. -->
    <?php if (hasRole('Administrator') || hasRole('Manager')): ?>
        <a href="reports.php" class="nav-link">
            <span class="nav-icon">▥</span>
            <span>Reports</span>
        </a>
    <?php endif; ?>

</nav>
<div class="sidebar-footer">
                <p>Vehicle Sales &amp; Management System</p>
                <span>Development version</span>
            </div>

        </aside>

        <!-- Create the main content area. -->
        <main class="main-content">

            <!-- Display the page header and logged-in user. -->
            <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Main Menu / Reservations</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    
    <div class="user-information">
                    
                    <a href="my_profile.php" class="profile-name-link">
                    <?= escapeHtml($user["full_name"]) ?>
</a>
                        <span><?= escapeHtml($userRole) ?></span>
                    </div>

    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>

           

            <!-- Place reservation content in the workspace. -->
            <section class="page-content">

                <!-- Introduce the reservation management page. -->
                <div class="page-heading">

                    <!-- Display the page title and description. -->
                    <div>
                        <h1>Reservation Management</h1>
                        <p>View, search, and monitor vehicle reservations.</p>
                    </div>

                    <!-- Allow users to register a new reservation. -->
                    <a href="add_reservation.php" class="primary-button">
                        + Add Reservation
                    </a>
                </div>

                <!-- Display a success message after creating a reservation. -->
                <?php if (isset($_GET["created"]) && $_GET["created"] === "1"): ?>
                    <div class="success-message">
                        Reservation created successfully.
                    </div>
                <?php endif; ?>

                <!-- Display a friendly error if the database query fails. -->
                <?php if ($databaseError): ?>

                    <div class="inventory-message error-message">
                        Unable to load reservations. Please try again later.
                    </div>

                <?php else: ?>

                    <!-- Display reservation summary cards. -->
                    <div class="inventory-summary">

                        <!-- Display the total reservation count. -->
                        <article class="summary-card">
                            <span class="summary-label">Total Reservations</span>
                            <strong><?= $totalReservations ?></strong>
                            <small>All reservation records</small>
                        </article>

                        <!-- Display the active reservation count. -->
                        <article class="summary-card">
                            <span class="summary-label">Active</span>
                            <strong><?= $statusCounts["Active"] ?></strong>
                            <small>Currently active reservations</small>
                        </article>

                        <!-- Display the completed reservation count. -->
                        <article class="summary-card">
                            <span class="summary-label">Completed</span>
                            <strong><?= $statusCounts["Completed"] ?></strong>
                            <small>Completed reservations</small>
                        </article>

                        <!-- Display the cancelled reservation count. -->
                        <article class="summary-card">
                            <span class="summary-label">Cancelled</span>
                            <strong><?= $statusCounts["Cancelled"] ?></strong>
                            <small>Cancelled reservations</small>
                        </article>

                    </div>

                    <!-- Create the reservation search and filter card. -->
                    <section class="inventory-card">

                        <!-- Introduce the search and filter controls. -->
                        <div class="card-heading">
                            <div>
                                <h2>Search and Filter Reservations</h2>
                                <p>Find reservations using customer, vehicle, or salesperson information.</p>
                            </div>
                        </div>

                        <!-- Submit search and filter values using GET. -->
                        <form action="reservations.php" method="GET" class="filter-form">

                            <!-- Search by reservation, customer, vehicle, or salesperson. -->
                            <div class="filter-field search-field">
                                <label for="search">Search reservations</label>
                                <input
                                    type="search"
                                    id="search"
                                    name="search"
                                    placeholder="ID, customer, vehicle, VIN, salesperson"
                                    value="<?= escapeHtml($search) ?>"
                                >
                            </div>

                            <!-- Filter reservations by status. -->
                            <div class="filter-field">
                                <label for="status">Reservation status</label>
                                <select id="status" name="status">

                                    <!-- Show all statuses when no filter is selected. -->
                                    <option value="">All statuses</option>

                                    <!-- Display the three supported reservation statuses. -->
                                    <?php foreach ($reservationStatuses as $reservationStatus): ?>
                                        <option
                                            value="<?= escapeHtml($reservationStatus) ?>"
                                            <?= $statusFilter === $reservationStatus ? "selected" : "" ?>
                                        >
                                            <?= escapeHtml($reservationStatus) ?>
                                        </option>
                                    <?php endforeach; ?>

                                </select>
                            </div>

                            <!-- Group the filter and reset buttons. -->
                            <div class="filter-actions">

                                <!-- Submit the selected filters. -->
                                <button type="submit" class="primary-button">
                                    Apply Filters
                                </button>

                                <!-- Clear the search and status filter. -->
                                <a href="reservations.php" class="secondary-button">
                                    Clear Filters
                                </a>
                            </div>

                        </form>
                    </section>

                    <!-- Display all matching reservation records. -->
                    <section class="inventory-card vehicle-list-card">

                        <!-- Display the matching reservation count. -->
                        <div class="card-heading vehicle-list-heading">
                            <div>
                                <h2>All Reservations</h2>
                                <p><?= $matchingReservations ?> matching reservation record(s)</p>
                            </div>
                        </div>

                        <!-- Display the table when reservation records exist. -->
                        <?php if (!empty($reservations)): ?>

                            <!-- Allow the table to scroll on smaller screens. -->
                            <div class="table-responsive">

                                <!-- Create the reservation table. -->
                                <table class="vehicle-table">

                                    <!-- Define the table headings. -->
                                    <thead>
                                        <tr>
                                            <th>Reservation ID</th>
                                            <th>Customer</th>
                                            <th>Vehicle</th>
                                            <th>Salesperson</th>
                                            <th>Reservation Date</th>
                                            <th>Expiry Date</th>
                                            <th>Status</th>
                                            <th>Actions</th>

                                        </tr>
                                    </thead>

                                    <!-- Display reservation records from MySQL. -->
                                    <tbody>

                                        <?php foreach ($reservations as $reservation): ?>

                                            <tr>

                                                <!-- Display the unique reservation ID. -->
                                                <td>
                                                    #<?= (int) $reservation["reservation_id"] ?>
                                                </td>

                                                <!-- Display the customer name and phone number. -->
                                                <td>
                                                    <strong>
                                                        <?= escapeHtml($reservation["customer_name"]) ?>
                                                    </strong>
                                                    <br>
                                                    <small>
                                                        <?= escapeHtml($reservation["customer_phone"]) ?>
                                                    </small>
                                                </td>

                                                <!-- Display the vehicle make, model, year, and VIN. -->
                                                <td>
                                                    <strong>
                                                        <?= escapeHtml(
                                                            $reservation["year"] . " " .
                                                            $reservation["make"] . " " .
                                                            $reservation["model"]
                                                        ) ?>
                                                    </strong>
                                                    <br>
                                                    <small>
                                                        VIN: <?= escapeHtml($reservation["vin"]) ?>
                                                    </small>
                                                </td>

                                                <!-- Display the assigned salesperson. -->
                                                <td>
                                                    <?= escapeHtml($reservation["salesperson_name"]) ?>
                                                </td>

                                                <!-- Display the reservation creation date. -->
                                                <td>
                                                    <?= escapeHtml(
                                                        date(
                                                            "d M Y, h:i A",
                                                            strtotime($reservation["reservation_date"])
                                                        )
                                                    ) ?>
                                                </td>

                                                <!-- Display the expiry date or indicate that none exists. -->
                                                <td>
                                                    <?php if (!empty($reservation["expiration_date"])): ?>
                                                        <?= escapeHtml(
                                                            date(
                                                                "d M Y, h:i A",
                                                                strtotime($reservation["expiration_date"])
                                                            )
                                                        ) ?>
                                                    <?php else: ?>
                                                        <span>Not specified</span>
                                                    <?php endif; ?>
                                                </td>

                                                <!-- Display the reservation status badge. -->
                                                <td>
                                                    <span class="status-badge <?= escapeHtml(
                                                        reservationStatusClass($reservation["reservation_status"])
                                                    ) ?>">
                                                        <?= escapeHtml($reservation["reservation_status"]) ?>
                                                    </span>
                                                </td>
                                                <!-- Provide an action to open the selected reservation. -->
                                                    <td>
                                                        <a
                                                            href="reservation_details.php?id=<?= (int) $reservation["reservation_id"] ?>"
                                                         class="secondary-button"
                                                        >
                                                            View Details
                                                        </a>
                                                    </td>

                                            </tr>

                                        <?php endforeach; ?>

                                    </tbody>
                                </table>
                            </div>

                        <?php else: ?>

                            <!-- Display a friendly message when no records match. -->
                            <div class="empty-inventory">

                                <div class="empty-inventory-icon">▣</div>

                                <h3>No reservations found</h3>

                                <p>
                                    <?php if ($totalReservations === 0): ?>
                                        No reservations have been registered yet.
                                        Use the Add Reservation button to create one.
                                    <?php else: ?>
                                        No reservations match your search or selected filter.
                                        Try changing your search criteria.
                                    <?php endif; ?>
                                </p>

                            </div>

                        <?php endif; ?>

                    </section>

                <?php endif; ?>

            </section>
        </main>
    </div>
</body>
</html>
