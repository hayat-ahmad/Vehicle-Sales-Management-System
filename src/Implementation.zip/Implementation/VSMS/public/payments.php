
<?php
// Load the authentication functions and database connection.
require_once __DIR__ . '/../includes/auth.php';

// Ensure that the user is logged in.
requireLogin();

// Get the current user's account information.
$user = currentUser();

// Allow only the three authorized roles to view payment history.
if (
    !hasRole('Administrator') &&
    !hasRole('Manager') &&
    !hasRole('Salesperson')
) {
    http_response_code(403);
    exit('Access denied. You are not authorized to view payments.');
}

// Identify whether the current user is a salesperson.
$isSalesperson = hasRole('Salesperson');

// Get the current user's ID.
$currentUserId = (int) $user['user_id'];

// Create a helper function to safely display values in HTML.
function paymentsEscape($value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

// Read the search text from the URL.
$search = trim($_GET['search'] ?? '');

// Read the selected payment status.
$statusFilter = trim($_GET['status'] ?? '');

// Define the payment statuses supported by the database.
$allowedStatuses = [
    'Completed',
    'Pending',
    'Failed',
    'Refunded'
];

// Reject invalid status filters.
if (!in_array($statusFilter, $allowedStatuses, true)) {
    $statusFilter = '';
}

// Prepare the SQL conditions and parameters.
$whereConditions = [];
$queryParameters = [];

// Restrict salespersons to payments related to their own sales.
if ($isSalesperson) {
    $whereConditions[] = 's.salesperson_id = :current_user_id';
    $queryParameters[':current_user_id'] = $currentUserId;
}

// Apply the selected payment status filter.
if ($statusFilter !== '') {
    $whereConditions[] = 'p.payment_status = :payment_status';
    $queryParameters[':payment_status'] = $statusFilter;
}

// Search by payment ID, sale ID, customer, vehicle, method, or reference.
if ($search !== '') {

    // Add all supported search conditions.
    $whereConditions[] = "(
        CAST(p.payment_id AS CHAR) LIKE :payment_id_search
        OR CAST(p.sale_id AS CHAR) LIKE :sale_id_search
        OR c.full_name LIKE :customer_search
        OR c.phone LIKE :phone_search
        OR v.make LIKE :make_search
        OR v.model LIKE :model_search
        OR v.vin LIKE :vin_search
        OR p.payment_method LIKE :method_search
        OR p.transaction_reference LIKE :reference_search
        OR payment_user.full_name LIKE :user_search
    )";

    // Prepare the search value.
    $searchValue = '%' . $search . '%';

    // Use separate named parameters for every search condition.
    $queryParameters[':payment_id_search'] = $searchValue;
    $queryParameters[':sale_id_search'] = $searchValue;
    $queryParameters[':customer_search'] = $searchValue;
    $queryParameters[':phone_search'] = $searchValue;
    $queryParameters[':make_search'] = $searchValue;
    $queryParameters[':model_search'] = $searchValue;
    $queryParameters[':vin_search'] = $searchValue;
    $queryParameters[':method_search'] = $searchValue;
    $queryParameters[':reference_search'] = $searchValue;
    $queryParameters[':user_search'] = $searchValue;
}

// Combine the SQL conditions.
$whereSql = '';

if (!empty($whereConditions)) {
    $whereSql = 'WHERE ' . implode(' AND ', $whereConditions);
}

// Prepare the page data.
$payments = [];
$totalPayments = 0;
$completedPayments = 0;
$pendingPayments = 0;
$failedPayments = 0;
$refundedPayments = 0;
$totalReceived = 0.00;
$pageError = '';

// Load payment summary and payment records.
try {

    // Build the summary query.
    $summarySql = "
        SELECT
            COUNT(*) AS total_payments,

            SUM(
                CASE
                    WHEN p.payment_status = 'Completed' THEN 1
                    ELSE 0
                END
            ) AS completed_payments,

            SUM(
                CASE
                    WHEN p.payment_status = 'Pending' THEN 1
                    ELSE 0
                END
            ) AS pending_payments,

            SUM(
                CASE
                    WHEN p.payment_status = 'Failed' THEN 1
                    ELSE 0
                END
            ) AS failed_payments,

            SUM(
                CASE
                    WHEN p.payment_status = 'Refunded' THEN 1
                    ELSE 0
                END
            ) AS refunded_payments,

            COALESCE(
                SUM(
                    CASE
                        WHEN p.payment_status = 'Completed'
                        THEN p.payment_amount
                        ELSE 0
                    END
                ),
                0
            ) AS total_received

        FROM payments AS p

        INNER JOIN sales AS s
            ON p.sale_id = s.sale_id

        " . ($isSalesperson
            ? 'WHERE s.salesperson_id = :summary_user_id'
            : '');

    // Prepare the summary query.
    $summaryStatement = $pdo->prepare($summarySql);

    // Restrict the summary to the salesperson when necessary.
    if ($isSalesperson) {
        $summaryStatement->bindValue(
            ':summary_user_id',
            $currentUserId,
            PDO::PARAM_INT
        );
    }

    // Execute the summary query.
    $summaryStatement->execute();

    // Retrieve the summary information.
    $summary = $summaryStatement->fetch(PDO::FETCH_ASSOC);

    // Store the summary values.
    if ($summary) {
        $totalPayments = (int) $summary['total_payments'];
        $completedPayments = (int) $summary['completed_payments'];
        $pendingPayments = (int) $summary['pending_payments'];
        $failedPayments = (int) $summary['failed_payments'];
        $refundedPayments = (int) $summary['refunded_payments'];
        $totalReceived = (float) $summary['total_received'];
    }

    // Build the query to retrieve individual payment records.
    $paymentsSql = "
        SELECT
            p.payment_id,
            p.sale_id,
            p.payment_amount,
            p.payment_method,
            p.transaction_reference,
            p.payment_date,
            p.payment_status,
            p.notes,

            c.customer_id,
            c.full_name AS customer_name,
            c.phone AS customer_phone,

            v.vehicle_id,
            v.make,
            v.model,
            v.year,
            v.vin,

            salesperson.full_name AS salesperson_name,

            payment_user.full_name AS recorded_by

        FROM payments AS p

        INNER JOIN sales AS s
            ON p.sale_id = s.sale_id

        INNER JOIN customers AS c
            ON s.customer_id = c.customer_id

        INNER JOIN vehicles AS v
            ON s.vehicle_id = v.vehicle_id

        INNER JOIN users AS salesperson
            ON s.salesperson_id = salesperson.user_id

        INNER JOIN users AS payment_user
            ON p.created_by = payment_user.user_id

        $whereSql

        ORDER BY p.payment_date DESC, p.payment_id DESC
    ";

    // Prepare the payment records query.
    $paymentsStatement = $pdo->prepare($paymentsSql);

    // Bind all search and filter parameters.
    foreach ($queryParameters as $parameter => $value) {

        // Bind the current user's ID as an integer.
        if ($parameter === ':current_user_id') {
            $paymentsStatement->bindValue(
                $parameter,
                $value,
                PDO::PARAM_INT
            );

        } else {

            // Bind search and status values as strings.
            $paymentsStatement->bindValue(
                $parameter,
                $value,
                PDO::PARAM_STR
            );
        }
    }

    // Execute the payment records query.
    $paymentsStatement->execute();

    // Retrieve all matching payment records.
    $payments = $paymentsStatement->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {

    // Log technical details without exposing them to the user.
    error_log('Payment history error: ' . $exception->getMessage());

    // Display a friendly error message.
    $pageError = 'Unable to load payment records. Please try again.';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Define the character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on mobile devices. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Payment History | VSMS</title>

    <!-- Reuse the existing application stylesheets. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <!-- Add styles specific to payment history. -->
    <style>
        .payments-page {
            padding: 24px;
            color: #263445;
        }

        .payments-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 16px;
            margin-bottom: 24px;
        }

        .payments-header h1 {
            margin: 0 0 6px;
            font-size: 25px;
        }

        .payments-header p {
            margin: 0;
            color: #748091;
        }

        .payments-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .payments-button {
            display: inline-block;
            padding: 10px 16px;
            border: none;
            border-radius: 7px;
            background: #f47755;
            color: #ffffff;
            text-decoration: none;
            font-weight: 600;
            cursor: pointer;
        }

        .payments-button:hover {
            background: #df6546;
            color: #ffffff;
        }

        .payments-button-secondary {
            background: #263b56;
        }

        .payments-button-secondary:hover {
            background: #1b2d43;
        }

        .payments-summary {
            display: grid;
            grid-template-columns: repeat(5, minmax(130px, 1fr));
            gap: 15px;
            margin-bottom: 24px;
        }

        .payments-summary-card {
            background: #ffffff;
            border: 1px solid #e7ebf0;
            border-radius: 10px;
            padding: 18px;
            box-shadow: 0 2px 8px rgba(25, 42, 62, 0.04);
        }

        .payments-summary-card span {
            display: block;
            margin-bottom: 8px;
            color: #748091;
            font-size: 13px;
        }

        .payments-summary-card strong {
            font-size: 22px;
            color: #263b56;
        }

        .payments-filters {
            display: flex;
            align-items: end;
            gap: 12px;
            flex-wrap: wrap;
            background: #ffffff;
            padding: 18px;
            border: 1px solid #e7ebf0;
            border-radius: 10px;
            margin-bottom: 18px;
        }

        .payments-filter-field {
            display: flex;
            flex-direction: column;
            gap: 7px;
            flex: 1;
            min-width: 180px;
        }

        .payments-filter-field label {
            font-size: 13px;
            font-weight: 600;
        }

        .payments-filter-field input,
        .payments-filter-field select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #dce2e9;
            border-radius: 6px;
            background: #ffffff;
        }

        .payments-table-container {
            overflow-x: auto;
            background: #ffffff;
            border: 1px solid #e7ebf0;
            border-radius: 10px;
        }

        .payments-table {
            width: 100%;
            min-width: 1150px;
            border-collapse: collapse;
        }

        .payments-table th,
        .payments-table td {
            padding: 13px 14px;
            text-align: left;
            border-bottom: 1px solid #edf0f4;
            vertical-align: middle;
        }

        .payments-table th {
            background: #f7f8fa;
            color: #596779;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.35px;
        }

        .payments-table td {
            font-size: 13px;
        }

        .payments-table tbody tr:hover {
            background: #fafbfd;
        }

        .payment-status {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
        }

        .payment-status-completed {
            background: #dff5e8;
            color: #197344;
        }

        .payment-status-pending {
            background: #fff1d6;
            color: #986300;
        }

        .payment-status-failed {
            background: #fde5e5;
            color: #b33b3b;
        }

        .payment-status-refunded {
            background: #e8e8f7;
            color: #56569a;
        }

        .payments-results-info {
            margin: 0 0 12px;
            color: #748091;
            font-size: 13px;
        }

        .payments-empty {
            padding: 28px;
            text-align: center;
            color: #748091;
        }

        .payments-error {
            padding: 14px 16px;
            margin-bottom: 18px;
            border-radius: 7px;
            background: #fff0f0;
            color: #a52c2c;
        }

        @media (max-width: 1100px) {
            .payments-summary {
                grid-template-columns: repeat(3, minmax(130px, 1fr));
            }
        }

        @media (max-width: 650px) {
            .payments-page {
                padding: 14px;
            }

            .payments-summary {
                grid-template-columns: repeat(2, minmax(120px, 1fr));
            }

            .payments-summary-card strong {
                font-size: 19px;
            }
        }
    </style>

</head>

<body>

<!-- Create the main dashboard layout. -->
<div class="dashboard-layout">

    <!-- Create the left navigation sidebar. -->
    <aside class="sidebar">

        <!-- Display the VSMS brand. -->
        <div class="brand">
                <div class="brand-logo">V</div>
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>
            </div>

        <!-- Display the main navigation links. -->
        <nav class="sidebar-navigation">

            <p class="navigation-heading">MAIN MENU</p>

            <!-- Dashboard navigation. -->
            <a href="dashboard.php" class="nav-link">
                <span class="nav-icon">▦</span>
                <span>Dashboard</span>
            </a>

            <!-- Vehicle navigation. -->
            <a href="vehicles.php" class="nav-link">
                <span class="nav-icon">🚘</span>
                <span>Vehicles</span>
            </a>

            <!-- Customer navigation. -->
            <a href="customers.php" class="nav-link">
                <span class="nav-icon">♙</span>
                <span>Customers</span>
            </a>

            <!-- Reservation navigation. -->
            <a href="reservations.php" class="nav-link">
                <span class="nav-icon">▣</span>
                <span>Reservations</span>
            </a>

            <!-- Sales navigation. -->
            <a href="sales.php" class="nav-link">
                <span class="nav-icon">▤</span>
                <span>Sales</span>
            </a>

            <!-- Highlight the current Payments page. -->
            <a href="payments.php" class="nav-link active">
                <span class="nav-icon">$</span>
                <span>Payments</span>
            </a>
            <!-- Outstanding Balances navigation. -->
<a href="outstanding_balances.php" class="nav-link">
    <span class="nav-icon">◷</span>
    <span>Outstanding Balances</span>
</a>

<!-- Invoice navigation. -->
<a href="invoices.php" class="nav-link">
    <span class="nav-icon">▧</span>
    <span>Invoices</span>
</a>

            <!-- Employee navigation. -->
            <a href="employees.php" class="nav-link">
                <span class="nav-icon">♧</span>
                <span>Employees</span>
            </a>
            <?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
    <span class="nav-icon">♙</span>
    <span>User Accounts</span>
</a>

<?php endif; ?>
            <!-- Reports navigation. -->
            <a href="reports.php" class="nav-link">
                <span class="nav-icon">▥</span>
                <span>Reports</span>
            </a>

        </nav>

        <!-- Display the sidebar footer. -->
        <div class="sidebar-footer">
            <p>Vehicle Sales &amp; Management System</p>
            <span>Development version</span>
        </div>

    </aside>

    <!-- Create the main workspace beside the sidebar. -->
    <main class="main-content">

        <!-- Keep the existing payment page and all its content. -->
        <div class="payments-page">


    <!-- Page heading and navigation actions. -->
    <div class="payments-header">

        <div>
            <h1>Payment History</h1>
            <p>View and search payments recorded against vehicle sales.</p>
        </div>

        <div class="payments-actions">

            <!-- Open the page for recording a new payment. -->
            <a href="add_payment.php" class="payments-button">
                + Record Payment
            </a>

            <!-- Return to the dashboard. -->
            <a
                href="dashboard.php"
                class="payments-button payments-button-secondary"
            >
                Dashboard
            </a>

        </div>

    </div>

    <!-- Display payment summary information. -->
    <div class="payments-summary">

        <div class="payments-summary-card">
            <span>Total Payments</span>
            <strong><?= number_format($totalPayments) ?></strong>
        </div>

        <div class="payments-summary-card">
            <span>Completed</span>
            <strong><?= number_format($completedPayments) ?></strong>
        </div>

        <div class="payments-summary-card">
            <span>Pending</span>
            <strong><?= number_format($pendingPayments) ?></strong>
        </div>

        <div class="payments-summary-card">
            <span>Failed / Refunded</span>
            <strong>
                <?= number_format($failedPayments + $refundedPayments) ?>
            </strong>
        </div>

        <div class="payments-summary-card">
            <span>Total Received</span>
            <strong>$<?= number_format($totalReceived, 2) ?></strong>
        </div>

    </div>

    <!-- Display an error message if the database query fails. -->
    <?php if ($pageError !== ''): ?>

        <div class="payments-error">
            <?= paymentsEscape($pageError) ?>
        </div>

    <?php endif; ?>

    <!-- Search and filter form. -->
    <form method="GET" action="payments.php" class="payments-filters">

        <div class="payments-filter-field">

            <label for="search">Search Payments</label>

            <input
                type="text"
                id="search"
                name="search"
                value="<?= paymentsEscape($search) ?>"
                placeholder="Payment ID, sale ID, customer, vehicle, reference..."
            >

        </div>

        <div class="payments-filter-field">

            <label for="status">Payment Status</label>

            <select id="status" name="status">

                <option value="">All Statuses</option>

                <option
                    value="Completed"
                    <?= $statusFilter === 'Completed' ? 'selected' : '' ?>
                >
                    Completed
                </option>

                <option
                    value="Pending"
                    <?= $statusFilter === 'Pending' ? 'selected' : '' ?>
                >
                    Pending
                </option>

                <option
                    value="Failed"
                    <?= $statusFilter === 'Failed' ? 'selected' : '' ?>
                >
                    Failed
                </option>

                <option
                    value="Refunded"
                    <?= $statusFilter === 'Refunded' ? 'selected' : '' ?>
                >
                    Refunded
                </option>

            </select>

        </div>

        <!-- Submit the search and filter values. -->
        <button type="submit" class="payments-button">
            Search
        </button>

        <!-- Clear the current search and filters. -->
        <a
            href="payments.php"
            class="payments-button payments-button-secondary"
        >
            Reset
        </a>

    </form>

    <!-- Display the number of matching payment records. -->
    <p class="payments-results-info">
        Showing <?= number_format(count($payments)) ?> matching payment record(s).
    </p>

    <!-- Display the payment records. -->
    <div class="payments-table-container">

        <table class="payments-table">

            <thead>
                <tr>
                    <th>Payment ID</th>
                    <th>Sale ID</th>
                    <th>Payment Date</th>
                    <th>Customer</th>
                    <th>Vehicle</th>
                    <th>Amount</th>
                    <th>Method</th>
                    <th>Reference</th>
                    <th>Salesperson</th>
                    <th>Recorded By</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>

                <!-- Display each payment as a table row. -->
                <?php if (!empty($payments)): ?>

                    <?php foreach ($payments as $payment): ?>

                        <?php
                        // Select the correct CSS class for the payment status.
                        $statusClass = match ($payment['payment_status']) {
                            'Completed' => 'payment-status-completed',
                            'Pending' => 'payment-status-pending',
                            'Failed' => 'payment-status-failed',
                            'Refunded' => 'payment-status-refunded',
                            default => ''
                        };
                        ?>

                        <tr>

                            <!-- Display the unique payment ID. -->
                            <td>
                                #<?= (int) $payment['payment_id'] ?>
                            </td>

                            <!-- Display the related sale ID. -->
                            <td>
                                #<?= (int) $payment['sale_id'] ?>
                            </td>

                            <!-- Display the payment date and time. -->
                            <td>
                                <?= paymentsEscape(
                                    date(
                                        'd M Y, h:i A',
                                        strtotime($payment['payment_date'])
                                    )
                                ) ?>
                            </td>

                            <!-- Display the customer name and phone. -->
                            <td>
                                <strong>
                                    <?= paymentsEscape($payment['customer_name']) ?>
                                </strong>
                                <br>
                                <small>
                                    <?= paymentsEscape($payment['customer_phone']) ?>
                                </small>
                            </td>

                            <!-- Display the vehicle information. -->
                            <td>
                                <strong>
                                    <?= paymentsEscape(
                                        $payment['year'] . ' ' .
                                        $payment['make'] . ' ' .
                                        $payment['model']
                                    ) ?>
                                </strong>
                                <br>
                                <small>
                                    VIN: <?= paymentsEscape($payment['vin']) ?>
                                </small>
                            </td>

                            <!-- Display the payment amount. -->
                            <td>
                                <strong>
                                    $<?= number_format(
                                        (float) $payment['payment_amount'],
                                        2
                                    ) ?>
                                </strong>
                            </td>

                            <!-- Display the payment method. -->
                            <td>
                                <?= paymentsEscape($payment['payment_method']) ?>
                            </td>

                            <!-- Display the transaction reference if available. -->
                            <td>
                                <?= $payment['transaction_reference'] !== null
                                    && $payment['transaction_reference'] !== ''
                                    ? paymentsEscape($payment['transaction_reference'])
                                    : '—'
                                ?>
                            </td>

                            <!-- Display the salesperson responsible for the sale. -->
                            <td>
                                <?= paymentsEscape($payment['salesperson_name']) ?>
                            </td>

                            <!-- Display the user who recorded the payment. -->
                            <td>
                                <?= paymentsEscape($payment['recorded_by']) ?>
                            </td>

                            <!-- Display the payment status. -->
                            <td>
                                <span class="payment-status <?= $statusClass ?>">
                                    <?= paymentsEscape($payment['payment_status']) ?>
                                </span>
                            </td>
                            <!-- Provide a link to the individual payment details page. -->
<td>
    <a
        href="payment_details.php?id=<?= (int) $payment['payment_id'] ?>"
        class="payments-button payments-button-secondary"
        style="padding: 7px 11px; font-size: 12px;"
    >
        View Details
    </a>
</td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <!-- Display a message when no payment records match. -->
                    <tr>
                        <td colspan="12" class="payments-empty">
                            No payment records found.
                            Try changing your search or status filter.
                        </td>
                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

  </div>
  <!-- Close the payment history page. -->

</main>
<!-- Close the main workspace. -->

</div>
<!-- Close the dashboard layout. -->

</body>
</html>
