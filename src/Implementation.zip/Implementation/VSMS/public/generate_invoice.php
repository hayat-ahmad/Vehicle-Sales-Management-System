
<?php
// Load authentication, session, and database connection.
require_once __DIR__ . "/../includes/auth.php";

// Make sure the user is logged in.
requireLogin();

// Get the currently logged-in user's information.
$user = currentUser();

// Allow only the three system roles to access invoices.
$allowedRoles = ["Administrator", "Manager", "Salesperson"];

// Stop access if the user's role is not allowed.
if (!in_array($user["role_name"], $allowedRoles, true)) {
    http_response_code(403);
    exit("Access denied.");
}

// Create a CSRF token if one does not already exist.
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Store the CSRF token for use in the form.
$csrfToken = $_SESSION["csrf_token"];

// Prepare a reusable HTML escaping function.
function e($value) {
    return htmlspecialchars((string)($value ?? ""), ENT_QUOTES, "UTF-8");
}

// Prepare a reusable currency formatting function.
function money($amount) {
    return number_format((float)$amount, 2);
}

// Store messages and invoice information.
$error = "";
$success = "";
$invoice = null;
$sale = null;

// Read the invoice ID from the URL, if provided.
$invoiceId = filter_input(INPUT_GET, "invoice_id", FILTER_VALIDATE_INT);

// Read the sale ID from the URL, if provided.
$saleId = filter_input(INPUT_GET, "sale_id", FILTER_VALIDATE_INT);

// Handle invoice generation when the form is submitted.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Check the submitted CSRF token.
    $submittedToken = $_POST["csrf_token"] ?? "";

    // Reject requests with an invalid CSRF token.
    if (!hash_equals($csrfToken, $submittedToken)) {
        http_response_code(403);
        exit("Invalid security token. Please refresh the page.");
    }

    // Read and validate the submitted sale ID.
    $saleId = filter_input(INPUT_POST, "sale_id", FILTER_VALIDATE_INT);

    // Make sure the sale ID is valid.
    if (!$saleId || $saleId <= 0) {
        $error = "Invalid sale ID.";
    } else {
        try {
            // Start a transaction to protect invoice generation.
            $pdo->beginTransaction();

            // Lock the sale record while generating its invoice.
            $saleQuery = "
                SELECT
                    s.sale_id,
                    s.customer_id,
                    s.vehicle_id,
                    s.salesperson_id,
                    s.sale_date,
                    s.vehicle_price,
                    s.discount_amount,
                    s.additional_charges,
                    s.final_amount,
                    s.sale_status,
                    c.full_name AS customer_name,
                    c.phone AS customer_phone,
                    c.email AS customer_email,
                    c.address AS customer_address,
                    v.make,
                    v.model,
                    v.year,
                    v.VIN,
                    v.color,
                    v.category,
                    u.full_name AS salesperson_name
                FROM sales s
                INNER JOIN customers c
                    ON s.customer_id = c.customer_id
                INNER JOIN vehicles v
                    ON s.vehicle_id = v.vehicle_id
                INNER JOIN users u
                    ON s.salesperson_id = u.user_id
                WHERE s.sale_id = :sale_id
                FOR UPDATE
            ";

            // Prepare and execute the sale query.
            $saleStatement = $pdo->prepare($saleQuery);
            $saleStatement->execute([
                ":sale_id" => $saleId
            ]);

            // Retrieve the sale information.
            $sale = $saleStatement->fetch(PDO::FETCH_ASSOC);

            // Stop if the sale does not exist.
            if (!$sale) {
                throw new RuntimeException("The selected sale was not found.");
            }

            // Salespersons can generate invoices only for their own sales.
            if (
                $user["role_name"] === "Salesperson" &&
                (int)$sale["salesperson_id"] !== (int)$user["user_id"]
            ) {
                throw new RuntimeException("You are not authorized to access this sale.");
            }

            // Only completed sales can have invoices.
            if ($sale["sale_status"] !== "Completed") {
                throw new RuntimeException("An invoice can only be generated for a completed sale.");
            }

            // Check whether an invoice already exists for this sale.
            $existingQuery = "
                SELECT invoice_id
                FROM invoices
                WHERE sale_id = :sale_id
                LIMIT 1
                FOR UPDATE
            ";

            // Execute the existing invoice query.
            $existingStatement = $pdo->prepare($existingQuery);
            $existingStatement->execute([
                ":sale_id" => $saleId
            ]);

            // Retrieve an existing invoice, if available.
            $existingInvoice = $existingStatement->fetch(PDO::FETCH_ASSOC);

            // If an invoice already exists, do not create another one.
            if ($existingInvoice) {

                // Commit the transaction without making changes.
                $pdo->commit();

                // Redirect to the existing invoice.
                header(
                    "Location: generate_invoice.php?invoice_id=" .
                    (int)$existingInvoice["invoice_id"]
                );
                exit;
            }

            // Calculate the total amount of completed payments.
            $paymentQuery = "
                SELECT
                    COUNT(*) AS payment_count,
                    COALESCE(SUM(payment_amount), 0) AS total_paid
                FROM payments
                WHERE sale_id = :sale_id
                AND status = 'Completed'
            ";

            // Execute the payment summary query.
            $paymentStatement = $pdo->prepare($paymentQuery);
            $paymentStatement->execute([
                ":sale_id" => $saleId
            ]);

            // Retrieve the payment summary.
            $paymentData = $paymentStatement->fetch(PDO::FETCH_ASSOC);

            // Calculate the amount received.
            $totalPaid = (float)$paymentData["total_paid"];

            // Calculate the remaining balance.
            $outstandingBalance = max(
                0,
                (float)$sale["final_amount"] - $totalPaid
            );

            // Build a payment summary to save with the invoice.
            $paymentSummary =
                "Completed payments: " .
                (int)$paymentData["payment_count"] .
                " | Amount received: " .
                money($totalPaid) .
                " | Outstanding balance: " .
                money($outstandingBalance);

            // Generate a unique invoice number using the date and sale ID.
            $invoiceNumber =
                "INV-" .
                date("Ymd") .
                "-" .
                str_pad((string)$saleId, 6, "0", STR_PAD_LEFT);

            // Insert the new invoice into the database.
            $insertQuery = "
                INSERT INTO invoices (
                    sale_id,
                    invoice_number,
                    issue_date,
                    total,
                    payment_summary
                ) VALUES (
                    :sale_id,
                    :invoice_number,
                    NOW(),
                    :total,
                    :payment_summary
                )
            ";

            // Prepare the invoice insertion statement.
            $insertStatement = $pdo->prepare($insertQuery);

            // Execute the invoice insertion.
            $insertStatement->execute([
                ":sale_id" => $saleId,
                ":invoice_number" => $invoiceNumber,
                ":total" => $sale["final_amount"],
                ":payment_summary" => $paymentSummary
            ]);

            // Get the ID of the newly created invoice.
            $newInvoiceId = (int)$pdo->lastInsertId();

            // Commit the transaction after successful generation.
            $pdo->commit();

            // Redirect to the generated invoice.
            header(
                "Location: generate_invoice.php?invoice_id=" .
                $newInvoiceId
            );
            exit;

             } catch (PDOException $exception) {

        // Roll back the transaction if a database error occurs.
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        // Log technical details privately for troubleshooting.
        error_log(
            "VSMS invoice generation database error: " .
            $exception->getMessage()
        );

        // Do not expose database details to the user.
        $error = "Unable to generate the invoice due to a database error. Please try again.";

    } catch (RuntimeException $exception) {

        // Roll back if a business-rule validation fails.
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        // Display the expected business-rule message.
        $error = $exception->getMessage();

    } catch (Throwable $exception) {

        // Roll back after any unexpected error.
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        // Log unexpected technical details privately.
        error_log(
            "VSMS unexpected invoice generation error: " .
            $exception->getMessage()
        );

        // Display a safe generic message.
        $error = "An unexpected error occurred. Please try again.";
    }
        
    }
}

// Load an invoice when an invoice ID is provided in the URL.
if ($_SERVER["REQUEST_METHOD"] !== "POST" && $invoiceId) {

    // Retrieve the invoice and its related sale information.
    $invoiceQuery = "
        SELECT
            i.invoice_id,
            i.sale_id,
            i.invoice_number,
            i.issue_date,
            i.total,
            i.payment_summary,
            s.sale_date,
            s.vehicle_price,
            s.discount_amount,
            s.additional_charges,
            s.final_amount,
            s.salesperson_id,
            c.full_name AS customer_name,
            c.phone AS customer_phone,
            c.email AS customer_email,
            c.address AS customer_address,
            v.make,
            v.model,
            v.year,
            v.VIN,
            v.color,
            v.category,
            u.full_name AS salesperson_name
        FROM invoices i
        INNER JOIN sales s
            ON i.sale_id = s.sale_id
        INNER JOIN customers c
            ON s.customer_id = c.customer_id
        INNER JOIN vehicles v
            ON s.vehicle_id = v.vehicle_id
        INNER JOIN users u
            ON s.salesperson_id = u.user_id
        WHERE i.invoice_id = :invoice_id
        LIMIT 1
    ";

    // Prepare and execute the invoice query.
    $invoiceStatement = $pdo->prepare($invoiceQuery);
    $invoiceStatement->execute([
        ":invoice_id" => $invoiceId
    ]);

    // Retrieve the invoice.
    $invoice = $invoiceStatement->fetch(PDO::FETCH_ASSOC);

    // Check whether the invoice exists.
    if (!$invoice) {
        $error = "Invoice not found.";
    } else {

        // Restrict salespersons to their own invoices.
        if (
            $user["role_name"] === "Salesperson" &&
            (int)$invoice["salesperson_id"] !== (int)$user["user_id"]
        ) {
            http_response_code(403);
            exit("You are not authorized to view this invoice.");
        }
    }
}

// Load a sale when a sale ID is provided without an invoice ID.
if (
    !$invoice &&
    !$error &&
    $_SERVER["REQUEST_METHOD"] !== "POST" &&
    $saleId
) {

    // Retrieve the sale and its related information.
    $saleQuery = "
        SELECT
            s.sale_id,
            s.sale_status,
            s.salesperson_id,
            s.final_amount,
            c.full_name AS customer_name,
            v.make,
            v.model,
            v.year,
            v.VIN,
            u.full_name AS salesperson_name
        FROM sales s
        INNER JOIN customers c
            ON s.customer_id = c.customer_id
        INNER JOIN vehicles v
            ON s.vehicle_id = v.vehicle_id
        INNER JOIN users u
            ON s.salesperson_id = u.user_id
        WHERE s.sale_id = :sale_id
        LIMIT 1
    ";

    // Prepare and execute the sale query.
    $saleStatement = $pdo->prepare($saleQuery);
    $saleStatement->execute([
        ":sale_id" => $saleId
    ]);

    // Retrieve the sale.
    $sale = $saleStatement->fetch(PDO::FETCH_ASSOC);

    // Check whether the sale exists.
    if (!$sale) {
        $error = "Sale not found.";
    } elseif (
        $user["role_name"] === "Salesperson" &&
        (int)$sale["salesperson_id"] !== (int)$user["user_id"]
    ) {
        // Restrict salespersons to their own sales.
        http_response_code(403);
        exit("You are not authorized to access this sale.");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Set the page character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on different devices. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Invoice Management | VSMS</title>

    <!-- Reuse the existing dashboard styling. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Reuse the existing vehicle page styling. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <style>
        /* Main invoice workspace. */
        .invoice-wrapper {
            max-width: 950px;
            margin: 25px auto;
        }

        /* White invoice document. */
        .invoice-paper {
            background: #ffffff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.08);
        }

        /* Invoice heading area. */
        .invoice-header {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            border-bottom: 2px solid #e5e7eb;
            padding-bottom: 20px;
            margin-bottom: 25px;
        }

        /* Main invoice title. */
        .invoice-header h1 {
            color: #172554;
            margin: 0 0 8px;
        }

        /* Invoice number and date. */
        .invoice-meta {
            text-align: right;
            color: #475569;
        }

        /* Two-column information layout. */
        .invoice-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
            margin-bottom: 25px;
        }

        /* Information section headings. */
        .invoice-section h3 {
            color: #172554;
            margin-bottom: 10px;
        }

        /* Information text. */
        .invoice-section p {
            margin: 5px 0;
            color: #475569;
        }

        /* Invoice financial table. */
        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        /* Table cells. */
        .invoice-table th,
        .invoice-table td {
            padding: 12px;
            border-bottom: 1px solid #e5e7eb;
            text-align: left;
        }

        /* Table headings. */
        .invoice-table th {
            background: #f1f5f9;
            color: #172554;
        }

        /* Right-align financial values. */
        .invoice-table .amount {
            text-align: right;
        }

        /* Final total row. */
        .invoice-total {
            font-weight: bold;
            font-size: 18px;
            color: #172554;
        }

        /* Payment summary area. */
        .payment-summary {
            background: #f8fafc;
            padding: 18px;
            margin-top: 25px;
            border-radius: 8px;
        }

        /* Invoice footer. */
        .invoice-footer {
            text-align: center;
            border-top: 1px solid #e5e7eb;
            margin-top: 30px;
            padding-top: 20px;
            color: #64748b;
        }

        /* Action buttons. */
        .invoice-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        /* Print-specific page styling. */
        @media print {
            body {
                background: #ffffff !important;
            }

            .sidebar,
            .sidebar-menu,
            .topbar,
            .invoice-actions,
            .no-print {
                display: none !important;
            }

            .invoice-wrapper {
                max-width: 100%;
                margin: 0;
            }

            .invoice-paper {
                box-shadow: none;
                padding: 10px;
            }
        }

        /* Responsive layout for smaller screens. */
        @media (max-width: 600px) {
            .invoice-paper {
                padding: 20px;
            }

            .invoice-header {
                flex-direction: column;
            }

            .invoice-meta {
                text-align: left;
            }

            .invoice-info {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

<?php if ($invoice): ?>

    <!-- Display the generated invoice. -->
    <div class="invoice-wrapper">

        <!-- Invoice action buttons are hidden when printing. -->
        <div class="invoice-actions no-print">
            <button type="button" onclick="window.print()" class="primary-button">
                Print Invoice
            </button>

            <a href="invoices.php" class="primary-button">
                Back to Invoice
            </a>
        </div>

        <!-- Printable invoice document. -->
        <div class="invoice-paper">

            <!-- Invoice heading and number. -->
            <div class="invoice-header">
                <div>
                    <h1>VEHICLE SALES INVOICE</h1>
                    <p>Vehicle Sales Management System</p>
                </div>

                <div class="invoice-meta">
                    <p><strong>Invoice Number:</strong></p>
                    <p><?= e($invoice["invoice_number"]) ?></p>

                    <p><strong>Issue Date:</strong></p>
                    <p><?= e(date("d M Y", strtotime($invoice["issue_date"]))) ?></p>
                </div>
            </div>

            <!-- Customer and sale information. -->
            <div class="invoice-info">

                <div class="invoice-section">
                    <h3>Bill To</h3>
                    <p><strong><?= e($invoice["customer_name"]) ?></strong></p>
                    <p>Phone: <?= e($invoice["customer_phone"]) ?></p>
                    <p>Email: <?= e($invoice["customer_email"] ?: "N/A") ?></p>
                    <p>Address: <?= nl2br(e($invoice["customer_address"] ?: "N/A")) ?></p>
                </div>

                <div class="invoice-section">
                    <h3>Sale Information</h3>
                    <p>Sale ID: #<?= e($invoice["sale_id"]) ?></p>
                    <p>Sale Date: <?= e(date("d M Y", strtotime($invoice["sale_date"]))) ?></p>
                    <p>Salesperson: <?= e($invoice["salesperson_name"]) ?></p>
                </div>

            </div>

            <!-- Vehicle information. -->
            <div class="invoice-section">
                <h3>Vehicle Details</h3>

                <p>
                    <strong>
                        <?= e($invoice["year"]) ?>
                        <?= e($invoice["make"]) ?>
                        <?= e($invoice["model"]) ?>
                    </strong>
                </p>

                <p>VIN: <?= e($invoice["VIN"]) ?></p>
                <p>Category: <?= e($invoice["category"]) ?></p>
                <p>Color: <?= e($invoice["color"]) ?></p>
            </div>

            <!-- Financial breakdown. -->
            <table class="invoice-table">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th class="amount">Amount</th>
                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <td>Vehicle Price</td>
                        <td class="amount">
                            <?= money($invoice["vehicle_price"]) ?>
                        </td>
                    </tr>

                    <tr>
                        <td>Discount</td>
                        <td class="amount">
                            <?= money($invoice["discount_amount"]) ?>
                        </td>
                    </tr>

                    <tr>
                        <td>Additional Charges</td>
                        <td class="amount">
                            <?= money($invoice["additional_charges"]) ?>
                        </td>
                    </tr>

                    <tr class="invoice-total">
                        <td>Final Invoice Total</td>
                        <td class="amount">
                            <?= money($invoice["total"]) ?>
                        </td>
                    </tr>
                </tbody>
            </table>

            <!-- Payment information saved when the invoice was generated. -->
            <div class="payment-summary">
                <h3>Payment Summary</h3>
                <p><?= e($invoice["payment_summary"] ?: "No payment information available.") ?></p>
            </div>

            <!-- Invoice footer. -->
            <div class="invoice-footer">
                <p>Thank you for your business.</p>
                <p>Generated by Vehicle Sales Management System.</p>
            </div>

        </div>
    </div>

<?php elseif ($sale): ?>

    <!-- Show the sale before invoice generation. -->
    <div class="invoice-wrapper">
        <div class="invoice-paper">

            <h2>Generate Invoice</h2>

            <p><strong>Sale ID:</strong> #<?= e($sale["sale_id"]) ?></p>

            <p>
                <strong>Customer:</strong>
                <?= e($sale["customer_name"]) ?>
            </p>

            <p>
                <strong>Vehicle:</strong>
                <?= e($sale["year"]) ?>
                <?= e($sale["make"]) ?>
                <?= e($sale["model"]) ?>
            </p>

            <p>
                <strong>VIN:</strong>
                <?= e($sale["VIN"]) ?>
            </p>

            <p>
                <strong>Salesperson:</strong>
                <?= e($sale["salesperson_name"]) ?>
            </p>

            <p>
                <strong>Sale Status:</strong>
                <?= e($sale["sale_status"]) ?>
            </p>

            <p>
                <strong>Final Amount:</strong>
                <?= money($sale["final_amount"]) ?>
            </p>

            <?php if ($sale["sale_status"] === "Completed"): ?>

                <!-- Submit the form to generate the invoice. -->
                <form method="POST" action="generate_invoice.php">

                    <!-- Include the CSRF security token. -->
                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= e($csrfToken) ?>"
                    >

                    <!-- Include the selected sale ID. -->
                    <input
                        type="hidden"
                        name="sale_id"
                        value="<?= e($sale["sale_id"]) ?>"
                    >

                    <button type="submit">
                        Generate Invoice
                    </button>

                    <a href="sales.php" class="btn btn-secondary">
                        Cancel
                    </a>

                </form>

            <?php else: ?>

                <p>
                    An invoice can only be generated after a sale is completed.
                </p>

                <a href="sales.php" class="btn btn-secondary">
                    Back to Sales
                </a>

            <?php endif; ?>

        </div>
    </div>

<?php else: ?>

    <!-- Display an error or ask the user to select a sale. -->
    <div class="invoice-wrapper">
        <div class="invoice-paper">

            <h2>Invoice Management</h2>

            <?php if ($error): ?>
                <p style="color: #dc2626;">
                    <?= e($error) ?>
                </p>
            <?php else: ?>
                <p>
                    Please open a completed sale from the Sales page
                    to generate its invoice.
                </p>
            <?php endif; ?>

            <a href="sales.php" class="btn btn-secondary">
                Go to Sales
            </a>

        </div>
    </div>

<?php endif; ?>

</body>
</html>
