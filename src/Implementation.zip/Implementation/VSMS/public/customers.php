
<?php
// Load the existing authentication functions and database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to log in before viewing customer records.
requireLogin();

// Retrieve the currently logged-in user's information.
$user = currentUser();

// Check whether the user's account is still active.
if ($user === null) {
    // Clear the current session information.
    $_SESSION = [];

    // Destroy the current session.
    session_destroy();

    // Redirect the user to the login page.
    redirect("login.php");
}

// Store the user's role for permission checks.
$userRole = $user["role_name"];

// Define the roles permitted to view customer records.
$allowedRoles = ["Administrator", "Manager", "Salesperson"];

// Check whether the user's role is permitted.
if (!in_array($userRole, $allowedRoles, true)) {
    // Return an HTTP 403 Forbidden response.
    http_response_code(403);

    // Stop the page from continuing.
    exit("Access denied. You are not allowed to view customers.");
}

// Allow only Administrators and Salespersons to register customers.
$canAddCustomers = in_array(
    $userRole,
    ["Administrator", "Salesperson"],
    true
);

// Define a function to safely display values in HTML.
function escapeCustomerDirectoryValue($value): string
{
    // Convert special characters into safe HTML entities.
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Read the search text submitted through the search form.
$search = trim($_GET["search"] ?? "");

// Initialize the customer records array.
$customers = [];

// Initialize the total customer count.
$totalCustomers = 0;

// Initialize the number of matching customers.
$matchingCustomers = 0;

// Initialize the database error indicator.
$databaseError = false;

// Try to retrieve customer information from MySQL.
try {

    // Retrieve the total number of registered customers.
    $totalQuery = $pdo->query(
        "SELECT COUNT(*) FROM customers"
    );

    // Store the total customer count as an integer.
    $totalCustomers = (int) $totalQuery->fetchColumn();

    // Prepare the SQL query for retrieving customers.
    $customerSql = "
        SELECT
            customer_id,
            full_name,
            phone,
            email,
            address,
            registration_date
        FROM customers
    ";

    // Initialize the query parameters.
    $parameters = [];

    // Apply the search condition when search text is provided.
    if ($search !== "") {

        // Search customer name, phone number, and email address.
        $customerSql .= "
            WHERE
                full_name LIKE ?
                OR phone LIKE ?
                OR email LIKE ?
        ";

        // Add wildcard characters to find partial matches.
        $searchValue = "%" . $search . "%";

        // Add one parameter for each SQL placeholder.
        $parameters[] = $searchValue;
        $parameters[] = $searchValue;
        $parameters[] = $searchValue;
    }

    // Display the newest customer records first.
    $customerSql .= "
        ORDER BY registration_date DESC, customer_id DESC
    ";

    // Prepare the customer query to protect against SQL injection.
    $customerQuery = $pdo->prepare($customerSql);

    // Execute the query using the supplied search parameters.
    $customerQuery->execute($parameters);

    // Retrieve all matching customer records.
    $customers = $customerQuery->fetchAll(PDO::FETCH_ASSOC);

    // Calculate the number of matching records.
    $matchingCustomers = count($customers);

} catch (PDOException $exception) {

    // Mark that a database error occurred.
    $databaseError = true;

    // Record technical details privately in the server error log.
    error_log(
        "VSMS customer directory error: " . $exception->getMessage()
    );
}

// Generate a CSRF token if the session does not already contain one.
if (empty($_SESSION["csrf_token"])) {

    // Generate a secure random token.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Store the CSRF token for the logout form.
$csrfToken = $_SESSION["csrf_token"];

// Safely prepare the current user's name for display.
$safeUserName = escapeCustomerDirectoryValue($user["full_name"]);

// Safely prepare the user's role for display.
$safeUserRole = escapeCustomerDirectoryValue($userRole);

// Safely prepare the CSRF token for the logout form.
$safeCsrfToken = escapeCustomerDirectoryValue($csrfToken);

?>
<!DOCTYPE html>
<!-- Declare this page as an HTML5 document. -->
<html lang="en">

<!-- Start the document head. -->
<head>

    <!-- Set the page character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on different devices. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Customers | VSMS</title>

    <!-- Load the existing dashboard styles. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Load the existing vehicle and table styles. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

</head>

<!-- Start the visible page. -->
<body>

    <!-- Create the main dashboard layout. -->
    <div class="dashboard-layout">

        <!-- Display the application sidebar. -->
        <aside class="sidebar">

            <!-- Display the VSMS brand. -->
            <div class="brand">
                <div class="brand-logo">V</div>

                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>
            </div>

            <!-- Display the main navigation links. -->
            
<!-- Display the main sidebar navigation. -->
<nav class="sidebar-navigation">

    <!-- Display the navigation heading. -->
    <p class="navigation-heading">MAIN MENU</p>

    <!-- Link to the dashboard. -->
    <a href="dashboard.php" class="nav-link">
        <span class="nav-icon">▦</span>
        <span>Dashboard</span>
    </a>

    <!-- Link to vehicle inventory. -->
    <a href="vehicles.php" class="nav-link">
        <span class="nav-icon">🚘</span>
        <span>Vehicles</span>
    </a>

    <!-- Highlight the current Customers page. -->
    <a href="customers.php" class="nav-link active">
        <span class="nav-icon">♙</span>
        <span>Customers</span>
    </a>

    <!-- Link to reservation management. -->
    <a href="reservations.php" class="nav-link">
        <span class="nav-icon">▣</span>
        <span>Reservations</span>
    </a>

    <!-- Link to sales management. -->
    <a href="sales.php" class="nav-link">
        <span class="nav-icon">▤</span>
        <span>Sales</span>
    </a>

    <!-- Link to payments. -->
    <a href="payments.php" class="nav-link">
        <span class="nav-icon">$</span>
        <span>Payments</span>
    </a>
    <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
    <span class="nav-icon">◷</span>
    <span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
    <span class="nav-icon">▧</span>
    <span>Invoices</span>
</a>

    <!-- Show Employees only to Administrators and Managers. -->
    <?php if (hasRole('Administrator') || hasRole('Manager')): ?>
        <a href="employees.php" class="nav-link">
            <span class="nav-icon">♧</span>
            <span>Employees</span>
        </a>
    <?php endif; ?>
    <?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
    <span class="nav-icon">♙</span>
    <span>User Accounts</span>
</a>

<?php endif; ?>

    <!-- Show Reports only to Administrators and Managers. -->
    <?php if (hasRole('Administrator') || hasRole('Manager')): ?>
        <a href="reports.php" class="nav-link">
            <span class="nav-icon">▥</span>
            <span>Reports</span>
        </a>
    <?php endif; ?>

</nav>
<div class="sidebar-footer">
                <p>Vehicle Sales &amp; Management System</p>
                <span>Development version</span>
            </div>

        </aside>

        <!-- Create the main page content area. -->
        <main class="main-content">

            <!-- Display the page header. -->
            <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Customer Management</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    
                    <div class="user-information">
                    <a href="my_profile.php" class="profile-name-link">
        <?= $safeUserName ?>
    </a>
                        <span><?= $safeUserRole ?></span>
                    </div>

    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>

           

            <!-- Display the customer directory content. -->
            <section class="page-content">

                <!-- Display the page heading and registration option. -->
                <div class="page-heading">

                    <div>
                        <h1>Customer Directory</h1>
                        <p>View and search customers registered in the system.</p>
                    </div>

                    <!-- Show the registration button only to authorized roles. -->
                    <?php if ($canAddCustomers): ?>

                        <a href="add_customer.php" class="primary-button">
                            + Register Customer
                        </a>

                    <?php endif; ?>

                </div>

                <!-- Display the customer statistics. -->
                <div class="inventory-summary">

                    <!-- Display the total registered customers. -->
                    <div class="summary-card">
                        <span class="summary-label">Total Customers</span>
                        <strong><?= number_format($totalCustomers) ?></strong>
                        <small>All registered customers</small>
                    </div>

                    <!-- Display the number of matching search results. -->
                    <div class="summary-card">
                        <span class="summary-label">Matching Records</span>
                        <strong><?= number_format($matchingCustomers) ?></strong>
                        <small>Based on the current search</small>
                    </div>

                </div>

                <!-- Display the customer search form. -->
                <section class="inventory-card">

                    <!-- Display the search section heading. -->
                    <div class="card-heading">
                        <div>
                            <h2>Search Customers</h2>
                            <p>Search using a name, phone number, or email address.</p>
                        </div>
                    </div>

                    <!-- Submit the search using the GET method. -->
                    <form action="customers.php" method="GET" class="filter-form">

                        <!-- Display the customer search field. -->
                        <div class="filter-field search-field">

                            <label for="search">Customer Search</label>

                            <input
                                type="search"
                                id="search"
                                name="search"
                                value="<?= escapeCustomerDirectoryValue($search) ?>"
                                placeholder="Enter name, phone number, or email..."
                            >

                        </div>

                        <!-- Display the search form buttons. -->
                        <div class="filter-actions">

                            <!-- Submit the search form. -->
                            <button type="submit" class="primary-button">
                                Search
                            </button>

                            <!-- Clear the search and show all customers. -->
                            <a href="customers.php" class="secondary-button">
                                Clear Search
                            </a>

                        </div>

                    </form>
                </section>

                <!-- Display database errors when a query fails. -->
                <?php if ($databaseError): ?>

                    <div class="inventory-message error-message">
                        Customer records could not be loaded. Please try again.
                    </div>

                <?php else: ?>

                    <!-- Display the customer records table. -->
                    <section class="vehicle-list-card">

                        <!-- Display the table heading. -->
                        <div class="vehicle-list-heading">
                            <div>
                                <h2>Registered Customers</h2>
                                <p>
                                    Showing <?= number_format($matchingCustomers) ?>
                                    customer record(s).
                                </p>
                            </div>
                        </div>

                        <!-- Make the table horizontally scrollable on small screens. -->
                        <div class="table-responsive">

                            <!-- Display the customer records. -->
                            <table class="vehicle-table">

                                <!-- Define the customer table headings. -->
                                <thead>
                                    <tr>
                                        <th>Customer ID</th>
                                        <th>Customer Name</th>
                                        <th>Phone Number</th>
                                        <th>Email Address</th>
                                        <th>Address</th>
                                        <th>Registration Date</th>
                                        <!-- Heading for customer actions. -->
                                        <th>Actions</th>
                                    </tr>
                                </thead>

                                <!-- Display the customer table records. -->
                                <tbody>

                                    <!-- Check whether any customers were found. -->
                                    <?php if (empty($customers)): ?>

                                        <tr>
                                            <td colspan="7">
                                                <div class="empty-inventory">
                                                    <div class="empty-inventory-icon">
                                                        ♙
                                                    </div>

                                                    <h3>No Customers Found</h3>

                                                    <p>
                                                        <?php if ($search !== ""): ?>
                                                            No customers match your search.
                                                            Try another name, phone number, or email.
                                                        <?php else: ?>
                                                            No customers have been registered yet.
                                                        <?php endif; ?>
                                                    </p>
                                                </div>
                                            </td>
                                        </tr>

                                    <?php else: ?>

                                        <!-- Loop through each customer record. -->
                                        <?php foreach ($customers as $customer): ?>

                                            <tr>

                                                <!-- Display the customer ID. -->
                                                <td>
                                                    #<?= (int) $customer["customer_id"] ?>
                                                </td>

                                                <!-- Display the customer's full name. -->
                                                <td>
                                                    <div class="vehicle-identity">
                                                        <strong>
                                                            <?= escapeCustomerDirectoryValue($customer["full_name"]) ?>
                                                        </strong>
                                                        <small>Registered customer</small>
                                                    </div>
                                                </td>

                                                <!-- Display the customer's phone number. -->
                                                <td>
                                                    <?= escapeCustomerDirectoryValue($customer["phone"]) ?>
                                                </td>

                                                <!-- Display the customer's email address. -->
                                                <td>
                                                    <?= $customer["email"] !== null && $customer["email"] !== ""
                                                        ? escapeCustomerDirectoryValue($customer["email"])
                                                        : "—" ?>
                                                </td>

                                                <!-- Display the customer's address. -->
                                                <td>
                                                    <?= $customer["address"] !== null && $customer["address"] !== ""
                                                        ? escapeCustomerDirectoryValue($customer["address"])
                                                        : "—" ?>
                                                </td>

                                                <!-- Display the registration date. -->
                                                <td>
                                                    <?= escapeCustomerDirectoryValue(
                                                        date(
                                                            "d M Y",
                                                            strtotime($customer["registration_date"])
                                                        )
                                                    ) ?>
                                                </td>
                                                <!-- Provide a link to the customer's details page. -->
                                                <td>
                                                    <a
                                                     href="customer_details.php?id=<?= (int) $customer["customer_id"] ?>"
                                                        class="secondary-button"
                                                    >
                                                     View Details
                                                    </a>
                                                </td>

                                            </tr>

                                        <?php endforeach; ?>

                                    <?php endif; ?>

                                </tbody>
                            </table>
                        </div>
                    </section>

                <?php endif; ?>

            </section>
        </main>
    </div>
</body>
</html>
