
<?php
// Load authentication, session, and database connection.
require_once __DIR__ . '/../includes/auth.php';

// Require the user to be logged in.
requireLogin();

// Get the current user's information.
$user = currentUser();

// Allow only Administrator, Manager, and Salesperson roles.
if (
    !hasRole('Administrator') &&
    !hasRole('Manager') &&
    !hasRole('Salesperson')
) {
    http_response_code(403);
    exit('Access denied.');
}

// Identify the logged-in user's role and ID.
$isSalesperson = hasRole('Salesperson');
$currentUserId = (int) $user['user_id'];

// Escape output before displaying database values in HTML.
function paymentEscape($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

// Convert a valid decimal amount into cents to avoid floating-point comparisons.
function paymentToCents(string $amount): int
{
    $parts = explode('.', $amount, 2);

    $whole = (int) $parts[0];
    $decimal = isset($parts[1])
        ? (int) str_pad($parts[1], 2, '0')
        : 0;

    return ($whole * 100) + $decimal;
}

// Define the payment methods available in the system.
$paymentMethods = [
    'Cash',
    'Card',
    'Bank Transfer',
    'Mobile Money',
    'Other'
];

// Create or reuse the session CSRF token.
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Read an optional sale ID from the URL.
$selectedSaleId = filter_input(
    INPUT_GET,
    'sale_id',
    FILTER_VALIDATE_INT
);

// Prepare page messages.
$errorMessage = '';
$successMessage = '';

// Display a success message after a successful payment.
if (isset($_GET['success']) && $_GET['success'] === '1') {
    $successMessage = 'Payment has been recorded successfully.';
}

// Keep submitted form values if validation fails.
$formSaleId = (int) ($_POST['sale_id'] ?? $selectedSaleId ?? 0);
$formAmount = trim($_POST['payment_amount'] ?? '');
$formMethod = trim($_POST['payment_method'] ?? 'Cash');
$formReference = trim($_POST['transaction_reference'] ?? '');
$formNotes = trim($_POST['notes'] ?? '');

// Process the submitted payment form.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Validate the CSRF token before processing the request.
    $submittedToken = $_POST['csrf_token'] ?? '';

    if (
        !is_string($submittedToken) ||
        !hash_equals($_SESSION['csrf_token'], $submittedToken)
    ) {
        $errorMessage = 'Invalid request. Please refresh the page and try again.';

    } elseif ($formSaleId <= 0) {

        // A valid sale must be selected.
        $errorMessage = 'Please select a valid sale.';

    } elseif (
        !preg_match('/^\d+(\.\d{1,2})?$/', $formAmount) ||
        paymentToCents($formAmount) <= 0
    ) {

        // The payment amount must be a positive number with at most two decimals.
        $errorMessage = 'Enter a valid payment amount greater than zero.';

    } elseif (!in_array($formMethod, $paymentMethods, true)) {

        // Reject payment methods that are not supported by the system.
        $errorMessage = 'Please select a valid payment method.';

    } elseif (strlen($formReference) > 100) {

        // Keep the reference within the database column limit.
        $errorMessage = 'Transaction reference cannot exceed 100 characters.';

    } else {

        // Start a database transaction so balance checks and payment insertion are atomic.
        try {
            $pdo->beginTransaction();

            // Lock the sale row to prevent simultaneous payments exceeding its balance.
            $saleSql = "
                SELECT
                    sale_id,
                    salesperson_id,
                    final_amount,
                    sale_status
                FROM sales
                WHERE sale_id = :sale_id
                LIMIT 1
                FOR UPDATE
            ";

            $saleStatement = $pdo->prepare($saleSql);
            $saleStatement->execute([
                ':sale_id' => $formSaleId
            ]);

            // Retrieve the selected sale.
            $sale = $saleStatement->fetch(PDO::FETCH_ASSOC);

            // Confirm that the sale exists.
            if (!$sale) {
                throw new RuntimeException('The selected sale could not be found.');
            }

            // Salespersons may record payments only for their own sales.
            if (
                $isSalesperson &&
                (int) $sale['salesperson_id'] !== $currentUserId
            ) {
                throw new RuntimeException(
                    'You are not authorized to record payments for this sale.'
                );
            }

            // Payments can be recorded only against completed sales.
            if ($sale['sale_status'] !== 'Completed') {
                throw new RuntimeException(
                    'Payments can only be recorded against completed sales.'
                );
            }

            // Calculate the total amount of completed payments for this sale.
            $paidSql = "
                SELECT COALESCE(SUM(payment_amount), 0) AS total_paid
                FROM payments
                WHERE sale_id = :sale_id
                  AND payment_status = 'Completed'
            ";

            $paidStatement = $pdo->prepare($paidSql);
            $paidStatement->execute([
                ':sale_id' => $formSaleId
            ]);

            // Retrieve the completed payment total.
            $paidAmount = (string) $paidStatement->fetchColumn();

            // Convert the sale amount and paid amount into cents.
            $saleAmountCents = paymentToCents((string) $sale['final_amount']);
            $paidAmountCents = paymentToCents($paidAmount);

            // Calculate the outstanding balance.
            $balanceCents = $saleAmountCents - $paidAmountCents;

            // Convert the submitted payment into cents.
            $newPaymentCents = paymentToCents($formAmount);

            // Prevent payments that exceed the outstanding balance.
            if ($newPaymentCents > $balanceCents) {
                throw new RuntimeException(
                    'Payment exceeds the outstanding balance of $' .
                    number_format($balanceCents / 100, 2) . '.'
                );
            }

            // Prepare the new payment record.
            $insertSql = "
                INSERT INTO payments (
                    sale_id,
                    payment_amount,
                    payment_method,
                    transaction_reference,
                    payment_status,
                    notes,
                    created_by
                ) VALUES (
                    :sale_id,
                    :payment_amount,
                    :payment_method,
                    :transaction_reference,
                    'Completed',
                    :notes,
                    :created_by
                )
            ";

            // Prepare the INSERT statement.
            $insertStatement = $pdo->prepare($insertSql);

            // Insert the payment using securely bound values.
            $insertStatement->execute([
                ':sale_id' => $formSaleId,
                ':payment_amount' => number_format(
                    $newPaymentCents / 100,
                    2,
                    '.',
                    ''
                ),
                ':payment_method' => $formMethod,
                ':transaction_reference' => $formReference !== ''
                    ? $formReference
                    : null,
                ':notes' => $formNotes !== ''
                    ? $formNotes
                    : null,
                ':created_by' => $currentUserId
            ]);

            // Commit the transaction after the payment is saved.
            $pdo->commit();

            // Redirect to prevent duplicate submissions when refreshing.
            header('Location: add_payment.php?success=1');
            exit;

        } catch (Throwable $exception) {

            // Roll back the transaction if an error occurs.
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            // Log technical details for troubleshooting.
            error_log('Payment recording error: ' . $exception->getMessage());

            // Show a safe and understandable message.
            $errorMessage = $exception instanceof RuntimeException
                ? $exception->getMessage()
                : 'Unable to record the payment. Please try again.';
        }
    }
}

// Prepare the list of completed sales and their payment balances.
$sales = [];

try {

    // Retrieve completed sales and calculate their paid and remaining amounts.
    $salesSql = "
        SELECT
            s.sale_id,
            s.sale_date,
            s.final_amount,
            c.full_name AS customer_name,
            c.phone AS customer_phone,
            v.make,
            v.model,
            v.year,
            COALESCE(p.total_paid, 0) AS total_paid,
            (
                s.final_amount - COALESCE(p.total_paid, 0)
            ) AS outstanding_balance

        FROM sales AS s

        INNER JOIN customers AS c
            ON s.customer_id = c.customer_id

        INNER JOIN vehicles AS v
            ON s.vehicle_id = v.vehicle_id

        LEFT JOIN (
            SELECT
                sale_id,
                SUM(payment_amount) AS total_paid
            FROM payments
            WHERE payment_status = 'Completed'
            GROUP BY sale_id
        ) AS p
            ON s.sale_id = p.sale_id

        WHERE s.sale_status = 'Completed'
          AND s.final_amount > COALESCE(p.total_paid, 0)
    ";

    // Restrict the list to the salesperson's own sales when necessary.
    if ($isSalesperson) {
        $salesSql .= " AND s.salesperson_id = :current_user_id";
    }

    // Sort the most recent sales first.
    $salesSql .= " ORDER BY s.sale_date DESC, s.sale_id DESC";

    // Prepare the query.
    $salesStatement = $pdo->prepare($salesSql);

    // Bind the salesperson ID if required.
    if ($isSalesperson) {
        $salesStatement->bindValue(
            ':current_user_id',
            $currentUserId,
            PDO::PARAM_INT
        );
    }

    // Execute the query and retrieve the sales.
    $salesStatement->execute();
    $sales = $salesStatement->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {

    // Log the database error and show a safe message.
    error_log('Payment sales list error: ' . $exception->getMessage());

    if ($errorMessage === '') {
        $errorMessage = 'Unable to load completed sales. Please try again.';
    }
}

// Find the selected sale in the available sales list.
$selectedSale = null;

foreach ($sales as $sale) {
    if ((int) $sale['sale_id'] === $formSaleId) {
        $selectedSale = $sale;
        break;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Set the page character encoding and responsive viewport. -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Record Payment | VSMS</title>

    <!-- Reuse the existing application stylesheets. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <!-- Add page-specific payment form styling. -->
    <style>
        .payment-page {
            padding: 24px;
            color: #263445;
        }

        .payment-header {
            margin-bottom: 24px;
        }

        .payment-header h1 {
            margin: 0 0 7px;
            font-size: 25px;
        }

        .payment-header p {
            margin: 0;
            color: #748091;
        }

        .payment-card {
            max-width: 850px;
            background: #ffffff;
            border: 1px solid #e7ebf0;
            border-radius: 10px;
            padding: 24px;
            box-shadow: 0 2px 8px rgba(25, 42, 62, 0.04);
        }

        .payment-form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
        }

        .payment-field {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .payment-field-full {
            grid-column: 1 / -1;
        }

        .payment-field label {
            font-size: 13px;
            font-weight: 600;
            color: #34465a;
        }

        .payment-field input,
        .payment-field select,
        .payment-field textarea {
            width: 100%;
            padding: 11px 12px;
            border: 1px solid #dce2e9;
            border-radius: 6px;
            font: inherit;
            background: #ffffff;
        }

        .payment-field textarea {
            min-height: 90px;
            resize: vertical;
        }

        .payment-field input:focus,
        .payment-field select:focus,
        .payment-field textarea:focus {
            outline: none;
            border-color: #f47755;
            box-shadow: 0 0 0 2px rgba(244, 119, 85, 0.12);
        }

        .payment-sale-info {
            grid-column: 1 / -1;
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 12px;
            padding: 16px;
            border-radius: 8px;
            background: #f5f7fa;
        }

        .payment-sale-info div span {
            display: block;
            color: #748091;
            font-size: 12px;
            margin-bottom: 6px;
        }

        .payment-sale-info div strong {
            color: #263b56;
            font-size: 16px;
        }

        .payment-balance {
            color: #d45e40 !important;
        }

        .payment-button {
            display: inline-block;
            border: none;
            border-radius: 7px;
            padding: 11px 18px;
            background: #f47755;
            color: #ffffff;
            text-decoration: none;
            font-weight: 600;
            cursor: pointer;
        }

        .payment-button:hover {
            background: #df6546;
            color: #ffffff;
        }

        .payment-button-secondary {
            background: #263b56;
        }

        .payment-button-secondary:hover {
            background: #1b2d43;
        }

        .payment-form-actions {
            grid-column: 1 / -1;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 8px;
        }

        .payment-message {
            max-width: 850px;
            padding: 13px 16px;
            margin-bottom: 18px;
            border-radius: 7px;
        }

        .payment-success {
            background: #e4f5e9;
            color: #197344;
        }

        .payment-error {
            background: #fff0f0;
            color: #a52c2c;
        }

        .payment-help {
            color: #748091;
            font-size: 12px;
            margin-top: 4px;
        }

        @media (max-width: 650px) {
            .payment-page {
                padding: 14px;
            }

            .payment-form-grid {
                grid-template-columns: 1fr;
            }

            .payment-sale-info {
                grid-template-columns: 1fr;
            }

            .payment-field-full {
                grid-column: auto;
            }
        }
    </style>
</head>

<body>
<div class="dashboard-layout">

    <!-- Create the left navigation sidebar. -->
    <aside class="sidebar">

        <!-- Display the VSMS brand. -->
        <div class="brand">
                <div class="brand-logo">V</div>
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>
            </div>

        <!-- Display the main navigation links. -->
        <nav class="sidebar-navigation">

            <p class="navigation-heading">MAIN MENU</p>

            <!-- Dashboard navigation. -->
            <a href="dashboard.php" class="nav-link">
                <span class="nav-icon">▦</span>
                <span>Dashboard</span>
            </a>

            <!-- Vehicle navigation. -->
            <a href="vehicles.php" class="nav-link">
                <span class="nav-icon">🚘</span>
                <span>Vehicles</span>
            </a>

            <!-- Customer navigation. -->
            <a href="customers.php" class="nav-link">
                <span class="nav-icon">♙</span>
                <span>Customers</span>
            </a>

            <!-- Reservation navigation. -->
            <a href="reservations.php" class="nav-link">
                <span class="nav-icon">▣</span>
                <span>Reservations</span>
            </a>

            <!-- Sales navigation. -->
            <a href="sales.php" class="nav-link">
                <span class="nav-icon">▤</span>
                <span>Sales</span>
            </a>

            <!-- Highlight the current Payments page. -->
            <a href="payments.php" class="nav-link active">
                <span class="nav-icon">$</span>
                <span>Payments</span>
            </a>
            <!-- Outstanding Balances navigation. -->
<a href="outstanding_balances.php" class="nav-link">
    <span class="nav-icon">◷</span>
    <span>Outstanding Balances</span>
</a>

<!-- Invoice navigation. -->
<a href="invoices.php" class="nav-link">
    <span class="nav-icon">▧</span>
    <span>Invoices</span>
</a>

            <!-- Employee navigation. -->
            <a href="employees.php" class="nav-link">
                <span class="nav-icon">♧</span>
                <span>Employees</span>
            </a>
            <?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
    <span class="nav-icon">♙</span>
    <span>User Accounts</span>
</a>

<?php endif; ?>

            <!-- Reports navigation. -->
            <a href="reports.php" class="nav-link">
                <span class="nav-icon">▥</span>
                <span>Reports</span>
            </a>

        </nav>

        <!-- Display the sidebar footer. -->
        <div class="sidebar-footer">
            <p>Vehicle Sales &amp; Management System</p>
            <span>Development version</span>
        </div>

    </aside>

    <!-- Create the main workspace beside the sidebar. -->
    <main class="main-content">


<div class="payment-page">

    <!-- Page heading. -->
    <div class="payment-header">
        <h1>Record Payment</h1>
        <p>Record a full or partial payment against a completed vehicle sale.</p>
    </div>

    <!-- Display the success message after a payment is saved. -->
    <?php if ($successMessage !== ''): ?>
        <div class="payment-message payment-success">
            <?= paymentEscape($successMessage) ?>
        </div>
    <?php endif; ?>

    <!-- Display validation or database error messages. -->
    <?php if ($errorMessage !== ''): ?>
        <div class="payment-message payment-error">
            <?= paymentEscape($errorMessage) ?>
        </div>
    <?php endif; ?>

    <div class="payment-card">

        <!-- Submit payment details securely using POST. -->
        <form method="POST" action="add_payment.php">

            <!-- Include the CSRF token to protect the form. -->
            <input
                type="hidden"
                name="csrf_token"
                value="<?= paymentEscape($_SESSION['csrf_token']) ?>"
            >

            <div class="payment-form-grid">

                <!-- Select the completed sale receiving the payment. -->
                <div class="payment-field payment-field-full">
                    <label for="sale_id">Select Sale *</label>

                    <select id="sale_id" name="sale_id" required>
                        <option value="">Choose a sale</option>

                        <?php foreach ($sales as $sale): ?>

                            <option
                                value="<?= (int) $sale['sale_id'] ?>"
                                <?= $formSaleId === (int) $sale['sale_id']
                                    ? 'selected'
                                    : '' ?>
                            >
                                <?= paymentEscape(
                                    '#' . $sale['sale_id'] .
                                    ' - ' . $sale['customer_name'] .
                                    ' - ' . $sale['year'] . ' ' .
                                    $sale['make'] . ' ' . $sale['model'] .
                                    ' - Balance: $' .
                                    number_format(
                                        (float) $sale['outstanding_balance'],
                                        2
                                    )
                                ) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                    <small class="payment-help">
                        Only completed sales with outstanding balances are displayed.
                    </small>
                </div>

                <!-- Display the selected sale's financial information. -->
                <?php if ($selectedSale): ?>

                    <div class="payment-sale-info">

                        <div>
                            <span>Sale Amount</span>
                            <strong>
                                $<?= number_format(
                                    (float) $selectedSale['final_amount'],
                                    2
                                ) ?>
                            </strong>
                        </div>

                        <div>
                            <span>Already Paid</span>
                            <strong>
                                $<?= number_format(
                                    (float) $selectedSale['total_paid'],
                                    2
                                ) ?>
                            </strong>
                        </div>

                        <div>
                            <span>Outstanding Balance</span>
                            <strong class="payment-balance">
                                $<?= number_format(
                                    (float) $selectedSale['outstanding_balance'],
                                    2
                                ) ?>
                            </strong>
                        </div>

                    </div>

                <?php endif; ?>

                <!-- Enter the amount received from the customer. -->
                <div class="payment-field">
                    <label for="payment_amount">Payment Amount *</label>

                    <input
                        type="number"
                        id="payment_amount"
                        name="payment_amount"
                        min="0.01"
                        step="0.01"
                        value="<?= paymentEscape($formAmount) ?>"
                        placeholder="Enter payment amount"
                        required
                    >

                    <small class="payment-help">
                        The server checks that the amount does not exceed the balance.
                    </small>
                </div>

                <!-- Select how the customer made the payment. -->
                <div class="payment-field">
                    <label for="payment_method">Payment Method *</label>

                    <select
                        id="payment_method"
                        name="payment_method"
                        required
                    >
                        <?php foreach ($paymentMethods as $method): ?>

                            <option
                                value="<?= paymentEscape($method) ?>"
                                <?= $formMethod === $method ? 'selected' : '' ?>
                            >
                                <?= paymentEscape($method) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>
                </div>

                <!-- Enter an optional transaction reference. -->
                <div class="payment-field payment-field-full">
                    <label for="transaction_reference">
                        Transaction Reference
                    </label>

                    <input
                        type="text"
                        id="transaction_reference"
                        name="transaction_reference"
                        maxlength="100"
                        value="<?= paymentEscape($formReference) ?>"
                        placeholder="Enter bank or transaction reference if available"
                    >
                </div>

                <!-- Enter optional payment notes. -->
                <div class="payment-field payment-field-full">
                    <label for="notes">Notes</label>

                    <textarea
                        id="notes"
                        name="notes"
                        placeholder="Additional payment information..."
                    ><?= paymentEscape($formNotes) ?></textarea>
                </div>

                <!-- Provide form submission and navigation buttons. -->
                <div class="payment-form-actions">

                    <button type="submit" class="payment-button">
                        Record Payment
                    </button>

                    <a
                        href="sales.php"
                        class="payment-button payment-button-secondary"
                    >
                        Back to Sales
                    </a>

                </div>

            </div>

        </form>

    </div>

</div>
</main>
<!-- Close the main workspace. -->

</div>
<!-- Close the dashboard layout. -->

</body>
</html>
