
<?php
// Load the existing authentication functions and database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to log in.
requireLogin();

// Retrieve the current user's information.
$user = currentUser();

// Check whether the account is still active.
if ($user === null) {
    // Clear the current session.
    $_SESSION = [];

    // Destroy the session.
    session_destroy();

    // Redirect the user to login.
    redirect("login.php");
}

// Store the current user's role.
$userRole = $user["role_name"];

// Only Administrators and Managers can access reports.
if (!in_array($userRole, ["Administrator", "Manager"], true)) {
    // Return an HTTP Forbidden response.
    http_response_code(403);

    // Stop execution.
    exit("Access denied. Only Administrators and Managers can view reports.");
}

// Create a helper function to safely display HTML values.
function escapeSalesReport($value): string
{
    // Escape special HTML characters.
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Define the valid sale statuses.
$saleStatuses = ["Pending", "Completed", "Cancelled"];

// Read the search text.
$search = trim($_GET["search"] ?? "");

// Read the selected sale status.
$statusFilter = trim($_GET["status"] ?? "");

// Read the beginning of the sale-date range.
$dateFrom = trim($_GET["date_from"] ?? "");

// Read the end of the sale-date range.
$dateTo = trim($_GET["date_to"] ?? "");

// Initialize the SQL conditions.
$conditions = ["1 = 1"];

// Initialize the prepared-statement parameters.
$parameters = [];

// Initialize the filter validation message.
$filterError = "";

// Initialize the database error indicator.
$databaseError = false;

// Initialize the sales report records.
$sales = [];

// Initialize the summary values.
$totalSales = 0;
$completedSales = 0;
$pendingSales = 0;
$cancelledSales = 0;
$totalRevenue = 0.00;
$totalDiscounts = 0.00;
$totalAdditionalCharges = 0.00;

// Validate the selected sale status.
if ($statusFilter !== "" && in_array($statusFilter, $saleStatuses, true)) {
    // Add the status filter to the SQL conditions.
    $conditions[] = "s.sale_status = ?";

    // Add the selected status to the parameters.
    $parameters[] = $statusFilter;
} else {
    // Clear an invalid status selection.
    $statusFilter = "";
}

// Apply the search filter when search text is provided.
if ($search !== "") {
    // Search sale ID, customer, phone, vehicle, VIN, and salesperson.
    $conditions[] = "(
        CAST(s.sale_id AS CHAR) LIKE ?
        OR c.full_name LIKE ?
        OR c.phone LIKE ?
        OR v.make LIKE ?
        OR v.model LIKE ?
        OR v.vin LIKE ?
        OR u.full_name LIKE ?
    )";

    // Add wildcard characters around the search text.
    $searchValue = "%" . $search . "%";

    // Add one parameter for each SQL placeholder.
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
}

// Validate the beginning date.
if ($dateFrom !== "") {
    // Parse the date using the expected format.
    $dateObject = DateTime::createFromFormat("!Y-m-d", $dateFrom);

    // Reject invalid dates.
    if (!$dateObject || $dateObject->format("Y-m-d") !== $dateFrom) {
        $filterError = "Please enter a valid start date.";
    } else {
        // Include sales made on or after the selected date.
        $conditions[] = "s.sale_date >= ?";

        // Add the beginning of the selected date.
        $parameters[] = $dateFrom . " 00:00:00";
    }
}

// Validate the ending date.
if ($dateTo !== "") {
    // Parse the date using the expected format.
    $dateObject = DateTime::createFromFormat("!Y-m-d", $dateTo);

    // Reject invalid dates.
    if (!$dateObject || $dateObject->format("Y-m-d") !== $dateTo) {
        $filterError = "Please enter a valid end date.";
    } else {
        // Include sales made before the following day.
        // This includes all transactions on the selected end date.
        $endDate = (new DateTime($dateTo))->modify("+1 day")->format("Y-m-d");

        // Add the ending-date condition.
        $conditions[] = "s.sale_date < ?";

        // Add the exclusive ending date.
        $parameters[] = $endDate . " 00:00:00";
    }
}

// Ensure that the start date is not later than the end date.
if ($dateFrom !== "" && $dateTo !== "" && $dateFrom > $dateTo) {
    // Set a clear validation message.
    $filterError = "The start date cannot be later than the end date.";
}

// Combine the conditions into one WHERE expression.
$whereSql = implode(" AND ", $conditions);

// Retrieve sales and calculate report totals.
try {
    // Run the sales report only when the filters are valid.
    if ($filterError === "") {

        // Select sales and their related customer, vehicle, and salesperson.
        $reportSql = "
            SELECT
                s.sale_id,
                s.sale_date,
                s.vehicle_price,
                s.discount_amount,
                s.additional_charges,
                s.final_amount,
                s.sale_status,
                c.full_name AS customer_name,
                c.phone AS customer_phone,
                v.make,
                v.model,
                v.`year` AS vehicle_year,
                v.vin,
                u.full_name AS salesperson_name
            FROM sales s
            INNER JOIN customers c
                ON s.customer_id = c.customer_id
            INNER JOIN vehicles v
                ON s.vehicle_id = v.vehicle_id
            INNER JOIN users u
                ON s.salesperson_id = u.user_id
            WHERE $whereSql
            ORDER BY s.sale_date DESC, s.sale_id DESC
        ";

        // Prepare the SQL statement.
        $reportStatement = $pdo->prepare($reportSql);

        // Execute the query using the prepared parameters.
        $reportStatement->execute($parameters);

        // Retrieve all matching sales.
        $sales = $reportStatement->fetchAll(PDO::FETCH_ASSOC);

        // Calculate the report totals from the retrieved records.
        foreach ($sales as $sale) {

            // Increase the total number of matching sales.
            $totalSales++;

            // Count completed sales and calculate their revenue.
            if ($sale["sale_status"] === "Completed") {
                $completedSales++;

                // Only completed sales contribute to revenue.
                $totalRevenue += (float) $sale["final_amount"];
            }

            // Count pending sales.
            if ($sale["sale_status"] === "Pending") {
                $pendingSales++;
            }

            // Count cancelled sales.
            if ($sale["sale_status"] === "Cancelled") {
                $cancelledSales++;
            }

            // Add the discount amount for the matching sales.
            $totalDiscounts += (float) $sale["discount_amount"];

            // Add the additional charges for the matching sales.
            $totalAdditionalCharges += (float) $sale["additional_charges"];
        }
    }

} catch (PDOException $exception) {
    // Mark the report as unavailable.
    $databaseError = true;

    // Record technical details in the server error log.
    error_log("VSMS sales report error: " . $exception->getMessage());
}

// Create a CSRF token if one does not already exist.
if (empty($_SESSION["csrf_token"])) {
    // Generate a secure random token.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Store the CSRF token for the logout form.
$csrfToken = $_SESSION["csrf_token"];

// Create a helper function for sale-status CSS classes.
function salesReportStatusClass(string $status): string
{
    // Return the correct CSS class for each sale status.
    return match ($status) {
        "Completed" => "sales-report-completed",
        "Pending" => "sales-report-pending",
        "Cancelled" => "sales-report-cancelled",
        default => ""
    };
}
?>

<!DOCTYPE html>
<!-- Declare the document as HTML5. -->
<html lang="en">

<head>
    <!-- Set the document character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on different screen sizes. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Sales Report | VSMS</title>

    <!-- Load the shared dashboard stylesheet. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Load the existing vehicle-management stylesheet. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <!-- Add styling specific to the sales report. -->
    <style>
        /* Arrange the sales summary cards in a responsive grid. */
        .sales-report-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(155px, 1fr));
            gap: 16px;
            margin: 24px 0;
        }

        /* Style each summary card. */
        .sales-report-card {
            background: #ffffff;
            border: 1px solid #e8eaf0;
            border-radius: 12px;
            padding: 20px;
        }

        /* Style the summary labels. */
        .sales-report-card span {
            display: block;
            color: #687386;
            font-size: 13px;
            margin-bottom: 10px;
        }

        /* Style the summary values. */
        .sales-report-card strong {
            display: block;
            color: #17233c;
            font-size: 25px;
        }

        /* Arrange the filter fields in a responsive grid. */
        .sales-report-filter {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
            gap: 14px;
            align-items: end;
        }

        /* Arrange each filter label and input vertically. */
        .sales-report-field {
            display: flex;
            flex-direction: column;
            gap: 7px;
        }

        /* Style the filter labels. */
        .sales-report-field label {
            font-size: 13px;
            font-weight: 600;
            color: #344054;
        }

        /* Style the filter controls. */
        .sales-report-field input,
        .sales-report-field select {
            width: 100%;
            min-height: 42px;
            padding: 9px 11px;
            border: 1px solid #d9dee8;
            border-radius: 7px;
            background: #ffffff;
            box-sizing: border-box;
        }

        /* Allow the sales table to scroll horizontally when necessary. */
        .sales-report-table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        /* Style the sales report table. */
        .sales-report-table {
            width: 100%;
            min-width: 1150px;
            border-collapse: collapse;
        }

        /* Style all table headings and cells. */
        .sales-report-table th,
        .sales-report-table td {
            padding: 13px 11px;
            text-align: left;
            border-bottom: 1px solid #edf0f4;
            font-size: 13px;
            vertical-align: middle;
        }

        /* Style the table header. */
        .sales-report-table th {
            background: #f7f8fa;
            color: #475467;
            font-weight: 600;
        }

        /* Style the sale status labels. */
        .sales-report-status {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            white-space: nowrap;
        }

        /* Style completed sales. */
        .sales-report-completed {
            background: #e8f7ee;
            color: #167443;
        }

        /* Style pending sales. */
        .sales-report-pending {
            background: #fff2df;
            color: #a65b00;
        }

        /* Style cancelled sales. */
        .sales-report-cancelled {
            background: #fdecec;
            color: #b42318;
        }

        /* Style report messages. */
        .sales-report-message {
            padding: 14px 16px;
            border-radius: 8px;
            margin: 16px 0;
        }

        /* Style error messages. */
        .sales-report-error {
            background: #fff0f0;
            color: #a61b1b;
        }

        /* Arrange report buttons. */
        .sales-report-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            align-items: center;
        }

        /* Style secondary report buttons. */
        .sales-report-secondary {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 42px;
            padding: 0 15px;
            border: 1px solid #d9dee8;
            border-radius: 7px;
            background: #ffffff;
            color: #344054;
            text-decoration: none;
            cursor: pointer;
            font-weight: 600;
        }

        /* Hide navigation and filters when printing. */
        @media print {
            .sidebar,
            .topbar,
            .sales-report-filter-card,
            .sales-report-actions,
            .page-heading {
                display: none !important;
            }

            /* Use the full page width for printing. */
            .main-content {
                margin: 0 !important;
                width: 100% !important;
            }

            /* Remove workspace spacing. */
            .page-content {
                padding: 0 !important;
            }

            /* Fit the report table to the printed page. */
            .sales-report-table {
                min-width: 100%;
            }
        }
    </style>
</head>

<body>
    <!-- Create the main VSMS dashboard layout. -->
    <div class="dashboard-layout">

        <!-- Display the application sidebar. -->
        <aside class="sidebar">

            <!-- Display the VSMS brand. -->
            <div class="brand">
                <div class="brand-logo">V</div>
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>
            </div>

            <!-- Display the main application navigation. -->
            <nav class="sidebar-navigation">

                <p class="navigation-heading">MAIN MENU</p>

                <!-- Link to the dashboard. -->
                <a href="dashboard.php" class="nav-link">
                    <span class="nav-icon">▦</span>
                    <span>Dashboard</span>
                </a>

                <!-- Link to vehicle inventory. -->
                <a href="vehicles.php" class="nav-link">
                    <span class="nav-icon">🚘</span>
                    <span>Vehicles</span>
                </a>

                <!-- Link to customer management. -->
                <a href="customers.php" class="nav-link">
                    <span class="nav-icon">♙</span>
                    <span>Customers</span>
                </a>

                <!-- Link to reservations. -->
                <a href="reservations.php" class="nav-link">
                    <span class="nav-icon">▣</span>
                    <span>Reservations</span>
                </a>

                <!-- Link to sales management. -->
                <a href="sales.php" class="nav-link">
                    <span class="nav-icon">▤</span>
                    <span>Sales</span>
                </a>

                <!-- Link to payments. -->
                <a href="payments.php" class="nav-link">
                    <span class="nav-icon">$</span>
                    <span>Payments</span>
                </a>

                <!-- Link to outstanding balances. -->
                <a href="outstanding_balances.php" class="nav-link">
                    <span class="nav-icon">◷</span>
                    <span>Outstanding Balances</span>
                </a>

                <!-- Link to invoices. -->
                <a href="invoices.php" class="nav-link">
                    <span class="nav-icon">▧</span>
                    <span>Invoices</span>
                </a>

                <!-- Link to employee management. -->
                <a href="employees.php" class="nav-link">
                    <span class="nav-icon">♧</span>
                    <span>Employees</span>
                </a>
                <?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
    <span class="nav-icon">♙</span>
    <span>User Accounts</span>
</a>

<?php endif; ?>
                <!-- Highlight the Reports section. -->
                <a href="inventory_report.php" class="nav-link active">
                    <span class="nav-icon">▥</span>
                    <span>Reports</span>
                </a>
            </nav>
        </aside>

        <!-- Create the main workspace. -->
        <main class="main-content">

            <!-- Display the page header and current user. -->
            <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Sales Report</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    
    <div class="user-information">
                    <a href="my_profile.php" class="profile-name-link"><?= escapeSalesReport($user["full_name"]) ?></a>
                        <span><?= escapeSalesReport($userRole) ?></span>
                    </div>

    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>
           
            <!-- Display the sales report content. -->
            <section class="page-content">

                <!-- Introduce the sales report. -->
                <div class="page-heading">
                    <div>
                        <h1>Sales Report</h1>
                        <p>Review sales transactions, customer information, vehicle details, and completed revenue.</p>
                    </div>
                </div>

                <!-- Display a database error if the report cannot load. -->
                <?php if ($databaseError): ?>
                    <div class="sales-report-message sales-report-error">
                        Unable to load the sales report. Please try again later.
                    </div>
                <?php else: ?>

                    <!-- Display summary values for the selected report. -->
                    <div class="sales-report-summary">

                        <!-- Display the total number of matching sales. -->
                        <article class="sales-report-card">
                            <span>Total Sales Records</span>
                            <strong><?= $totalSales ?></strong>
                        </article>

                        <!-- Display completed sales. -->
                        <article class="sales-report-card">
                            <span>Completed Sales</span>
                            <strong><?= $completedSales ?></strong>
                        </article>

                        <!-- Display pending sales. -->
                        <article class="sales-report-card">
                            <span>Pending Sales</span>
                            <strong><?= $pendingSales ?></strong>
                        </article>

                        <!-- Display cancelled sales. -->
                        <article class="sales-report-card">
                            <span>Cancelled Sales</span>
                            <strong><?= $cancelledSales ?></strong>
                        </article>

                        <!-- Display revenue from completed sales only. -->
                        <article class="sales-report-card">
                            <span>Completed Revenue</span>
                            <strong>$<?= number_format($totalRevenue, 2) ?></strong>
                        </article>

                        <!-- Display discounts in the filtered sales records. -->
                        <article class="sales-report-card">
                            <span>Total Discounts</span>
                            <strong>$<?= number_format($totalDiscounts, 2) ?></strong>
                        </article>

                        <!-- Display additional charges in the filtered sales records. -->
                        <article class="sales-report-card">
                            <span>Additional Charges</span>
                            <strong>$<?= number_format($totalAdditionalCharges, 2) ?></strong>
                        </article>
                    </div>

                    <!-- Display search and date filters. -->
                    <section class="inventory-card sales-report-filter-card">

                        <div class="card-heading">
                            <div>
                                <h2>Search and Filter Sales</h2>
                                <p>Choose a sale status, date range, or search term.</p>
                            </div>
                        </div>

                        <!-- Submit report filters using GET. -->
                        <form action="sales_report.php" method="GET" class="sales-report-filter">

                            <!-- Search for sales and related records. -->
                            <div class="sales-report-field">
                                <label for="search">Search</label>
                                <input
                                    type="search"
                                    id="search"
                                    name="search"
                                    placeholder="Sale ID, customer, vehicle, VIN..."
                                    value="<?= escapeSalesReport($search) ?>"
                                >
                            </div>

                            <!-- Filter by sale status. -->
                            <div class="sales-report-field">
                                <label for="status">Sale Status</label>
                                <select id="status" name="status">
                                    <option value="">All Statuses</option>

                                    <?php foreach ($saleStatuses as $saleStatus): ?>
                                        <option
                                            value="<?= escapeSalesReport($saleStatus) ?>"
                                            <?= $statusFilter === $saleStatus ? "selected" : "" ?>
                                        >
                                            <?= escapeSalesReport($saleStatus) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Select the beginning of the sale-date range. -->
                            <div class="sales-report-field">
                                <label for="date_from">Sale Date From</label>
                                <input
                                    type="date"
                                    id="date_from"
                                    name="date_from"
                                    value="<?= escapeSalesReport($dateFrom) ?>"
                                >
                            </div>

                            <!-- Select the end of the sale-date range. -->
                            <div class="sales-report-field">
                                <label for="date_to">Sale Date To</label>
                                <input
                                    type="date"
                                    id="date_to"
                                    name="date_to"
                                    value="<?= escapeSalesReport($dateTo) ?>"
                                >
                            </div>

                            <!-- Display filter actions. -->
                            <div class="sales-report-actions">
                                <button type="submit" class="primary-button">
                                    Apply Filters
                                </button>

                                <a href="sales_report.php" class="sales-report-secondary">
                                    Reset
                                </a>
                            </div>
                        </form>
                    </section>

                    <!-- Display any filter validation message. -->
                    <?php if ($filterError !== ""): ?>
                        <div class="sales-report-message sales-report-error">
                            <?= escapeSalesReport($filterError) ?>
                        </div>
                    <?php endif; ?>

                    <!-- Display the report table when the filters are valid. -->
                    <?php if ($filterError === ""): ?>
                        <section class="inventory-card">

                            <!-- Display the report heading and print action. -->
                            <div class="card-heading">
                                <div>
                                    <h2>Sales Transactions</h2>
                                    <p><?= $totalSales ?> matching transaction(s).</p>
                                </div>

                                <!-- Print the current report. -->
                                <button
                                    type="button"
                                    class="sales-report-secondary"
                                    onclick="window.print()"
                                >
                                    Print Report
                                </button>
                            </div>

                            <!-- Allow horizontal scrolling for the wide report table. -->
                            <div class="sales-report-table-wrapper">

                                <table class="sales-report-table">
                                    <thead>
                                        <tr>
                                            <th>Sale ID</th>
                                            <th>Sale Date</th>
                                            <th>Customer</th>
                                            <th>Phone</th>
                                            <th>Vehicle</th>
                                            <th>VIN</th>
                                            <th>Salesperson</th>
                                            <th>Vehicle Price</th>
                                            <th>Discount</th>
                                            <th>Additional Charges</th>
                                            <th>Final Amount</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php if (empty($sales)): ?>

                                            <!-- Explain when no sales match the filters. -->
                                            <tr>
                                                <td colspan="12">
                                                    No sales records match the selected filters.
                                                </td>
                                            </tr>

                                        <?php else: ?>

                                            <!-- Display each matching sale. -->
                                            <?php foreach ($sales as $sale): ?>
                                                <tr>

                                                    <!-- Display the sale reference. -->
                                                    <td>#<?= (int) $sale["sale_id"] ?></td>

                                                    <!-- Display the sale date. -->
                                                    <td>
                                                        <?= escapeSalesReport(date("d M Y", strtotime($sale["sale_date"]))) ?>
                                                    </td>

                                                    <!-- Display the customer name. -->
                                                    <td>
                                                        <?= escapeSalesReport($sale["customer_name"]) ?>
                                                    </td>

                                                    <!-- Display the customer phone number. -->
                                                    <td>
                                                        <?= escapeSalesReport($sale["customer_phone"]) ?>
                                                    </td>

                                                    <!-- Display the vehicle make, model, and year. -->
                                                    <td>
                                                        <?= escapeSalesReport($sale["make"]) ?>
                                                        <?= escapeSalesReport($sale["model"]) ?>
                                                        (<?= (int) $sale["vehicle_year"] ?>)
                                                    </td>

                                                    <!-- Display the vehicle VIN. -->
                                                    <td>
                                                        <?= escapeSalesReport($sale["vin"]) ?>
                                                    </td>

                                                    <!-- Display the responsible salesperson. -->
                                                    <td>
                                                        <?= escapeSalesReport($sale["salesperson_name"]) ?>
                                                    </td>

                                                    <!-- Display the original vehicle price. -->
                                                    <td>
                                                        $<?= number_format((float) $sale["vehicle_price"], 2) ?>
                                                    </td>

                                                    <!-- Display the discount amount. -->
                                                    <td>
                                                        $<?= number_format((float) $sale["discount_amount"], 2) ?>
                                                    </td>

                                                    <!-- Display additional charges. -->
                                                    <td>
                                                        $<?= number_format((float) $sale["additional_charges"], 2) ?>
                                                    </td>

                                                    <!-- Display the final sale amount. -->
                                                    <td>
                                                        $<?= number_format((float) $sale["final_amount"], 2) ?>
                                                    </td>

                                                    <!-- Display the sale status. -->
                                                    <td>
                                                        <span class="sales-report-status <?= salesReportStatusClass($sale["sale_status"]) ?>">
                                                            <?= escapeSalesReport($sale["sale_status"]) ?>
                                                        </span>
                                                    </td>

                                                </tr>
                                            <?php endforeach; ?>

                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    <?php endif; ?>

                <?php endif; ?>

            </section>
        </main>
    </div>
</body>
</html>
