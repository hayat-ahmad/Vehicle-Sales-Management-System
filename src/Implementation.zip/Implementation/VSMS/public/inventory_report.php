
<?php
// Load the existing authentication functions and PDO database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to log in before accessing this report.
requireLogin();

// Retrieve the currently logged-in user's information.
$user = currentUser();

// Check whether the user's account is still active.
if ($user === null) {
    // Clear the current session data.
    $_SESSION = [];

    // Destroy the current session.
    session_destroy();

    // Redirect the user to the login page.
    redirect("login.php");
}

// Store the user's role for access checks.
$userRole = $user["role_name"];

// Allow only Administrators and Managers to view reports.
if (!in_array($userRole, ["Administrator", "Manager"], true)) {
    // Return the HTTP Forbidden status.
    http_response_code(403);

    // Stop execution and display an access-denied message.
    exit("Access denied. Only Administrators and Managers can view reports.");
}

// Create a helper function for safely displaying HTML values.
function escapeInventoryReport($value): string
{
    // Escape special HTML characters.
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Define all vehicle statuses used by the VSMS database.
$vehicleStatuses = [
    "Available",
    "Reserved",
    "Sold",
    "Under Maintenance",
    "Unavailable"
];

// Read the search value submitted through the GET form.
$search = trim($_GET["search"] ?? "");

// Read the selected vehicle status.
$statusFilter = trim($_GET["status"] ?? "");

// Read the selected vehicle category.
$categoryFilter = trim($_GET["category"] ?? "");

// Read the beginning of the registration-date range.
$dateFrom = trim($_GET["date_from"] ?? "");

// Read the end of the registration-date range.
$dateTo = trim($_GET["date_to"] ?? "");

// Initialize the query conditions.
// Only active vehicle records are included in this report.
$conditions = ["is_active = 1"];

// Initialize the prepared-statement parameter array.
$parameters = [];

// Initialize a variable for filter validation errors.
$filterError = "";

// Initialize the database-error indicator.
$databaseError = false;

// Initialize report data arrays.
$vehicles = [];
$categories = [];
$statusCounts = [];

// Initialize the total vehicle count.
$totalVehicles = 0;

// Initialize the number of records matching the filters.
$matchingVehicles = 0;

// Validate the selected vehicle status.
if ($statusFilter !== "" && in_array($statusFilter, $vehicleStatuses, true)) {
    // Add the selected status to the SQL conditions.
    $conditions[] = "status = ?";

    // Add the status as a prepared-statement parameter.
    $parameters[] = $statusFilter;
} else {
    // Clear an invalid status value.
    $statusFilter = "";
}

// Apply the category filter when a category is selected.
if ($categoryFilter !== "") {
    // Add the category condition to the SQL query.
    $conditions[] = "category = ?";

    // Add the category as a prepared-statement parameter.
    $parameters[] = $categoryFilter;
}

// Apply the search filter when search text is provided.
if ($search !== "") {
    // Search the VIN, make, and model fields.
    $conditions[] = "(vin LIKE ? OR make LIKE ? OR model LIKE ?)";

    // Add wildcard characters around the search text.
    $searchValue = "%" . $search . "%";

    // Add one parameter for each search placeholder.
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
}

// Validate the beginning date when it is provided.
if ($dateFrom !== "") {
    // Check that the date follows the YYYY-MM-DD format.
    $dateObject = DateTime::createFromFormat("!Y-m-d", $dateFrom);

    // Reject invalid calendar dates.
    if (!$dateObject || $dateObject->format("Y-m-d") !== $dateFrom) {
        $filterError = "Please enter a valid start date.";
    } else {
        // Filter vehicles registered on or after the selected date.
        $conditions[] = "DATE(created_at) >= ?";

        // Add the beginning date to the query parameters.
        $parameters[] = $dateFrom;
    }
}

// Validate the ending date when it is provided.
if ($dateTo !== "") {
    // Check that the date follows the YYYY-MM-DD format.
    $dateObject = DateTime::createFromFormat("!Y-m-d", $dateTo);

    // Reject invalid calendar dates.
    if (!$dateObject || $dateObject->format("Y-m-d") !== $dateTo) {
        $filterError = "Please enter a valid end date.";
    } else {
        // Filter vehicles registered on or before the selected date.
        $conditions[] = "DATE(created_at) <= ?";

        // Add the ending date to the query parameters.
        $parameters[] = $dateTo;
    }
}

// Check that the start date is not later than the end date.
if ($dateFrom !== "" && $dateTo !== "" && $dateFrom > $dateTo) {
    // Display a clear validation message.
    $filterError = "The start date cannot be later than the end date.";
}

// Combine all conditions into one SQL WHERE expression.
$whereSql = implode(" AND ", $conditions);

// Retrieve the report data from MySQL.
try {
    // Count vehicles grouped by their current status.
    $countStatement = $pdo->query(
        "SELECT status, COUNT(*) AS total
         FROM vehicles
         WHERE is_active = 1
         GROUP BY status"
    );

    // Retrieve all status counts.
    $countRows = $countStatement->fetchAll(PDO::FETCH_ASSOC);

    // Initialize every vehicle status with a zero count.
    foreach ($vehicleStatuses as $vehicleStatus) {
        $statusCounts[$vehicleStatus] = 0;
    }

    // Store the actual counts returned by MySQL.
    foreach ($countRows as $countRow) {
        $statusCounts[$countRow["status"]] = (int) $countRow["total"];
    }

    // Calculate the total number of active vehicle records.
    $totalVehicles = array_sum($statusCounts);

    // Retrieve available vehicle categories for the filter dropdown.
    $categoryStatement = $pdo->query(
        "SELECT DISTINCT category
         FROM vehicles
         WHERE is_active = 1
         ORDER BY category"
    );

    // Store the category names.
    $categories = $categoryStatement->fetchAll(PDO::FETCH_COLUMN);

    // Run the filtered report query only when the filters are valid.
    if ($filterError === "") {
        // Select the vehicle information needed for the report.
        $reportSql = "
            SELECT
                vehicle_id,
                vin,
                make,
                model,
                `year`,
                category,
                price,
                mileage,
                status,
                created_at
            FROM vehicles
            WHERE $whereSql
            ORDER BY created_at DESC, vehicle_id DESC
        ";

        // Prepare the report query.
        $reportStatement = $pdo->prepare($reportSql);

        // Execute the query using the prepared parameters.
        $reportStatement->execute($parameters);

        // Retrieve the matching vehicle records.
        $vehicles = $reportStatement->fetchAll(PDO::FETCH_ASSOC);

        // Count the matching report records.
        $matchingVehicles = count($vehicles);
    }

// Handle database errors without showing technical details.
} catch (PDOException $exception) {
    // Mark the report as unavailable.
    $databaseError = true;

    // Record technical details in the PHP error log.
    error_log("VSMS inventory report error: " . $exception->getMessage());
}

// Create a CSRF token if the session does not already contain one.
if (empty($_SESSION["csrf_token"])) {
    // Generate a secure random token.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Store the token for the logout form.
$csrfToken = $_SESSION["csrf_token"];

// Create a helper function for vehicle status CSS classes.
function inventoryReportStatusClass(string $status): string
{
    // Return a CSS class based on the vehicle status.
    return match ($status) {
        "Available" => "status-available",
        "Reserved" => "status-reserved",
        "Sold" => "status-sold",
        "Under Maintenance" => "status-maintenance",
        "Unavailable" => "status-unavailable",
        default => "status-unavailable"
    };
}
?>

<!DOCTYPE html>
<!-- Declare this document as an HTML5 page. -->
<html lang="en">

<head>
    <!-- Set the character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Inventory Report | VSMS</title>

    <!-- Load the existing dashboard stylesheet. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Load the existing vehicle-management stylesheet. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <!-- Add report-specific styles without changing existing CSS files. -->
    <style>
        /* Arrange the report summary cards in a responsive grid. */
        .report-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 16px;
            margin: 24px 0;
        }

        /* Style each report summary card. */
        .report-summary-card {
            background: #ffffff;
            border: 1px solid #e8eaf0;
            border-radius: 12px;
            padding: 20px;
        }

        /* Style the summary card labels. */
        .report-summary-card span {
            display: block;
            color: #687386;
            font-size: 13px;
            margin-bottom: 10px;
        }

        /* Style the summary card numbers. */
        .report-summary-card strong {
            display: block;
            color: #17233c;
            font-size: 26px;
        }

        /* Arrange the report filters. */
        .report-filter-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
            gap: 14px;
            align-items: end;
        }

        /* Arrange each filter label and input vertically. */
        .report-filter-field {
            display: flex;
            flex-direction: column;
            gap: 7px;
        }

        /* Style the filter labels. */
        .report-filter-field label {
            font-size: 13px;
            font-weight: 600;
            color: #344054;
        }

        /* Style the filter inputs and dropdowns. */
        .report-filter-field input,
        .report-filter-field select {
            width: 100%;
            min-height: 42px;
            padding: 9px 11px;
            border: 1px solid #d9dee8;
            border-radius: 7px;
            background: #ffffff;
            box-sizing: border-box;
        }

        /* Style the report table container. */
        .report-table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        /* Make the report table use the available width. */
        .report-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 850px;
        }

        /* Style the report table headings and cells. */
        .report-table th,
        .report-table td {
            padding: 13px 12px;
            text-align: left;
            border-bottom: 1px solid #edf0f4;
            font-size: 13px;
        }

        /* Give the report table header a subtle background. */
        .report-table th {
            background: #f7f8fa;
            color: #475467;
            font-weight: 600;
        }

        /* Style the report status labels. */
        .report-status {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            white-space: nowrap;
        }

        /* Give available vehicles a green status label. */
        .report-status.status-available {
            background: #e8f7ee;
            color: #167443;
        }

        /* Give reserved vehicles a blue status label. */
        .report-status.status-reserved {
            background: #eaf2ff;
            color: #2459a6;
        }

        /* Give sold vehicles a grey status label. */
        .report-status.status-sold {
            background: #edf0f3;
            color: #475467;
        }

        /* Give maintenance vehicles an orange status label. */
        .report-status.status-maintenance {
            background: #fff2df;
            color: #a65b00;
        }

        /* Give unavailable vehicles a red status label. */
        .report-status.status-unavailable {
            background: #fdecec;
            color: #b42318;
        }

        /* Style report messages. */
        .report-message {
            padding: 14px 16px;
            border-radius: 8px;
            margin: 16px 0;
        }

        /* Style validation and database error messages. */
        .report-error {
            background: #fff0f0;
            color: #a61b1b;
        }

        /* Arrange the report action buttons. */
        .report-actions {
            display: flex;
            gap: 10px;
            flex-wrap: nowrap;
            align-items: center;

        }

        /* Style the secondary reset and print buttons. */
        .report-secondary-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 42px;
            padding: 0 15px;
            border: 1px solid #d9dee8;
            border-radius: 7px;
            background: #ffffff;
            color: #344054;
            text-decoration: none;
            cursor: pointer;
            font-weight: 600;
        }

        /* Hide navigation and controls when printing the report. */
        @media print {
            .sidebar,
            .topbar,
            .report-filter-card,
            .report-actions,
            .page-heading {
                display: none !important;
            }

            /* Use the full page width for the printed report. */
            .main-content {
                margin: 0 !important;
                width: 100% !important;
            }

            /* Remove workspace background and spacing for printing. */
            .page-content {
                padding: 0 !important;
            }

            /* Keep the report table readable on paper. */
            .report-table {
                min-width: 100%;
            }
        }
    </style>
</head>

<body>
    <!-- Create the shared VSMS dashboard layout. -->
    <div class="dashboard-layout">

        <!-- Display the main application sidebar. -->
        <aside class="sidebar">

            <!-- Display the VSMS brand. -->
            <div class="brand">
                <div class="brand-logo">V</div>
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>
            </div>

            <!-- Display the application navigation links. -->
            <nav class="sidebar-navigation">
                <p class="navigation-heading">MAIN MENU</p>

                <!-- Link to the dashboard. -->
                <a href="dashboard.php" class="nav-link">
                    <span class="nav-icon">▦</span>
                    <span>Dashboard</span>
                </a>

                <!-- Link to vehicle inventory. -->
                <a href="vehicles.php" class="nav-link">
                    <span class="nav-icon">🚘</span>
                    <span>Vehicles</span>
                </a>

                <!-- Link to customer management. -->
                <a href="customers.php" class="nav-link">
                    <span class="nav-icon">♙</span>
                    <span>Customers</span>
                </a>

                <!-- Link to reservations. -->
                <a href="reservations.php" class="nav-link">
                    <span class="nav-icon">▣</span>
                    <span>Reservations</span>
                </a>

                <!-- Link to sales. -->
                <a href="sales.php" class="nav-link">
                    <span class="nav-icon">▤</span>
                    <span>Sales</span>
                </a>

                <!-- Link to payments. -->
                <a href="payments.php" class="nav-link">
                    <span class="nav-icon">$</span>
                    <span>Payments</span>
                </a>

                <!-- Link to outstanding balances. -->
                <a href="outstanding_balances.php" class="nav-link">
                    <span class="nav-icon">◷</span>
                    <span>Outstanding Balances</span>
                </a>

                <!-- Link to invoices. -->
                <a href="invoices.php" class="nav-link">
                    <span class="nav-icon">▧</span>
                    <span>Invoices</span>
                </a>

                <!-- Link to employee management. -->
                <a href="employees.php" class="nav-link">
                    <span class="nav-icon">♧</span>
                    <span>Employees</span>
                </a>
                <?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
    <span class="nav-icon">♙</span>
    <span>User Accounts</span>
</a>

<?php endif; ?>
                <!-- Highlight the current Reports section. -->
                <a href="inventory_report.php" class="nav-link active">
                    <span class="nav-icon">▥</span>
                    <span>Reports</span>
                </a>
            </nav>
        </aside>

        <!-- Create the main workspace. -->
        <main class="main-content">

            <!-- Display the page heading and user information. -->
            <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Inventory Report</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    <div class="user-information">
                    <a href="my_profile.php" class="profile-name-link"><?= escapeInventoryReport($user["full_name"]) ?></a>
                        <span><?= escapeInventoryReport($userRole) ?></span>
                    </div>
    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>
      
          

            <!-- Display the inventory report content. -->
            <section class="page-content">

                <!-- Introduce the report and its purpose. -->
                <div class="page-heading">
                    <div>
                        <h1>Vehicle Inventory Report</h1>
                        <p>Review the dealership's active vehicle inventory and current status distribution.</p>
                    </div>
                </div>

                <!-- Display database errors without exposing technical details. -->
                <?php if ($databaseError): ?>
                    <div class="report-message report-error">
                        Unable to load the inventory report. Please try again later.
                    </div>
                <?php else: ?>

                    <!-- Display the live vehicle-status summary. -->
                    <div class="report-summary">

                        <!-- Display the total active vehicle count. -->
                        <article class="report-summary-card">
                            <span>Total Vehicles</span>
                            <strong><?= $totalVehicles ?></strong>
                        </article>

                        <!-- Display available vehicles. -->
                        <article class="report-summary-card">
                            <span>Available</span>
                            <strong><?= $statusCounts["Available"] ?></strong>
                        </article>

                        <!-- Display reserved vehicles. -->
                        <article class="report-summary-card">
                            <span>Reserved</span>
                            <strong><?= $statusCounts["Reserved"] ?></strong>
                        </article>

                        <!-- Display sold vehicles. -->
                        <article class="report-summary-card">
                            <span>Sold</span>
                            <strong><?= $statusCounts["Sold"] ?></strong>
                        </article>

                        <!-- Display vehicles under maintenance. -->
                        <article class="report-summary-card">
                            <span>Under Maintenance</span>
                            <strong><?= $statusCounts["Under Maintenance"] ?></strong>
                        </article>

                        <!-- Display unavailable vehicles. -->
                        <article class="report-summary-card">
                            <span>Unavailable</span>
                            <strong><?= $statusCounts["Unavailable"] ?></strong>
                        </article>
                    </div>

                    <!-- Display the report search and filter controls. -->
                    <section class="inventory-card report-filter-card">

                        <div class="card-heading">
                            <div>
                                <h2>Filter Inventory Report</h2>
                                <p>Choose the criteria you want to include in the report.</p>
                            </div>
                        </div>

                        <!-- Submit report filters using GET. -->
                        <form action="inventory_report.php" method="GET" class="report-filter-form">

                            <!-- Search by VIN, make, or model. -->
                            <div class="report-filter-field">
                                <label for="search">Search</label>
                                <input
                                    type="search"
                                    id="search"
                                    name="search"
                                    placeholder="VIN, make, or model"
                                    value="<?= escapeInventoryReport($search) ?>"
                                >
                            </div>

                            <!-- Filter by vehicle status. -->
                            <div class="report-filter-field">
                                <label for="status">Vehicle Status</label>
                                <select id="status" name="status">
                                    <option value="">All Statuses</option>

                                    <?php foreach ($vehicleStatuses as $vehicleStatus): ?>
                                        <option
                                            value="<?= escapeInventoryReport($vehicleStatus) ?>"
                                            <?= $statusFilter === $vehicleStatus ? "selected" : "" ?>
                                        >
                                            <?= escapeInventoryReport($vehicleStatus) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Filter by vehicle category. -->
                            <div class="report-filter-field">
                                <label for="category">Category</label>
                                <select id="category" name="category">
                                    <option value="">All Categories</option>

                                    <?php foreach ($categories as $category): ?>
                                        <option
                                            value="<?= escapeInventoryReport($category) ?>"
                                            <?= $categoryFilter === $category ? "selected" : "" ?>
                                        >
                                            <?= escapeInventoryReport($category) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Filter by registration start date. -->
                            <div class="report-filter-field">
                                <label for="date_from">Registration From</label>
                                <input
                                    type="date"
                                    id="date_from"
                                    name="date_from"
                                    value="<?= escapeInventoryReport($dateFrom) ?>"
                                >
                            </div>

                            <!-- Filter by registration end date. -->
                            <div class="report-filter-field">
                                <label for="date_to">Registration To</label>
                                <input
                                    type="date"
                                    id="date_to"
                                    name="date_to"
                                    value="<?= escapeInventoryReport($dateTo) ?>"
                                >
                            </div>

                            <!-- Display the filter actions. -->
                            <div class="report-actions">
                                <button type="submit" class="primary-button">
                                    Apply Filters
                                </button>
                                

                                <a href="inventory_report.php" class="report-secondary-button">
                                    Reset
                                </a>
                            </div>
                        </form>
                    </section>

                    <!-- Display a filter validation message when needed. -->
                    <?php if ($filterError !== ""): ?>
                        <div class="report-message report-error">
                            <?= escapeInventoryReport($filterError) ?>
                        </div>
                    <?php endif; ?>

                    <!-- Display the filtered report table. -->
                    <?php if ($filterError === ""): ?>
                        <section class="inventory-card">

                            <!-- Display the report heading and print action. -->
                            <div class="card-heading">
                                <div>
                                    <h2>Inventory Records</h2>
                                    <p>
                                        <?= $matchingVehicles ?>
                                        matching vehicle record(s).
                                    </p>
                                </div>

                                <!-- Print the current report using the browser. -->
                                <button
                                    type="button"
                                    class="report-secondary-button"
                                    onclick="window.print()"
                                >
                                    Print Report
                                </button>
                            </div>

                            <!-- Allow the table to scroll horizontally on small screens. -->
                            <div class="report-table-wrapper">

                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>VIN</th>
                                            <th>Vehicle</th>
                                            <th>Year</th>
                                            <th>Category</th>
                                            <th>Price</th>
                                            <th>Mileage</th>
                                            <th>Status</th>
                                            <th>Registration Date</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php if (empty($vehicles)): ?>

                                            <!-- Explain when no records match the filters. -->
                                            <tr>
                                                <td colspan="8">
                                                    No vehicle records match the selected filters.
                                                </td>
                                            </tr>

                                        <?php else: ?>

                                            <!-- Display every vehicle returned by the database. -->
                                            <?php foreach ($vehicles as $vehicle): ?>
                                                <tr>

                                                    <!-- Display the vehicle VIN. -->
                                                    <td><?= escapeInventoryReport($vehicle["vin"]) ?></td>

                                                    <!-- Display the vehicle make and model. -->
                                                    <td>
                                                        <?= escapeInventoryReport($vehicle["make"]) ?>
                                                        <?= escapeInventoryReport($vehicle["model"]) ?>
                                                    </td>

                                                    <!-- Display the manufacturing year. -->
                                                    <td><?= (int) $vehicle["year"] ?></td>

                                                    <!-- Display the vehicle category. -->
                                                    <td><?= escapeInventoryReport($vehicle["category"]) ?></td>

                                                    <!-- Display the vehicle price. -->
                                                    <td>
                                                        $<?= number_format((float) $vehicle["price"], 2) ?>
                                                    </td>

                                                    <!-- Display the recorded mileage. -->
                                                    <td>
                                                        <?= number_format((int) $vehicle["mileage"]) ?>
                                                    </td>

                                                    <!-- Display the vehicle's current status. -->
                                                    <td>
                                                        <span class="report-status <?= inventoryReportStatusClass($vehicle["status"]) ?>">
                                                            <?= escapeInventoryReport($vehicle["status"]) ?>
                                                        </span>
                                                    </td>

                                                    <!-- Display the vehicle registration date. -->
                                                    <td>
                                                        <?= escapeInventoryReport(date("d M Y", strtotime($vehicle["created_at"]))) ?>
                                                    </td>

                                                </tr>
                                            <?php endforeach; ?>

                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    <?php endif; ?>

                <?php endif; ?>

            </section>
        </main>
    </div>
</body>
</html>
