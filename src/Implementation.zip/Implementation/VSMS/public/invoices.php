
<?php
// Load authentication, session, and database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to log in before accessing this page.
requireLogin();

// Get the currently logged-in user's information.
$user = currentUser();

// Define the roles allowed to access invoice listings.
$allowedRoles = ["Administrator", "Manager", "Salesperson"];

// Block users whose roles are not authorized.
if (!in_array($user["role_name"], $allowedRoles, true)) {
    http_response_code(403);
    exit("Access denied.");
}

// Escape output to help prevent cross-site scripting.
function e($value) {
    return htmlspecialchars((string)($value ?? ""), ENT_QUOTES, "UTF-8");
}

// Format monetary values with two decimal places.
function money($amount) {
    return number_format((float)$amount, 2);
}

// Read the search text from the URL.
$search = trim($_GET["search"] ?? "");

// Start with the common invoice query conditions.
$whereConditions = [];
$queryParameters = [];

// Restrict Salespersons to invoices belonging to their own sales.
if ($user["role_name"] === "Salesperson") {
    $whereConditions[] = "s.salesperson_id = :salesperson_id";
    $queryParameters[":salesperson_id"] = $user["user_id"];
}

// Add search conditions when the user enters a search term.
if ($search !== "") {

    // Search invoice number, sale ID, customer, phone, and vehicle details.
    $whereConditions[] = "(
        i.invoice_number LIKE :search_invoice
        OR CAST(s.sale_id AS CHAR) LIKE :search_sale
        OR c.full_name LIKE :search_customer
        OR c.phone LIKE :search_phone
        OR v.make LIKE :search_make
        OR v.model LIKE :search_model
        OR v.VIN LIKE :search_vin
    )";

    // Prepare the search value with wildcard characters.
    $searchValue = "%" . $search . "%";

    // Bind separate parameters for each search condition.
    $queryParameters[":search_invoice"] = $searchValue;
    $queryParameters[":search_sale"] = $searchValue;
    $queryParameters[":search_customer"] = $searchValue;
    $queryParameters[":search_phone"] = $searchValue;
    $queryParameters[":search_make"] = $searchValue;
    $queryParameters[":search_model"] = $searchValue;
    $queryParameters[":search_vin"] = $searchValue;
}

// Combine all conditions into the SQL WHERE clause.
$whereSql = "";

if (!empty($whereConditions)) {
    $whereSql = "WHERE " . implode(" AND ", $whereConditions);
}

// Retrieve summary information for the user's permitted invoices.
$summaryQuery = "
    SELECT
        COUNT(*) AS total_invoices,
        COALESCE(SUM(i.total), 0) AS total_invoiced
    FROM invoices i
    INNER JOIN sales s
        ON i.sale_id = s.sale_id
    $whereSql
";

// Prepare and execute the summary query.
$summaryStatement = $pdo->prepare($summaryQuery);
$summaryStatement->execute($queryParameters);

// Retrieve the summary results.
$summary = $summaryStatement->fetch(PDO::FETCH_ASSOC);

// Retrieve the invoice records and their related information.
$invoiceQuery = "
    SELECT
        i.invoice_id,
        i.sale_id,
        i.invoice_number,
        i.issue_date,
        i.total,
        c.full_name AS customer_name,
        c.phone AS customer_phone,
        v.make,
        v.model,
        v.year,
        v.VIN,
        u.full_name AS salesperson_name
    FROM invoices i
    INNER JOIN sales s
        ON i.sale_id = s.sale_id
    INNER JOIN customers c
        ON s.customer_id = c.customer_id
    INNER JOIN vehicles v
        ON s.vehicle_id = v.vehicle_id
    INNER JOIN users u
        ON s.salesperson_id = u.user_id
    $whereSql
    ORDER BY i.issue_date DESC, i.invoice_id DESC
";

// Prepare the invoice listing query.
$invoiceStatement = $pdo->prepare($invoiceQuery);

// Execute the query using the same permitted filters.
$invoiceStatement->execute($queryParameters);

// Retrieve all matching invoices.
$invoices = $invoiceStatement->fetchAll(PDO::FETCH_ASSOC);

// Count the invoices displayed in the table.
$displayedCount = count($invoices);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Set the page character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Invoices | VSMS</title>

    <!-- Load the existing dashboard stylesheet. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Load the existing vehicle management stylesheet. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <style>
        /* Main page container. */
        .invoices-container {
            padding: 25px;
        }

        /* Page heading and action button. */
        .page-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            margin-bottom: 25px;
            flex-wrap: wrap;
            color: #da8c6e;
        }

        /* Summary cards layout. */
        .invoice-summary-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }

        /* Individual summary card. */
        .invoice-summary-card {
            background: #ffffff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        /* Summary card label. */
        .invoice-summary-card p {
            color: #64748b;
            margin: 0 0 8px;
        }

        /* Summary card value. */
        .invoice-summary-card h2 {
            color: #172554;
            margin: 0;
            font-size: 25px;
        }

        /* Search area. */
        .invoice-search-card {
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        /* Search form layout. */
        .invoice-search-form {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        /* Search input. */
        .invoice-search-form input {
            flex: 1;
            min-width: 200px;
            padding: 11px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
        }

        /* Invoice table container. */
        .invoice-table-card {
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            overflow-x: auto;
        }

        /* Invoice table. */
        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 850px;
        }

        /* Table headings and cells. */
        .invoice-table th,
        .invoice-table td {
            padding: 13px 12px;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }

        /* Table heading appearance. */
        .invoice-table th {
            background: #f8fafc;
            color: #334155;
            font-weight: 600;
        }

        /* Invoice number appearance. */
        .invoice-number {
            color: #1d4ed8;
            font-weight: 600;
        }

        /* Action link appearance. */
        .view-invoice-link {
            display: inline-block;
            padding: 7px 12px;
            background: #fff1eb;
            color: #c2410c;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 600;
        }

        /* Empty table message. */
        .empty-message {
            text-align: center;
            padding: 35px;
            color: #64748b;
        }

        /* Responsive summary cards. */
        @media (max-width: 650px) {
            .invoice-summary-grid {
                grid-template-columns: 1fr;
            }

            .invoices-container {
                padding: 15px;
            }
        }
    </style>
</head>

<body>
<!-- Main dashboard layout: sidebar and page workspace. -->
    <div class="dashboard-layout">

        <!-- Left navigation sidebar. -->
        <aside class="sidebar">

            <!-- VSMS branding. -->
            <div class="brand">
                <div class="brand-logo">V</div>
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>
            </div>

            <!-- Main navigation menu. -->
            <nav class="sidebar-navigation">

                <p class="navigation-heading">MAIN MENU</p>

                <a href="dashboard.php" class="nav-link">
                    <span class="nav-icon">▦</span>
                    <span>Dashboard</span>
                </a>

                <a href="vehicles.php" class="nav-link">
                    <span class="nav-icon">🚘</span>
                    <span>Vehicles</span>
                </a>

                <a href="customers.php" class="nav-link">
                    <span class="nav-icon">♙</span>
                    <span>Customers</span>
                </a>

                <a href="reservations.php" class="nav-link">
                    <span class="nav-icon">▣</span>
                    <span>Reservations</span>
                </a>

                <a href="sales.php" class="nav-link">
                    <span class="nav-icon">▤</span>
                    <span>Sales</span>
                </a>

                <a href="payments.php" class="nav-link">
                    <span class="nav-icon">$</span>
                    <span>Payments</span>
                </a>
                <a href="outstanding_balances.php" class="nav-link">
        <span class="nav-icon">◷</span>
        <span>Outstanding Balances</span>
    </a>

                <!-- Highlight the current Invoices page. -->
                <a href="invoices.php" class="nav-link active">
                    <span class="nav-icon">▧</span>
                    <span>Invoices</span>
                </a>

                <?php if (hasRole("Administrator") || hasRole("Manager")): ?>
                    <a href="employees.php" class="nav-link">
                        <span class="nav-icon">♧</span>
                        <span>Employees</span>
                    </a>
                    <?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
    <span class="nav-icon">♙</span>
    <span>User Accounts</span>
</a>

<?php endif; ?>

                    <a href="reports.php" class="nav-link">
                        <span class="nav-icon">▥</span>
                        <span>Reports</span>
                    </a>
                <?php endif; ?>

            </nav>
            <div class="sidebar-footer">
                <p>Vehicle Sales &amp; Management System</p>
                <span>Development version</span>
            </div>
        </aside>

        <!-- Main page workspace. -->
        <main class="main-content">

    <!-- Main invoice management container. -->
    <section class="invoices-container">

        <!-- Page heading and navigation. -->
        <div class="page-heading">

            <div>
                <h1>Invoice Management</h1>
                <p>View and manage generated sales invoices.</p>
            </div>

            <!-- Return to the sales page to generate invoices. -->
            <a href="sales.php" class="primary-button">
                Go to Sales
            </a>

        </div>

        <!-- Invoice summary cards. -->
        <div class="invoice-summary-grid">

            <!-- Total invoice count. -->
            <div class="invoice-summary-card">
                <p>Total Invoices</p>
                <h2><?= number_format((int)$summary["total_invoices"]) ?></h2>
            </div>

            <!-- Total invoiced amount. -->
            <div class="invoice-summary-card">
                <p>Total Invoiced Amount</p>
                <h2><?= money($summary["total_invoiced"]) ?></h2>
            </div>

        </div>

        <!-- Invoice search section. -->
        <div class="invoice-search-card">

            <h3>Search Invoices</h3>

            <form method="GET" action="invoices.php" class="invoice-search-form">

                <!-- Keep the entered search term in the input. -->
                <input
                    type="text"
                    name="search"
                    placeholder="Search invoice, sale, customer, phone, or vehicle..."
                    value="<?= e($search) ?>"
                >

                <!-- Submit the search form. -->
                <button type="submit" class="primary-button">
                    Search
                </button>

                <!-- Clear the search filter. -->
                <a href="invoices.php" class="primary-button">
                    Clear
                </a>

            </form>

        </div>

        <!-- Invoice records table. -->
        <div class="invoice-table-card">

            <div class="page-heading">

                <div>
                    <h3>Generated Invoices</h3>
                    <p>
                        Showing <?= number_format($displayedCount) ?>
                        invoice(s).
                    </p>
                </div>

            </div>

            <?php if (!empty($invoices)): ?>

                <!-- Display the invoice records. -->
                <table class="invoice-table">

                    <thead>
                        <tr>
                            <th>Invoice Number</th>
                            <th>Sale ID</th>
                            <th>Customer</th>
                            <th>Vehicle</th>
                            <th>Issue Date</th>
                            <th>Total Amount</th>
                            <th>Salesperson</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php foreach ($invoices as $invoice): ?>

                            <!-- Display one invoice record. -->
                            <tr>

                                <td class="invoice-number">
                                    <?= e($invoice["invoice_number"]) ?>
                                </td>

                                <td>
                                    #<?= e($invoice["sale_id"]) ?>
                                </td>

                                <td>
                                    <strong>
                                        <?= e($invoice["customer_name"]) ?>
                                    </strong>
                                    <br>
                                    <small>
                                        <?= e($invoice["customer_phone"]) ?>
                                    </small>
                                </td>

                                <td>
                                    <?= e($invoice["year"]) ?>
                                    <?= e($invoice["make"]) ?>
                                    <?= e($invoice["model"]) ?>
                                    <br>
                                    <small>VIN: <?= e($invoice["VIN"]) ?></small>
                                </td>

                                <td>
                                    <?= e(date(
                                        "d M Y",
                                        strtotime($invoice["issue_date"])
                                    )) ?>
                                </td>

                                <td>
                                    <?= money($invoice["total"]) ?>
                                </td>

                                <td>
                                    <?= e($invoice["salesperson_name"]) ?>
                                </td>

                                <td>
                                    <a
                                        href="generate_invoice.php?invoice_id=<?= (int)$invoice["invoice_id"] ?>"
                                        class="view-invoice-link"
                                    >
                                        View Invoice
                                    </a>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    </tbody>

                </table>

            <?php else: ?>

                <!-- Display when no matching invoices exist. -->
                <div class="empty-message">

                    <h3>No Invoices Found</h3>

                    <?php if ($search !== ""): ?>
                        <p>No invoices match your search.</p>
                    <?php else: ?>
                        <p>No invoices have been generated yet.</p>
                    <?php endif; ?>

                    <a href="sales.php" class="btn btn-primary">
                        Go to Sales
                    </a>

                </div>

            <?php endif; ?>

        </div>

        </section>

</main>
</div>

</body>
</html>
