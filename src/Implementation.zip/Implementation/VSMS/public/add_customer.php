
<?php
// Load the existing authentication functions and database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to log in before accessing this page.
requireLogin();

// Retrieve the current user's information.
$user = currentUser();

// Check whether the user's account is still active.
if ($user === null) {
    // Clear the current session information.
    $_SESSION = [];

    // Destroy the current session.
    session_destroy();

    // Redirect the user to the login page.
    redirect("login.php");
}

// Store the current user's role.
$userRole = $user["role_name"];

// Allow only Administrators and Salespersons to register customers.
if (!in_array($userRole, ["Administrator", "Salesperson"], true)) {
    // Return an HTTP 403 Forbidden response.
    http_response_code(403);

    // Stop the page from continuing.
    exit("Access denied. You are not allowed to register customers.");
}

// Define a function to safely display values in HTML.
function escapeCustomerValue($value): string
{
    // Convert special characters into safe HTML entities.
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Initialize the array that will contain validation errors.
$errors = [];

// Initialize the customer form fields.
$formData = [
    "full_name" => "",
    "phone" => "",
    "email" => "",
    "address" => ""
];

// Generate a CSRF token if one does not already exist.
if (empty($_SESSION["csrf_token"])) {
    // Generate a secure random token.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Store the session's CSRF token.
$csrfToken = $_SESSION["csrf_token"];

// Check whether the form has been submitted.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Retrieve the submitted CSRF token.
    $submittedToken = $_POST["csrf_token"] ?? "";

    // Verify that the submitted token is valid.
    if (
        !is_string($submittedToken) ||
        !hash_equals($csrfToken, $submittedToken)
    ) {
        // Add an error if the token is invalid.
        $errors[] = "Your form session is invalid. Please reload the page and try again.";
    }

    // Read the customer's full name.
    $formData["full_name"] = trim($_POST["full_name"] ?? "");

    // Read the customer's phone number.
    $formData["phone"] = trim($_POST["phone"] ?? "");

    // Read the customer's email address.
    $formData["email"] = trim($_POST["email"] ?? "");

    // Read the customer's address.
    $formData["address"] = trim($_POST["address"] ?? "");

    // Validate the customer's full name.
    if ($formData["full_name"] === "") {
        // Require a customer name.
        $errors[] = "Customer full name is required.";
    } elseif (strlen($formData["full_name"]) > 150) {
        // Enforce the database column length.
        $errors[] = "Customer name cannot exceed 150 characters.";
    }

    // Validate the customer's phone number.
// It must contain exactly 10 digits and start with 07.
if (!preg_match('/^07[0-9]{8}$/', $formData["phone"])) {
    $errors[] = "Phone number must contain exactly 10 digits and start with 07.";
}

    // Validate the email address only when one is provided.
    if ($formData["email"] !== "") {

        // Check whether the email address has a valid format.
        if (!filter_var($formData["email"], FILTER_VALIDATE_EMAIL)) {
            // Add an error for an invalid email address.
            $errors[] = "Please enter a valid email address.";
        } elseif (strlen($formData["email"]) > 150) {
            // Enforce the database column length.
            $errors[] = "Email address cannot exceed 150 characters.";
        }
    }

    // Check the maximum permitted address length.
    if (strlen($formData["address"]) > 65535) {
        // Prevent an excessively long address.
        $errors[] = "Customer address is too long.";
    }

    // Continue only when all validation checks have passed.
    if (empty($errors)) {

        try {
            // Prepare the SQL query to insert a new customer.
            $insertQuery = $pdo->prepare(
                "INSERT INTO customers
                (full_name, phone, email, address)
                VALUES (?, ?, ?, ?)"
            );

            // Execute the query using the validated form values.
            $insertQuery->execute([
                $formData["full_name"],
                $formData["phone"],
                $formData["email"] !== "" ? $formData["email"] : null,
                $formData["address"] !== "" ? $formData["address"] : null
            ]);

            // Redirect back to this page after successful registration.
            redirect("add_customer.php?added=1");

        } catch (PDOException $exception) {

            // Record the technical database error in the server log.
            error_log("VSMS customer registration error: " . $exception->getMessage());

            // Show a safe error message to the user.
            $errors[] = "The customer could not be registered. Please try again.";
        }
    }
}

// Safely prepare the current user's name for display.
$safeUserName = escapeCustomerValue($user["full_name"]);

// Safely prepare the user's role for display.
$safeUserRole = escapeCustomerValue($userRole);

// Safely prepare the CSRF token for the logout form.
$safeCsrfToken = escapeCustomerValue($csrfToken);

?>
<!DOCTYPE html>
<!-- Declare this page as an HTML5 document. -->
<html lang="en">

<!-- Start the document head. -->
<head>

    <!-- Set the page character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on different devices. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Register Customer | VSMS</title>

    <!-- Load the existing dashboard styles. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Reuse the existing vehicle form and card styles. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

</head>

<!-- Start the visible page. -->
<body>

    <!-- Create the main dashboard layout. -->
    <div class="dashboard-layout">

        <!-- Display the application sidebar. -->
        <aside class="sidebar">

<!-- Display the system logo and name. -->
<div class="brand">

    <!-- Display the short system name inside a logo box. -->
    <div class="brand-logo">V</div>

    <!-- Display the full system name. -->
    <div class="brand-text">
        <h2>VSMS</h2>
        <p>Vehicle Management</p>
    </div>

<!-- Close the brand section. -->
</div>

<!-- Display the main sidebar navigation. -->


<!-- Display all available system navigation links. -->
<nav class="sidebar-navigation">

    <!-- Display the navigation section heading. -->
    <p class="navigation-heading">MAIN MENU</p>

    <!-- Link to the Dashboard. -->
    <a href="dashboard.php" class="nav-link active">
        <span class="nav-icon">▦</span>
        <span>Dashboard</span>
    </a>

    <!-- Link to Vehicle Management. -->
    <a href="vehicles.php" class="nav-link">
        <span class="nav-icon">🚘</span>
        <span>Vehicles</span>
    </a>

    <!-- Link to Customer Management. -->
    <a href="customers.php" class="nav-link">
        <span class="nav-icon">♙</span>
        <span>Customers</span>
    </a>

    <!-- Link to Reservation Management. -->
    <a href="reservations.php" class="nav-link">
        <span class="nav-icon">▣</span>
        <span>Reservations</span>
    </a>

    <!-- Link to Sales Management. -->
    <a href="sales.php" class="nav-link">
        <span class="nav-icon">▤</span>
        <span>Sales</span>
    </a>

    <!-- Link to Payment Management. -->
    <a href="payments.php" class="nav-link">
        <span class="nav-icon">$</span>
        <span>Payments</span>
    </a>
    <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
<span class="nav-icon">◷</span>
<span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
<span class="nav-icon">▧</span>
<span>Invoices</span>
</a>

    <!-- Show employee management only to authorized management roles. -->
    <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

        <a href="employees.php" class="nav-link">
            <span class="nav-icon">♧</span>
            <span>Employees</span>
        </a>

    <?php endif; ?>
    <!-- Only Administrators can access User Account Management. -->
<?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
<span class="nav-icon">♙</span>
<span>User Accounts</span>
</a>

<?php endif; ?>

    <!-- Show reports only to authorized management roles. -->
    <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

        <a href="reports.php" class="nav-link">
            <span class="nav-icon">▥</span>
            <span>Reports</span>
        </a>

    <?php endif; ?>

<!-- Close the navigation section. -->
</nav>


<!-- Display a short project description at the bottom of the sidebar. -->
<div class="sidebar-footer">
    <p>Vehicle Sales &amp; Management System</p>
    <span>Development version</span>
</div>

<!-- Close the sidebar. -->
</aside>


        <!-- Create the main page content area. -->
        <main class="main-content">

            <!-- Display the page header. -->
            <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Customer Management</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    
                    <div class="user-information">
                    <a href="my_profile.php" class="profile-name-link">
        <?= $safeUserName ?>
    </a>
                        <span><?= $safeUserRole ?></span>
                    </div>

    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>
            

            <!-- Display the customer registration content. -->
            <section class="page-content">

                <!-- Display the page heading and navigation. -->
                <div class="page-heading">

                    <div>
                        <h1>Register New Customer</h1>
                        <p>Add a new customer to the vehicle sales system.</p>
                    </div>

                    <!-- Provide a link back to the dashboard. -->
                    <a href="dashboard.php" class="secondary-button">Back to Dashboard</a>

                </div>

                <!-- Display a success message after registration. -->
                <?php if (isset($_GET["added"]) && $_GET["added"] === "1"): ?>

                    <div class="inventory-message success-message">
                        Customer registered successfully.
                    </div>

                <?php endif; ?>

                <!-- Display validation or database errors. -->
                <?php if (!empty($errors)): ?>

                    <div class="inventory-message error-message">

                        <ul>
                            <?php foreach ($errors as $error): ?>

                                <li><?= escapeCustomerValue($error) ?></li>

                            <?php endforeach; ?>
                        </ul>

                    </div>

                <?php endif; ?>

                <!-- Start the customer registration form. -->
                <form action="add_customer.php" method="POST" class="vehicle-form">

                    <!-- Include the CSRF token to protect the form. -->
                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= escapeCustomerValue($csrfToken) ?>"
                    >

                    <!-- Create the customer information card. -->
                    <section class="inventory-card">

                        <!-- Display the card heading. -->
                        <div class="card-heading">
                            <div>
                                <h2>Customer Information</h2>
                                <p>Enter the customer's basic contact information.</p>
                            </div>
                        </div>

                        <!-- Arrange the customer fields in a responsive grid. -->
                        <div class="vehicle-form-grid">

                            <!-- Customer full name field. -->
                            <div class="filter-field">

                                <label for="full_name">
                                    Full Name <span class="required-mark">*</span>
                                </label>

                                <input
                                    type="text"
                                    id="full_name"
                                    name="full_name"
                                    maxlength="150"
                                    value="<?= escapeCustomerValue($formData["full_name"]) ?>"
                                    placeholder="Enter customer's full name"
                                    autocomplete="name"
                                    required
                                >

                            </div>

                            <!-- Customer phone number field. -->
                            <div class="filter-field">

                                <label for="phone">
                                    Phone Number <span class="required-mark">*</span>
                                </label>

                                <input
    type="tel"
    id="phone"
    name="phone"
    inputmode="numeric"
    pattern="07[0-9]{8}"
    minlength="10"
    maxlength="10"
    value="<?= escapeCustomerValue($formData["phone"]) ?>"
    placeholder="07XXXXXXXX"
    autocomplete="tel"
    title="Enter exactly 10 digits starting with 07."
    required
>

                            </div>

                            <!-- Customer email address field. -->
                            <div class="filter-field">

                                <label for="email">Email Address</label>

                                <input
                                    type="email"
                                    id="email"
                                    name="email"
                                    maxlength="150"
                                    value="<?= escapeCustomerValue($formData["email"]) ?>"
                                    placeholder="Enter email address (optional)"
                                    autocomplete="email"
                                >

                            </div>

                        </div>
                    </section>

                    <!-- Create the customer address card. -->
                    <section class="inventory-card">

                        <!-- Display the address card heading. -->
                        <div class="card-heading">
                            <div>
                                <h2>Address Information</h2>
                                <p>Provide the customer's address if available.</p>
                            </div>
                        </div>

                        <!-- Display the customer address field. -->
                        <div class="filter-field vehicle-description-field">

                            <label for="address">Customer Address</label>

                            <textarea
                                id="address"
                                name="address"
                                rows="4"
                                placeholder="Enter customer's address (optional)"
                            ><?= escapeCustomerValue($formData["address"]) ?></textarea>

                        </div>
                    </section>

                    <!-- Display the form action buttons. -->
                    <div class="vehicle-form-actions">

                        <!-- Allow the user to clear the form by returning to this page. -->
                        <a href="add_customer.php" class="secondary-button">Clear Form</a>

                        <!-- Submit the customer registration form. -->
                        <button type="submit" class="primary-button">
                            Register Customer
                        </button>

                    </div>

                </form>

            </section>
        </main>
    </div>
</body>
</html>
