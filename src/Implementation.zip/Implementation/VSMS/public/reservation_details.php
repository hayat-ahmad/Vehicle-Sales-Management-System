
<?php
// Load the existing authentication functions and PDO database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to log in before viewing reservation details.
requireLogin();

// Retrieve the currently logged-in user's information.
$user = currentUser();

// Check whether the user's account is still active.
if ($user === null) {
    // Clear the current session data.
    $_SESSION = [];

    // Destroy the current session.
    session_destroy();

    // Redirect the user to the login page.
    redirect("login.php");
}

// Store the user's role for display.
$userRole = $user["role_name"];

// Allow only approved VSMS roles to view reservation details.
$allowedRoles = ["Administrator", "Manager", "Salesperson"];

// Check whether the current role is permitted.
if (!in_array($userRole, $allowedRoles, true)) {
    // Return the HTTP Forbidden status.
    http_response_code(403);

    // Stop execution and display an access-denied message.
    exit("Access denied. Your role cannot view reservation details.");
}

// Define a helper function to safely display text in HTML.
function escapeHtml($value): string
{
    // Convert special characters to HTML entities.
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Read the reservation ID from the URL.
$reservationId = $_GET["id"] ?? "";

// Validate that the reservation ID is a positive whole number.
if (!ctype_digit((string) $reservationId) || (int) $reservationId < 1) {
    // Return a not-found response for an invalid ID.
    http_response_code(404);

    // Stop execution with a friendly message.
    exit("Reservation not found. Please provide a valid reservation ID.");
}

// Convert the validated reservation ID into an integer.
$reservationId = (int) $reservationId;

// Initialize the reservation variable.
$reservation = null;

// Initialize the database error flag.
$databaseError = false;

// Retrieve the reservation and its related records.
try {
    // Prepare a query joining reservation, customer, vehicle, and salesperson.
    $reservationQuery = $pdo->prepare(
        "SELECT
            r.reservation_id,
            r.customer_id,
            r.vehicle_id,
            r.salesperson_id,
            r.reservation_date,
            r.expiration_date,
            r.reservation_status,
            r.created_at,
            r.updated_at,

            c.full_name AS customer_name,
            c.phone AS customer_phone,
            c.email AS customer_email,
            c.address AS customer_address,
            c.registration_date AS customer_registration_date,

            v.vin,
            v.make,
            v.model,
            v.`year`,
            v.category,
            v.price,
            v.mileage,
            v.fuel_type,
            v.transmission,
            v.color,
            v.status AS vehicle_status,
            v.image_path,

            u.full_name AS salesperson_name,
            u.username AS salesperson_username,
            u.email AS salesperson_email

         FROM reservations AS r

         INNER JOIN customers AS c
            ON r.customer_id = c.customer_id

         INNER JOIN vehicles AS v
            ON r.vehicle_id = v.vehicle_id

         INNER JOIN users AS u
            ON r.salesperson_id = u.user_id

         WHERE r.reservation_id = ?
         LIMIT 1"
    );

    // Execute the query using the validated reservation ID.
    $reservationQuery->execute([$reservationId]);

    // Retrieve the matching reservation record.
    $reservation = $reservationQuery->fetch();

} catch (PDOException $exception) {
    // Record that a database error occurred.
    $databaseError = true;

    // Log technical details privately for troubleshooting.
    error_log("VSMS reservation details error: " . $exception->getMessage());
}

// If no reservation exists, return a not-found response.
if (!$databaseError && $reservation === false) {
    // Set the HTTP status to 404.
    http_response_code(404);

    // Display a friendly message and stop the page.
    exit("The requested reservation could not be found.");
}
// Prevent salespersons from viewing another salesperson's reservation.
if (
    !$databaseError &&
    is_array($reservation) &&
    $userRole === "Salesperson" &&
    (int) $reservation["salesperson_id"] !== (int) $user["user_id"]
) {
    http_response_code(403);

    exit("Access denied. You can view only your own reservations.");
}

// Determine whether the current user is allowed to cancel this reservation.
$canCancelReservation = false;

// Only active reservations can be cancelled.
if (
    !$databaseError &&
    is_array($reservation) &&
    $reservation["reservation_status"] === "Active"
) {
    // Administrators and Managers can cancel any active reservation.
    if (in_array($userRole, ["Administrator", "Manager"], true)) {
        $canCancelReservation = true;
    }

    // Salespersons can cancel only reservations assigned to their own account.
    if (
        $userRole === "Salesperson" &&
        (int) $reservation["salesperson_id"] === (int) $user["user_id"]
    ) {
        $canCancelReservation = true;
    }
}

// Create a CSRF token if one does not already exist.
if (empty($_SESSION["csrf_token"])) {
    // Generate a secure random token.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Store the CSRF token for the logout form.
$csrfToken = $_SESSION["csrf_token"];

// Convert reservation status into a CSS class.
function reservationStatusClass(string $status): string
{
    // Return the appropriate existing status style.
    return match ($status) {
        "Active" => "status-reserved",
        "Cancelled" => "status-unavailable",
        "Completed" => "status-available",
        default => "status-unavailable"
    };
}
?>
<!DOCTYPE html>
<!-- Declare this document as an HTML5 page. -->
<html lang="en">

<head>
    <!-- Set the character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on different screen sizes. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Reservation Details | VSMS</title>

    <!-- Load the existing dashboard stylesheet. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Reuse the existing vehicle and card styles. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <!-- Add styles specifically for reservation details. -->
    <style>
        /* Arrange the details cards in a responsive grid. */
        .reservation-details-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        /* Style each information card. */
        .reservation-detail-card {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            padding: 22px;
        }

        /* Style the card headings. */
        .reservation-detail-card h2 {
            margin: 0 0 18px;
            font-size: 18px;
            color: #172033;
        }

        /* Arrange each label and value. */
        .detail-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 15px;
            padding: 12px 0;
            border-bottom: 1px solid #eef0f3;
        }

        /* Remove the border from the final detail row. */
        .detail-row:last-child {
            border-bottom: none;
        }

        /* Style the detail labels. */
        .detail-label {
            color: #6b7280;
            font-size: 14px;
        }

        /* Style the detail values. */
        .detail-value {
            color: #172033;
            font-size: 14px;
            font-weight: 600;
            text-align: right;
            overflow-wrap: anywhere;
        }

        /* Style the main reservation summary. */
        .reservation-overview {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            padding: 24px;
            margin-top: 20px;
        }

        /* Arrange the overview information. */
        .reservation-overview-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        /* Style the reservation number. */
        .reservation-number {
            font-size: 22px;
            font-weight: 700;
            color: #172033;
        }

        /* Style the vehicle photograph. */
        .reservation-vehicle-image {
            width: 100%;
            max-height: 220px;
            object-fit: cover;
            border-radius: 9px;
            margin-bottom: 15px;
        }

        /* Style the vehicle placeholder. */
        .reservation-vehicle-placeholder {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            height: 160px;
            margin-bottom: 15px;
            border-radius: 9px;
            background: #f1f3f6;
            color: #64748b;
            font-weight: 700;
        }

        /* Arrange the page actions. */
        .reservation-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 20px;
        }

        /* Style the reservation cancellation action. */
        .danger-button {
            display: inline-block;
            padding: 10px 16px;
            border: none;
            border-radius: 7px;
            background: #dc2626;
            color: #ffffff;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
        }

        /* Slightly darken the cancellation action when hovered. */
        .danger-button:hover {
            background: #b91c1c;
        }

        /* Stack the detail cards on smaller screens. */
        @media (max-width: 768px) {
            .reservation-details-grid {
                grid-template-columns: 1fr;
            }

            .detail-row {
                flex-direction: column;
                gap: 5px;
            }

            .detail-value {
                text-align: left;
            }
        }
    </style>
</head>

<body>
    <!-- Create the main dashboard layout. -->
    <div class="dashboard-layout">

        <!-- Create the navigation sidebar. -->
        <aside class="sidebar">

<!-- Display the system logo and name. -->
<div class="brand">

    <!-- Display the short system name inside a logo box. -->
    <div class="brand-logo">V</div>

    <!-- Display the full system name. -->
    <div class="brand-text">
        <h2>VSMS</h2>
        <p>Vehicle Management</p>
    </div>

<!-- Close the brand section. -->
</div>

<!-- Display the main sidebar navigation. -->


<!-- Display all available system navigation links. -->
<nav class="sidebar-navigation">

    <!-- Display the navigation section heading. -->
    <p class="navigation-heading">MAIN MENU</p>

    <!-- Link to the Dashboard. -->
    <a href="dashboard.php" class="nav-link active">
        <span class="nav-icon">▦</span>
        <span>Dashboard</span>
    </a>

    <!-- Link to Vehicle Management. -->
    <a href="vehicles.php" class="nav-link">
        <span class="nav-icon">🚘</span>
        <span>Vehicles</span>
    </a>

    <!-- Link to Customer Management. -->
    <a href="customers.php" class="nav-link">
        <span class="nav-icon">♙</span>
        <span>Customers</span>
    </a>

    <!-- Link to Reservation Management. -->
    <a href="reservations.php" class="nav-link">
        <span class="nav-icon">▣</span>
        <span>Reservations</span>
    </a>

    <!-- Link to Sales Management. -->
    <a href="sales.php" class="nav-link">
        <span class="nav-icon">▤</span>
        <span>Sales</span>
    </a>

    <!-- Link to Payment Management. -->
    <a href="payments.php" class="nav-link">
        <span class="nav-icon">$</span>
        <span>Payments</span>
    </a>
    <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
<span class="nav-icon">◷</span>
<span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
<span class="nav-icon">▧</span>
<span>Invoices</span>
</a>

    <!-- Show employee management only to authorized management roles. -->
    <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

        <a href="employees.php" class="nav-link">
            <span class="nav-icon">♧</span>
            <span>Employees</span>
        </a>

    <?php endif; ?>
    <!-- Only Administrators can access User Account Management. -->
<?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
<span class="nav-icon">♙</span>
<span>User Accounts</span>
</a>

<?php endif; ?>

    <!-- Show reports only to authorized management roles. -->
    <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

        <a href="reports.php" class="nav-link">
            <span class="nav-icon">▥</span>
            <span>Reports</span>
        </a>

    <?php endif; ?>

<!-- Close the navigation section. -->
</nav>


<!-- Display a short project description at the bottom of the sidebar. -->
<div class="sidebar-footer">
    <p>Vehicle Sales &amp; Management System</p>
    <span>Development version</span>
</div>

<!-- Close the sidebar. -->
</aside>


        <!-- Create the main workspace. -->
        <main class="main-content">

            <!-- Display the page header. -->
            <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Main Menu / Reservations</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    
    <div class="user-information">
                    
                    <a href="my_profile.php" class="profile-name-link">
                    <?= escapeHtml($user["full_name"]) ?>
</a>
                        <span><?= escapeHtml($userRole) ?></span>
                    </div>

    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>
           

            <!-- Display the reservation details workspace. -->
            <section class="page-content">

                <?php if ($databaseError): ?>

                    <!-- Display a friendly database error message. -->
                    <div class="inventory-message error-message">
                        Unable to load reservation details. Please try again later.
                    </div>

                    <!-- Provide a link back to the reservation list. -->
                    <a href="reservations.php" class="secondary-button">
                        Back to Reservations
                    </a>

                <?php else: ?>

                    <!-- Display the page introduction and navigation. -->
                    <div class="page-heading">

                        <div>
                            <h1>Reservation Details</h1>
                            <p>Review the reservation, customer, vehicle, and salesperson information.</p>
                        </div>

                        <!-- Provide a link back to the reservation list. -->
                        <a href="reservations.php" class="secondary-button">
                            Back to Reservations
                        </a>

                    </div>

                    <!-- Display the main reservation overview. -->
                    <section class="reservation-overview">

                        <!-- Display the reservation number and status. -->
                        <div class="reservation-overview-header">

                            <div>
                                <span class="detail-label">Reservation Number</span>
                                <div class="reservation-number">
                                    #<?= (int) $reservation["reservation_id"] ?>
                                </div>
                            </div>

                            <!-- Display the current reservation status. -->
                            <span class="status-badge <?= escapeHtml(
                                reservationStatusClass($reservation["reservation_status"])
                            ) ?>">
                                <?= escapeHtml($reservation["reservation_status"]) ?>
                            </span>

                        </div>

                        <!-- Display the main reservation dates. -->
                        <div class="reservation-details-grid">

                            <!-- Display reservation dates. -->
                            <article class="reservation-detail-card">

                                <h2>Reservation Information</h2>

                                <div class="detail-row">
                                    <span class="detail-label">Reservation ID</span>
                                    <span class="detail-value">
                                        #<?= (int) $reservation["reservation_id"] ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Reservation Date</span>
                                    <span class="detail-value">
                                        <?= escapeHtml(date(
                                            "d M Y, h:i A",
                                            strtotime($reservation["reservation_date"])
                                        )) ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Expiration Date</span>
                                    <span class="detail-value">
                                        <?php if (!empty($reservation["expiration_date"])): ?>
                                            <?= escapeHtml(date(
                                                "d M Y, h:i A",
                                                strtotime($reservation["expiration_date"])
                                            )) ?>
                                        <?php else: ?>
                                            Not specified
                                        <?php endif; ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Current Status</span>
                                    <span class="detail-value">
                                        <?= escapeHtml($reservation["reservation_status"]) ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Record Created</span>
                                    <span class="detail-value">
                                        <?= escapeHtml(date(
                                            "d M Y, h:i A",
                                            strtotime($reservation["created_at"])
                                        )) ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Last Updated</span>
                                    <span class="detail-value">
                                        <?= escapeHtml(date(
                                            "d M Y, h:i A",
                                            strtotime($reservation["updated_at"])
                                        )) ?>
                                    </span>
                                </div>

                            </article>

                            <!-- Display the customer information. -->
                            <article class="reservation-detail-card">

                                <h2>Customer Information</h2>

                                <div class="detail-row">
                                    <span class="detail-label">Customer Name</span>
                                    <span class="detail-value">
                                        <?= escapeHtml($reservation["customer_name"]) ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Phone Number</span>
                                    <span class="detail-value">
                                        <?= escapeHtml($reservation["customer_phone"]) ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Email Address</span>
                                    <span class="detail-value">
                                        <?= !empty($reservation["customer_email"])
                                            ? escapeHtml($reservation["customer_email"])
                                            : "Not provided" ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Address</span>
                                    <span class="detail-value">
                                        <?= !empty($reservation["customer_address"])
                                            ? escapeHtml($reservation["customer_address"])
                                            : "Not provided" ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Customer Since</span>
                                    <span class="detail-value">
                                        <?= escapeHtml(date(
                                            "d M Y",
                                            strtotime($reservation["customer_registration_date"])
                                        )) ?>
                                    </span>
                                </div>

                                <!-- Link to the related customer record. -->
                                <div class="reservation-actions">
                                    <a
                                        href="customer_details.php?id=<?= (int) $reservation["customer_id"] ?>"
                                        class="secondary-button"
                                    >
                                        View Customer
                                    </a>
                                </div>

                            </article>

                            <!-- Display the reserved vehicle information. -->
                            <article class="reservation-detail-card">

                                <h2>Reserved Vehicle</h2>

                                <!-- Display the vehicle photograph when available. -->
                                <?php if (!empty($reservation["image_path"])): ?>

                                    <img
                                        src="<?= escapeHtml($reservation["image_path"]) ?>"
                                        alt="<?= escapeHtml(
                                            $reservation["make"] . " " . $reservation["model"]
                                        ) ?>"
                                        class="reservation-vehicle-image"
                                    >

                                <?php else: ?>

                                    <!-- Display a placeholder when no image exists. -->
                                    <div class="reservation-vehicle-placeholder">
                                        VEHICLE IMAGE NOT AVAILABLE
                                    </div>

                                <?php endif; ?>

                                <div class="detail-row">
                                    <span class="detail-label">Vehicle</span>
                                    <span class="detail-value">
                                        <?= escapeHtml(
                                            $reservation["year"] . " " .
                                            $reservation["make"] . " " .
                                            $reservation["model"]
                                        ) ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">VIN</span>
                                    <span class="detail-value">
                                        <?= escapeHtml($reservation["vin"]) ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Category</span>
                                    <span class="detail-value">
                                        <?= escapeHtml($reservation["category"]) ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Price</span>
                                    <span class="detail-value">
                                        <?= number_format((float) $reservation["price"], 2) ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Mileage</span>
                                    <span class="detail-value">
                                        <?= number_format((int) $reservation["mileage"]) ?> km
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Fuel Type</span>
                                    <span class="detail-value">
                                        <?= escapeHtml($reservation["fuel_type"]) ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Transmission</span>
                                    <span class="detail-value">
                                        <?= escapeHtml($reservation["transmission"]) ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Color</span>
                                    <span class="detail-value">
                                        <?= escapeHtml($reservation["color"]) ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Current Vehicle Status</span>
                                    <span class="detail-value">
                                        <?= escapeHtml($reservation["vehicle_status"]) ?>
                                    </span>
                                </div>

                                <!-- Link to the related vehicle record. -->
                                <div class="reservation-actions">
                                    <a
                                        href="vehicle_details.php?id=<?= (int) $reservation["vehicle_id"] ?>"
                                        class="secondary-button"
                                    >
                                        View Vehicle
                                    </a>
                                </div>

                            </article>

                            <!-- Display the assigned salesperson information. -->
                            <article class="reservation-detail-card">

                                <h2>Salesperson Information</h2>

                                <div class="detail-row">
                                    <span class="detail-label">Salesperson</span>
                                    <span class="detail-value">
                                        <?= escapeHtml($reservation["salesperson_name"]) ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Username</span>
                                    <span class="detail-value">
                                        <?= escapeHtml($reservation["salesperson_username"]) ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Email Address</span>
                                    <span class="detail-value">
                                        <?= escapeHtml($reservation["salesperson_email"]) ?>
                                    </span>
                                </div>

                                <div class="detail-row">
                                    <span class="detail-label">Salesperson ID</span>
                                    <span class="detail-value">
                                        <?= (int) $reservation["salesperson_id"] ?>
                                    </span>
                                </div>

                            </article>

                        </div>

                        <!-- Provide navigation actions at the bottom of the page. -->
                        <div class="reservation-actions">

                            <!-- Return to the reservation list. -->
                            <a href="reservations.php" class="secondary-button">
                                Back to Reservations
                            </a>

                            <?php if ($canCancelReservation): ?>

                                <!-- Open the cancellation confirmation page for this reservation. -->
                                <a
                                    href="cancel_reservation.php?id=<?= (int) $reservation["reservation_id"] ?>"
                                    class="danger-button"
                                >
                                    Cancel Reservation
                                </a>

                            <?php endif; ?>

                            <!-- Allow the user to create another reservation. -->
                            <a href="add_reservation.php" class="primary-button">
                                + Add Reservation
                            </a>

                        </div>

                    </section>

                <?php endif; ?>

            </section>
        </main>
    </div>
</body>
</html>
