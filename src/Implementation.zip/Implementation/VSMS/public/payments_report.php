
<?php
// Load the authentication functions and database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to be logged in.
requireLogin();

// Retrieve the current user's information.
$user = currentUser();

// Stop access if the account is no longer active.
if ($user === null) {
    // Clear the current session.
    $_SESSION = [];

    // Destroy the session.
    session_destroy();

    // Return the user to the login page.
    redirect("login.php");
}

// Allow only Administrators and Managers to access reports.
if (!in_array($user["role_name"], ["Administrator", "Manager"], true)) {
    http_response_code(403);
    exit("You do not have permission to access this report.");
}

// Create a helper function to safely display text.
function paymentReportEscape($value): string
{
    return htmlspecialchars((string) ($value ?? ""), ENT_QUOTES, "UTF-8");
}

// Create a helper function to format monetary values.
function paymentReportMoney($amount): string
{
    return number_format((float) $amount, 2);
}

// Read the search text submitted by the user.
$search = trim($_GET["search"] ?? "");

// Read the selected payment/balance status.
$paymentStatus = trim($_GET["payment_status"] ?? "");

// Read the start and end dates.
$startDate = trim($_GET["start_date"] ?? "");
$endDate = trim($_GET["end_date"] ?? "");

// Prepare an array to hold validation errors.
$errors = [];

// Check that the selected status is valid.
$allowedStatuses = ["Unpaid", "Partially Paid", "Fully Paid"];

if ($paymentStatus !== "" && !in_array($paymentStatus, $allowedStatuses, true)) {
    $paymentStatus = "";
}

// Validate the start date format.
if ($startDate !== "" && !DateTime::createFromFormat("Y-m-d", $startDate)) {
    $errors[] = "The start date is invalid.";
}

// Validate the end date format.
if ($endDate !== "" && !DateTime::createFromFormat("Y-m-d", $endDate)) {
    $errors[] = "The end date is invalid.";
}

// Make sure the start date is not after the end date.
if ($startDate !== "" && $endDate !== "" && $startDate > $endDate) {
    $errors[] = "The start date cannot be later than the end date.";
}

// Initialize the report records.
$reportRows = [];

// Initialize report summary values.
$totalSales = 0;
$totalSalesValue = 0;
$totalReceived = 0;
$totalOutstanding = 0;
$unpaidCount = 0;
$partialCount = 0;
$fullyPaidCount = 0;

// Track whether the database query failed.
$databaseError = false;

// Run the report only when the filters are valid.
if (empty($errors)) {
    try {
        // Start with completed sales only.
        $sql = "
            SELECT
                s.sale_id,
                s.sale_date,
                s.final_amount,

                c.customer_id,
                c.full_name AS customer_name,
                c.phone AS customer_phone,

                v.make,
                v.model,
                v.year,
                v.vin,

                u.full_name AS salesperson_name,

                COALESCE(p.total_paid, 0) AS total_paid,
                COALESCE(p.payment_count, 0) AS payment_count,
                p.last_payment_date

            FROM sales s

            INNER JOIN customers c
                ON s.customer_id = c.customer_id

            INNER JOIN vehicles v
                ON s.vehicle_id = v.vehicle_id

            INNER JOIN users u
                ON s.salesperson_id = u.user_id

            LEFT JOIN (
                SELECT
                    sale_id,
                    SUM(payment_amount) AS total_paid,
                    COUNT(*) AS payment_count,
                    MAX(payment_date) AS last_payment_date

                FROM payments

                WHERE payment_status = 'Completed'

                GROUP BY sale_id
            ) p
                ON s.sale_id = p.sale_id

            WHERE s.sale_status = 'Completed'
        ";

        // Prepare an array for SQL query parameters.
        $parameters = [];

        // Add the search condition when a search value is provided.
        if ($search !== "") {
            $sql .= "
                AND (
                    CAST(s.sale_id AS CHAR) LIKE ?
                    OR c.full_name LIKE ?
                    OR c.phone LIKE ?
                    OR v.make LIKE ?
                    OR v.model LIKE ?
                    OR v.vin LIKE ?
                    OR u.full_name LIKE ?
                )
            ";

            // Prepare the search value safely.
            $searchValue = "%" . $search . "%";

            // Add one parameter for each search condition.
            $parameters = array_merge(
                $parameters,
                [
                    $searchValue,
                    $searchValue,
                    $searchValue,
                    $searchValue,
                    $searchValue,
                    $searchValue,
                    $searchValue
                ]
            );
        }

        // Filter sales using the selected start date.
        if ($startDate !== "") {
            $sql .= " AND DATE(s.sale_date) >= ?";
            $parameters[] = $startDate;
        }

        // Filter sales using the selected end date.
        if ($endDate !== "") {
            $sql .= " AND DATE(s.sale_date) <= ?";
            $parameters[] = $endDate;
        }

        // Filter sales by their live payment/balance status.
        if ($paymentStatus === "Unpaid") {
            $sql .= " AND COALESCE(p.total_paid, 0) <= 0";
        } elseif ($paymentStatus === "Partially Paid") {
            $sql .= "
                AND COALESCE(p.total_paid, 0) > 0
                AND COALESCE(p.total_paid, 0) < s.final_amount
            ";
        } elseif ($paymentStatus === "Fully Paid") {
            $sql .= " AND COALESCE(p.total_paid, 0) >= s.final_amount";
        }

        // Show the newest sales first.
        $sql .= " ORDER BY s.sale_date DESC, s.sale_id DESC";

        // Prepare the SQL statement.
        $statement = $pdo->prepare($sql);

        // Execute the query using the supplied parameters.
        $statement->execute($parameters);

        // Retrieve all matching report records.
        $reportRows = $statement->fetchAll(PDO::FETCH_ASSOC);

        // Calculate the summary values from the filtered records.
        foreach ($reportRows as $row) {
            // Read the sale amount.
            $saleAmount = (float) $row["final_amount"];

            // Read the completed payment amount.
            $paidAmount = (float) $row["total_paid"];

            // Calculate the remaining balance.
            $balance = max(0, $saleAmount - $paidAmount);

            // Add the sale amount to the total.
            $totalSalesValue += $saleAmount;

            // Add received payments to the total.
            $totalReceived += $paidAmount;

            // Add the remaining balance to the total.
            $totalOutstanding += $balance;

            // Count the sale.
            $totalSales++;

            // Count unpaid sales.
            if ($paidAmount <= 0) {
                $unpaidCount++;
            // Count partially paid sales.
            } elseif ($paidAmount < $saleAmount) {
                $partialCount++;
            // Count fully paid sales.
            } else {
                $fullyPaidCount++;
            }
        }

    } catch (PDOException $exception) {
        // Record technical details in the server error log.
        error_log("VSMS payments report error: " . $exception->getMessage());

        // Show a safe error message on the page.
        $databaseError = true;
    }
}

// Safely prepare the user's name for display.
$fullName = paymentReportEscape($user["full_name"]);

// Safely prepare the user's role for display.
$roleName = paymentReportEscape($user["role_name"]);

// Create a CSRF token if one does not already exist.
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Safely prepare the token for the logout form.
$csrfToken = paymentReportEscape($_SESSION["csrf_token"]);
?>

<!DOCTYPE html>
<!-- Declare the document as HTML5. -->
<html lang="en">

<head>
    <!-- Set the page character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the report responsive. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Payments Report | VSMS</title>

    <!-- Load the shared dashboard stylesheet. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Load the existing vehicle and report-related styles. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <style>
        /* Add spacing around the report content. */
        .report-content {
            padding: 25px;
        }

        /* Arrange the report heading and actions. */
        .report-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 22px;
        }

        /* Style the report title. */
        .report-heading h1 {
            margin: 0 0 6px;
            color: #172033;
            font-size: 25px;
        }

        /* Style the report description. */
        .report-heading p {
            margin: 0;
            color: #64748b;
        }

        /* Arrange the summary cards. */
        .report-summary {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 16px;
            margin-bottom: 22px;
        }

        /* Style each summary card. */
        .summary-card {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            padding: 18px;
            box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04);
        }

        /* Style the summary card label. */
        .summary-card p {
            margin: 0 0 9px;
            color: #64748b;
            font-size: 13px;
        }

        /* Style the summary card value. */
        .summary-card h2 {
            margin: 0;
            color: #172033;
            font-size: 23px;
        }

        /* Arrange the filter controls. */
        .report-filter {
            display: flex;
            flex-wrap: wrap;
            align-items: end;
            gap: 12px;
            padding: 18px;
            margin-bottom: 20px;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
        }

        /* Arrange each filter field vertically. */
        .filter-field {
            display: flex;
            flex-direction: column;
            gap: 6px;
            min-width: 150px;
        }

        /* Style filter labels. */
        .filter-field label {
            color: #475569;
            font-size: 13px;
            font-weight: 600;
        }

        /* Style filter inputs and dropdowns. */
        .filter-field input,
        .filter-field select {
            min-height: 40px;
            padding: 8px 10px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            background: #ffffff;
        }

        /* Style the report buttons. */
        .report-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 40px;
            padding: 9px 15px;
            border: none;
            border-radius: 6px;
            background: #f26b4f;
            color: #ffffff;
            text-decoration: none;
            font-weight: 600;
            cursor: pointer;
        }

        /* Style the secondary button. */
        .report-button.secondary {
            background: #64748b;
        }

        /* Style the report table container. */
        .report-table-card {
            overflow: hidden;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
        }

        /* Add spacing around the table heading. */
        .report-table-heading {
            padding: 18px;
            border-bottom: 1px solid #e5e7eb;
        }

        /* Style the table heading. */
        .report-table-heading h2 {
            margin: 0;
            color: #172033;
            font-size: 18px;
        }

        /* Allow wide tables to scroll horizontally. */
        .report-table-wrapper {
            overflow-x: auto;
        }

        /* Style the report table. */
        .report-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1100px;
        }

        /* Style table cells. */
        .report-table th,
        .report-table td {
            padding: 12px 14px;
            border-bottom: 1px solid #edf0f4;
            text-align: left;
            white-space: nowrap;
            font-size: 13px;
        }

        /* Style table headings. */
        .report-table th {
            background: #f8fafc;
            color: #475569;
            font-weight: 700;
        }

        /* Highlight a row when the mouse moves over it. */
        .report-table tbody tr:hover {
            background: #fafbfc;
        }

        /* Style the payment status labels. */
        .payment-status {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
        }

        /* Style the unpaid status. */
        .payment-unpaid {
            background: #fee2e2;
            color: #991b1b;
        }

        /* Style the partially paid status. */
        .payment-partial {
            background: #fef3c7;
            color: #92400e;
        }

        /* Style the fully paid status. */
        .payment-paid {
            background: #dcfce7;
            color: #166534;
        }

        /* Style general messages. */
        .report-message {
            padding: 14px 16px;
            margin-bottom: 18px;
            border-radius: 7px;
        }

        /* Style validation and database error messages. */
        .report-error {
            background: #fee2e2;
            color: #991b1b;
        }

        /* Style the empty report message. */
        .empty-report {
            padding: 35px;
            text-align: center;
            color: #64748b;
        }

        /* Adapt the summary cards to smaller screens. */
        @media (max-width: 1000px) {
            .report-summary {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        /* Adapt the report to mobile screens. */
        @media (max-width: 600px) {
            .report-summary {
                grid-template-columns: 1fr;
            }

            .report-content {
                padding: 15px;
            }
        }

        /* Hide navigation and filters when printing. */
        @media print {
            .sidebar,
            .topbar,
            .report-filter,
            .report-actions {
                display: none !important;
            }

            .dashboard-layout {
                display: block !important;
            }

            .main-content,
            .report-content {
                width: 100% !important;
                padding: 0 !important;
                margin: 0 !important;
            }

            .report-table {
                min-width: 0;
            }

            .report-table th,
            .report-table td {
                font-size: 9px;
                padding: 6px;
            }
        }
    </style>
</head>

<body>

    <!-- Create the shared application layout. -->
    <div class="dashboard-layout">

        <!-- Create the navigation sidebar. -->
        <aside class="sidebar">

            <!-- Display the VSMS brand. -->
            <div class="brand">
                <div class="brand-logo">V</div>
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>
            </div>

            <!-- Display the main navigation links. -->
            <nav class="sidebar-navigation">

                <p class="navigation-heading">MAIN MENU</p>

                <a href="dashboard.php" class="nav-link">
                    <span class="nav-icon">▦</span>
                    <span>Dashboard</span>
                </a>

                <a href="vehicles.php" class="nav-link">
                    <span class="nav-icon">🚘</span>
                    <span>Vehicles</span>
                </a>

                <a href="customers.php" class="nav-link">
                    <span class="nav-icon">♙</span>
                    <span>Customers</span>
                </a>

                <a href="reservations.php" class="nav-link">
                    <span class="nav-icon">▣</span>
                    <span>Reservations</span>
                </a>

                <a href="sales.php" class="nav-link">
                    <span class="nav-icon">↗</span>
                    <span>Sales</span>
                </a>

                <a href="payments.php" class="nav-link">
                    <span class="nav-icon">$</span>
                    <span>Payments</span>
                </a>
                

                <a href="outstanding_balances.php" class="nav-link">
                    <span class="nav-icon">≡</span>
                    <span>Outstanding Balances</span>
                </a>

                <a href="invoices.php" class="nav-link">
                    <span class="nav-icon">▤</span>
                    <span>Invoices</span>
                </a>

                <a href="employees.php" class="nav-link">
                    <span class="nav-icon">♧</span>
                    <span>Employees</span>
                </a>
                <?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
    <span class="nav-icon">♙</span>
    <span>User Accounts</span>
</a>

<?php endif; ?>
                <!-- Highlight the Reports section. -->
                <a href="inventory_report.php" class="nav-link active">
                    <span class="nav-icon">▥</span>
                    <span>Reports</span>
                </a>

            </nav>
        </aside>

        <!-- Create the main report workspace. -->
        <main class="main-content">

            <!-- Display the top header. -->
            <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Payments Report</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    <div class="user-information">
    <a href="my_profile.php" class="profile-name-link">
        <?= $fullName ?>
                        </a>
                        <span><?= $roleName ?></span>
    </div>

    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>
            

            <!-- Start the report content. -->
            <section class="report-content">

                <!-- Display the report heading and print action. -->
                <div class="report-heading">

                    <div>
                        <h1>Payments and Outstanding Balances</h1>
                        <p>Review completed sales, payments received, and remaining customer balances.</p>
                    </div>

                    <div class="report-actions">
                        <button type="button" class="report-button" onclick="window.print()">
                            Print Report
                        </button>
                    </div>

                </div>

                <!-- Display validation errors. -->
                <?php foreach ($errors as $error): ?>
                    <div class="report-message report-error">
                        <?= paymentReportEscape($error) ?>
                    </div>
                <?php endforeach; ?>

                <!-- Display a safe database error message. -->
                <?php if ($databaseError): ?>
                    <div class="report-message report-error">
                        The report could not be loaded. Please try again later.
                    </div>
                <?php endif; ?>

                <!-- Display the summary cards. -->
                <div class="report-summary">

                    <div class="summary-card">
                        <p>Completed Sales</p>
                        <h2><?= number_format($totalSales) ?></h2>
                    </div>

                    <div class="summary-card">
                        <p>Total Sales Value</p>
                        <h2><?= paymentReportMoney($totalSalesValue) ?></h2>
                    </div>

                    <div class="summary-card">
                        <p>Total Payments Received</p>
                        <h2><?= paymentReportMoney($totalReceived) ?></h2>
                    </div>

                    <div class="summary-card">
                        <p>Outstanding Balance</p>
                        <h2><?= paymentReportMoney($totalOutstanding) ?></h2>
                    </div>

                    <div class="summary-card">
                        <p>Unpaid Sales</p>
                        <h2><?= number_format($unpaidCount) ?></h2>
                    </div>

                    <div class="summary-card">
                        <p>Partially Paid Sales</p>
                        <h2><?= number_format($partialCount) ?></h2>
                    </div>

                </div>

                <!-- Create the report filters. -->
                <form method="GET" action="payments_report.php" class="report-filter">

                    <div class="filter-field">
                        <label for="search">Search</label>
                        <input
                            type="text"
                            id="search"
                            name="search"
                            placeholder="Sale, customer, vehicle..."
                            value="<?= paymentReportEscape($search) ?>"
                        >
                    </div>

                    <div class="filter-field">
                        <label for="payment_status">Payment Status</label>
                        <select id="payment_status" name="payment_status">
                            <option value="">All Statuses</option>
                            <option value="Unpaid" <?= $paymentStatus === "Unpaid" ? "selected" : "" ?>>
                                Unpaid
                            </option>
                            <option value="Partially Paid" <?= $paymentStatus === "Partially Paid" ? "selected" : "" ?>>
                                Partially Paid
                            </option>
                            <option value="Fully Paid" <?= $paymentStatus === "Fully Paid" ? "selected" : "" ?>>
                                Fully Paid
                            </option>
                        </select>
                    </div>

                    <div class="filter-field">
                        <label for="start_date">Start Date</label>
                        <input
                            type="date"
                            id="start_date"
                            name="start_date"
                            value="<?= paymentReportEscape($startDate) ?>"
                        >
                    </div>

                    <div class="filter-field">
                        <label for="end_date">End Date</label>
                        <input
                            type="date"
                            id="end_date"
                            name="end_date"
                            value="<?= paymentReportEscape($endDate) ?>"
                        >
                    </div>

                    <button type="submit" class="report-button">
                        Apply Filters
                    </button>

                    <a href="payments_report.php" class="report-button secondary">
                        Reset
                    </a>

                </form>

                <!-- Display the detailed report table. -->
                <div class="report-table-card">

                    <div class="report-table-heading">
                        <h2>Customer Payment Details</h2>
                    </div>

                    <div class="report-table-wrapper">

                        <table class="report-table">

                            <thead>
                                <tr>
                                    <th>Sale ID</th>
                                    <th>Sale Date</th>
                                    <th>Customer</th>
                                    <th>Phone</th>
                                    <th>Vehicle</th>
                                    <th>Salesperson</th>
                                    <th>Sale Amount</th>
                                    <th>Paid Amount</th>
                                    <th>Balance</th>
                                    <th>Payments</th>
                                    <th>Last Payment</th>
                                    <th>Status</th>
                                </tr>
                            </thead>

                            <tbody>

                                <?php if (empty($reportRows)): ?>

                                    <tr>
                                        <td colspan="12" class="empty-report">
                                            No payment records match your filters.
                                        </td>
                                    </tr>

                                <?php else: ?>

                                    <?php foreach ($reportRows as $row): ?>

                                        <?php
                                        // Read the total sale amount.
                                        $saleAmount = (float) $row["final_amount"];

                                        // Read the total completed payments.
                                        $paidAmount = (float) $row["total_paid"];

                                        // Calculate the remaining balance.
                                        $balance = max(0, $saleAmount - $paidAmount);

                                        // Determine the payment status.
                                        if ($paidAmount <= 0) {
                                            $statusLabel = "Unpaid";
                                            $statusClass = "payment-unpaid";
                                        } elseif ($paidAmount < $saleAmount) {
                                            $statusLabel = "Partially Paid";
                                            $statusClass = "payment-partial";
                                        } else {
                                            $statusLabel = "Fully Paid";
                                            $statusClass = "payment-paid";
                                        }

                                        // Combine the vehicle details.
                                        $vehicleName = $row["year"] . " " .
                                            $row["make"] . " " .
                                            $row["model"];
                                        ?>

                                        <tr>

                                            <td>
                                                #<?= (int) $row["sale_id"] ?>
                                            </td>

                                            <td>
                                                <?= paymentReportEscape(date("d M Y", strtotime($row["sale_date"]))) ?>
                                            </td>

                                            <td>
                                                <?= paymentReportEscape($row["customer_name"]) ?>
                                            </td>

                                            <td>
                                                <?= paymentReportEscape($row["customer_phone"]) ?>
                                            </td>

                                            <td>
                                                <?= paymentReportEscape($vehicleName) ?>
                                                <br>
                                                <small>VIN: <?= paymentReportEscape($row["vin"]) ?></small>
                                            </td>

                                            <td>
                                                <?= paymentReportEscape($row["salesperson_name"]) ?>
                                            </td>

                                            <td>
                                                <?= paymentReportMoney($saleAmount) ?>
                                            </td>

                                            <td>
                                                <?= paymentReportMoney($paidAmount) ?>
                                            </td>

                                            <td>
                                                <?= paymentReportMoney($balance) ?>
                                            </td>

                                            <td>
                                                <?= (int) $row["payment_count"] ?>
                                            </td>

                                            <td>
                                                <?php if (!empty($row["last_payment_date"])): ?>
                                                    <?= paymentReportEscape(date("d M Y", strtotime($row["last_payment_date"]))) ?>
                                                <?php else: ?>
                                                    —
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <span class="payment-status <?= $statusClass ?>">
                                                    <?= paymentReportEscape($statusLabel) ?>
                                                </span>
                                            </td>

                                        </tr>

                                    <?php endforeach; ?>

                                <?php endif; ?>

                            </tbody>

                        </table>

                    </div>
                </div>

            </section>
        </main>
    </div>
</body>
</html>
