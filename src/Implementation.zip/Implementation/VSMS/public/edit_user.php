
<?php
// Load authentication and the database connection.
require_once __DIR__ . "/../includes/auth.php";

// Only Administrators can manage user accounts.
requireRole("Administrator");

$currentUser = currentUser();

if ($currentUser === null) {
    redirect("login.php");
}

// Safely display values in HTML.
function escapeEditUserHtml($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Create a CSRF token.
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION["csrf_token"];

// Validate the selected user ID.
$userId = filter_var(
    $_GET["id"] ?? $_POST["user_id"] ?? "",
    FILTER_VALIDATE_INT,
    ["options" => ["min_range" => 1]]
);

if ($userId === false) {
    http_response_code(400);
    exit("Invalid user account ID.");
}

// Initialize messages.
$errors = [];
$successMessage = "";

// Load account information.
function loadEditUserAccount(PDO $pdo, int $userId): ?array
{
    $query = $pdo->prepare(
        "SELECT
            u.user_id,
            u.full_name,
            u.username,
            u.email,
            u.status,
            u.role_id,
            r.role_name,
            e.employee_id,
            e.full_name AS employee_name
         FROM users AS u
         INNER JOIN roles AS r ON r.role_id = u.role_id
         LEFT JOIN employees AS e ON e.user_id = u.user_id
         WHERE u.user_id = ?
         LIMIT 1"
    );

    $query->execute([$userId]);

    $account = $query->fetch(PDO::FETCH_ASSOC);

    return $account ?: null;
}

try {
    $account = loadEditUserAccount($pdo, (int) $userId);
} catch (PDOException $exception) {
    error_log("VSMS edit account load error: " . $exception->getMessage());
    http_response_code(500);
    exit("The user account could not be loaded.");
}

if (!$account) {
    http_response_code(404);
    exit("The selected user account was not found.");
}

// Initial form values.
$fullName = $account["full_name"];
$email = $account["email"];
$selectedRole = $account["role_name"];
$selectedEmployeeId = $account["employee_id"] !== null
    ? (string) $account["employee_id"]
    : "";

// Process the submitted form.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $submittedToken = $_POST["csrf_token"] ?? "";
    $action = $_POST["action"] ?? "";

    // Validate the security token.
    if (
        !is_string($submittedToken) ||
        !hash_equals($csrfToken, $submittedToken)
    ) {
        $errors[] = "Invalid request. Refresh the page and try again.";

    } else {

        // ---------------------------------------------------------
        // ACTION 1: UPDATE ACCOUNT INFORMATION
        // ---------------------------------------------------------
        if ($action === "profile") {

            $nameInput = $_POST["full_name"] ?? "";
            $emailInput = $_POST["email"] ?? "";

            $fullName = is_string($nameInput) ? trim($nameInput) : "";
            $email = is_string($emailInput) ? trim($emailInput) : "";

            preg_match_all('/./us', $fullName, $nameCharacters);

            if (
                $fullName === "" ||
                count($nameCharacters[0]) > 100
            ) {
                $errors[] = "Enter a full name of no more than 100 characters.";
            }

            if (
                $email === "" ||
                !filter_var($email, FILTER_VALIDATE_EMAIL) ||
                strlen($email) > 150
            ) {
                $errors[] = "Enter a valid email address of no more than 150 characters.";
            }

            if (empty($errors)) {
                try {
                    $pdo->beginTransaction();

                    // Lock the selected account.
                    $lockQuery = $pdo->prepare(
                        "SELECT user_id
                         FROM users
                         WHERE user_id = ?
                         FOR UPDATE"
                    );

                    $lockQuery->execute([$userId]);

                    if (!$lockQuery->fetchColumn()) {
                        throw new RuntimeException("The account no longer exists.");
                    }

                    // Check for a duplicate email address.
                    $duplicateQuery = $pdo->prepare(
                        "SELECT user_id
                         FROM users
                         WHERE email = ?
                           AND user_id <> ?
                         LIMIT 1"
                    );

                    $duplicateQuery->execute([$email, $userId]);

                    if ($duplicateQuery->fetch()) {
                        throw new RuntimeException(
                            "This email address is already used by another account."
                        );
                    }

                    // Update the login account.
                    $updateUser = $pdo->prepare(
                        "UPDATE users
                         SET full_name = ?, email = ?
                         WHERE user_id = ?"
                    );

                    $updateUser->execute([
                        $fullName,
                        $email,
                        $userId
                    ]);

                    // Update the linked employee, if applicable.
                    $updateEmployee = $pdo->prepare(
                        "UPDATE employees
                         SET full_name = ?, email = ?
                         WHERE user_id = ?"
                    );

                    $updateEmployee->execute([
                        $fullName,
                        $email,
                        $userId
                    ]);

                    $pdo->commit();

                    $successMessage =
                        "Account information updated successfully.";

                } catch (RuntimeException $exception) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }

                    $errors[] = $exception->getMessage();

                } catch (PDOException $exception) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }

                    error_log("VSMS profile update error: " . $exception->getMessage());

                    $errors[] =
                        "Account information could not be updated.";
                }
            }

        // ---------------------------------------------------------
        // ACTION 2: CHANGE ACCOUNT ROLE
        // ---------------------------------------------------------
        } elseif ($action === "role") {

            $roleInput = $_POST["role_name"] ?? "";
            $employeeInput = $_POST["employee_id"] ?? "";

            $selectedRole = is_string($roleInput)
                ? trim($roleInput)
                : "";

            $selectedEmployeeId = is_string($employeeInput)
                ? trim($employeeInput)
                : "";

            $allowedRoles = [
                "Administrator",
                "Manager",
                "Salesperson"
            ];

            if (!in_array($selectedRole, $allowedRoles, true)) {
                $errors[] = "Select a valid system role.";
            }

            if ((int) $userId === (int) $currentUser["user_id"]) {
                $errors[] = "You cannot change your own system role.";
            }

            if ($selectedRole === "Salesperson") {
                if (
                    $selectedEmployeeId === "" ||
                    !ctype_digit($selectedEmployeeId) ||
                    (int) $selectedEmployeeId < 1
                ) {
                    $errors[] = "Select an eligible Salesperson employee.";
                }
            } else {
                $selectedEmployeeId = "";
            }

            if (empty($errors)) {
                try {
                    $pdo->beginTransaction();

                    // Lock the target user and read the current role.
                    $lockUser = $pdo->prepare(
                        "SELECT
                            u.user_id,
                            u.status,
                            r.role_name
                         FROM users AS u
                         INNER JOIN roles AS r ON r.role_id = u.role_id
                         WHERE u.user_id = ?
                         FOR UPDATE"
                    );

                    $lockUser->execute([$userId]);
                    $lockedUser = $lockUser->fetch(PDO::FETCH_ASSOC);

                    if (!$lockedUser) {
                        throw new RuntimeException("The account no longer exists.");
                    }

                    $oldRole = $lockedUser["role_name"];

                    // Prevent self-role changes.
                    if ((int) $userId === (int) $currentUser["user_id"]) {
                        throw new RuntimeException(
                            "You cannot change your own system role."
                        );
                    }

                    // Protect the last active Administrator.
                    if (
                        $oldRole === "Administrator" &&
                        $selectedRole !== "Administrator" &&
                        $lockedUser["status"] === "active"
                    ) {
                        $adminCount = $pdo->query(
                            "SELECT COUNT(*)
                             FROM users AS u
                             INNER JOIN roles AS r ON r.role_id = u.role_id
                             WHERE r.role_name = 'Administrator'
                               AND u.status = 'active'"
                        );

                        if ((int) $adminCount->fetchColumn() <= 1) {
                            throw new RuntimeException(
                                "You cannot change the role of the last active Administrator."
                            );
                        }
                    }

                    // Find the selected role ID.
                    $roleQuery = $pdo->prepare(
                        "SELECT role_id
                         FROM roles
                         WHERE role_name = ?
                         LIMIT 1"
                    );

                    $roleQuery->execute([$selectedRole]);
                    $newRoleId = $roleQuery->fetchColumn();

                    if (!$newRoleId) {
                        throw new RuntimeException(
                            "The selected system role was not found."
                        );
                    }

                    // Lock the currently linked employee, if any.
                    $currentEmployeeQuery = $pdo->prepare(
                        "SELECT employee_id
                         FROM employees
                         WHERE user_id = ?
                         FOR UPDATE"
                    );

                    $currentEmployeeQuery->execute([$userId]);
                    $currentEmployeeId = $currentEmployeeQuery->fetchColumn();

                    // Validate the selected employee for a Salesperson account.
                    if ($selectedRole === "Salesperson") {

                        $employeeQuery = $pdo->prepare(
                            "SELECT employee_id, position, status, user_id
                             FROM employees
                             WHERE employee_id = ?
                             FOR UPDATE"
                        );

                        $employeeQuery->execute([
                            (int) $selectedEmployeeId
                        ]);

                        $employee = $employeeQuery->fetch(PDO::FETCH_ASSOC);

                        if (!$employee) {
                            throw new RuntimeException(
                                "The selected employee was not found."
                            );
                        }

                        if (
                            $employee["position"] !== "Salesperson" ||
                            $employee["status"] !== "Active"
                        ) {
                            throw new RuntimeException(
                                "Only active Salesperson employees can be linked."
                            );
                        }

                        if (
                            $employee["user_id"] !== null &&
                            (int) $employee["user_id"] !== (int) $userId
                        ) {
                            throw new RuntimeException(
                                "This employee is already linked to another account."
                            );
                        }
                    }

                    // Update the previous employee's position to match the new account role
                    // before removing the employee-account link.
                    if ($currentEmployeeId !== false) {
                    
                        $updateEmployeePosition = $pdo->prepare(
                            "UPDATE employees
                             SET position = ?
                             WHERE employee_id = ?"
                        );
                    
                        $updateEmployeePosition->execute([
                            $selectedRole,
                            (int) $currentEmployeeId
                        ]);
                    }
                    
                    // Remove the previous employee link.
                    // The employee record itself will remain in the database.
                    $unlinkQuery = $pdo->prepare(
                        "UPDATE employees
                         SET user_id = NULL
                         WHERE user_id = ?"
                    );
                    
                    $unlinkQuery->execute([$userId]);

                    // Update the user's role.
                    $updateRole = $pdo->prepare(
                        "UPDATE users
                         SET role_id = ?
                         WHERE user_id = ?"
                    );

                    $updateRole->execute([
                        (int) $newRoleId,
                        $userId
                    ]);

                    // Link the selected employee for the Salesperson role.
                    if ($selectedRole === "Salesperson") {

                        $linkEmployee = $pdo->prepare(
                            "UPDATE employees
                             SET user_id = ?
                             WHERE employee_id = ?
                               AND user_id IS NULL
                               AND position = 'Salesperson'
                               AND status = 'Active'"
                        );

                        $linkEmployee->execute([
                            $userId,
                            (int) $selectedEmployeeId
                        ]);

                        if ($linkEmployee->rowCount() !== 1) {
                            throw new RuntimeException(
                                "The employee could not be linked. Refresh and try again."
                            );
                        }
                    }

                    $pdo->commit();

                    $successMessage =
                        "Account role changed successfully from " .
                        $oldRole . " to " . $selectedRole . ".";

                } catch (RuntimeException $exception) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }

                    $errors[] = $exception->getMessage();

                } catch (PDOException $exception) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }

                    error_log("VSMS role update error: " . $exception->getMessage());

                    $errors[] =
                        "The account role could not be changed.";
                }
            }

        // ---------------------------------------------------------
        // ACTION 3: RESET ACCOUNT PASSWORD
        // ---------------------------------------------------------
        } elseif ($action === "password") {

            $newPassword = $_POST["new_password"] ?? "";
            $confirmPassword = $_POST["confirm_password"] ?? "";

            if (
                !is_string($newPassword) ||
                !is_string($confirmPassword)
            ) {
                $errors[] = "Invalid password information.";

            } else {

                if (strlen($newPassword) < 12) {
                    $errors[] =
                        "The new password must contain at least 12 characters.";
                }

                if (strlen($newPassword) > 72) {
                    $errors[] =
                        "The new password must not exceed 72 bytes.";
                }

                if ($newPassword !== $confirmPassword) {
                    $errors[] =
                        "The new password and confirmation do not match.";
                }
            }

            if (empty($errors)) {
                try {
                    $passwordHash = password_hash(
                        $newPassword,
                        PASSWORD_DEFAULT
                    );

                    if ($passwordHash === false) {
                        throw new RuntimeException(
                            "The password could not be secured."
                        );
                    }

                    $updatePassword = $pdo->prepare(
                        "UPDATE users
                         SET password_hash = ?
                         WHERE user_id = ?"
                    );

                    $updatePassword->execute([
                        $passwordHash,
                        $userId
                    ]);

                    $successMessage =
                        "Password reset successfully. Communicate the temporary password securely to the account holder.";

                } catch (RuntimeException $exception) {
                    $errors[] = $exception->getMessage();

                } catch (PDOException $exception) {
                    error_log("VSMS password reset error: " . $exception->getMessage());

                    $errors[] =
                        "The password could not be reset. Please try again.";
                }
            }

        } else {
            $errors[] = "Invalid account-management action.";
        }
    }

    // Reload account information after the submitted action.
    try {
        $account = loadEditUserAccount($pdo, (int) $userId);

        if (!$account) {
            http_response_code(404);
            exit("The user account could not be found.");
        }

        // Keep the form values synchronized after successful updates.
        if (empty($errors)) {
            $fullName = $account["full_name"];
            $email = $account["email"];
            $selectedRole = $account["role_name"];
            $selectedEmployeeId = $account["employee_id"] !== null
                ? (string) $account["employee_id"]
                : "";
        }

    } catch (PDOException $exception) {
        error_log("VSMS account refresh error: " . $exception->getMessage());
    }
}

// Load available Salesperson employees.
$employees = [];

try {
    $employeeQuery = $pdo->prepare(
        "SELECT employee_id, full_name
         FROM employees
         WHERE position = 'Salesperson'
           AND status = 'Active'
           AND (user_id IS NULL OR user_id = ?)
         ORDER BY full_name ASC"
    );

    $employeeQuery->execute([$userId]);
    $employees = $employeeQuery->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {
    error_log("VSMS employee list error: " . $exception->getMessage());
    $errors[] = "The eligible employee list could not be loaded.";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Edit User Account | VSMS</title>

    <link rel="stylesheet" href="assets/css/dashboard.css">

    <style>
        .account-edit-page {
            padding: 28px;
        }

        .account-edit-card {
            max-width: 850px;
            background: #ffffff;
            padding: 25px;
            margin-bottom: 22px;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.04);
        }

        .account-edit-card h2 {
            margin-top: 0;
            margin-bottom: 8px;
        }

        .section-description {
            color: #687589;
            margin-bottom: 22px;
            font-size: 14px;
        }

        .account-edit-form {
            display: grid;
            gap: 17px;
        }

        .account-edit-form label {
            display: block;
            font-weight: 600;
            margin-bottom: 7px;
        }

        .account-edit-form input,
        .account-edit-form select {
            width: 100%;
            padding: 12px;
            border: 1px solid #dce1e8;
            border-radius: 7px;
            font: inherit;
        }

        .account-edit-form input[readonly] {
            background: #f2f4f7;
            color: #667085;
        }

        .account-message {
            max-width: 850px;
            padding: 14px 17px;
            margin-bottom: 18px;
            border-radius: 8px;
        }

        .account-success {
            background: #e4f5eb;
            color: #176b43;
        }

        .account-error {
            background: #fdeaea;
            color: #9b2929;
        }

        .account-note {
            color: #687589;
            font-size: 13px;
            line-height: 1.6;
        }

        .account-section-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .account-back-link {
            display: inline-block;
            margin-bottom: 20px;
            text-decoration: none;
        }

        @media (max-width: 600px) {
            .account-edit-page {
                padding: 16px;
            }

            .account-edit-card {
                padding: 17px;
            }
        }
    </style>
</head>

<body>

<div class="dashboard-layout">

    <main class="main-content">

        <div class="account-edit-page">

            <a href="users.php" class="account-back-link">
                ← Back to User Management
            </a>

            <div class="page-header">
                <div>
                    <h1>Edit User Account</h1>
                    <p>Manage account information, role and password in one place.</p>
                </div>
            </div>

            <?php if (!empty($errors)): ?>
                <div class="account-message account-error">
                    <?php foreach ($errors as $error): ?>
                        <p><?= escapeEditUserHtml($error) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($successMessage !== ""): ?>
                <div class="account-message account-success">
                    <?= escapeEditUserHtml($successMessage) ?>
                </div>
            <?php endif; ?>

            <!-- ACCOUNT INFORMATION -->
            <section class="account-edit-card">

                <h2>1. Account Information</h2>

                <p class="section-description">
                    Update the user's name and email address.
                </p>

                <form
                    method="POST"
                    action="edit_user.php?id=<?= (int) $userId ?>"
                    class="account-edit-form"
                >

                    <input type="hidden" name="csrf_token"
                        value="<?= escapeEditUserHtml($csrfToken) ?>">

                    <input type="hidden" name="user_id"
                        value="<?= (int) $userId ?>">

                    <input type="hidden" name="action" value="profile">

                    <div>
                        <label>Username</label>
                        <input type="text"
                            value="<?= escapeEditUserHtml($account["username"]) ?>"
                            readonly>
                        <p class="account-note">
                            Username cannot be changed here.
                        </p>
                    </div>

                    <div>
                        <label for="full_name">Full Name</label>
                        <input type="text"
                            id="full_name"
                            name="full_name"
                            maxlength="100"
                            value="<?= escapeEditUserHtml($fullName) ?>"
                            required>
                    </div>

                    <div>
                        <label for="email">Email Address</label>
                        <input type="email"
                            id="email"
                            name="email"
                            maxlength="150"
                            value="<?= escapeEditUserHtml($email) ?>"
                            required>
                    </div>

                    <div class="account-section-actions">
                        <button type="submit" class="btn btn-primary">
                            Save Account Information
                        </button>
                    </div>

                </form>

            </section>

            <!-- ROLE MANAGEMENT -->
            <section class="account-edit-card">

                <h2>2. System Role</h2>

                <p class="section-description">
                    Change the user's access role and manage the linked
                    employee account when the Salesperson role is selected.
                </p>

                <form
                    method="POST"
                    action="edit_user.php?id=<?= (int) $userId ?>"
                    class="account-edit-form"
                >

                    <input type="hidden" name="csrf_token"
                        value="<?= escapeEditUserHtml($csrfToken) ?>">

                    <input type="hidden" name="user_id"
                        value="<?= (int) $userId ?>">

                    <input type="hidden" name="action" value="role">

                    <div>
                        <label for="role_name">System Role</label>

                        <select name="role_name" id="role_name" required
                            <?= (int) $userId === (int) $currentUser["user_id"] ? "disabled" : "" ?>>

                            <option value="Administrator"
                                <?= $selectedRole === "Administrator" ? "selected" : "" ?>>
                                Administrator
                            </option>

                            <option value="Manager"
                                <?= $selectedRole === "Manager" ? "selected" : "" ?>>
                                Manager
                            </option>

                            <option value="Salesperson"
                                <?= $selectedRole === "Salesperson" ? "selected" : "" ?>>
                                Salesperson
                            </option>

                        </select>

                        <?php if ((int) $userId === (int) $currentUser["user_id"]): ?>
                            <p class="account-note">
                                You cannot change your own role.
                            </p>
                        <?php endif; ?>
                    </div>

                    <div id="employee-selection">

                        <label for="employee_id">
                            Link to Salesperson Employee
                        </label>

                        <select name="employee_id" id="employee_id">

                            <option value="">Select an employee</option>

                            <?php foreach ($employees as $employee): ?>
                                <option
                                    value="<?= (int) $employee["employee_id"] ?>"
                                    <?= $selectedEmployeeId === (string) $employee["employee_id"] ? "selected" : "" ?>
                                >
                                    <?= escapeEditUserHtml($employee["full_name"]) ?>
                                    (ID: <?= (int) $employee["employee_id"] ?>)
                                </option>
                            <?php endforeach; ?>

                        </select>

                        <p class="account-note">
                            Only active employees with the Salesperson
                            position and no other login account are eligible.
                        </p>

                    </div>

                    <p class="account-note">
                        Changing a Salesperson account to another role
                        removes its employee link but does not delete the
                        employee record. You cannot demote the last active
                        Administrator.
                    </p>

                    <div class="account-section-actions">
                        <button type="submit" class="btn btn-primary"
                            <?= (int) $userId === (int) $currentUser["user_id"] ? "disabled" : "" ?>>
                            Save Role Changes
                        </button>
                    </div>

                </form>

            </section>

            <!-- PASSWORD MANAGEMENT -->
            <section class="account-edit-card">

                <h2>3. Password Management</h2>

                <p class="section-description">
                    Set a new password for this user account.
                </p>

                <form
                    method="POST"
                    action="edit_user.php?id=<?= (int) $userId ?>"
                    class="account-edit-form"
                    onsubmit="return confirm('Are you sure you want to reset this user password?');"
                >

                    <input type="hidden" name="csrf_token"
                        value="<?= escapeEditUserHtml($csrfToken) ?>">

                    <input type="hidden" name="user_id"
                        value="<?= (int) $userId ?>">

                    <input type="hidden" name="action" value="password">

                    <div>
                        <label for="new_password">New Password</label>

                        <input type="password"
                            id="new_password"
                            name="new_password"
                            minlength="12"
                            maxlength="72"
                            autocomplete="new-password"
                            required>
                    </div>

                    <div>
                        <label for="confirm_password">Confirm New Password</label>

                        <input type="password"
                            id="confirm_password"
                            name="confirm_password"
                            minlength="12"
                            maxlength="72"
                            autocomplete="new-password"
                            required>
                    </div>

                    <p class="account-note">
                        The password must contain at least 12 characters.
                        Share the temporary password securely with the
                        account holder.
                    </p>

                    <div class="account-section-actions">
                        <button type="submit" class="btn btn-primary">
                            Reset User Password
                        </button>
                    </div>

                </form>

            </section>

        </div>

    </main>

</div>

<script>
    // Get the role and employee selection controls.
    const roleSelector = document.getElementById("role_name");
    const employeeSection = document.getElementById("employee-selection");
    const employeeSelector = document.getElementById("employee_id");

    // Show employee selection only for the Salesperson role.
    function updateEmployeeVisibility() {

        if (roleSelector.value === "Salesperson") {
            employeeSection.style.display = "block";
            employeeSelector.required = true;
        } else {
            employeeSection.style.display = "none";
            employeeSelector.required = false;
        }
    }

    // Update the employee section when the selected role changes.
    roleSelector.addEventListener("change", updateEmployeeVisibility);

    // Set the correct initial display.
    updateEmployeeVisibility();
</script>

</body>
</html>
