
<?php
// Start the session, connect to the database, and load authentication functions.
require_once __DIR__ . '/../includes/auth.php';

// Make sure the user is logged in before showing sales information.
requireLogin();

// Get the currently logged-in user's information.
$user = currentUser();

// Allow only the three authorized system roles to access this page.
if (
    !hasRole('Administrator') &&
    !hasRole('Manager') &&
    !hasRole('Salesperson')
) {
    http_response_code(403);
    exit('Access denied. You are not authorized to view sales.');
}

// Determine whether the logged-in user is a salesperson.
$isSalesperson = hasRole('Salesperson');

// Store the logged-in user's ID for salesperson-specific filtering.
$currentUserId = (int) $user['user_id'];

// Create a helper function to safely display database values in HTML.
function salesEscape($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

// Read the search text submitted through the search form.
$search = trim($_GET['search'] ?? '');

// Read the selected sale status.
$statusFilter = trim($_GET['status'] ?? '');

// Accept only statuses that exist in the sales table.
$allowedStatuses = ['Pending', 'Completed', 'Cancelled'];

// Ignore invalid status values.
if (!in_array($statusFilter, $allowedStatuses, true)) {
    $statusFilter = '';
}

// Prepare the base condition and parameters.
$whereConditions = [];
$queryParameters = [];

// Salespersons can view only the sales assigned to their own account.
if ($isSalesperson) {
    $whereConditions[] = 's.salesperson_id = :current_user_id';
    $queryParameters[':current_user_id'] = $currentUserId;
}

// Add the selected status to the search conditions.
if ($statusFilter !== '') {
    $whereConditions[] = 's.sale_status = :sale_status';
    $queryParameters[':sale_status'] = $statusFilter;
}

// Search by sale ID, customer, phone, vehicle, VIN, or salesperson.
if ($search !== '') {
    $whereConditions[] = "(
        CAST(s.sale_id AS CHAR) LIKE :sale_id_search
        OR c.full_name LIKE :customer_search
        OR c.phone LIKE :phone_search
        OR v.make LIKE :make_search
        OR v.model LIKE :model_search
        OR v.vin LIKE :vin_search
        OR salesperson.full_name LIKE :salesperson_search
    )";

    // Add separate named parameters for each search condition.
    $searchValue = '%' . $search . '%';

    $queryParameters[':sale_id_search'] = $searchValue;
    $queryParameters[':customer_search'] = $searchValue;
    $queryParameters[':phone_search'] = $searchValue;
    $queryParameters[':make_search'] = $searchValue;
    $queryParameters[':model_search'] = $searchValue;
    $queryParameters[':vin_search'] = $searchValue;
    $queryParameters[':salesperson_search'] = $searchValue;
}

// Combine all conditions into one SQL WHERE clause.
$whereSql = '';

if (!empty($whereConditions)) {
    $whereSql = 'WHERE ' . implode(' AND ', $whereConditions);
}

// Prepare variables for the page.
$sales = [];
$totalSales = 0;
$pendingSales = 0;
$completedSales = 0;
$cancelledSales = 0;
$totalRevenue = 0.00;
$pageError = '';

// Load the sales records from the database.
try {
    // Build the query that retrieves the sales summary.
    $summarySql = "
        SELECT
            COUNT(*) AS total_sales,
            SUM(CASE WHEN sale_status = 'Pending' THEN 1 ELSE 0 END) AS pending_sales,
            SUM(CASE WHEN sale_status = 'Completed' THEN 1 ELSE 0 END) AS completed_sales,
            SUM(CASE WHEN sale_status = 'Cancelled' THEN 1 ELSE 0 END) AS cancelled_sales,
            COALESCE(
                SUM(
                    CASE
                        WHEN sale_status = 'Completed' THEN final_amount
                        ELSE 0
                    END
                ),
                0
            ) AS total_revenue
        FROM sales
        " . ($isSalesperson ? 'WHERE salesperson_id = :summary_user_id' : '');

    // Prepare the summary query.
    $summaryStatement = $pdo->prepare($summarySql);

    // Restrict the summary to the logged-in salesperson when necessary.
    if ($isSalesperson) {
        $summaryStatement->bindValue(
            ':summary_user_id',
            $currentUserId,
            PDO::PARAM_INT
        );
    }

    // Execute the summary query.
    $summaryStatement->execute();

    // Retrieve the summary information.
    $summary = $summaryStatement->fetch(PDO::FETCH_ASSOC);

    // Store the summary values for display.
    if ($summary) {
        $totalSales = (int) $summary['total_sales'];
        $pendingSales = (int) $summary['pending_sales'];
        $completedSales = (int) $summary['completed_sales'];
        $cancelledSales = (int) $summary['cancelled_sales'];
        $totalRevenue = (float) $summary['total_revenue'];
    }

    // Build the query that retrieves individual sales records.
    $salesSql = "
        SELECT
            s.sale_id,
            s.sale_date,
            s.vehicle_price,
            s.discount_amount,
            s.additional_charges,
            s.final_amount,
            s.sale_status,

            c.customer_id,
            c.full_name AS customer_name,
            c.phone AS customer_phone,

            v.vehicle_id,
            v.make,
            v.model,
            v.year,
            v.vin,

            salesperson.user_id AS salesperson_id,
            salesperson.full_name AS salesperson_name,

            s.reservation_id,

            
            invoice.invoice_id

        FROM sales AS s

        INNER JOIN customers AS c
            ON s.customer_id = c.customer_id

        INNER JOIN vehicles AS v
            ON s.vehicle_id = v.vehicle_id

            INNER JOIN users AS salesperson
            ON s.salesperson_id = salesperson.user_id

        
        LEFT JOIN invoices AS invoice
            ON invoice.sale_id = s.sale_id

        $whereSql

        ORDER BY s.sale_date DESC, s.sale_id DESC
    ";

    // Prepare the sales query.
    $salesStatement = $pdo->prepare($salesSql);

    // Bind every search parameter securely.
    foreach ($queryParameters as $parameter => $value) {
        if ($parameter === ':current_user_id') {
            $salesStatement->bindValue(
                $parameter,
                $value,
                PDO::PARAM_INT
            );
        } else {
            $salesStatement->bindValue(
                $parameter,
                $value,
                PDO::PARAM_STR
            );
        }
    }

    // Execute the sales query.
    $salesStatement->execute();

    // Retrieve all matching sales records.
    $sales = $salesStatement->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {
    // Log the technical error without exposing database details to users.
    error_log('Sales history error: ' . $exception->getMessage());

    // Display a friendly message on the page.
    $pageError = 'Unable to load sales records. Please try again.';
}

// Build a URL that preserves the current search and filter values.
function salesFilterUrl(string $status, string $search): string
{
    // Prepare the URL parameters.
    $parameters = [];

    // Preserve the search term when it exists.
    if ($search !== '') {
        $parameters['search'] = $search;
    }

    // Add the selected status when it exists.
    if ($status !== '') {
        $parameters['status'] = $status;
    }

    // Return the URL with safely encoded query parameters.
    return 'sales.php' . (
        empty($parameters) ? '' : '?' . http_build_query($parameters)
    );
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Define the character encoding and responsive page settings. -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Sales History | VSMS</title>

    <!-- Reuse the existing dashboard and vehicle stylesheets. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <!-- Add styles specific to the sales history page. -->
    <style>
        .sales-page {
            padding: 24px;
            color: #263445;
        }

        .sales-page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
            margin-bottom: 24px;
        }

        .sales-page-header h1 {
            margin: 0 0 6px;
            font-size: 25px;
        }

        .sales-page-header p {
            margin: 0;
            color: #748091;
        }

        .sales-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .sales-button {
            display: inline-block;
            padding: 10px 16px;
            border: none;
            border-radius: 7px;
            background: #f47755;
            color: #ffffff;
            text-decoration: none;
            font-weight: 600;
            cursor: pointer;
        }

        .sales-button:hover {
            background: #df6546;
            color: #ffffff;
        }

        .sales-button-secondary {
            background: #263b56;
        }

        .sales-button-secondary:hover {
            background: #1b2d43;
        }

        .sales-summary {
            display: grid;
            grid-template-columns: repeat(5, minmax(140px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }

        .sales-summary-card {
            background: #ffffff;
            border: 1px solid #e7ebf0;
            border-radius: 10px;
            padding: 18px;
            box-shadow: 0 2px 8px rgba(25, 42, 62, 0.04);
        }

        .sales-summary-card span {
            display: block;
            margin-bottom: 8px;
            color: #748091;
            font-size: 13px;
        }

        .sales-summary-card strong {
            font-size: 23px;
            color: #263b56;
        }

        .sales-filters {
            display: flex;
            align-items: end;
            gap: 12px;
            flex-wrap: wrap;
            background: #ffffff;
            padding: 18px;
            border: 1px solid #e7ebf0;
            border-radius: 10px;
            margin-bottom: 18px;
        }

        .sales-filter-field {
            display: flex;
            flex-direction: column;
            gap: 7px;
            flex: 1;
            min-width: 180px;
        }

        .sales-filter-field label {
            font-size: 13px;
            font-weight: 600;
        }

        .sales-filter-field input,
        .sales-filter-field select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #dce2e9;
            border-radius: 6px;
            background: #ffffff;
        }

        .sales-table-container {
            overflow-x: auto;
            background: #ffffff;
            border: 1px solid #e7ebf0;
            border-radius: 10px;
        }

        .sales-table {
            width: 100%;
            min-width: 1100px;
            border-collapse: collapse;
        }

        .sales-table th,
        .sales-table td {
            padding: 13px 14px;
            text-align: left;
            border-bottom: 1px solid #edf0f4;
            vertical-align: middle;
        }

        .sales-table th {
            background: #f7f8fa;
            color: #596779;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.35px;
        }

        .sales-table td {
            font-size: 13px;
        }

        .sales-table tbody tr:hover {
            background: #fafbfd;
        }

        .sales-status {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
        }

        .sales-status-pending {
            background: #fff1d6;
            color: #986300;
        }

        .sales-status-completed {
            background: #dff5e8;
            color: #197344;
        }

        .sales-status-cancelled {
            background: #fde5e5;
            color: #b33b3b;
        }

        .sales-row-action {
            color: #e66e4e;
            font-weight: 600;
            text-decoration: none;
            white-space: nowrap;
        }

        .sales-row-action:hover {
            text-decoration: underline;
        }

        .sales-empty,
        .sales-error {
            padding: 28px;
            text-align: center;
            color: #748091;
        }

        .sales-error {
            margin-bottom: 18px;
            background: #fff0f0;
            color: #a52c2c;
            border-radius: 8px;
        }

        .sales-results-info {
            margin: 0 0 12px;
            color: #748091;
            font-size: 13px;
        }

        @media (max-width: 1100px) {
            .sales-summary {
                grid-template-columns: repeat(3, minmax(140px, 1fr));
            }
        }

        @media (max-width: 650px) {
            .sales-page {
                padding: 14px;
            }

            .sales-summary {
                grid-template-columns: repeat(2, minmax(120px, 1fr));
            }

            .sales-summary-card strong {
                font-size: 19px;
            }
        }
    </style>
</head>

<body>

<!-- Create the shared dashboard layout for the sidebar and page content. -->
<div class="dashboard-layout">

    <!-- Start the left navigation sidebar. -->
    <aside class="sidebar">

        <!-- Display the VSMS brand. -->
        <div class="brand">
                <div class="brand-logo">V</div>
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>
            </div>

        <!-- Display the navigation links. -->
        <nav class="sidebar-navigation">

            <p class="navigation-heading">MAIN MENU</p>

            <!-- Dashboard navigation. -->
            <a href="dashboard.php" class="nav-link">
                <span class="nav-icon">▦</span>
                <span>Dashboard</span>
            </a>

            <!-- Vehicle navigation. -->
            <a href="vehicles.php" class="nav-link">
                <span class="nav-icon">🚘</span>
                <span>Vehicles</span>
            </a>

            <!-- Customer navigation. -->
            <a href="customers.php" class="nav-link">
                <span class="nav-icon">♙</span>
                <span>Customers</span>
            </a>

            <!-- Reservation navigation. -->
            <a href="reservations.php" class="nav-link">
                <span class="nav-icon">▣</span>
                <span>Reservations</span>
            </a>

            <!-- Highlight Sales as the current page. -->
            <a href="sales.php" class="nav-link active">
                <span class="nav-icon">▤</span>
                <span>Sales</span>
            </a>

            <!-- Payment navigation. -->
            <a href="payments.php" class="nav-link">
                <span class="nav-icon">$</span>
                <span>Payments</span>
            </a>
            <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
    <span class="nav-icon">◷</span>
    <span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
    <span class="nav-icon">▧</span>
    <span>Invoices</span>
</a>

            <!-- Show Employees to Administrators and Managers only. -->
            <?php if (hasRole('Administrator') || hasRole('Manager')): ?>
                <a href="employees.php" class="nav-link">
                    <span class="nav-icon">♧</span>
                    <span>Employees</span>
                </a>
            <?php endif; ?>
            <?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
    <span class="nav-icon">♙</span>
    <span>User Accounts</span>
</a>

<?php endif; ?>

            <!-- Show Reports to Administrators and Managers only. -->
            <?php if (hasRole('Administrator') || hasRole('Manager')): ?>
                <a href="reports.php" class="nav-link">
                    <span class="nav-icon">▥</span>
                    <span>Reports</span>
                </a>
            <?php endif; ?>

        </nav>
        <div class="sidebar-footer">
                <p>Vehicle Sales &amp; Management System</p>
                <span>Development version</span>
            </div>

    </aside>

    <!-- Start the main content area beside the sidebar. -->
    <main class="main-content">

        <!-- Main sales history page container. -->
        <div class="sales-page">

    <!-- Page heading and navigation actions. -->
    <div class="sales-page-header">
        <div>
            <h1>Sales History</h1>
            <p>View, search, and manage vehicle sales records.</p>
        </div>

        <div class="sales-actions">
            <!-- Provide a shortcut to register a new sale. -->
            <a href="add_sale.php" class="sales-button">
                + Add New Sale
            </a>

            <!-- Provide a shortcut back to the dashboard. -->
            <a href="dashboard.php" class="sales-button sales-button-secondary">
                Dashboard
            </a>
        </div>
    </div>

    <!-- Display the sales summary cards. -->
    <div class="sales-summary">

        <div class="sales-summary-card">
            <span>Total Sales</span>
            <strong><?= number_format($totalSales) ?></strong>
        </div>

        <div class="sales-summary-card">
            <span>Pending Sales</span>
            <strong><?= number_format($pendingSales) ?></strong>
        </div>

        <div class="sales-summary-card">
            <span>Completed Sales</span>
            <strong><?= number_format($completedSales) ?></strong>
        </div>

        <div class="sales-summary-card">
            <span>Cancelled Sales</span>
            <strong><?= number_format($cancelledSales) ?></strong>
        </div>

        <div class="sales-summary-card">
            <span>Completed Revenue</span>
            <strong>$<?= number_format($totalRevenue, 2) ?></strong>
        </div>

    </div>

    <!-- Display a friendly error if the database query fails. -->
    <?php if ($pageError !== ''): ?>
        <div class="sales-error">
            <?= salesEscape($pageError) ?>
        </div>
    <?php endif; ?>

    <!-- Search and status filter form. -->
    <form method="GET" action="sales.php" class="sales-filters">

        <div class="sales-filter-field">
            <label for="search">Search Sales</label>

            <input
                type="text"
                id="search"
                name="search"
                value="<?= salesEscape($search) ?>"
                placeholder="Sale ID, customer, phone, vehicle, VIN..."
            >
        </div>

        <div class="sales-filter-field">
            <label for="status">Sale Status</label>

            <select id="status" name="status">
                <option value="">All Statuses</option>

                <option
                    value="Pending"
                    <?= $statusFilter === 'Pending' ? 'selected' : '' ?>
                >
                    Pending
                </option>

                <option
                    value="Completed"
                    <?= $statusFilter === 'Completed' ? 'selected' : '' ?>
                >
                    Completed
                </option>

                <option
                    value="Cancelled"
                    <?= $statusFilter === 'Cancelled' ? 'selected' : '' ?>
                >
                    Cancelled
                </option>
            </select>
        </div>

        <!-- Submit the search and filter values. -->
        <button type="submit" class="sales-button">
            Search
        </button>

        <!-- Clear all search and filter values. -->
        <a href="sales.php" class="sales-button sales-button-secondary">
            Reset
        </a>

    </form>

    <!-- Display the number of records matching the current filters. -->
    <p class="sales-results-info">
        Showing <?= number_format(count($sales)) ?> matching sales record(s).
    </p>

    <!-- Sales records table. -->
    <div class="sales-table-container">

        <table class="sales-table">

            <thead>
                <tr>
                    <th>Sale ID</th>
                    <th>Sale Date</th>
                    <th>Customer</th>
                    <th>Vehicle</th>
                    <th>Salesperson</th>
                    <th>Final Amount</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>

                <!-- Display each matching sale as a table row. -->
                <?php if (!empty($sales)): ?>

                    <?php foreach ($sales as $sale): ?>

                        <?php
                        // Select a CSS class based on the sale status.
                        $statusClass = match ($sale['sale_status']) {
                            'Pending' => 'sales-status-pending',
                            'Completed' => 'sales-status-completed',
                            'Cancelled' => 'sales-status-cancelled',
                            default => ''
                        };
                        ?>

                        <tr>

                            <!-- Display the unique sale ID. -->
                            <td>
                                #<?= (int) $sale['sale_id'] ?>
                            </td>

                            <!-- Display the sale date. -->
                            <td>
                                <?= salesEscape(
                                    date('d M Y, h:i A', strtotime($sale['sale_date']))
                                ) ?>
                            </td>

                            <!-- Display the customer name and phone. -->
                            <td>
                                <strong>
                                    <?= salesEscape($sale['customer_name']) ?>
                                </strong>
                                <br>
                                <small>
                                    <?= salesEscape($sale['customer_phone']) ?>
                                </small>
                            </td>

                            <!-- Display vehicle information. -->
                            <td>
                                <strong>
                                    <?= salesEscape(
                                        $sale['year'] . ' ' .
                                        $sale['make'] . ' ' .
                                        $sale['model']
                                    ) ?>
                                </strong>
                                <br>
                                <small>
                                    VIN: <?= salesEscape($sale['vin']) ?>
                                </small>
                            </td>

                            <!-- Display the responsible salesperson. -->
                            <td>
                                <?= salesEscape($sale['salesperson_name']) ?>
                            </td>

                            <!-- Display the final sale amount. -->
                            <td>
                                <strong>
                                    $<?= number_format(
                                        (float) $sale['final_amount'],
                                        2
                                    ) ?>
                                </strong>
                            </td>

                            <!-- Display the current sale status. -->
                            <td>
                                <span class="sales-status <?= $statusClass ?>">
                                    <?= salesEscape($sale['sale_status']) ?>
                                </span>
                            </td>

                           
                            <!-- Show the correct action according to the sale status. -->
                            <td>

                                <?php if ($sale['sale_status'] === 'Pending'): ?>

                                    <!-- Allow authorized users to complete pending sales. -->
                                    <a
                                        href="complete_sale.php?id=<?= (int) $sale['sale_id'] ?>"
                                        class="sales-row-action"
                                    >
                                        Complete Sale
                                    </a>

                                <?php elseif ($sale['sale_status'] === 'Completed'): ?>

                                    <?php if (!empty($sale['invoice_id'])): ?>

                                        <!-- Open the existing invoice without generating another one. -->
                                        <a
                                            href="generate_invoice.php?invoice_id=<?= (int) $sale['invoice_id'] ?>"
                                            class="sales-row-action"
                                        >
                                            View Invoice
                                        </a>

                                    <?php else: ?>

                                        <!-- Generate an invoice for this completed sale. -->
                                        <a
                                            href="generate_invoice.php?sale_id=<?= (int) $sale['sale_id'] ?>"
                                            class="sales-row-action"
                                        >
                                            Generate Invoice
                                        </a>

                                    <?php endif; ?>

                                <?php else: ?>

                                    <!-- Cancelled sales cannot generate invoices. -->
                                    <span>Cancelled</span>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <!-- Show this message when no records match the search. -->
                    <tr>
                        <td colspan="8" class="sales-empty">
                            No sales records found.
                            Try changing your search or status filter.
                        </td>
                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

        </div>
        <!-- Close the sales-page container. -->

    </main>
    <!-- Close the main content area. -->

</div>
<!-- Close the shared dashboard layout. -->

</body>
</html>
