
<?php
// Load authentication, session handling, and the database connection.
require_once __DIR__ . "/../includes/auth.php";

// Only Administrators can access User Management.
requireRole("Administrator");

// Retrieve the authenticated Administrator's information.
$currentUser = currentUser();

// Redirect if the account is unavailable.
if ($currentUser === null) {
    redirect("login.php");
}
// Safely convert database values into HTML text.
function escapeUserHtml($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// Create a CSRF token if the session does not already contain one.
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Keep the CSRF token available for the forms.
$csrfToken = $_SESSION["csrf_token"];

// Initialize the page message.
$message = "";

// Process account activation or deactivation requests.
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Only Administrators can change account statuses.
    if ($currentUser["role_name"] !== "Administrator") {

        // Return the HTTP 403 Forbidden status.
        http_response_code(403);

        // Stop the unauthorized request.
        exit("Access denied. Only Administrators can manage account statuses.");
    }

    // Read the submitted security token.
    $submittedToken = $_POST["csrf_token"] ?? "";

    // Read the requested user ID.
    $targetUserId = filter_var(
        $_POST["user_id"] ?? "",
        FILTER_VALIDATE_INT,
        ["options" => ["min_range" => 1]]
    );

    // Read the requested account status.
    $newStatus = $_POST["new_status"] ?? "";

    // Verify the security token before changing an account.
    if (
        !is_string($submittedToken) ||
        !hash_equals($csrfToken, $submittedToken)
    ) {
        $message = "Invalid request. Please refresh the page and try again.";

    // Accept only the two account statuses supported by the database.
    } elseif (
        $targetUserId === false ||
        !in_array($newStatus, ["active", "inactive"], true)
    ) {
        $message = "Invalid account information.";

    } else {

        try {
            // Retrieve the target account and its assigned role.
            $targetQuery = $pdo->prepare(
                "SELECT u.user_id, u.status, r.role_name
                 FROM users AS u
                 INNER JOIN roles AS r ON r.role_id = u.role_id
                 WHERE u.user_id = ?
                 LIMIT 1"
            );

            // Execute the query for the selected account.
            $targetQuery->execute([$targetUserId]);

            // Store the selected account information.
            $targetUser = $targetQuery->fetch(PDO::FETCH_ASSOC);

            // Check that the requested account exists.
            if (!$targetUser) {
                $message = "The selected user account was not found.";

            // Prevent the Administrator from deactivating their own account.
            } elseif (
                (int) $targetUserId === (int) $currentUser["user_id"] &&
                $newStatus === "inactive"
            ) {
                $message = "You cannot deactivate your own account.";

            } else {

                // Check whether this action would deactivate the last active Administrator.
                $isLastAdministrator = false;

                if (
                    $targetUser["role_name"] === "Administrator" &&
                    $targetUser["status"] === "active" &&
                    $newStatus === "inactive"
                ) {
                    // Count the currently active Administrator accounts.
                    $adminCountQuery = $pdo->query(
                        "SELECT COUNT(*)
                         FROM users AS u
                         INNER JOIN roles AS r ON r.role_id = u.role_id
                         WHERE r.role_name = 'Administrator'
                           AND u.status = 'active'"
                    );

                    // Mark the account as protected if only one remains.
                    $isLastAdministrator =
                        (int) $adminCountQuery->fetchColumn() <= 1;
                }

                // Do not deactivate the last active Administrator.
                if ($isLastAdministrator) {
                    $message =
                        "You cannot deactivate the last active Administrator.";

                } else {
                    // Update the account status using a prepared statement.
                    $updateQuery = $pdo->prepare(
                        "UPDATE users
                         SET status = ?
                         WHERE user_id = ?"
                    );

                    // Execute the account status update.
                    $updateQuery->execute([$newStatus, $targetUserId]);

                    // Prepare a confirmation message.
                    $message = "The user account status was updated successfully.";
                }
            }

        } catch (PDOException $exception) {
            // Record the technical error privately.
            error_log("VSMS user status update error: " . $exception->getMessage());

            // Show a safe message to the user.
            $message = "The account status could not be updated. Please try again.";
        }
    }
}

// Read the search text from the URL.
$search = trim($_GET["search"] ?? "");

// Read the selected status filter.
$statusFilter = trim($_GET["status"] ?? "");
// Retrieve user accounts together with any linked employee record.
$sql = "
    SELECT
        u.user_id,
        u.full_name,
        u.username,
        u.email,
        u.status,
        u.created_at,
        r.role_name,
        e.employee_id,
        e.full_name AS employee_name,
        e.position AS employee_position
    FROM users AS u
    INNER JOIN roles AS r
        ON r.role_id = u.role_id
    LEFT JOIN employees AS e
        ON e.user_id = u.user_id
";

// Store the query conditions separately.
$conditions = [];

// Store the values for the prepared SQL query.
$parameters = [];

// Search by name, username, or email when search text is provided.
if ($search !== "") {
    $conditions[] = "(
    u.full_name LIKE ?
    OR u.username LIKE ?
    OR u.email LIKE ?
    OR e.full_name LIKE ?
)";

    // Add the search value for all three search fields.
    $searchValue = "%" . $search . "%";
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
    $parameters[] = $searchValue;
}

// Apply the account status filter when it is valid.
if (in_array($statusFilter, ["active", "inactive"], true)) {
    $conditions[] = "u.status = ?";
    $parameters[] = $statusFilter;
}

// Add the conditions to the query when filters are selected.
if (!empty($conditions)) {
    $sql .= " WHERE " . implode(" AND ", $conditions);
}

// Show the newest accounts first.
$sql .= " ORDER BY u.created_at DESC, u.user_id DESC";

// Initialize the account list.
$users = [];

// Retrieve the user accounts.
try {
    // Prepare the user directory query.
    $userQuery = $pdo->prepare($sql);

    // Execute it using the search and filter values.
    $userQuery->execute($parameters);

    // Fetch all matching user accounts.
    $users = $userQuery->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {
    // Record database details in the server error log.
    error_log("VSMS user directory error: " . $exception->getMessage());

    // Show a safe page message.
    $message = "User accounts could not be loaded.";
}

// Safely prepare the current Administrator's name.
$currentName = escapeUserHtml($currentUser["full_name"]);

?>
<!DOCTYPE html>
<!-- Tell the browser that this is an HTML5 page. -->
<html lang="en">

<head>
    <!-- Set the character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on different devices. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>User Management | VSMS</title>

    <!-- Load the existing dashboard styles. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Load the existing table and button styles. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <style>
        /* Give the user page a consistent content layout. */
        .user-page {
            padding: 28px;
        }

        /* Arrange the page heading and action buttons. */
        .user-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
            margin-bottom: 22px;
        }

        /* Style the user management content card. */
        .user-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 22px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.04);
        }

        /* Arrange the search and filter controls. */
        .user-filter {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        /* Style the search box and status selector. */
        .user-filter input,
        .user-filter select {
            min-height: 42px;
            padding: 9px 12px;
            border: 1px solid #d8dee8;
            border-radius: 7px;
            font: inherit;
        }

        /* Keep the user table horizontally scrollable on small screens. */
        .user-table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        /* Make the user table fill the available space. */
        .user-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 760px;
        }

        /* Add spacing and separators to table cells. */
        .user-table th,
        .user-table td {
            padding: 13px 12px;
            text-align: left;
            border-bottom: 1px solid #e8ebf0;
        }

        /* Give the table headings a light background. */
        .user-table th {
            background: #f5f7fa;
            color: #26364b;
        }

        /* Show account status as a rounded label. */
        .user-status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        /* Identify active accounts. */
        .user-status-active {
            background: #e3f7eb;
            color: #16743c;
        }

        /* Identify inactive accounts. */
        .user-status-inactive {
            background: #edf0f4;
            color: #596579;
        }

        /* Style the action links and buttons. */
        .user-action {
            display: inline-block;
            border: 0;
            border-radius: 6px;
            padding: 7px 11px;
            margin: 2px;
            text-decoration: none;
            font: inherit;
            font-size: 13px;
            cursor: pointer;
        }

        /* Style the edit action. */
        .user-edit {
            background: #e8efff;
            color: #244f9b;
        }

        /* Style the activation action. */
        .user-activate {
            background: #e3f7eb;
            color: #16743c;
        }

        /* Style the deactivation action. */
        .user-deactivate {
            background: #fff0ed;
            color: #b33d2e;
        }

        /* Style the page message. */
        .user-message {
            background: #fff7e5;
            color: #76520c;
            padding: 12px 15px;
            border-radius: 7px;
            margin-bottom: 18px;
        }

        /* Style the primary page links. */
        .user-primary-link {
            display: inline-block;
            background: #ef765f;
            color: #ffffff;
            padding: 10px 15px;
            border-radius: 7px;
            text-decoration: none;
            font-weight: 600;
        }

        /* Add a hover effect to primary links. */
        .user-primary-link:hover {
            background: #d95f49;
        }

        /* Improve the layout on narrow screens. */
        @media (max-width: 650px) {
            .user-page {
                padding: 16px;
            }

            .user-filter {
                flex-direction: column;
            }

            .user-filter input,
            .user-filter select {
                width: 100%;
            }
        }
        /* Style the linked employee name. */
.user-employee-link {
    display: block;
    color: #244f9b;
    font-weight: 600;
    text-decoration: none;
}

/* Add a hover effect to the employee link. */
.user-employee-link:hover {
    color: #e56b45;
    text-decoration: underline;
}

/* Display the employee's position below their name. */
.user-employee-position {
    display: block;
    margin-top: 4px;
    color: #718096;
    font-size: 12px;
}

/* Make unlinked accounts easy to identify. */
.user-not-linked {
    color: #8a94a6;
    font-size: 13px;
    font-style: italic;
}
    </style>
</head>

<body>
    <!-- Create the main dashboard layout. -->
    <div class="dashboard-layout">

        <!-- Display the existing VSMS sidebar. -->
        <aside class="sidebar">

            <!-- Display the system logo and name. -->
            <div class="brand">

                <!-- Display the short system name inside a logo box. -->
                <div class="brand-logo">V</div>

                <!-- Display the full system name. -->
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>

            <!-- Close the brand section. -->
            </div>

            <!-- Display the main sidebar navigation. -->
            

<!-- Display all available system navigation links. -->
            <nav class="sidebar-navigation">

                <!-- Display the navigation section heading. -->
                <p class="navigation-heading">MAIN MENU</p>

                <!-- Link to the Dashboard. -->
                <a href="dashboard.php" class="nav-link ">
                    <span class="nav-icon">▦</span>
                    <span>Dashboard</span>
                </a>

                <!-- Link to Vehicle Management. -->
                <a href="vehicles.php" class="nav-link">
                    <span class="nav-icon">🚘</span>
                    <span>Vehicles</span>
                </a>

                <!-- Link to Customer Management. -->
                <a href="customers.php" class="nav-link">
                    <span class="nav-icon">♙</span>
                    <span>Customers</span>
                </a>

                <!-- Link to Reservation Management. -->
                <a href="reservations.php" class="nav-link">
                    <span class="nav-icon">▣</span>
                    <span>Reservations</span>
                </a>

                <!-- Link to Sales Management. -->
                <a href="sales.php" class="nav-link">
                    <span class="nav-icon">▤</span>
                    <span>Sales</span>
                </a>

                <!-- Link to Payment Management. -->
                <a href="payments.php" class="nav-link">
                    <span class="nav-icon">$</span>
                    <span>Payments</span>
                </a>
                <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
    <span class="nav-icon">◷</span>
    <span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
    <span class="nav-icon">▧</span>
    <span>Invoices</span>
</a>

                <!-- Show employee management only to authorized management roles. -->
                <?php if (in_array($currentUser["role_name"], ["Administrator", "Manager"], true)): ?>

                    <a href="employees.php" class="nav-link">
                        <span class="nav-icon">♧</span>
                        <span>Employees</span>
                    </a>

                <?php endif; ?>
                <!-- Only Administrators can access User Account Management. -->
<?php if ($currentUser["role_name"] === "Administrator"): ?>

    <a href="users.php" class="nav-link active">
        <span class="nav-icon">♙</span>
        <span>User Accounts</span>
    </a>

<?php endif; ?>

                <!-- Show reports only to authorized management roles. -->
                <?php if (in_array($currentUser["role_name"], ["Administrator", "Manager"], true)): ?>

                    <a href="reports.php" class="nav-link">
                        <span class="nav-icon">▥</span>
                        <span>Reports</span>
                    </a>

                <?php endif; ?>

            <!-- Close the navigation section. -->
            </nav>


            <!-- Display a short project description at the bottom of the sidebar. -->
            <div class="sidebar-footer">
                <p>Vehicle Sales &amp; Management System</p>
                <span>Development version</span>
            </div>

        <!-- Close the sidebar. -->
        </aside>


        <!-- Create the main page content area. -->
        <main class="main-content">

            <!-- Display the user management workspace. -->
            <section class="user-page">

                <!-- Display the page title and account creation links. -->
                <div class="user-heading">
                    <div>
                        <h1>User Management</h1>
                        <p>Manage system login accounts and access status.</p>
                    </div>

                    <!-- Link to the new Administrator and Manager account form. -->
                    <a href="create_salesperson_account.php" class="user-primary-link">
    + Create Login Account
</a>
                </div>

                <!-- Display a message after an account operation. -->
                <?php if ($message !== ""): ?>
                    <div class="user-message">
                        <?= escapeUserHtml($message) ?>
                    </div>
                <?php endif; ?>

                <!-- Display the account directory. -->
                <div class="user-card">

                    <!-- Provide search and status filtering. -->
                    <form method="GET" action="users.php" class="user-filter">

                        <!-- Search by full name, username, or email. -->
                        <input
                            type="text"
                            name="search"
                            placeholder="Search name, username, or email"
                            value="<?= escapeUserHtml($search) ?>"
                        >

                        <!-- Filter accounts by their current status. -->
                        <select name="status">
                            <option value="">All statuses</option>
                            <option value="active" <?= $statusFilter === "active" ? "selected" : "" ?>>
                                Active
                            </option>
                            <option value="inactive" <?= $statusFilter === "inactive" ? "selected" : "" ?>>
                                Inactive
                            </option>
                        </select>

                        <!-- Submit the search and filter values. -->
                        <button type="submit" class="user-action user-edit">
                            Search
                        </button>

                        <!-- Clear all search filters. -->
                        <a href="users.php" class="user-action user-edit">
                            Reset
                        </a>

                    </form>

                    <!-- Make the table scroll horizontally when needed. -->
                    <div class="user-table-wrapper">

                        <!-- Display the user account records. -->
                        <table class="user-table">

                            <!-- Define the table headings. -->
                            <thead>
                            <tr>
    <th>ID</th>
    <th>Full Name</th>
    <th>Username</th>
    <th>Email</th>
    <th>Role</th>
    <th>Employee</th>
    <th>Status</th>
    <th>Actions</th>
</tr>
                            </thead>

                            <!-- Display the account records. -->
                            <tbody>

                                <?php if (empty($users)): ?>

                                    <!-- Display a message when no accounts match. -->
                                    <tr>
                                        <td colspan="8">No user accounts were found.</td>
                                    </tr>

                                <?php else: ?>

                                    <!-- Display each matching user account. -->
                                    <?php foreach ($users as $account): ?>

                                        <tr>
                                            <td><?= (int) $account["user_id"] ?></td>

                                            <td>
                                                <?= escapeUserHtml($account["full_name"]) ?>
                                            </td>

                                            <td>
                                                <?= escapeUserHtml($account["username"]) ?>
                                            </td>

                                            <td>
                                                <?= escapeUserHtml($account["email"]) ?>
                                            </td>

                                            <td>
                                                <?= escapeUserHtml($account["role_name"]) ?>
                                            </td>
                                            <!-- Show the employee linked to this login account, if any. -->
<td>
    <?php if (!empty($account["employee_id"])): ?>

        <a
            href="employee_details.php?id=<?= (int) $account["employee_id"] ?>"
            class="user-employee-link"
        >
            <?= escapeUserHtml($account["employee_name"]) ?>
        </a>

        <small class="user-employee-position">
            <?= escapeUserHtml($account["employee_position"]) ?>
        </small>

    <?php else: ?>

        <span class="user-not-linked">Not linked</span>

    <?php endif; ?>
</td>

                                            <td>
                                                <span class="user-status user-status-<?= escapeUserHtml($account["status"]) ?>">
                                                    <?= escapeUserHtml(ucfirst($account["status"])) ?>
                                                </span>
                                            </td>

                                            <td>

                                            <!-- Open the selected account's edit page. -->
<a
    href="edit_user.php?id=<?= (int) $account["user_id"] ?>"
    class="user-action user-edit"
>
    Edit
</a>
<!-- Open the selected account's role-management page. -->


                                                <!-- Submit an account status change securely. -->
                                                <form
                                                    method="POST"
                                                    action="users.php"
                                                    style="display:inline;"
                                                    onsubmit="return confirm('Are you sure you want to change this account status?');"
                                                >

                                                    <!-- Send the CSRF token for request verification. -->
                                                    <input
                                                        type="hidden"
                                                        name="csrf_token"
                                                        value="<?= escapeUserHtml($csrfToken) ?>"
                                                    >

                                                    <!-- Identify the account being changed. -->
                                                    <input
                                                        type="hidden"
                                                        name="user_id"
                                                        value="<?= (int) $account["user_id"] ?>"
                                                    >

                                                    <!-- Choose the opposite of the current status. -->
                                                    <input
                                                        type="hidden"
                                                        name="new_status"
                                                        value="<?= $account["status"] === "active" ? "inactive" : "active" ?>"
                                                    >

                                                    <!-- Display the appropriate status action. -->
                                                    <?php if ($account["status"] === "active"): ?>

                                                        <button
                                                            type="submit"
                                                            class="user-action user-deactivate"
                                                        >
                                                            Deactivate
                                                        </button>

                                                    <?php else: ?>

                                                        <button
                                                            type="submit"
                                                            class="user-action user-activate"
                                                        >
                                                            Activate
                                                        </button>

                                                    <?php endif; ?>

                                                </form>

                                            </td>
                                        </tr>

                                    <?php endforeach; ?>

                                <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </main>
    </div>
</body>
</html>
