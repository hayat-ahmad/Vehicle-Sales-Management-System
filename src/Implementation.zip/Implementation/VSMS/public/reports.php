
<?php
// Load authentication functions and the database connection.
require_once __DIR__ . "/../includes/auth.php";

// Ensure that the visitor is logged in.
requireLogin();

// Retrieve the current logged-in user's information.
$user = currentUser();

// Allow only Administrators and Managers to access reports.
if (!hasRole("Administrator") && !hasRole("Manager")) {
    http_response_code(403);
    exit("Access denied. You do not have permission to view reports.");
}

// If the account is no longer active, return the user to login.
if ($user === null) {
    redirect("login.php");
}

// Safely prepare the user's name for display.
$fullName = htmlspecialchars($user["full_name"], ENT_QUOTES, "UTF-8");

// Safely prepare the user's role for display.
$roleName = htmlspecialchars($user["role_name"], ENT_QUOTES, "UTF-8");

// Safely prepare the session CSRF token for the logout form.
$csrfToken = htmlspecialchars($_SESSION["csrf_token"] ?? "", ENT_QUOTES, "UTF-8");

// Define the five reports already implemented in the system.
$reports = [
    [
        "number" => "01",
        "icon" => "🚘",
        "title" => "Vehicle Inventory Report",
        "description" => "Review vehicle inventory, availability, reservations, sales status, and registration dates.",
        "file" => "inventory_report.php",
        "category" => "INVENTORY"
    ],
    [
        "number" => "02",
        "icon" => "📊",
        "title" => "Sales Report",
        "description" => "Review sales records, completed revenue, discounts, additional charges, and sales status.",
        "file" => "sales_report.php",
        "category" => "SALES"
    ],
    [
        "number" => "03",
        "icon" => "👥",
        "title" => "Customer Purchase History",
        "description" => "Explore completed customer purchases, purchased vehicles, purchase values, and payment balances.",
        "file" => "customer_report.php",
        "category" => "CUSTOMERS"
    ],
    [
        "number" => "04",
        "icon" => "💳",
        "title" => "Payments and Outstanding Balances",
        "description" => "Monitor completed payments, unpaid sales, partial payments, and outstanding balances.",
        "file" => "payments_report.php",
        "category" => "FINANCE"
    ],
    [
        "number" => "05",
        "icon" => "🏆",
        "title" => "Salesperson Performance",
        "description" => "Compare salesperson performance using completed sales, revenue, average sale value, and discounts.",
        "file" => "salesperson_performance_report.php",
        "category" => "PERFORMANCE"
    ]
];

?>

<!DOCTYPE html>
<!-- Declare the document as HTML5. -->
<html lang="en">

<head>
    <!-- Set the document character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive on different screen sizes. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Reports Overview | VSMS</title>

    <!-- Load the existing dashboard stylesheet. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Load the existing vehicle stylesheet for shared page components. -->
    <link rel="stylesheet" href="assets/css/vehicles.css">

    <!-- Add styling specifically for the reports overview page. -->
    <style>
        /* Arrange the report cards in a responsive grid. */
        .reports-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 22px;
            margin-top: 25px;
        }

        /* Style each individual report card. */
        .report-card {
            background: #ffffff;
            border: 1px solid #e6eaf0;
            border-radius: 14px;
            padding: 24px;
            display: flex;
            flex-direction: column;
            min-height: 245px;
            box-shadow: 0 3px 12px rgba(20, 35, 60, 0.04);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        /* Add a small hover effect to report cards. */
        .report-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 22px rgba(20, 35, 60, 0.09);
        }

        /* Arrange the report number and icon. */
        .report-card-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 18px;
        }

        /* Style the report number. */
        .report-number {
            color: #8a94a6;
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 1px;
        }

        /* Style the report icon container. */
        .report-icon {
            width: 46px;
            height: 46px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #fff1ec;
            border-radius: 12px;
            font-size: 23px;
        }

        /* Style the report category label. */
        .report-category {
            color: #e56b4b;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 1px;
            margin-bottom: 9px;
        }

        /* Style the report title. */
        .report-card h3 {
            color: #17243a;
            font-size: 18px;
            margin: 0 0 10px;
        }

        /* Style the report description. */
        .report-card p {
            color: #687386;
            font-size: 13px;
            line-height: 1.7;
            margin: 0 0 22px;
        }

        /* Push the report action to the bottom of each card. */
        .report-card-action {
            margin-top: auto;
        }

        /* Style the report opening link. */
        .report-open-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #e56b4b;
            font-size: 13px;
            font-weight: 700;
            text-decoration: none;
        }

        /* Change the link appearance when the user hovers over it. */
        .report-open-link:hover {
            color: #c94f32;
            text-decoration: underline;
        }

        /* Style the short introduction panel. */
        .reports-intro {
            background: #ffffff;
            border: 1px solid #e6eaf0;
            border-radius: 14px;
            padding: 22px 24px;
            margin-top: 20px;
        }

        /* Style the introduction heading. */
        .reports-intro h2 {
            color: #17243a;
            font-size: 17px;
            margin: 0 0 8px;
        }

        /* Style the introduction description. */
        .reports-intro p {
            color: #687386;
            font-size: 13px;
            line-height: 1.7;
            margin: 0;
        }

        /* Adjust the report cards for smaller screens. */
        @media (max-width: 600px) {
            .reports-grid {
                grid-template-columns: 1fr;
            }

            .report-card {
                min-height: auto;
            }
        }
    </style>
</head>

<body>

    <!-- Create the main dashboard layout. -->
    <div class="dashboard-layout">

        <!-- Display the application sidebar. -->
        <aside class="sidebar">

            <!-- Display the VSMS brand. -->
            <div class="brand">
                <div class="brand-logo">V</div>
                <div class="brand-text">
                    <h2>VSMS</h2>
                    <p>Vehicle Management</p>
                </div>
            </div>

            <!-- Display the main navigation links. -->
            <nav class="sidebar-navigation">

                <!-- Display the navigation heading. -->
                <p class="navigation-heading">MAIN MENU</p>

                <!-- Link to the dashboard. -->
                <a href="dashboard.php" class="nav-link">
                    <span class="nav-icon">▦</span>
                    <span>Dashboard</span>
                </a>

                <!-- Link to vehicle inventory. -->
                <a href="vehicles.php" class="nav-link">
                    <span class="nav-icon">🚘</span>
                    <span>Vehicles</span>
                </a>

                <!-- Link to customers. -->
                <a href="customers.php" class="nav-link">
                    <span class="nav-icon">♙</span>
                    <span>Customers</span>
                </a>

                <!-- Link to reservations. -->
                <a href="reservations.php" class="nav-link">
                    <span class="nav-icon">▣</span>
                    <span>Reservations</span>
                </a>

                <!-- Link to sales. -->
                <a href="sales.php" class="nav-link">
                    <span class="nav-icon">▤</span>
                    <span>Sales</span>
                </a>

                <!-- Link to payments. -->
                <a href="payments.php" class="nav-link">
                    <span class="nav-icon">$</span>
                    <span>Payments</span>
                </a>
                <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
    <span class="nav-icon">◷</span>
    <span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
    <span class="nav-icon">▧</span>
    <span>Invoices</span>
</a>

                <!-- Link to employees. -->
                <a href="employees.php" class="nav-link">
                    <span class="nav-icon">♧</span>
                    <span>Employees</span>
                </a>
                <?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
    <span class="nav-icon">♙</span>
    <span>User Accounts</span>
</a>

<?php endif; ?>
                <!-- Highlight the current Reports page. -->
                <a href="reports.php" class="nav-link active">
                    <span class="nav-icon">▥</span>
                    <span>Reports</span>
                </a>

            </nav>
            <div class="sidebar-footer">
                <p>Vehicle Sales &amp; Management System</p>
                <span>Development version</span>
            </div>
        </aside>

        <!-- Create the main workspace beside the sidebar. -->
        <main class="main-content">

            <!-- Display the page header and current user. -->
            <header class="topbar">

<!-- Display the current page location. -->
<div class="breadcrumb">
    
    <strong>Main Menu / Reports</strong>
</div>

<!-- Display the logged-in user's information and logout button. -->
<div class="topbar-user">

    <!-- Display the first letter of the user's name. -->
    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
    </div>

    <!-- Display the user's name and role. -->
    <div class="user-information">
    <a href="my_profile.php" class="profile-name-link">
        <?= $fullName ?>
                        </a>
                        <span><?= $roleName ?></span>
    </div>

    <!-- Create a secure POST form for logging out. -->
    <form action="logout.php" method="POST">

        <!-- Send the current session's CSRF token to the logout script. -->
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

        <!-- Submit the logout request. -->
        <button type="submit" class="logout-button">Logout</button>

    <!-- Close the logout form. -->
    </form>

<!-- Close the user information section. -->
</div>

<!-- Close the top header. -->
</header>
      

            <!-- Display the reports overview content. -->
            <section class="page-content">

                <!-- Introduce the reports section. -->
                <div class="page-heading">
                    <div>
                        <h1>Reports Overview</h1>
                        <p>Access operational, financial, inventory, and performance reports.</p>
                    </div>
                </div>

                <!-- Explain the purpose of the reports section. -->
                <section class="reports-intro">
                    <h2>Management Reports</h2>
                    <p>
                        Select a report below to review system information.
                        Each report provides its own search, filtering, and print options.
                    </p>
                </section>

                <!-- Display all five available reports. -->
                <section class="reports-grid">

                    <?php foreach ($reports as $report): ?>

                        <!-- Display one report card. -->
                        <article class="report-card">

                            <!-- Display the report number and icon. -->
                            <div class="report-card-top">
                                <span class="report-number">
                                    REPORT <?= htmlspecialchars($report["number"], ENT_QUOTES, "UTF-8") ?>
                                </span>

                                <span class="report-icon">
                                    <?= htmlspecialchars($report["icon"], ENT_QUOTES, "UTF-8") ?>
                                </span>
                            </div>

                            <!-- Display the report category. -->
                            <div class="report-category">
                                <?= htmlspecialchars($report["category"], ENT_QUOTES, "UTF-8") ?>
                            </div>

                            <!-- Display the report title. -->
                            <h3>
                                <?= htmlspecialchars($report["title"], ENT_QUOTES, "UTF-8") ?>
                            </h3>

                            <!-- Display the report description. -->
                            <p>
                                <?= htmlspecialchars($report["description"], ENT_QUOTES, "UTF-8") ?>
                            </p>

                            <!-- Provide a link to open the selected report. -->
                            <div class="report-card-action">
                                <a
                                    href="<?= htmlspecialchars($report["file"], ENT_QUOTES, "UTF-8") ?>"
                                    class="report-open-link"
                                >
                                    Open Report <span aria-hidden="true">→</span>
                                </a>
                            </div>

                        </article>

                    <?php endforeach; ?>

                </section>

            </section>

        </main>

    </div>

</body>
</html>
