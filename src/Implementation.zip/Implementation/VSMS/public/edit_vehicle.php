
<?php
// Load the existing authentication functions and PDO database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to be logged in before accessing this page.
requireLogin();

// Check whether the logged-in user is an Administrator or Manager.
if (!hasRole("Administrator") && !hasRole("Manager")) {

    // Return HTTP status 403 because this user is not authorized.
    http_response_code(403);

    // Stop the page and explain that editing is not permitted.
    exit("Access denied. Only Administrators and Managers can edit vehicles.");
}

// Retrieve the requested vehicle ID from the URL.
$vehicleId = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

// Stop processing if the URL does not contain a valid positive vehicle ID.
if ($vehicleId === false || $vehicleId === null || $vehicleId <= 0) {
    // Set the response status to indicate an invalid request.
    http_response_code(400);

    // Display a simple message explaining the problem.
    exit("Invalid vehicle ID. Please return to the vehicle inventory.");
}

// Retrieve the logged-in user's information for the page header.
$user = currentUser();

// Stop if the current user's account is no longer available.
if (!$user) {
    // Return the user to the login page.
    header("Location: login.php");

    // Stop executing the current PHP page.
    exit;
}

// Create a session CSRF token if one does not already exist.
if (empty($_SESSION["csrf_token"])) {
    // Generate a secure random token for form submission verification.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Store the current session's CSRF token for use in the form.
$csrfToken = $_SESSION["csrf_token"];

// Create an array to store validation and processing errors.
$errors = [];

// Create a variable to store a success message if needed.
$successMessage = "";

// Define the allowed vehicle status values from the database ENUM.
$allowedStatuses = [
    "Available",
    "Reserved",
    "Sold",
    "Under Maintenance",
    "Unavailable"
];

// Prepare a SQL query to retrieve the selected active vehicle.
$selectSql = "SELECT *
              FROM vehicles
              WHERE vehicle_id = :vehicle_id
              AND is_active = 1
              LIMIT 1";

// Prepare the vehicle lookup using PDO.
$selectStatement = $pdo->prepare($selectSql);

// Bind the selected vehicle ID as an integer.
$selectStatement->bindValue(":vehicle_id", $vehicleId, PDO::PARAM_INT);

// Execute the vehicle lookup query.
$selectStatement->execute();

// Retrieve the selected vehicle as an associative array.
$vehicle = $selectStatement->fetch(PDO::FETCH_ASSOC);

// Check whether the requested vehicle exists and is active.
if (!$vehicle) {
    // Return a not-found HTTP response.
    http_response_code(404);

    // Stop processing because there is no vehicle to edit.
    exit("Vehicle not found or no longer active. Return to the vehicle inventory.");
}

// Copy the current vehicle information into form values.
// These values will be displayed when the page first opens.
$formValues = [
    "vin" => $vehicle["vin"],
    "make" => $vehicle["make"],
    "model" => $vehicle["model"],
    "year" => $vehicle["year"],
    "category" => $vehicle["category"],
    "price" => $vehicle["price"],
    "mileage" => $vehicle["mileage"],
    "fuel_type" => $vehicle["fuel_type"],
    "transmission" => $vehicle["transmission"],
    "color" => $vehicle["color"],
    "status" => $vehicle["STATUS"],
    "description" => $vehicle["description"] ?? ""
];

// Process the form only when the user submits it using POST.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Read the CSRF token submitted with the form.
    $submittedToken = $_POST["csrf_token"] ?? "";

    // Verify that the submitted token matches the current session token.
    if (!is_string($submittedToken) || !hash_equals($csrfToken, $submittedToken)) {
        // Add an error if the security token is invalid.
        $errors[] = "Security verification failed. Please refresh the page and try again.";
    }

    // Read the submitted VIN and remove unnecessary spaces.
    $formValues["vin"] = trim((string) ($_POST["vin"] ?? ""));

    // Read the submitted vehicle make.
    $formValues["make"] = trim((string) ($_POST["make"] ?? ""));

    // Read the submitted vehicle model.
    $formValues["model"] = trim((string) ($_POST["model"] ?? ""));

    // Read the submitted manufacturing year.
    $formValues["year"] = trim((string) ($_POST["year"] ?? ""));

    // Read the submitted vehicle category.
    $formValues["category"] = trim((string) ($_POST["category"] ?? ""));

    // Read the submitted vehicle price.
    $formValues["price"] = trim((string) ($_POST["price"] ?? ""));

    // Read the submitted vehicle mileage.
    $formValues["mileage"] = trim((string) ($_POST["mileage"] ?? ""));

    // Read the submitted fuel type.
    $formValues["fuel_type"] = trim((string) ($_POST["fuel_type"] ?? ""));

    // Read the submitted transmission type.
    $formValues["transmission"] = trim((string) ($_POST["transmission"] ?? ""));

    // Read the submitted vehicle color.
    $formValues["color"] = trim((string) ($_POST["color"] ?? ""));

    // Read the submitted vehicle status.
    $formValues["status"] = trim((string) ($_POST["status"] ?? ""));

    // Read the submitted vehicle description.
    $formValues["description"] = trim((string) ($_POST["description"] ?? ""));

    // Check whether the VIN field is empty.
    if ($formValues["vin"] === "") {
        // Add a validation error for the missing VIN.
        $errors[] = "VIN is required.";
    }

    // Check whether the make field is empty.
    if ($formValues["make"] === "") {
        // Add a validation error for the missing make.
        $errors[] = "Vehicle make is required.";
    }

    // Check whether the model field is empty.
    if ($formValues["model"] === "") {
        // Add a validation error for the missing model.
        $errors[] = "Vehicle model is required.";
    }

    // Check whether the year is a valid integer.
    $yearValue = filter_var($formValues["year"], FILTER_VALIDATE_INT);

    // Validate the manufacturing year.
    if ($yearValue === false || $yearValue < 1886 || $yearValue > ((int) date("Y") + 1)) {
        // Add a validation error for an invalid year.
        $errors[] = "Enter a valid vehicle year.";
    }

    // Check whether the category field is empty.
    if ($formValues["category"] === "") {
        // Add a validation error for the missing category.
        $errors[] = "Vehicle category is required.";
    }

    // Check whether the price is numeric and greater than zero.
    if (!is_numeric($formValues["price"]) || (float) $formValues["price"] <= 0) {
        // Add a validation error for an invalid price.
        $errors[] = "Enter a valid price greater than zero.";
    }

    // Validate the mileage as a non-negative integer.
    $mileageValue = filter_var($formValues["mileage"], FILTER_VALIDATE_INT);

    // Check whether the mileage is valid.
    if ($mileageValue === false || $mileageValue < 0) {
        // Add a validation error for invalid mileage.
        $errors[] = "Mileage must be a valid non-negative whole number.";
    }

    // Check whether the fuel type is empty.
    if ($formValues["fuel_type"] === "") {
        // Add a validation error for missing fuel type.
        $errors[] = "Fuel type is required.";
    }

    // Check whether the transmission type is empty.
    if ($formValues["transmission"] === "") {
        // Add a validation error for missing transmission.
        $errors[] = "Transmission is required.";
    }

    // Check whether the color is empty.
    if ($formValues["color"] === "") {
        // Add a validation error for missing color.
        $errors[] = "Vehicle color is required.";
    }

    // Check whether the submitted status belongs to the allowed values.
    if (!in_array($formValues["status"], $allowedStatuses, true)) {
        // Add a validation error for an invalid vehicle status.
        $errors[] = "Select a valid vehicle status.";
    }

    // Check whether another vehicle already uses the submitted VIN.
    if ($formValues["vin"] !== "") {

        // Prepare a query that excludes the current vehicle from the VIN check.
        $vinSql = "SELECT vehicle_id
                   FROM vehicles
                   WHERE vin = :vin
                   AND vehicle_id <> :vehicle_id
                   LIMIT 1";

        // Prepare the VIN uniqueness query.
        $vinStatement = $pdo->prepare($vinSql);

        // Bind the submitted VIN to the query.
        $vinStatement->bindValue(":vin", $formValues["vin"], PDO::PARAM_STR);

        // Bind the current vehicle ID to exclude its own record.
        $vinStatement->bindValue(":vehicle_id", $vehicleId, PDO::PARAM_INT);

        // Execute the VIN uniqueness check.
        $vinStatement->execute();

        // Check whether another vehicle has the same VIN.
        if ($vinStatement->fetch()) {
            // Add an error because VIN must be unique.
            $errors[] = "This VIN already belongs to another vehicle.";
        }
    }

    // Preserve the existing image path unless a new image is uploaded.
    $newImagePath = $vehicle["image_path"];

    // Prepare a variable to track the newly uploaded image's physical path.
    $newImagePhysicalPath = null;

    // Check whether the user selected a new vehicle photograph.
    if (
        empty($errors) &&
        isset($_FILES["vehicle_image"]) &&
        $_FILES["vehicle_image"]["error"] !== UPLOAD_ERR_NO_FILE
    ) {

        // Check whether the uploaded file was received successfully.
        if ($_FILES["vehicle_image"]["error"] !== UPLOAD_ERR_OK) {
            // Add an error if the upload did not complete successfully.
            $errors[] = "The vehicle image could not be uploaded. Please try again.";
        } else {

            // Set the maximum allowed image size to five megabytes.
            $maximumImageSize = 5 * 1024 * 1024;

            // Check whether the uploaded image exceeds the size limit.
            if ($_FILES["vehicle_image"]["size"] > $maximumImageSize) {
                // Add an error when the image is too large.
                $errors[] = "The vehicle image must not exceed 5 MB.";
            } else {

                // Read the temporary path of the uploaded file.
                $temporaryImagePath = $_FILES["vehicle_image"]["tmp_name"];

                // Detect the actual MIME type of the uploaded file.
                $fileInfo = finfo_open(FILEINFO_MIME_TYPE);

                // Read the detected file MIME type.
                $imageMimeType = finfo_file($fileInfo, $temporaryImagePath);

                // Close the file information resource.
                finfo_close($fileInfo);

                // Define the supported image MIME types and file extensions.
                $allowedImageTypes = [
                    "image/jpeg" => "jpg",
                    "image/png" => "png",
                    "image/webp" => "webp"
                ];

                // Verify that the uploaded file is a supported image.
                if (!isset($allowedImageTypes[$imageMimeType]) || getimagesize($temporaryImagePath) === false) {
                    // Add an error if the file is not a valid supported image.
                    $errors[] = "Only valid JPG, PNG, and WebP images are allowed.";
                } else {

                    // Build the physical path to the vehicle upload folder.
                    $uploadDirectory = __DIR__ . "/uploads/vehicles/";

                    // Create the upload folder if it does not already exist.
                    if (!is_dir($uploadDirectory) && !mkdir($uploadDirectory, 0755, true)) {
                        // Add an error if the upload folder cannot be created.
                        $errors[] = "The vehicle image folder could not be created.";
                    } else {

                        // Generate a random filename to avoid filename collisions.
                        $newImageFileName = bin2hex(random_bytes(16)) . "." . $allowedImageTypes[$imageMimeType];

                        // Build the complete destination path for the new image.
                        $newImagePhysicalPath = $uploadDirectory . $newImageFileName;

                        // Store the relative image path in the database.
                        $newImagePath = "uploads/vehicles/" . $newImageFileName;

                        // Move the uploaded image into the vehicle upload folder.
                        if (!move_uploaded_file($temporaryImagePath, $newImagePhysicalPath)) {
                            // Add an error if the uploaded image cannot be saved.
                            $errors[] = "The vehicle image could not be saved.";
                        }
                    }
                }
            }
        }
    }

    // Update the database only when all validation checks have passed.
    // Update the database only when all validation checks have passed.
    if (empty($errors)) {
    
        try {
    
            // Start a database transaction.
            $pdo->beginTransaction();
    
            // Lock the vehicle record to prevent simultaneous status changes.
            $lockVehicleStatement = $pdo->prepare(
                "SELECT `STATUS` AS vehicle_status, is_active
                 FROM vehicles
                 WHERE vehicle_id = ?
                 FOR UPDATE"
            );
    
            // Execute the vehicle locking query.
            $lockVehicleStatement->execute([$vehicleId]);
    
            // Retrieve the locked vehicle record.
            $lockedVehicle = $lockVehicleStatement->fetch(PDO::FETCH_ASSOC);
    
            // Ensure that the vehicle still exists and is active.
            if (!$lockedVehicle || (int) $lockedVehicle["is_active"] !== 1) {
                throw new RuntimeException(
                    "This vehicle no longer exists or is inactive."
                );
            }
    
            // Retrieve any active reservation for this vehicle.
            $activeReservationStatement = $pdo->prepare(
                "SELECT reservation_id
                 FROM reservations
                 WHERE vehicle_id = ?
                   AND reservation_status = 'Active'
                 LIMIT 1
                 FOR UPDATE"
            );
    
            // Execute the active reservation check.
            $activeReservationStatement->execute([$vehicleId]);
    
            // Determine whether an active reservation exists.
            $hasActiveReservation = (bool) $activeReservationStatement->fetch();
    
            // Retrieve any pending or completed sale for this vehicle.
            $existingSaleStatement = $pdo->prepare(
                "SELECT sale_id, sale_status
                 FROM sales
                 WHERE vehicle_id = ?
                   AND sale_status IN ('Pending', 'Completed')
                 LIMIT 1
                 FOR UPDATE"
            );
    
            // Execute the existing sale check.
            $existingSaleStatement->execute([$vehicleId]);
    
            // Retrieve the existing sale, if one exists.
            $existingSale = $existingSaleStatement->fetch(PDO::FETCH_ASSOC);
    
            // Read the vehicle's current database status.
            $currentStatus = $lockedVehicle["vehicle_status"];
    
            // Read the status selected in the edit form.
            $requestedStatus = $formValues["status"];
    
            // Prevent a vehicle with an active reservation from losing Reserved status.
            if (
                $hasActiveReservation &&
                $requestedStatus !== "Reserved"
            ) {
                throw new RuntimeException(
                    "This vehicle has an active reservation. Its status must remain Reserved."
                );
            }
    
            // Prevent manual changes to a vehicle with a pending sale.
            if (
                $existingSale &&
                $existingSale["sale_status"] === "Pending" &&
                $requestedStatus !== $currentStatus
            ) {
                throw new RuntimeException(
                    "This vehicle has a pending sale. Its status cannot be changed manually."
                );
            }
    
            // Prevent a completed sale from being changed back to another status.
            if (
                $existingSale &&
                $existingSale["sale_status"] === "Completed" &&
                $requestedStatus !== "Sold"
            ) {
                throw new RuntimeException(
                    "This vehicle has a completed sale and must remain Sold."
                );
            }
    
            // Prevent manually assigning Reserved or Sold without the corresponding business transaction.
            if (
                !$hasActiveReservation &&
                !$existingSale &&
                in_array($requestedStatus, ["Reserved", "Sold"], true)
            ) {
                throw new RuntimeException(
                    "Reserved and Sold statuses must be assigned through the reservation or sales process."
                );
            }
    
            // Prepare the SQL statement to update the selected vehicle.
            $updateSql = "UPDATE vehicles
                          SET
                              vin = :vin,
                              make = :make,
                              model = :model,
                              year = :year,
                              category = :category,
                              price = :price,
                              mileage = :mileage,
                              fuel_type = :fuel_type,
                              transmission = :transmission,
                              color = :color,
                              `STATUS` = :status,
                              description = :description,
                              image_path = :image_path
                          WHERE vehicle_id = :vehicle_id
                            AND is_active = 1";
    
            // Prepare the vehicle update statement.
            $updateStatement = $pdo->prepare($updateSql);
    
            // Bind the vehicle information.
            $updateStatement->bindValue(":vin", $formValues["vin"], PDO::PARAM_STR);
            $updateStatement->bindValue(":make", $formValues["make"], PDO::PARAM_STR);
            $updateStatement->bindValue(":model", $formValues["model"], PDO::PARAM_STR);
            $updateStatement->bindValue(":year", $yearValue, PDO::PARAM_INT);
            $updateStatement->bindValue(":category", $formValues["category"], PDO::PARAM_STR);
            $updateStatement->bindValue(":price", $formValues["price"], PDO::PARAM_STR);
            $updateStatement->bindValue(":mileage", $mileageValue, PDO::PARAM_INT);
            $updateStatement->bindValue(":fuel_type", $formValues["fuel_type"], PDO::PARAM_STR);
            $updateStatement->bindValue(":transmission", $formValues["transmission"], PDO::PARAM_STR);
            $updateStatement->bindValue(":color", $formValues["color"], PDO::PARAM_STR);
            $updateStatement->bindValue(":status", $requestedStatus, PDO::PARAM_STR);
            $updateStatement->bindValue(":description", $formValues["description"], PDO::PARAM_STR);
    
            // Bind the existing or newly uploaded image path.
            $updateStatement->bindValue(
                ":image_path",
                $newImagePath,
                $newImagePath === null ? PDO::PARAM_NULL : PDO::PARAM_STR
            );
    
            // Bind the vehicle ID.
            $updateStatement->bindValue(":vehicle_id", $vehicleId, PDO::PARAM_INT);
    
            // Execute the vehicle update.
            $updateStatement->execute();
    
            // Commit the transaction after the database update succeeds.
            $pdo->commit();
    
            // Delete the previous photograph only after the database update succeeds.
            if ($newImagePhysicalPath !== null && !empty($vehicle["image_path"])) {
    
                // Extract only the previous image filename.
                $oldImageFileName = basename(
                    str_replace("\\", "/", $vehicle["image_path"])
                );
    
                // Build the physical path to the previous photograph.
                $oldImagePhysicalPath = __DIR__ . "/uploads/vehicles/" . $oldImageFileName;
    
                // Remove the previous photograph if it exists.
                if (is_file($oldImagePhysicalPath)) {
                    unlink($oldImagePhysicalPath);
                }
            }
    
            // Redirect to the inventory page after successful updating.
            header("Location: vehicles.php?updated=1");
    
            // Stop executing after the redirect.
            exit;
    
        } catch (RuntimeException $exception) {
    
            // Roll back the transaction if it is still active.
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
    
            // Remove the newly uploaded image if the update was rejected.
            if ($newImagePhysicalPath !== null && is_file($newImagePhysicalPath)) {
                unlink($newImagePhysicalPath);
            }
    
            // Display the specific business-rule validation message.
            $errors[] = $exception->getMessage();
    
        } catch (PDOException $exception) {
    
            // Roll back the transaction if it is still active.
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
    
            // Remove the newly uploaded image if the database update failed.
            if ($newImagePhysicalPath !== null && is_file($newImagePhysicalPath)) {
                unlink($newImagePhysicalPath);
            }
    
            // Handle duplicate database values.
            if ($exception->getCode() === "23000") {
                $errors[] = "The vehicle could not be updated because its VIN may already exist.";
            } else {
                $errors[] = "An unexpected database error occurred. Please try again.";
            }
    
        } catch (Throwable $exception) {
    
            // Roll back the transaction if it is still active.
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
    
            // Remove the newly uploaded image if the update failed.
            if ($newImagePhysicalPath !== null && is_file($newImagePhysicalPath)) {
                unlink($newImagePhysicalPath);
            }
    
            // Display a general error without exposing internal details.
            $errors[] = "An unexpected error occurred. Please try again.";
        }
    }
}
// Create a helper function to safely display values inside HTML.
$escape = static function ($value): string {
    // Escape special HTML characters to help prevent cross-site scripting.
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
};

// Prepare the current user's full name for the page header.
$userName = $escape($user["full_name"]);

// Prepare the current user's role for the page header.
$userRole = $escape($user["role_name"]);

// Prepare the CSRF token for the logout form.
$escapedCsrfToken = $escape($csrfToken);

// Prepare the current vehicle image URL if an image exists.
$imageUrl = "";

// Check whether the vehicle has a stored image path.
if (!empty($vehicle["image_path"])) {

    // Extract only the image filename from the stored path.
    $imageFileName = basename(str_replace("\\", "/", $vehicle["image_path"]));

    // Build the physical path to the stored image.
    $imagePhysicalPath = __DIR__ . "/uploads/vehicles/" . $imageFileName;

    // Check whether the stored image file exists.
    if (is_file($imagePhysicalPath)) {

        // Create the browser URL for the stored image.
        $imageUrl = "uploads/vehicles/" . rawurlencode($imageFileName);
    }
}
?>

<!DOCTYPE html>
<!-- Tell the browser that this page uses HTML5. -->
<html lang="en">
<!-- Start the HTML document and declare its language. -->

<head>
    <!-- Store page settings and stylesheet links. -->
    <meta charset="UTF-8">
    <!-- Support standard characters and symbols. -->

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Make the page responsive on different screen sizes. -->

    <title>Edit Vehicle | VSMS</title>
    <!-- Set the browser tab title. -->

    <link rel="stylesheet" href="assets/css/dashboard.css">
    <!-- Load the shared dashboard styles. -->

    <link rel="stylesheet" href="assets/css/vehicles.css">
    <!-- Load the shared vehicle module styles. -->
</head>

<body>
    <!-- Start the visible page content. -->

    <div class="dashboard-layout">
        <!-- Create the main dashboard layout. -->

        <aside class="sidebar">

<!-- Display the system logo and name. -->
<div class="brand">

    <!-- Display the short system name inside a logo box. -->
    <div class="brand-logo">V</div>

    <!-- Display the full system name. -->
    <div class="brand-text">
        <h2>VSMS</h2>
        <p>Vehicle Management</p>
    </div>

<!-- Close the brand section. -->
</div>

<!-- Display the main sidebar navigation. -->


<!-- Display all available system navigation links. -->
<nav class="sidebar-navigation">

    <!-- Display the navigation section heading. -->
    <p class="navigation-heading">MAIN MENU</p>

    <!-- Link to the Dashboard. -->
    <a href="dashboard.php" class="nav-link active">
        <span class="nav-icon">▦</span>
        <span>Dashboard</span>
    </a>

    <!-- Link to Vehicle Management. -->
    <a href="vehicles.php" class="nav-link">
        <span class="nav-icon">🚘</span>
        <span>Vehicles</span>
    </a>

    <!-- Link to Customer Management. -->
    <a href="customers.php" class="nav-link">
        <span class="nav-icon">♙</span>
        <span>Customers</span>
    </a>

    <!-- Link to Reservation Management. -->
    <a href="reservations.php" class="nav-link">
        <span class="nav-icon">▣</span>
        <span>Reservations</span>
    </a>

    <!-- Link to Sales Management. -->
    <a href="sales.php" class="nav-link">
        <span class="nav-icon">▤</span>
        <span>Sales</span>
    </a>

    <!-- Link to Payment Management. -->
    <a href="payments.php" class="nav-link">
        <span class="nav-icon">$</span>
        <span>Payments</span>
    </a>
    <!-- Link to Outstanding Balances. -->
<a href="outstanding_balances.php" class="nav-link">
<span class="nav-icon">◷</span>
<span>Outstanding Balances</span>
</a>

<!-- Link to Invoice Management. -->
<a href="invoices.php" class="nav-link">
<span class="nav-icon">▧</span>
<span>Invoices</span>
</a>

    <!-- Show employee management only to authorized management roles. -->
    <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

        <a href="employees.php" class="nav-link">
            <span class="nav-icon">♧</span>
            <span>Employees</span>
        </a>

    <?php endif; ?>
    <!-- Only Administrators can access User Account Management. -->
<?php if ($user["role_name"] === "Administrator"): ?>

<a href="users.php" class="nav-link">
<span class="nav-icon">♙</span>
<span>User Accounts</span>
</a>

<?php endif; ?>

    <!-- Show reports only to authorized management roles. -->
    <?php if (in_array($user["role_name"], ["Administrator", "Manager"], true)): ?>

        <a href="reports.php" class="nav-link">
            <span class="nav-icon">▥</span>
            <span>Reports</span>
        </a>

    <?php endif; ?>

<!-- Close the navigation section. -->
</nav>


<!-- Display a short project description at the bottom of the sidebar. -->
<div class="sidebar-footer">
    <p>Vehicle Sales &amp; Management System</p>
    <span>Development version</span>
</div>

<!-- Close the sidebar. -->
</aside>


        <main class="main-content">
            <!-- Create the main content area. -->
            <header class="topbar">
                <!-- Create the top header containing the page location and user information. -->
                <div class="breadcrumb">
                    
                    <strong>Vehicles / Vehicle Details</strong>
                </div>

                <div class="topbar-user">
                    <!-- Display the logged-in user and logout control. -->
                    <div class="user-avatar">
    <a href="my_profile.php" class="profile-name-link">
        <?= htmlspecialchars(strtoupper(substr($user["full_name"], 0, 1)), ENT_QUOTES, "UTF-8") ?>
        
    </div>
                    <div class="user-information">
                        <!-- Group the user's name and role together. -->
                        <a href="my_profile.php" class="profile-name-link"><?= $userName ?>
   
</a>
                        <!-- Display the escaped user's full name. -->
                        <span><?= $userRole ?></span>
                        <!-- Display the escaped user's role. -->
                    </div>

                    <form action="logout.php" method="POST">
                        <!-- Submit a secure POST request when the user logs out. -->

                        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                        <!-- Send the current session's CSRF token for verification. -->

                        <button type="submit" class="logout-button">
                            <!-- Create the logout button. -->
                            Logout
                            <!-- Display the button label. -->
                        </button>
                    </form>
                </div>
            </header>

           

            <section class="edit-vehicle-section">
                <!-- Start the vehicle editing section. -->

                <div class="edit-vehicle-heading">
                    <!-- Display the heading and return link. -->

                    <div>
                        <!-- Group the title and description. -->
                        <h1>Edit Vehicle</h1>
                        <!-- Display the page heading. -->
                        <p>Update the information for this vehicle.</p>
                        <!-- Explain the purpose of this page. -->
                    </div>

                    <a href="vehicle_details.php?id=<?= (int) $vehicleId ?>" class="secondary-button">
                        <!-- Return to the details page of this vehicle. -->
                        Back to Details
                        <!-- Display the return button label. -->
                    </a>
                </div>

                <?php if (!empty($errors)): ?>
                    <!-- Display validation or database errors when they exist. -->

                    <div class="edit-vehicle-errors">
                        <!-- Create the error message container. -->

                        <?php foreach ($errors as $error): ?>
                            <!-- Loop through all recorded errors. -->

                            <p><?= $escape($error) ?></p>
                            <!-- Display each error safely. -->

                        <?php endforeach; ?>
                        <!-- Finish displaying the error list. -->

                    </div>
                <?php endif; ?>
                <!-- Finish the error-message condition. -->

                <form
                    action="edit_vehicle.php?id=<?= (int) $vehicleId ?>"
                    method="POST"
                    enctype="multipart/form-data"
                    class="edit-vehicle-form"
                >
                    <!-- Submit the edited vehicle information and optional image. -->

                    <input type="hidden" name="csrf_token" value="<?= $escape($csrfToken) ?>">
                    <!-- Include the security token required by the server. -->

                    <h2>Vehicle Information</h2>
                    <!-- Display the form section heading. -->

                    <div class="edit-vehicle-grid">
                        <!-- Arrange the form fields in a responsive grid. -->

                        <div class="edit-vehicle-field">
                            <!-- Create the VIN field. -->
                            <label for="vin">VIN *</label>
                            <!-- Explain which value belongs in the input. -->
                            <input
                                type="text"
                                id="vin"
                                name="vin"
                                maxlength="50"
                                required
                                value="<?= $escape($formValues["vin"]) ?>"
                            >
                            <!-- Display the current VIN and allow it to be edited. -->
                        </div>

                        <div class="edit-vehicle-field">
                            <!-- Create the vehicle make field. -->
                            <label for="make">Make *</label>
                            <!-- Explain which value belongs in the input. -->
                            <input
                                type="text"
                                id="make"
                                name="make"
                                maxlength="100"
                                required
                                value="<?= $escape($formValues["make"]) ?>"
                            >
                            <!-- Display and allow editing of the vehicle make. -->
                        </div>

                        <div class="edit-vehicle-field">
                            <!-- Create the vehicle model field. -->
                            <label for="model">Model *</label>
                            <!-- Explain which value belongs in the input. -->
                            <input
                                type="text"
                                id="model"
                                name="model"
                                maxlength="100"
                                required
                                value="<?= $escape($formValues["model"]) ?>"
                            >
                            <!-- Display and allow editing of the vehicle model. -->
                        </div>

                        <div class="edit-vehicle-field">
                            <!-- Create the manufacturing year field. -->
                            <label for="year">Year *</label>
                            <!-- Explain which value belongs in the input. -->
                            <input
                                type="number"
                                id="year"
                                name="year"
                                min="1886"
                                max="<?= (int) date("Y") + 1 ?>"
                                required
                                value="<?= $escape($formValues["year"]) ?>"
                            >
                            <!-- Display and allow editing of the manufacturing year. -->
                        </div>

                        <div class="edit-vehicle-field">
                            <!-- Create the vehicle category field. -->
                            <label for="category">Category *</label>
                            <!-- Explain which value belongs in the input. -->
                            <input
                                type="text"
                                id="category"
                                name="category"
                                maxlength="50"
                                required
                                value="<?= $escape($formValues["category"]) ?>"
                            >
                            <!-- Display and allow editing of the vehicle category. -->
                        </div>

                        <div class="edit-vehicle-field">
                            <!-- Create the vehicle price field. -->
                            <label for="price">Price *</label>
                            <!-- Explain which value belongs in the input. -->
                            <input
                                type="number"
                                id="price"
                                name="price"
                                min="0.01"
                                step="0.01"
                                required
                                value="<?= $escape($formValues["price"]) ?>"
                            >
                            <!-- Display and allow editing of the vehicle price. -->
                        </div>

                        <div class="edit-vehicle-field">
                            <!-- Create the mileage field. -->
                            <label for="mileage">Mileage *</label>
                            <!-- Explain which value belongs in the input. -->
                            <input
                                type="number"
                                id="mileage"
                                name="mileage"
                                min="0"
                                step="1"
                                required
                                value="<?= $escape($formValues["mileage"]) ?>"
                            >
                            <!-- Display and allow editing of the vehicle mileage. -->
                        </div>

                        <div class="edit-vehicle-field">
                            <!-- Create the fuel type field. -->
                            <label for="fuel_type">Fuel Type *</label>
                            <!-- Explain which value belongs in the input. -->
                            <input
                                type="text"
                                id="fuel_type"
                                name="fuel_type"
                                maxlength="50"
                                required
                                value="<?= $escape($formValues["fuel_type"]) ?>"
                            >
                            <!-- Display and allow editing of the fuel type. -->
                        </div>

                        <div class="edit-vehicle-field">
                            <!-- Create the transmission field. -->
                            <label for="transmission">Transmission *</label>
                            <!-- Explain which value belongs in the input. -->
                            <input
                                type="text"
                                id="transmission"
                                name="transmission"
                                maxlength="50"
                                required
                                value="<?= $escape($formValues["transmission"]) ?>"
                            >
                            <!-- Display and allow editing of the transmission. -->
                        </div>

                        <div class="edit-vehicle-field">
                            <!-- Create the vehicle color field. -->
                            <label for="color">Color *</label>
                            <!-- Explain which value belongs in the input. -->
                            <input
                                type="text"
                                id="color"
                                name="color"
                                maxlength="50"
                                required
                                value="<?= $escape($formValues["color"]) ?>"
                            >
                            <!-- Display and allow editing of the vehicle color. -->
                        </div>

                        <div class="edit-vehicle-field">
                            <!-- Create the vehicle status field. -->
                            <label for="status">Status *</label>
                            <!-- Explain which value belongs in the selection. -->

                            <select id="status" name="status" required>
                                <!-- Allow the user to select an existing vehicle status. -->

                                <?php foreach ($allowedStatuses as $statusOption): ?>
                                    <!-- Loop through the allowed database status values. -->

                                    <option
                                        value="<?= $escape($statusOption) ?>"
                                        <?= $formValues["status"] === $statusOption ? "selected" : "" ?>
                                    >
                                        <!-- Select the vehicle's current status automatically. -->
                                        <?= $escape($statusOption) ?>
                                        <!-- Display the status option. -->
                                    </option>

                                <?php endforeach; ?>
                                <!-- Finish the status options. -->

                            </select>
                        </div>

                    </div>

                    <div class="edit-vehicle-field edit-vehicle-description">
                        <!-- Create the vehicle description field. -->
                        <label for="description">Description</label>
                        <!-- Explain which information belongs in the text area. -->

                        <textarea
                            id="description"
                            name="description"
                            rows="5"
                        ><?= $escape($formValues["description"]) ?></textarea>
                        <!-- Display and allow editing of the existing vehicle description. -->
                    </div>

                    <div class="edit-vehicle-image-section">
                        <!-- Create the image replacement section. -->

                        <h3>Vehicle Photograph</h3>
                        <!-- Display the image section heading. -->

                        <?php if ($imageUrl !== ""): ?>
                            <!-- Display the current image when one exists. -->

                            <img
                                src="<?= $escape($imageUrl) ?>"
                                alt="Current vehicle photograph"
                                class="edit-vehicle-current-image"
                            >
                            <!-- Show the photograph currently saved for this vehicle. -->

                        <?php else: ?>
                            <!-- Display a message when no current image exists. -->

                            <p>No photograph is currently saved for this vehicle.</p>
                            <!-- Explain that the vehicle has no stored image. -->

                        <?php endif; ?>

                        <label for="vehicle_image">Choose a replacement image</label>
                        <!-- Allow the user to select a new vehicle photograph. -->

                        <input
                            type="file"
                            id="vehicle_image"
                            name="vehicle_image"
                            accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                        >
                        <!-- Accept supported image types from the user's computer. -->

                        <p class="edit-vehicle-image-note">
                            <!-- Display instructions for replacing the photograph. -->
                            Leave this field empty to keep the existing photograph. Maximum size: 5 MB.
                            <!-- Explain the image replacement behavior and size limit. -->
                        </p>
                    </div>

                    <div class="edit-vehicle-actions">
                        <!-- Group the form submission and cancel buttons. -->

                        <button type="submit" class="primary-button">
                            <!-- Submit the updated vehicle information. -->
                            Save Changes
                            <!-- Display the submit button label. -->
                        </button>

                        <a href="vehicles.php" class="secondary-button">
                            <!-- Return to the vehicle inventory without saving. -->
                            Cancel
                            <!-- Display the cancel button label. -->
                        </a>
                    </div>

                </form>
            </section>
        </main>
    </div>
</body>
</html>
