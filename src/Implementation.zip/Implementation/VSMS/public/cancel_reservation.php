
<?php

// Load the existing authentication functions and database connection.
require_once __DIR__ . "/../includes/auth.php";

// Require the user to log in before accessing this page.
requireLogin();

// Retrieve the currently logged-in user's information.
$user = currentUser();

// Check whether the account is still active.
if ($user === null) {
    // Clear the current session information.
    $_SESSION = [];

    // Destroy the current session.
    session_destroy();

    // Redirect the user to the login page.
    redirect("login.php");
}

// Store the current user's ID and role.
$userId = (int) $user["user_id"];
$userRole = $user["role_name"];

// Allow only the three existing VSMS roles to access this feature.
if (!in_array($userRole, ["Administrator", "Manager", "Salesperson"], true)) {
    // Return an HTTP 403 Forbidden response.
    http_response_code(403);

    // Stop the page from continuing.
    exit("Access denied. You cannot cancel reservations.");
}

// Generate a CSRF token if the session does not already have one.
if (empty($_SESSION["csrf_token"])) {
    // Create a secure random token.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Store the session's CSRF token.
$csrfToken = $_SESSION["csrf_token"];

// Initialize the message displayed to the user.
$message = "";

// Initialize the message type for styling.
$messageType = "";

// Read the reservation ID from the URL or submitted form.
$reservationId = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

// Use the submitted ID when the request is a POST.
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $reservationId = filter_input(INPUT_POST, "reservation_id", FILTER_VALIDATE_INT);
}

// Check that the reservation ID is valid.
if (!$reservationId || $reservationId < 1) {
    http_response_code(400);
    exit("Invalid reservation ID.");
}

// Process cancellation only when the form is submitted.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Retrieve the submitted CSRF token.
    $submittedToken = $_POST["csrf_token"] ?? "";

    // Verify the submitted token against the session token.
    if (
        !is_string($submittedToken) ||
        !hash_equals($csrfToken, $submittedToken)
    ) {
        // Reject the request if the token is invalid.
        $message = "Your form session is invalid. Please reload the page.";
        $messageType = "error";

    } else {

        // Start a database transaction.
        $pdo->beginTransaction();

        try {

            // Lock the selected reservation while processing cancellation.
            $reservationQuery = $pdo->prepare(
                "SELECT reservation_id, vehicle_id, salesperson_id,
                        reservation_status
                 FROM reservations
                 WHERE reservation_id = ?
                 FOR UPDATE"
            );

            // Execute the reservation query.
            $reservationQuery->execute([$reservationId]);

            // Retrieve the selected reservation.
            $reservation = $reservationQuery->fetch(PDO::FETCH_ASSOC);

            // Check whether the reservation exists.
            if (!$reservation) {
                throw new RuntimeException("The selected reservation was not found.");
            }

            // Allow salespeople to cancel only their own reservations.
            if (
                $userRole === "Salesperson" &&
                (int) $reservation["salesperson_id"] !== $userId
            ) {
                throw new RuntimeException(
                    "You can cancel only reservations assigned to your account."
                );
            }

            // Prevent cancellation of already cancelled or completed reservations.
            if ($reservation["reservation_status"] !== "Active") {
                throw new RuntimeException(
                    "Only active reservations can be cancelled."
                );
            }

            // Retrieve the vehicle ID connected to this reservation.
            $vehicleId = (int) $reservation["vehicle_id"];

            // Lock the related vehicle record.
            $vehicleQuery = $pdo->prepare(
                "SELECT vehicle_id, status
                 FROM vehicles
                 WHERE vehicle_id = ?
                 FOR UPDATE"
            );

            // Execute the vehicle query.
            $vehicleQuery->execute([$vehicleId]);

            // Retrieve the vehicle information.
            $vehicle = $vehicleQuery->fetch(PDO::FETCH_ASSOC);

            // Check whether the related vehicle still exists.
            if (!$vehicle) {
                throw new RuntimeException(
                    "The vehicle associated with this reservation was not found."
                );
            }

            // Mark the reservation as cancelled.
            $cancelQuery = $pdo->prepare(
                "UPDATE reservations
                 SET reservation_status = 'Cancelled'
                 WHERE reservation_id = ?
                   AND reservation_status = 'Active'"
            );

            // Execute the reservation update.
            $cancelQuery->execute([$reservationId]);

            // Confirm that exactly one reservation was updated.
            if ($cancelQuery->rowCount() !== 1) {
                throw new RuntimeException(
                    "The reservation could not be cancelled. Please try again."
                );
            }

            // Check whether another active reservation exists for this vehicle.
            $otherReservationQuery = $pdo->prepare(
                "SELECT COUNT(*)
                 FROM reservations
                 WHERE vehicle_id = ?
                   AND reservation_status = 'Active'
                   AND reservation_id <> ?"
            );

            // Execute the check using the vehicle and current reservation IDs.
            $otherReservationQuery->execute([$vehicleId, $reservationId]);

            // Convert the result into an integer.
            $otherActiveReservations = (int) $otherReservationQuery->fetchColumn();

            // Restore the vehicle only when it is still Reserved.
            if (
                $vehicle["status"] === "Reserved" &&
                $otherActiveReservations === 0
            ) {

                // Change the vehicle status back to Available.
                $vehicleUpdate = $pdo->prepare(
                    "UPDATE vehicles
                     SET status = 'Available'
                     WHERE vehicle_id = ?
                       AND status = 'Reserved'"
                );

                // Execute the vehicle update.
                $vehicleUpdate->execute([$vehicleId]);
            }

            // Commit both database changes together.
            $pdo->commit();

            // Redirect to this page to prevent accidental form resubmission.
            redirect("cancel_reservation.php?id=" . $reservationId . "&cancelled=1");

        } catch (Throwable $exception) {

            // Roll back all database changes if cancellation fails.
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            // Log technical errors privately.
            error_log("VSMS reservation cancellation error: " . $exception->getMessage());

            // Display a safe message to the user.
            $message = $exception instanceof RuntimeException
                ? $exception->getMessage()
                : "The reservation could not be cancelled because of a system error.";

            // Mark the message as an error.
            $messageType = "error";
        }
    }
}

// Check whether the reservation has just been cancelled successfully.
if (isset($_GET["cancelled"]) && $_GET["cancelled"] === "1") {
    // Display a success message.
    $message = "The reservation was cancelled successfully.";
    $messageType = "success";
}

// Retrieve the reservation and its related information for display.
$detailsQuery = $pdo->prepare(
    "SELECT r.reservation_id,
            r.reservation_status,
            r.reservation_date,
            c.full_name AS customer_name,
            v.make,
            v.model,
            v.`year`,
            v.status AS vehicle_status,
            u.full_name AS salesperson_name,
            r.salesperson_id
     FROM reservations AS r
     INNER JOIN customers AS c
        ON r.customer_id = c.customer_id
     INNER JOIN vehicles AS v
        ON r.vehicle_id = v.vehicle_id
     INNER JOIN users AS u
        ON r.salesperson_id = u.user_id
     WHERE r.reservation_id = ?"
);

// Execute the details query.
$detailsQuery->execute([$reservationId]);

// Retrieve the reservation details.
$details = $detailsQuery->fetch(PDO::FETCH_ASSOC);

// Stop if the reservation does not exist.
if (!$details) {
    http_response_code(404);
    exit("Reservation not found.");
}

// Prevent salespeople from viewing or cancelling another salesperson's reservation here.
if (
    $userRole === "Salesperson" &&
    (int) $details["salesperson_id"] !== $userId
) {
    http_response_code(403);
    exit("Access denied. This reservation is not assigned to your account.");
}

// Escape the values before displaying them in HTML.
$customerName = htmlspecialchars($details["customer_name"], ENT_QUOTES, "UTF-8");
$vehicleName = htmlspecialchars(
    $details["make"] . " " . $details["model"] . " (" . $details["year"] . ")",
    ENT_QUOTES,
    "UTF-8"
);
$salespersonName = htmlspecialchars($details["salesperson_name"], ENT_QUOTES, "UTF-8");
$reservationStatus = htmlspecialchars($details["reservation_status"], ENT_QUOTES, "UTF-8");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Set the page character encoding. -->
    <meta charset="UTF-8">

    <!-- Make the page responsive. -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the browser tab title. -->
    <title>Cancel Reservation | VSMS</title>

    <!-- Reuse the existing VSMS dashboard stylesheet. -->
    <link rel="stylesheet" href="assets/css/dashboard.css">

    <!-- Add simple styling for the cancellation confirmation page. -->
    <style>
        .confirmation-card {
            max-width: 650px;
            margin: 35px auto;
            padding: 30px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 18px rgba(0, 0, 0, 0.06);
        }

        .confirmation-card h1 {
            margin-bottom: 12px;
        }

        .confirmation-details {
            margin: 25px 0;
            padding: 18px;
            background: #f5f6f8;
            border-radius: 8px;
            line-height: 1.9;
        }

        .warning-message {
            margin: 20px 0;
            padding: 14px;
            background: #fff3e8;
            color: #a64b12;
            border-radius: 8px;
        }

        .success-message {
            margin: 20px 0;
            padding: 14px;
            background: #e8f7ed;
            color: #176b37;
            border-radius: 8px;
        }

        .error-message {
            margin: 20px 0;
            padding: 14px;
            background: #fdecec;
            color: #a12626;
            border-radius: 8px;
        }

        .confirmation-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 25px;
        }

        .cancel-button {
            padding: 11px 20px;
            border: none;
            border-radius: 7px;
            background: #d9534f;
            color: #ffffff;
            cursor: pointer;
            font-size: 14px;
        }

        .cancel-button:hover {
            background: #bd3935;
        }
    </style>
</head>

<body>

    <!-- Create the main VSMS page layout. -->
    <div class="dashboard-layout">

        <!-- Create the main content area. -->
        <main class="main-content">

            <!-- Display the page heading and confirmation information. -->
            <section class="page-content">

                <div class="confirmation-card">

                    <h1>Cancel Reservation</h1>

                    <p>Please review the reservation information before continuing.</p>

                    <!-- Display the reservation information. -->
                    <div class="confirmation-details">
                        <strong>Reservation ID:</strong>
                        <?= (int) $details["reservation_id"] ?>
                        <br>

                        <strong>Customer:</strong>
                        <?= $customerName ?>
                        <br>

                        <strong>Vehicle:</strong>
                        <?= $vehicleName ?>
                        <br>

                        <strong>Salesperson:</strong>
                        <?= $salespersonName ?>
                        <br>

                        <strong>Reservation Status:</strong>
                        <?= $reservationStatus ?>
                    </div>

                    <!-- Display a warning about the cancellation action. -->
                    <?php if ($details["reservation_status"] === "Active"): ?>

                        <div class="warning-message">
                            Cancelling this reservation will release the vehicle
                            back to Available status when the business rules allow it.
                        </div>

                    <?php endif; ?>

                    <!-- Display any success or error message. -->
                    <?php if ($message !== ""): ?>
                        <div class="<?= $messageType === "success" ? "success-message" : "error-message" ?>"
                             role="alert">
                            <?= htmlspecialchars($message, ENT_QUOTES, "UTF-8") ?>
                        </div>
                    <?php endif; ?>

                    <!-- Show the cancellation form only for active reservations. -->
                    <?php if ($details["reservation_status"] === "Active" && $messageType !== "success"): ?>

                        <form action="cancel_reservation.php" method="POST">

                            <!-- Send the reservation ID to the cancellation handler. -->
                            <input
                                type="hidden"
                                name="reservation_id"
                                value="<?= (int) $details["reservation_id"] ?>"
                            >

                            <!-- Protect the cancellation request with the session CSRF token. -->
                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, "UTF-8") ?>"
                            >

                            <div class="confirmation-actions">

                                <!-- Submit the cancellation request. -->
                                <button type="submit" class="cancel-button"
                                    onclick="return confirm('Are you sure you want to cancel this reservation?');">
                                    Confirm Cancellation
                                </button>

                                <!-- Return to the reservation details page. -->
                                <a href="reservation_details.php?id=<?= (int) $details["reservation_id"] ?>"
                                   class="secondary-button">
                                    Go Back
                                </a>

                            </div>

                        </form>

                    <?php else: ?>

                        <!-- Provide a return link when cancellation is not available. -->
                        <div class="confirmation-actions">
                            <a href="reservation_details.php?id=<?= (int) $details["reservation_id"] ?>"
                               class="secondary-button">
                                Return to Reservation Details
                            </a>
                        </div>

                    <?php endif; ?>

                </div>

            </section>

        </main>

    </div>

</body>
</html>
